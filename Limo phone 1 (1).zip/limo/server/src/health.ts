import { readFileSync } from 'node:fs'
import type { FastifyInstance } from 'fastify'
import type { ServerConfig } from './config.js'
import type { DB } from './db/database.js'
import { getProviderStates } from './db/providers.js'
import { keyAliasFor, type ProviderRegistry } from './providers/registry.js'
import type { Vault } from './vault/vault.js'

const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')) as {
  version: string
}

/**
 * Public health probe — powers the UI's boot state and the status bar.
 * Never leaks secret material; provider readiness is key-presence + last
 * recorded state only. Open mode (LIMO #8): no setup/login state exists.
 */
export function registerHealthRoute(
  app: FastifyInstance,
  ctx: { db: DB; config: ServerConfig; vault: Vault; registry: ProviderRegistry },
): void {
  const { db, vault, registry } = ctx
  app.get('/api/health', { config: { public: true } }, async () => {
    const errors = new Map(getProviderStates(db).map((p) => [p.id, p.last_error]))
    const providers = registry.list().map((a) => {
      const hasKey = a.needsKey ? vault.hasSecret(keyAliasFor(a.id)) : true
      return {
        id: a.id,
        label: a.label,
        needsKey: a.needsKey,
        configured: hasKey,
        lastError: errors.get(a.id) ?? null,
      }
    })
    return {
      ok: true,
      name: 'LIMO AGENT',
      version: pkg.version,
      auth: { mode: 'open' as const },
      vault: { state: vault.state },
      providers,
    }
  })
}
