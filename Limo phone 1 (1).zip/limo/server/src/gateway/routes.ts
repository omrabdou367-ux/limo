import { randomBytes } from 'node:crypto'
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify'
import type { ServerConfig } from '../config.js'
import type { DB } from '../db/database.js'
import { recordUsage } from '../db/usage.js'
import { authGuard } from '../auth/guard.js'
import { KEY_ALIASES, keyAliasFor, type ProviderRegistry } from '../providers/registry.js'
import { ProviderError, type StreamEvent, type Usage } from '../providers/types.js'
import type { Vault } from '../vault/vault.js'
import { listCatalogModels } from '../db/catalog.js'
import { resolveChain } from '../router/engine.js'
import type { CircuitBreaker } from '../router/breaker.js'
import { recordEgress, updateEgress } from '../db/egress.js'
import { pickAutoModel } from '../agent/autoselect.js'
import { openSse, startHeartbeat, writeSseData, writeSseDone } from './sse.js'
import type { Logger } from '../logger.js'

/**
 * The OpenAI-compatible gateway.
 *  - POST /v1/chat/completions  (stream:true -> SSE; stream:false -> JSON)
 *  - GET  /v1/models
 * Model ids are provider-prefixed: `openrouter/…`, `groq/…`, `ollama/…`.
 *
 * Phase 2 routing (PLAN §8.1.2): the attempt chain comes from the router
 * engine — active profile first, then SIMPLE_FALLBACK (phase-1 behaviour),
 * then the bare model. A per-provider circuit breaker gates every attempt:
 * local config errors (locked vault / missing key) never open a breaker;
 * real upstream failures do. /v1/models also merges the daily catalog's
 * FREE rows for providers that are not configured (or unreachable) right
 * now, so free-model discovery survives a locked vault.
 */

const chatSchema = {
  type: 'object',
  required: ['model', 'messages'],
  additionalProperties: false,
  properties: {
    model: { type: 'string', minLength: 3 },
    messages: {
      type: 'array',
      minItems: 1,
      items: {
        type: 'object',
        required: ['role', 'content'],
        additionalProperties: false,
        properties: {
          role: { type: 'string', enum: ['system', 'user', 'assistant'] },
          content: { type: 'string' },
        },
      },
    },
    stream: { type: 'boolean' },
    temperature: { type: 'number', minimum: 0, maximum: 2 },
    max_tokens: { type: 'integer', minimum: 1 },
  },
} as const

interface Body {
  model: string
  messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }>
  stream?: boolean
  temperature?: number
  max_tokens?: number
}

export function registerGatewayRoutes(
  app: FastifyInstance,
  ctx: { db: DB; config: ServerConfig; registry: ProviderRegistry; vault: Vault; log: Logger; breaker: CircuitBreaker },
): void {
  const { db, config, registry, vault, log, breaker } = ctx

  app.get('/v1/models', async () => {
    const data: Array<{ id: string; object: 'model'; owned_by: string; free?: boolean }> = []
    const errors: Array<{ provider: string; error: string }> = []
    const seen = new Set<string>()
    for (const adapter of registry.list()) {
      const hasKey = adapter.needsKey ? vault.hasSecret(keyAliasFor(adapter.id)) : true
      if (hasKey) {
        try {
          const models = await registry.listModels(adapter.id, config, db)
          for (const m of models) {
            const id = `${adapter.id}/${m.id}`
            seen.add(id)
            data.push({ id, object: 'model', owned_by: m.ownedBy, free: m.free })
          }
          continue
        } catch (e) {
          errors.push({ provider: adapter.id, error: e instanceof Error ? e.message : String(e) })
          // fall through to the catalog merge below — free discovery survives
        }
      }
      // unconfigured or failing keyed provider: expose the catalog's FREE rows
      // (chat attempts return a clear missing_key / vault_locked 409)
      for (const row of listCatalogModels(db)) {
        if (row.provider !== adapter.id || row.free !== 1) continue
        const id = `${adapter.id}/${row.model_id}`
        if (seen.has(id)) continue
        seen.add(id)
        data.push({ id, object: 'model', owned_by: row.owned_by ?? adapter.id, free: true })
      }
    }
    return { object: 'list', data, omnara: { errors } }
  })

  app.post(
    '/v1/chat/completions',
    { schema: { body: chatSchema } },
    async (request: FastifyRequest<{ Body: Body }>, reply: FastifyReply) => {
      const body = request.body
      const wantStream = body.stream === true
      // LIMO #21 — model 'auto': the gateway resolves it through the SAME real
      // routing the agent engine uses (usable models + owner prefs + reason)
      // so every surface (main chat, box, agent, forge) can ask for "auto".
      let requestedModel = body.model
      if (requestedModel === 'auto') {
        const pick = await pickAutoModel(db, registry, vault, config, 'planner')
        if (!pick) {
          return reply.code(409).send({
            error: { message: 'auto: لا نموذج قابل للاستخدام الآن — أدخل مفتاح مزود في الخزنة أو شغّل مزودًا محليًا', type: 'no_model', code: 409 },
          })
        }
        requestedModel = pick.model
      }
      // phase 2: the router engine owns the attempt chain (profile → simple → bare)
      const { chain: attempts, source, profileName } = resolveChain(db, config, requestedModel)
      const started = Date.now()
      let lastError: ProviderError | null = null

      for (let i = 0; i < attempts.length; i++) {
        const attempt = attempts[i]!

        let providerId: string
        let modelId: string
        try {
          const resolved = registry.resolveModel(attempt)
          providerId = resolved.providerId
          modelId = resolved.modelId
        } catch (e) {
          lastError = e instanceof ProviderError ? e : new ProviderError('provider_error', String(e))
          // the ledger keeps one row per REQUEST — even one that never reached
          // an upstream (typo'd provider/model) — so the board stays honest
          recordUsage(db, {
            provider: attempt.slice(0, attempt.indexOf('/')) || attempt,
            model: attempt,
            ok: false,
            durationMs: 0,
            errorKind: lastError.kind,
          })
          continue
        }
        const adapter = registry.get(providerId)!

        if (adapter.needsKey) {
          if (!vault.isUnlocked) {
            recordUsage(db, { provider: providerId, model: modelId, ok: false, durationMs: 0, errorKind: 'vault_locked' })
            lastError = new ProviderError(
              'vault_locked',
              'الخزنة مقفلة بعد إعادة التشغيل — افتحها من الواجهة ثم أعد المحاولة',
              409,
            )
            continue
          }
          if (!vault.hasSecret(keyAliasFor(providerId))) {
            recordUsage(db, { provider: providerId, model: modelId, ok: false, durationMs: 0, errorKind: 'missing_key' })
            lastError = new ProviderError('missing_key', `${providerId}: لا يوجد مفتاح مضبوط — أضفه من لوحة الخزنة`, 409)
            continue
          }
        }

        // circuit breaker gates every real upstream attempt
        if (!breaker.canAttempt(providerId)) {
          recordUsage(db, { provider: providerId, model: modelId, ok: false, durationMs: 0, errorKind: 'breaker_open' })
          lastError = new ProviderError(
            'breaker_open',
            `${providerId}: قاطع الدارة مفتوح بعد إخفاقات متتالية — جرّب لاحقًا أو صفّره من لوحة التوجيه`,
            503,
          )
          continue
        }

        const controller = new AbortController()
        // Client-disconnect detection: ServerResponse 'close' fires both on
        // disconnect AND after normal finish — the writableEnded guard tells
        // them apart. `clientGone` (not signal.aborted) is what the fallback
        // logic consults, so our own cleanups may abort freely.
        let clientGone = false
        let egressId: number | null = null
        const onClose = () => {
          if (!reply.raw.writableEnded) {
            clientGone = true
            controller.abort()
          }
        }
        reply.raw.on('close', onClose)

        try {
          // v2.2 #7 «ما غادر الجهاز»: fingerprint the dispatched payload (size +
          // sha256) BEFORE the call — content itself is never stored.
          const egressPayload = JSON.stringify({
            model: modelId,
            messages: body.messages,
            temperature: body.temperature ?? null,
            max_tokens: body.max_tokens ?? null,
          })
          egressId = recordEgress(db, { source: 'gateway', provider: providerId, model: attempt, payload: egressPayload, config })
          const events = adapter.streamChat({
            modelId,
            messages: body.messages,
            temperature: body.temperature,
            maxTokens: body.max_tokens,
            signal: controller.signal,
          })

          if (wantStream) {
            await runStreamed({ reply, events, model: attempt, providerId, controller, onClose, db, started })
          } else {
            await runAggregated({ reply, events, model: attempt, providerId, controller, onClose, db, started })
          }
          updateEgress(db, egressId!, true)
          breaker.recordSuccess(providerId)
          return
        } catch (e) {
          reply.raw.removeListener('close', onClose)
          if (clientGone) return // client went away — nothing to send
          const pe = e instanceof ProviderError ? e : new ProviderError('provider_error', e instanceof Error ? e.message : String(e))
          updateEgress(db, egressId!, false, pe.kind)
          breaker.recordFailure(providerId, pe.message)
          recordUsage(db, { provider: providerId, model: modelId, ok: false, durationMs: Date.now() - started, errorKind: pe.kind })
          log.warn('gateway: provider attempt failed', {
            provider: providerId,
            kind: pe.kind,
            attempt: i + 1,
            of: attempts.length,
            router: source,
            profile: profileName,
          })
          lastError = pe
          if (i < attempts.length - 1) continue
          throw pe
        }
      }

      throw lastError ?? new ProviderError('provider_error', 'no provider available')
    },
  )
}

function chunk(id: string, created: number, model: string, delta: Record<string, unknown>, finishReason: string | null) {
  return { id, object: 'chat.completion.chunk', created, model, choices: [{ index: 0, delta, finish_reason: finishReason }] }
}

/**
 * Streamed relay. The FIRST event is pulled before SSE opens, so a failing
 * attempt (bad key, unreachable) can still fall through to the next model
 * without ever having committed a content-type to the client.
 */
async function runStreamed(args: {
  reply: FastifyReply
  events: AsyncGenerator<StreamEvent>
  model: string
  providerId: string
  controller: AbortController
  onClose: () => void
  db: DB
  started: number
}): Promise<void> {
  const { reply, events, model, providerId, controller, onClose, db, started } = args
  const iterator = events[Symbol.asyncIterator]()
  let opened = false
  const heartbeat: { t?: NodeJS.Timeout } = {}
  let finish = 'stop'
  let usage: Usage | undefined
  try {
    let current = await iterator.next() // may throw BEFORE open -> caller falls back
    openSse(reply)
    opened = true
    heartbeat.t = startHeartbeat(reply)
    const id = `chatcmpl-${randomBytes(8).toString('hex')}`
    const created = Math.floor(Date.now() / 1000)
    writeSseData(reply, chunk(id, created, model, { role: 'assistant' }, null))
    while (!current.done) {
      if (reply.raw.writableEnded || controller.signal.aborted) break
      const evt = current.value
      if (evt.type === 'delta') {
        writeSseData(reply, chunk(id, created, model, { content: evt.content }, null))
      } else if (evt.type === 'finish') {
        finish = evt.reason
      } else if (evt.type === 'usage') {
        usage = evt.usage
      }
      current = await iterator.next()
    }
    writeSseData(reply, chunk(id, created, model, {}, finish))
    if (usage) {
      writeSseData(reply, {
        id,
        object: 'chat.completion.chunk',
        created,
        model,
        choices: [],
        usage: {
          prompt_tokens: usage.promptTokens ?? null,
          completion_tokens: usage.completionTokens ?? null,
          total_tokens: (usage.promptTokens ?? 0) + (usage.completionTokens ?? 0),
        },
      })
    }
    recordUsage(db, {
      provider: providerId,
      model,
      ok: true,
      promptTokens: usage?.promptTokens ?? null,
      completionTokens: usage?.completionTokens ?? null,
      durationMs: Date.now() - started,
    })
  } catch (e) {
    if (!opened) throw e // pre-stream failure: caller may fall back to the next model
    const msg = e instanceof Error ? e.message : String(e)
    writeSseData(reply, { error: { message: msg, type: 'provider_error' } })
    recordUsage(db, { provider: providerId, model, ok: false, durationMs: Date.now() - started, errorKind: 'provider_error' })
  } finally {
    if (heartbeat.t) clearInterval(heartbeat.t)
    reply.raw.removeListener('close', onClose)
    controller.abort() // release upstream if we exited early
    if (opened && !reply.raw.writableEnded) writeSseDone(reply)
    await iterator.return?.(undefined).catch(() => undefined)
  }
}

/** Non-stream: consume everything, send one chat.completion object. */
async function runAggregated(args: {
  reply: FastifyReply
  events: AsyncGenerator<StreamEvent>
  model: string
  providerId: string
  controller: AbortController
  onClose: () => void
  db: DB
  started: number
}): Promise<void> {
  const { reply, events, model, providerId, controller, onClose, db, started } = args
  const id = `chatcmpl-${randomBytes(8).toString('hex')}`
  const created = Math.floor(Date.now() / 1000)
  let content = ''
  let finish = 'stop'
  let usage: Usage | undefined
  // for-await closes the generator on early exit; errors propagate to the
  // caller (which may fall back) — the caller removes the close listener.
  for await (const evt of events) {
    if (evt.type === 'delta') content += evt.content
    else if (evt.type === 'finish') finish = evt.reason
    else if (evt.type === 'usage') usage = evt.usage
  }
  reply.raw.removeListener('close', onClose)
  controller.abort()
  recordUsage(db, {
    provider: providerId,
    model,
    ok: true,
    promptTokens: usage?.promptTokens ?? null,
    completionTokens: usage?.completionTokens ?? null,
    durationMs: Date.now() - started,
  })
  reply.send({
    id,
    object: 'chat.completion',
    created,
    model,
    choices: [{ index: 0, message: { role: 'assistant', content }, finish_reason: finish }],
    usage: usage
      ? {
          prompt_tokens: usage.promptTokens ?? null,
          completion_tokens: usage.completionTokens ?? null,
          total_tokens: (usage.promptTokens ?? 0) + (usage.completionTokens ?? 0),
        }
      : undefined,
  })
}
