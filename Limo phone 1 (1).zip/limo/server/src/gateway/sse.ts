import type { FastifyReply } from 'fastify'

/** SSE plumbing for the /v1 gateway — raw socket writes, heartbeats, flush. */

export function openSse(reply: FastifyReply): void {
  reply.hijack()
  const raw = reply.raw
  raw.writeHead(200, {
    'content-type': 'text/event-stream; charset=utf-8',
    'cache-control': 'no-cache, no-transform',
    connection: 'keep-alive',
    'x-accel-buffering': 'no', // proxies: do not buffer
  })
  raw.write(': stream open\n\n')
}

export function writeSseData(reply: FastifyReply, payload: unknown): void {
  reply.raw.write(`data: ${JSON.stringify(payload)}\n\n`)
}

export function writeSseDone(reply: FastifyReply): void {
  reply.raw.write('data: [DONE]\n\n')
  reply.raw.end()
}

export function startHeartbeat(reply: FastifyReply, intervalMs = 15_000): NodeJS.Timeout {
  const t = setInterval(() => {
    if (reply.raw.writableEnded) {
      clearInterval(t)
      return
    }
    reply.raw.write(': ping\n\n')
  }, intervalMs)
  t.unref?.()
  return t
}
