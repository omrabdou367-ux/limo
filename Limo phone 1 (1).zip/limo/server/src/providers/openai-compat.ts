import { ProviderError, type FetchLike, type ModelInfo, type ProviderAdapter, type StreamEvent } from './types.js'

/**
 * Base adapter for every OpenAI-compatible provider (OpenRouter, Groq, and
 * later any "Custom Provider" — phase 2). Streams upstream SSE and yields
 * normalized events; nothing is cached here (the registry owns caching).
 */
export function makeOpenAICompatAdapter(opts: {
  id: string
  label: string
  baseUrl: string
  needsKey: boolean
  getKey: () => string | null
  extraHeaders?: Record<string, string>
  fetchImpl?: FetchLike
  isFreeModel?: (id: string) => boolean
}): ProviderAdapter {
  const doFetch: FetchLike = opts.fetchImpl ?? ((u, i) => fetch(u, i))
  const headers = (): Record<string, string> => {
    const h: Record<string, string> = {
      'content-type': 'application/json',
      ...opts.extraHeaders,
    }
    const key = opts.getKey()
    if (opts.needsKey) {
      if (!key) throw new ProviderError('invalid_key', `${opts.id}: missing API key`, 409)
      h.authorization = `Bearer ${key}`
    }
    return h
  }

  async function listModels(signal?: AbortSignal): Promise<ModelInfo[]> {
    let res: Response
    const h = headers() // throws invalid_key BEFORE any network attempt
    try {
      res = await doFetch(`${opts.baseUrl}/models`, { headers: h, signal })
    } catch (e) {
      if (e instanceof ProviderError) throw e
      throw unreachable(e)
    }
    if (!res.ok) throw await mapHttpError(res, opts.id)
    const body = (await res.json()) as { data?: Array<{ id: string; context_length?: number; owned_by?: string }> }
    return (body.data ?? []).map((m) => ({
      id: m.id,
      ownedBy: m.owned_by ?? opts.id,
      contextLength: m.context_length,
      free: opts.isFreeModel?.(m.id),
    }))
  }

  async function* streamChat(params: {
    modelId: string
    messages: { role: string; content: string }[]
    temperature?: number
    maxTokens?: number
    signal: AbortSignal
  }): AsyncGenerator<StreamEvent> {
    const body: Record<string, unknown> = {
      model: params.modelId,
      messages: params.messages,
      stream: true,
    }
    if (params.temperature !== undefined) body.temperature = params.temperature
    if (params.maxTokens !== undefined) body.max_tokens = params.maxTokens
    const h = headers() // throws invalid_key BEFORE any network attempt

    let res: Response
    try {
      res = await doFetch(`${opts.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: h,
        body: JSON.stringify(body),
        signal: params.signal,
      })
    } catch (e) {
      if (e instanceof ProviderError) throw e
      throw unreachable(e)
    }
    if (!res.ok) throw await mapHttpError(res, opts.id)
    if (!res.body) throw new ProviderError('provider_error', `${opts.id}: empty stream body`)

    yield* parseSseStream(res.body, opts.id)
  }

  return { id: opts.id, label: opts.label, needsKey: opts.needsKey, listModels, streamChat }
}

/** Parse an OpenAI-style SSE body into normalized events. */
export async function* parseSseStream(
  body: AsyncIterable<Uint8Array>,
  provider: string,
): AsyncGenerator<StreamEvent> {
  const decoder = new TextDecoder()
  let buffer = ''
  for await (const chunk of body) {
    buffer += decoder.decode(chunk, { stream: true })
    let nl: number
    while ((nl = buffer.indexOf('\n')) >= 0) {
      const line = buffer.slice(0, nl).trimEnd()
      buffer = buffer.slice(nl + 1)
      if (!line.startsWith('data:')) continue
      const data = line.slice(5).trim()
      if (data === '[DONE]') return
      let evt: {
        choices?: Array<{ delta?: { content?: string }; finish_reason?: string | null }>
        usage?: { prompt_tokens?: number; completion_tokens?: number }
        error?: { message?: string }
      }
      try {
        evt = JSON.parse(data)
      } catch {
        continue // tolerate keep-alive noise
      }
      if (evt.error) throw new ProviderError('provider_error', `${provider}: ${evt.error.message ?? 'upstream error'}`)
      const delta = evt.choices?.[0]?.delta?.content
      if (typeof delta === 'string' && delta.length > 0) yield { type: 'delta', content: delta }
      const finish = evt.choices?.[0]?.finish_reason
      if (finish) yield { type: 'finish', reason: finish }
      if (evt.usage) {
        yield {
          type: 'usage',
          usage: { promptTokens: evt.usage.prompt_tokens, completionTokens: evt.usage.completion_tokens },
        }
      }
    }
  }
}

async function mapHttpError(res: Response, provider: string): Promise<ProviderError> {
  const text = await res.text().catch(() => '')
  let detail = text.slice(0, 300)
  try {
    const j = JSON.parse(text) as { error?: { message?: string } }
    if (j.error?.message) detail = j.error.message
  } catch {
    /* keep raw */
  }
  if (res.status === 401 || res.status === 403) {
    return new ProviderError('invalid_key', `${provider}: rejected the API key — ${detail}`, 401)
  }
  if (res.status === 404) {
    return new ProviderError('model_not_found', `${provider}: model not found — ${detail}`, 404)
  }
  if (res.status === 429) {
    const ra = Number(res.headers.get('retry-after'))
    return new ProviderError(
      'rate_limited',
      `${provider}: rate limit / free quota exhausted — ${detail}`,
      429,
      Number.isFinite(ra) && ra > 0 ? ra : undefined,
    )
  }
  if (res.status >= 500) {
    return new ProviderError('provider_error', `${provider}: upstream error ${res.status} — ${detail}`, 502)
  }
  return new ProviderError('provider_error', `${provider}: HTTP ${res.status} — ${detail}`, 400)
}

function unreachable(e: unknown): ProviderError {
  const msg = e instanceof Error ? e.message : String(e)
  return new ProviderError('provider_unreachable', `connection failed — ${msg}`, 503)
}
