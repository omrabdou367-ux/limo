import { ProviderError, type FetchLike, type ModelInfo, type ProviderAdapter, type StreamEvent } from './types.js'

/**
 * Ollama — NATIVE endpoints (locked in plan v1): /api/tags for models and
 * /api/chat for streaming chat (NDJSON, not SSE). Normalized to the same
 * StreamEvent shape as every other adapter. Keyless by design.
 */
export function makeOllamaAdapter(opts: {
  rootUrl: string
  fetchImpl?: FetchLike
}): ProviderAdapter {
  const doFetch: FetchLike = opts.fetchImpl ?? ((u, i) => fetch(u, i))
  const root = opts.rootUrl.replace(/\/+$/, '')

  async function listModels(signal?: AbortSignal): Promise<ModelInfo[]> {
    let res: Response
    try {
      res = await doFetch(`${root}/api/tags`, { signal })
    } catch (e) {
      throw unreachable(e)
    }
    if (!res.ok) throw await mapError(res)
    const body = (await res.json()) as {
      models?: Array<{ name: string; details?: { parameter_size?: string } }>
    }
    return (body.models ?? []).map((m) => ({
      id: m.name,
      ownedBy: 'ollama',
      free: true,
    }))
  }

  async function* streamChat(params: {
    modelId: string
    messages: { role: string; content: string }[]
    temperature?: number
    maxTokens?: number
    signal: AbortSignal
  }): AsyncGenerator<StreamEvent> {
    const options: Record<string, unknown> = {}
    if (params.temperature !== undefined) options.temperature = params.temperature
    if (params.maxTokens !== undefined) options.num_predict = params.maxTokens

    let res: Response
    try {
      res = await doFetch(`${root}/api/chat`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          model: params.modelId,
          messages: params.messages,
          stream: true,
          options,
        }),
        signal: params.signal,
      })
    } catch (e) {
      throw unreachable(e)
    }
    if (!res.ok) throw await mapError(res)
    if (!res.body) throw new ProviderError('provider_error', 'ollama: empty stream body')

    // NDJSON: one JSON object per line, `done:true` terminates
    const decoder = new TextDecoder()
    let buffer = ''
    for await (const chunk of res.body) {
      buffer += decoder.decode(chunk, { stream: true })
      let nl: number
      while ((nl = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, nl).trim()
        buffer = buffer.slice(nl + 1)
        if (!line) continue
        let evt: {
          message?: { content?: string }
          done?: boolean
          error?: string
          prompt_eval_count?: number
          eval_count?: number
        }
        try {
          evt = JSON.parse(line)
        } catch {
          continue
        }
        if (evt.error) throw new ProviderError('provider_error', `ollama: ${evt.error}`, 502)
        const content = evt.message?.content
        if (typeof content === 'string' && content.length > 0) yield { type: 'delta', content }
        if (evt.done) {
          if (evt.prompt_eval_count !== undefined || evt.eval_count !== undefined) {
            yield {
              type: 'usage',
              usage: { promptTokens: evt.prompt_eval_count, completionTokens: evt.eval_count },
            }
          }
          yield { type: 'finish', reason: 'stop' }
          return
        }
      }
    }
  }

  return { id: 'ollama', label: 'Ollama', needsKey: false, listModels, streamChat }
}

async function mapError(res: Response): Promise<ProviderError> {
  const text = await res.text().catch(() => '')
  let detail = text.slice(0, 300)
  try {
    const j = JSON.parse(text) as { error?: string }
    if (j.error) detail = j.error
  } catch {
    /* raw */
  }
  if (res.status === 404) return new ProviderError('model_not_found', `ollama: model not found — ${detail}`, 404)
  if (res.status >= 500) return new ProviderError('provider_error', `ollama: HTTP ${res.status} — ${detail}`, 502)
  return new ProviderError('provider_error', `ollama: HTTP ${res.status} — ${detail}`, 400)
}

function unreachable(e: unknown): ProviderError {
  const msg = e instanceof Error ? e.message : String(e)
  return new ProviderError('provider_unreachable', `Ollama غير متصل — ${msg}`, 503)
}
