import type { DB } from '../db/database.js'
import type { Vault } from '../vault/vault.js'
import type { FetchLike } from './types.js'
import { keyAliasFor, type ProviderRegistry } from './registry.js'
import { makeOpenAICompatAdapter } from './openai-compat.js'
import { listCustomProviders, type CustomProvider } from '../db/custom_providers.js'

/**
 * Custom providers (PLAN.md §8.1.5): any user-added OpenAI-compatible
 * endpoint becomes a first-class adapter — LM Studio, llama.cpp server,
 * vLLM, or any documented /v1 provider — with zero bespoke code.
 *
 * The vault alias follows the universal convention '<id>:default'.
 */

export function makeCustomProviderAdapter(
  row: CustomProvider,
  getKey: () => string | null,
  fetchImpl?: FetchLike,
) {
  return makeOpenAICompatAdapter({
    id: row.id,
    label: row.label,
    baseUrl: row.baseUrl.replace(/\/+$/, ''),
    needsKey: row.needsKey,
    getKey,
    fetchImpl,
  })
}

/** Register every enabled custom provider (boot + after CRUD). */
export function syncCustomProviders(
  registry: ProviderRegistry,
  db: DB,
  vault: Vault,
  fetchImpl?: FetchLike,
): void {
  for (const row of listCustomProviders(db)) {
    registry.unregister(row.id)
    if (!row.enabled) continue
    registry.register(
      makeCustomProviderAdapter(row, () => vault.getSecret(keyAliasFor(row.id)), fetchImpl),
    )
  }
}
