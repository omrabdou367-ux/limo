import { makeOpenAICompatAdapter } from './openai-compat.js'
import type { FetchLike, ProviderAdapter } from './types.js'

/** OpenRouter — free models carry the `:free` suffix. */
export function makeOpenRouterAdapter(opts: {
  baseUrl: string
  getKey: () => string | null
  fetchImpl?: FetchLike
}): ProviderAdapter {
  return makeOpenAICompatAdapter({
    id: 'openrouter',
    label: 'OpenRouter',
    baseUrl: opts.baseUrl,
    needsKey: true,
    getKey: opts.getKey,
    fetchImpl: opts.fetchImpl,
    extraHeaders: { 'X-Title': 'Omnara' },
    isFreeModel: (id) => id.endsWith(':free'),
  })
}
