import { makeOpenAICompatAdapter } from './openai-compat.js'
import type { FetchLike, ProviderAdapter } from './types.js'

/** Groq — OpenAI-compatible, fastest first token, documented free tier. */
export function makeGroqAdapter(opts: {
  baseUrl: string
  getKey: () => string | null
  fetchImpl?: FetchLike
}): ProviderAdapter {
  return makeOpenAICompatAdapter({
    id: 'groq',
    label: 'Groq',
    baseUrl: opts.baseUrl,
    needsKey: true,
    getKey: opts.getKey,
    fetchImpl: opts.fetchImpl,
  })
}
