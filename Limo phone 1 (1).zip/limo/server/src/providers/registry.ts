import type { ServerConfig } from '../config.js'
import type { DB } from '../db/database.js'
import { markProviderError, markProviderOk } from '../db/providers.js'
import type { Vault } from '../vault/vault.js'
import { makeGroqAdapter } from './groq.js'
import { makeOllamaAdapter } from './ollama.js'
import { makeOpenRouterAdapter } from './openrouter.js'
import { ProviderError, type FetchLike, type ModelInfo, type ProviderAdapter } from './types.js'

export interface ResolvedModel {
  providerId: string
  modelId: string
}

export class ProviderRegistry {
  private adapters = new Map<string, ProviderAdapter>()
  private modelsCache = new Map<string, { at: number; models: ModelInfo[] }>()

  register(adapter: ProviderAdapter): void {
    this.adapters.set(adapter.id, adapter)
    this.modelsCache.delete(adapter.id)
  }

  /** Remove a provider (custom-provider deletion) — cache goes with it. */
  unregister(id: string): boolean {
    this.modelsCache.delete(id)
    return this.adapters.delete(id)
  }

  get(id: string): ProviderAdapter | undefined {
    return this.adapters.get(id)
  }

  list(): ProviderAdapter[] {
    return [...this.adapters.values()]
  }

  /** 'groq/llama-3.3-70b-versatile' -> { providerId: 'groq', modelId: '…' } */
  resolveModel(prefixedId: string): ResolvedModel {
    const slash = prefixedId.indexOf('/')
    if (slash <= 0) {
      throw new ProviderError(
        'model_not_found',
        `معرّف النموذج يجب أن يبدأ باسم المزود، مثل groq/llama-3.3-70b-versatile — وصل: ${prefixedId}`,
        404,
      )
    }
    const providerId = prefixedId.slice(0, slash)
    const modelId = prefixedId.slice(slash + 1)
    if (!this.adapters.has(providerId)) {
      throw new ProviderError('model_not_found', `مزود غير معروف: ${providerId}`, 404)
    }
    return { providerId, modelId }
  }

  /** Live model list with per-provider cache (PLAN.md §4.2 — nothing hardcoded). */
  async listModels(
    providerId: string,
    cfg: ServerConfig,
    db: DB,
    signal?: AbortSignal,
  ): Promise<ModelInfo[]> {
    const cached = this.modelsCache.get(providerId)
    if (cached && Date.now() - cached.at < cfg.modelsCacheTtlMs) return cached.models
    const adapter = this.adapters.get(providerId)
    if (!adapter) return []
    try {
      const models = await adapter.listModels(signal)
      this.modelsCache.set(providerId, { at: Date.now(), models })
      markProviderOk(db, providerId)
      return models
    } catch (e) {
      markProviderError(db, providerId, e instanceof Error ? e.message : String(e))
      throw e
    }
  }

  invalidateCache(providerId?: string): void {
    if (providerId) this.modelsCache.delete(providerId)
    else this.modelsCache.clear()
  }
}

export const KEY_ALIASES: Record<string, string> = {
  openrouter: 'openrouter:default',
  groq: 'groq:default',
}

/** Vault alias convention for any provider: explicit map or '<id>:default'. */
export function keyAliasFor(providerId: string): string {
  return KEY_ALIASES[providerId] ?? `${providerId}:default`
}

export function buildDefaultRegistry(opts: {
  config: ServerConfig
  vault: Vault
  fetchImpl?: FetchLike
}): ProviderRegistry {
  const { config, vault } = opts
  const registry = new ProviderRegistry()

  registry.register(
    makeOpenRouterAdapter({
      baseUrl: config.openrouterBaseUrl,
      getKey: () => vault.getSecret(keyAliasFor('openrouter')),
      fetchImpl: opts.fetchImpl,
    }),
  )
  registry.register(
    makeGroqAdapter({
      baseUrl: config.groqBaseUrl,
      getKey: () => vault.getSecret(keyAliasFor('groq')),
      fetchImpl: opts.fetchImpl,
    }),
  )
  registry.register(makeOllamaAdapter({ rootUrl: config.ollamaBaseUrl, fetchImpl: opts.fetchImpl }))

  return registry
}
