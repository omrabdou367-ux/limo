/** Provider layer — one interface over every upstream (PLAN.md §4.2). */

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant'
  content: string
}

export interface ModelInfo {
  id: string
  ownedBy: string
  free?: boolean
  contextLength?: number
}

export interface Usage {
  promptTokens?: number
  completionTokens?: number
}

export type StreamEvent =
  | { type: 'delta'; content: string }
  | { type: 'finish'; reason: 'stop' | 'length' | 'content_filter' | string }
  | { type: 'usage'; usage: Usage }

export type ProviderErrorKind =
  | 'invalid_key'
  | 'vault_locked'
  | 'missing_key'
  | 'rate_limited'
  | 'quota_exceeded'
  | 'model_not_found'
  | 'provider_unreachable'
  | 'breaker_open'
  | 'provider_error'

export class ProviderError extends Error {
  constructor(
    public readonly kind: ProviderErrorKind,
    message: string,
    public readonly status = 502,
    public readonly retryAfterSec?: number,
  ) {
    super(message)
    this.name = 'ProviderError'
  }
  /** Fastify & the error handler look for statusCode. */
  get statusCode(): number {
    return this.status
  }
}

export type FetchLike = (url: string, init?: RequestInit) => Promise<Response>

export interface ProviderAdapter {
  id: string
  needsKey: boolean
  /** Human name for UI grouping. */
  label: string
  listModels(signal?: AbortSignal): Promise<ModelInfo[]>
  /**
   * Always streams internally; the gateway either relays (stream) or
   * aggregates (non-stream). Providers never see `stream` — one code path.
   */
  streamChat(params: {
    modelId: string
    messages: ChatMessage[]
    temperature?: number
    maxTokens?: number
    signal: AbortSignal
  }): AsyncGenerator<StreamEvent>
}
