import { randomBytes } from 'node:crypto'
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'

/**
 * Project workspaces — LIMO's sandboxed FS roots (HYPERBRAIN "build" mode,
 * App Genesis, Library). Every agent FS tool is jailed inside
 * `<dataDir>/projects/<id>`; the UI reads through the same store.
 *
 * Rules (owner security doctrine):
 *  - paths are ALWAYS validated against traversal (`..`, absolute, null bytes)
 *  - reads capped at 256KB, writes capped at 256KB, text only
 *  - deletions of project FILES are a `deletion` risk (approval gate)
 *  - deleting a project removes its row AND its directory (user-initiated)
 */

export interface ProjectRow {
  id: string
  name: string
  description: string
  kind: string
  status: string
  created_at: string
  updated_at: string
}

export interface ProjectFileEntry {
  path: string
  size: number
  dir: boolean
}

const MAX_READ_BYTES = 256 * 1024
const MAX_WRITE_BYTES = 256 * 1024
const MAX_LIST_ENTRIES = 1000
const SKIP_DIRS = new Set(['node_modules', '.git', '.next', 'dist', 'build', '__pycache__', '.venv'])

export function projectsRoot(config: ServerConfig): string {
  return resolve(config.dataDir, 'projects')
}

export function projectDir(config: ServerConfig, id: string): string {
  // id is validated by callers (DB row exists + charset) — belt & suspenders:
  if (!/^[a-f0-9]{8,12}$/.test(id)) throw new Error('معرّف مشروع غير صالح')
  return join(projectsRoot(config), id)
}

export function createProject(
  db: DB,
  config: ServerConfig,
  input: { name: string; description?: string; kind?: string },
): ProjectRow {
  const id = randomBytes(5).toString('hex') // 10 hex chars
  const now = new Date().toISOString()
  const dir = projectDir(config, id)
  mkdirSync(dir, { recursive: true })
  db.prepare('INSERT INTO projects (id, name, description, kind, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
    id,
    input.name,
    input.description ?? '',
    input.kind ?? 'general',
    'active',
    now,
    now,
  )
  return getProject(db, id)!
}

export function listProjects(db: DB): ProjectRow[] {
  return db.prepare('SELECT * FROM projects ORDER BY updated_at DESC').all() as ProjectRow[]
}

export function getProject(db: DB, id: string): ProjectRow | undefined {
  return db.prepare('SELECT * FROM projects WHERE id = ?').get(id) as ProjectRow | undefined
}

export function touchProject(db: DB, id: string): void {
  db.prepare('UPDATE projects SET updated_at = ? WHERE id = ?').run(new Date().toISOString(), id)
}

export function updateProject(db: DB, id: string, patch: { name?: string; description?: string; kind?: string; status?: string }): ProjectRow | undefined {
  const cur = getProject(db, id)
  if (!cur) return undefined
  db.prepare('UPDATE projects SET name = ?, description = ?, kind = ?, status = ?, updated_at = ? WHERE id = ?').run(
    patch.name ?? cur.name,
    patch.description ?? cur.description,
    patch.kind ?? cur.kind,
    patch.status ?? cur.status,
    new Date().toISOString(),
    id,
  )
  return getProject(db, id)
}

export function deleteProject(db: DB, config: ServerConfig, id: string): boolean {
  const cur = getProject(db, id)
  if (!cur) return false
  db.prepare('DELETE FROM projects WHERE id = ?').run(id) // tasks reference it with ON DELETE SET NULL
  const dir = projectDir(config, id)
  if (existsSync(dir)) rmSync(dir, { recursive: true, force: true })
  return true
}

/** Resolve a relative path INSIDE the project dir, or null when it escapes. */
export function safeProjectPath(config: ServerConfig, id: string, rel: string): string | null {
  if (typeof rel !== 'string' || rel.length === 0 || rel.length > 512) return null
  if (rel.includes('\0')) return null
  const root = projectDir(config, id)
  const abs = resolve(root, rel)
  if (abs !== root && !abs.startsWith(root + '/')) return null // escaped the jail
  return abs
}

export function listProjectFiles(config: ServerConfig, id: string): ProjectFileEntry[] {
  const root = projectDir(config, id)
  if (!existsSync(root)) return []
  const out: ProjectFileEntry[] = []
  const walk = (dir: string, prefix: string, depth: number): void => {
    if (out.length >= MAX_LIST_ENTRIES || depth > 10) return
    let entries: Array<{ name: string; isDirectory: () => boolean }>
    try {
      entries = readdirSync(dir, { withFileTypes: true }).map((e) => ({ name: e.name, isDirectory: () => e.isDirectory() }))
    } catch {
      return
    }
    for (const e of entries.sort((a, b) => a.name.localeCompare(b.name))) {
      if (out.length >= MAX_LIST_ENTRIES) return
      if (e.name === '.git') continue
      const full = join(dir, e.name)
      const rel = prefix ? `${prefix}/${e.name}` : e.name
      let st
      try {
        st = statSync(full)
      } catch {
        continue
      }
      if (st.isDirectory()) {
        if (SKIP_DIRS.has(e.name)) continue
        out.push({ path: rel, size: 0, dir: true })
        walk(full, rel, depth + 1)
      } else {
        out.push({ path: rel, size: st.size, dir: false })
      }
    }
  }
  walk(root, '', 0)
  return out
}

export function readProjectFile(config: ServerConfig, id: string, rel: string): { path: string; size: number; content: string } | null {
  const abs = safeProjectPath(config, id, rel)
  if (!abs || !existsSync(abs)) return null
  const st = statSync(abs)
  if (!st.isFile() || st.size > MAX_READ_BYTES) return null
  return { path: rel, size: st.size, content: readFileSync(abs, 'utf8') }
}

export function writeProjectFile(config: ServerConfig, id: string, rel: string, content: string): { path: string; bytes: number } {
  if (typeof content !== 'string' || content.length > MAX_WRITE_BYTES) throw new Error('المحتوى يتجاوز الحد (256KB)')
  const abs = safeProjectPath(config, id, rel)
  if (!abs) throw new Error('مسار خارج حدود المشروع')
  mkdirSync(join(abs, '..'), { recursive: true })
  writeFileSync(abs, content, 'utf8')
  return { path: rel, bytes: Buffer.byteLength(content, 'utf8') }
}

export function deleteProjectFile(config: ServerConfig, id: string, rel: string): boolean {
  const abs = safeProjectPath(config, id, rel)
  if (!abs || !existsSync(abs)) return false
  rmSync(abs, { recursive: true, force: true })
  return true
}

/** Preview MIME map (served with a sandboxing CSP — see routes/projects.ts). */
export const PREVIEW_MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/plain; charset=utf-8',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
}
