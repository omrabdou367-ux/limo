import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import type { Logger } from '../logger.js'
import type { ChatMessage } from '../providers/types.js'
import { affectedFilesFor, latestInventory, persistInventory, scanRepository, type ArchitectureMap } from './scanner.js'
import { applyPatch, commitInSandbox, createSandbox, destroySandbox, guardedRun, mergeToCurrent, revertCommit, sandboxDiff, sandboxExists } from './sandbox.js'
import { reviewDiff, type SecurityReview } from './security.js'
import { extractJson, buildModelFn } from '../agent/model.js'
import { FORGE_SYSTEM_PROMPT, assessFiles, gateForLevel, type AutonomyLevel, type ForgePlanJson, type ForgeStatus } from './types.js'

/**
 * The Reality Forge orchestrator (RF spec §5): one natural-language request
 * about OMNARA ITSELF becomes a controlled engineering run —
 *
 *   architect (scan + affected files + risk)
 *   → engineer (plan + patch, in an isolated worktree at L2+)
 *   → qa (allowlisted tests inside the sandbox at L3+)
 *   → security auditor (static diff review — always)
 *   → the human gate (approval) → merge (apply) — and rollback is a NEW
 *   revert commit: the audit trail is append-only.
 *
 * The run is resumable: every phase persists its result on the change row;
 * re-invoking continues from the last non-terminal status.
 */

export interface ForgeDeps {
  db: DB
  config: ServerConfig
  /** optional: the pipeline itself never calls providers directly — the
   * prebuilt modelFn carries everything; kept for caller convenience */
  registry?: ProviderRegistry
  vault?: Vault
  log: Logger
  /** nullable: without a model the forge still does deterministic analysis */
  modelFn: ((messages: ChatMessage[], opts?: { maxTokens?: number }) => Promise<string>) | null
  model: string | null
}

export interface ForgeChangeRow {
  id: number
  request: string
  model: string | null
  status: ForgeStatus
  level: number
  plan: string | null
  branch: string | null
  worktree: string | null
  diff: string | null
  test_output: string | null
  security_review: string | null
  commit_id: string | null
  rollback_of: string | null
  error: string | null
  created_at: string
  updated_at: string
}

/** Terminal statuses — a row here never runs again (LIMO #19 adds the
 *  owner's `cancelled` interruption to the list). */
export const TERMINAL_STATUSES: ForgeStatus[] = ['applied', 'rejected', 'rolled_back', 'cancelled', 'failed']
const TERMINAL = TERMINAL_STATUSES

export function getChange(db: DB, id: number): ForgeChangeRow | undefined {
  return db.prepare('SELECT * FROM forge_changes WHERE id = ?').get(id) as ForgeChangeRow | undefined
}

function setStatus(db: DB, id: number, status: ForgeStatus, patch: Partial<Record<string, string | null>> = {}): void {
  // LIMO #19: once the owner cancelled, the row stays cancelled — an
  // in-flight phase may finish its work but can never resurrect the change.
  const cur = db.prepare('SELECT status FROM forge_changes WHERE id = ?').get(id) as { status: string } | undefined
  if (cur && cur.status === 'cancelled' && status !== 'cancelled') return
  const cols = Object.keys(patch)
  const sets = ['status = ?', "updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')", ...cols.map((c) => `${c} = ?`)]
  db.prepare(`UPDATE forge_changes SET ${sets.join(', ')} WHERE id = ?`).run(status, ...cols.map((c) => patch[c] ?? null), id)
}

function logEvent(db: DB, changeId: number, actor: string, kind: string, data: Record<string, unknown>): void {
  db.prepare('INSERT INTO forge_change_events (change_id, actor, kind, data) VALUES (?, ?, ?, ?)').run(
    changeId,
    actor,
    kind,
    JSON.stringify(scrub(data)),
  )
}

function scrub(data: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(data)) {
    out[k] = typeof v === 'string' && v.length > 2000 ? `${v.slice(0, 2000)}…` : v
  }
  return out
}

// ------------------------------------------------- shared entry points
// One creation/launch path for ALL callers (REST route, box brain, agent
// tools) — the audit's no-third-parallel-layer rule: the box and the agent
// drive the SAME pipeline the owner drives from the Forge screen.

/** The owner-set autonomy level — read once, used by every entry point. */
export function readAutonomyLevel(db: DB): AutonomyLevel {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(AUTONOMY_KEY) as { value: string } | undefined
  const n = row ? Number(row.value) : 0
  return Number.isInteger(n) && n >= 0 && n <= 4 ? (n as AutonomyLevel) : 0
}

const AUTONOMY_KEY = 'forge_autonomy_level'
const ENGINEERING_KEY = 'forge_engineering_model'

/** LIMO #19: the owner-pinned engineering intelligence model (the forge's
 *  planner/engineer). null = fall back to the conversation/task model. */
export function readEngineeringModel(db: DB): string | null {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(ENGINEERING_KEY) as { value: string } | undefined
  return row && row.value.trim() ? row.value : null
}

/** Model resolution for every forge run: the owner pin wins over the model
 *  that happened to start the conversation — one resolver, all callers. */
export function resolveForgeModel(db: DB, requested: string | null): string | null {
  return readEngineeringModel(db) ?? requested
}

/** One deps builder for every forge entry point (REST/box/agent) — the same
 *  vault-unlock honesty and the same `source: 'forge'` provenance. Replaces
 *  the route-local copy (audit rule: unify, never duplicate). */
export function forgeDepsFor(
  base: { db: DB; config: ServerConfig; registry?: ProviderRegistry; vault?: Vault; log: Logger },
  model: string | null,
): ForgeDeps {
  const modelFn =
    model && base.registry && base.vault?.isUnlocked
      ? buildModelFn({ db: base.db, config: base.config, registry: base.registry, vault: base.vault, log: base.log, model, source: 'forge' })
      : null
  return { db: base.db, config: base.config, registry: base.registry, vault: base.vault, log: base.log, modelFn, model: modelFn ? model : null }
}

/** Insert the change row (status 'analyzing') — the request pinned to its level. */
export function createChange(db: DB, request: string, model: string | null, level: AutonomyLevel): number {
  const info = db
    .prepare("INSERT INTO forge_changes (request, model, status, level) VALUES (?, ?, 'analyzing', ?)")
    .run(request, model, level)
  return Number(info.lastInsertRowid)
}

/** Fire-and-forget launch with crash logging — never leaves a silent corpse. */
export function startChange(deps: ForgeDeps, id: number, log?: Logger): void {
  void runForgeChange(deps, id).catch((e) => {
    const msg = e instanceof Error ? e.message : String(e)
    if (log) log.error('forge: change crashed after launch', { id, err: msg })
    try {
      setStatus(deps.db, id, 'failed', { error: msg })
    } catch {
      /* recording the failure must never crash the caller */
    }
  })
}

export interface ChatChangeView {
  id: number
  request: string
  status: ForgeStatus
  level: number
  model: string | null
  planSummary: string | null
  affectedFiles: string[]
  /** LIMO #19 planner v2 — surfaced for the owner's decision */
  complexity: string | null
  dependencies: string[]
  regressions: string[]
  diff: string | null
  diffTruncated: boolean
  test: { code: number | null; skipped: boolean; failedStep: string | null; steps: Array<{ name: string; code: number; durationMs: number }> }
  security: { verdict: string | null; findings: number | null }
  commitId: string | null
  rollbackOf: string | null
  error: string | null
  createdAt: string
  updatedAt: string
  events: Array<{ actor: string; kind: string; ts: string }>
}

/**
 * Bounded chat view of one change — what the box/agent may quote in a
 * conversation: plan summary, bounded diff, test/security verdicts and the
 * last audit events. No raw dumps, no secret-bearing content.
 */
export function changeForChat(db: DB, id: number): { ok: true; change: ChatChangeView } | { ok: false; error: string } {
  const change = getChange(db, id)
  if (!change) return { ok: false, error: `لا يوجد تغيير Reality Forge بالرقم ${id}` }
  let planSummary: string | null = null
  let affectedFiles: string[] = []
  let complexity: string | null = null
  let dependencies: string[] = []
  let regressions: string[] = []
  try {
    if (change.plan) {
      const p = JSON.parse(change.plan) as { summary?: string; files?: string[]; complexity?: string; dependencies?: string[]; regressions?: string[] }
      planSummary = typeof p.summary === 'string' ? p.summary.slice(0, 400) : null
      affectedFiles = Array.isArray(p.files) ? p.files.slice(0, 8) : []
      complexity = typeof p.complexity === 'string' ? p.complexity : null
      dependencies = Array.isArray(p.dependencies) ? p.dependencies.slice(0, 6).map(String) : []
      regressions = Array.isArray(p.regressions) ? p.regressions.slice(0, 4).map(String) : []
    }
  } catch {
    /* plan is not JSON yet — honest empty fields */
  }
  let test: ChatChangeView['test'] = { code: null, skipped: false, failedStep: null, steps: [] }
  try {
    if (change.test_output) {
      const t = JSON.parse(change.test_output) as { code?: number; skipped?: boolean; failedStep?: string | null; steps?: Array<{ name?: string; code?: number; durationMs?: number }> }
      test = {
        code: typeof t.code === 'number' ? t.code : null,
        skipped: t.skipped === true,
        failedStep: typeof t.failedStep === 'string' ? t.failedStep : null,
        steps: Array.isArray(t.steps)
          ? t.steps
              .filter((s) => s && typeof s.name === 'string')
              .slice(0, 8)
              .map((s) => ({ name: s.name as string, code: typeof s.code === 'number' ? s.code : -1, durationMs: typeof s.durationMs === 'number' ? s.durationMs : 0 }))
          : [],
      }
    }
  } catch {
    /* keep defaults */
  }
  let security: ChatChangeView['security'] = { verdict: null, findings: null }
  try {
    if (change.security_review) {
      const s = JSON.parse(change.security_review) as { verdict?: string; findings?: unknown[] }
      security = { verdict: typeof s.verdict === 'string' ? s.verdict : null, findings: Array.isArray(s.findings) ? s.findings.length : null }
    }
  } catch {
    /* keep defaults */
  }
  const events = (
    db.prepare('SELECT actor, kind, ts FROM forge_change_events WHERE change_id = ? ORDER BY id DESC LIMIT 8').all(change.id) as Array<{
      actor: string
      kind: string
      ts: string
    }>
  ).reverse()
  return {
    ok: true,
    change: {
      id: change.id,
      request: change.request.slice(0, 200),
      status: change.status,
      level: change.level,
      model: change.model,
      planSummary,
      affectedFiles,
      complexity,
      dependencies,
      regressions,
      diff: change.diff ? change.diff.slice(0, 2400) : null,
      diffTruncated: !!change.diff && change.diff.length > 2400,
      test,
      security,
      commitId: change.commit_id,
      rollbackOf: change.rollback_of,
      error: change.error,
      createdAt: change.created_at,
      updatedAt: change.updated_at,
      events,
    },
  }
}

/** The full pipeline for one change; resumable by status. */
export async function runForgeChange(deps: ForgeDeps, changeId: number): Promise<void> {
  const { db, config, log } = deps
  const root = config.forgeRepoRoot
  if (!root) {
    setStatus(db, changeId, 'failed', { error: 'Reality Forge معطّل — لم يُعثر على مستودع git (اضبط FORGE_REPO_ROOT)' })
    return
  }
  let change = getChange(db, changeId)
  if (!change) return
  if (TERMINAL.includes(change.status)) return // already done — idempotent

  const level = change.level as AutonomyLevel

  try {
    // ------------------------------------------------ 1) architect: scan
    if (change.status === 'analyzing') {
      const map = scanRepository(root)
      persistInventory(db, map)
      const affected = affectedFilesFor(map, change.request)
      const risk = assessFiles(affected)
      // LIMO #19 planner v2 — deterministic dependency + regression analysis
      // from the REAL import graph and debt list (the model may refine, never
      // silently remove): reverse edges = files that import an affected file.
      const affectedSet = new Set(affected)
      const dependencies = [...new Set(map.edges.filter((e) => affectedSet.has(e.to) && !affectedSet.has(e.from)).map((e) => e.from))].slice(0, 8)
      const debtDetail = new Map(map.debt.map((d) => [d.file, d.detail]))
      const regressions = affected
        .filter((f) => debtDetail.has(f))
        .map((f) => `${f} — ${debtDetail.get(f)}`)
        .slice(0, 4)
      const complexity: 'low' | 'medium' | 'high' = risk.class || affected.length > 6 ? 'high' : affected.length >= 3 ? 'medium' : 'low'
      const complexityReason = risk.class
        ? `ملف عالي الخطر (${risk.class})`
        : `${affected.length} ملفاً متأثراً${dependencies.length ? ` و${dependencies.length} تبعية عكسية` : ''}`
      const basePlan: ForgePlanJson = {
        summary: `فحص ${map.files.length} ملفاً عبر ${Object.keys(map.layers).length} طبقات (${Object.entries(map.layers).map(([k, v]) => `${k}:${v}`).join(' · ')}) — الأنماط: ${map.patterns.slice(0, 3).join(' / ')}`,
        steps: [
          { title: 'تحديد الملفات المتأثرة', detail: affected.length ? affected.join(' · ') : 'لم تحدد ملفات بالمطابقة النصية — سيعتمد على تحليل النموذج' },
          { title: 'تقييم الخطر', detail: risk.class ? `عالي الخطر: ${risk.class}` : 'منخفض الخطر (لا ملفات حساسة في الأثر)' },
        ],
        files: affected,
        risks: risk.class ? [risk.class] : [],
        complexity,
        complexityReason,
        dependencies,
        regressions,
      }
      setStatus(db, changeId, 'planned', { plan: JSON.stringify(basePlan) })
      logEvent(db, changeId, 'architect', 'scanned', { files: map.files.length, layers: map.layers, affected, risk: risk.class, complexity, dependencies, regressions: regressions.length })
      change = getChange(db, changeId)!
    }

    // --------------------------------------- 2) engineer: plan + patch
    if (change.status === 'planned') {
      const gate = gateForLevel(level, assessFiles(JSON.parse(change.plan ?? '{}').files ?? []).class)
      if (!gate.mayProposeDiff) {
        logEvent(db, changeId, 'master', 'stopped_at_level', { level, note: 'L0: تحليل وتوصيات فقط — لا فروق ولا تنفيذ' })
        return // stays 'planned' with the analysis — an honest stop
      }
      let plan: ForgePlanJson = JSON.parse(change.plan!)
      if (deps.modelFn) {
        const raw = await deps.modelFn(
          [
            { role: 'system', content: FORGE_SYSTEM_PROMPT },
            {
              role: 'user',
              content: `طلب المالك: «${change.request}»\n\nنتيجة الفحص: ${plan.summary}\nالملفات المتأثرة المرشحة: ${plan.files.join(' · ') || '(بلا مطابقة نصية — حدد بنفسك من الفحص)'}\nالتبعيات العكسية المقيسة (ملفات تستورد المتأثر): ${plan.dependencies?.join(' · ') || '(لا شيء من رسم الاستيراد)'}\n\nأعد JSON فقط: {"summary":"...","steps":[{"title":"...","detail":"..."}],"files":["..."],"risks":["..."],"complexity":"low|medium|high","complexityReason":"لماذا هذا التقدير","dependencies":["ملفات تعتمد على الملفات المتأثرة"],"regressions":["مخاطر انحدار محددة"],"patch":"unified diff اختياري — أدمجه فقط إن كان الطلب يتطلب تعديل كود واضحاً"}`,
            },
          ],
          { maxTokens: 2000 },
        )
        const modelPlan = extractJson<ForgePlanJson>(raw)
        if (modelPlan?.summary) {
          plan = {
            summary: modelPlan.summary,
            steps: Array.isArray(modelPlan.steps) ? modelPlan.steps.slice(0, 10) : plan.steps,
            files: Array.isArray(modelPlan.files) && modelPlan.files.length ? modelPlan.files : plan.files,
            risks: Array.isArray(modelPlan.risks) ? modelPlan.risks : plan.risks,
            complexity: modelPlan.complexity === 'low' || modelPlan.complexity === 'medium' || modelPlan.complexity === 'high' ? modelPlan.complexity : plan.complexity,
            complexityReason: typeof modelPlan.complexityReason === 'string' && modelPlan.complexityReason.trim() ? modelPlan.complexityReason.slice(0, 300) : plan.complexityReason,
            dependencies: Array.isArray(modelPlan.dependencies) && modelPlan.dependencies.length ? modelPlan.dependencies.slice(0, 8).map(String) : plan.dependencies,
            regressions: Array.isArray(modelPlan.regressions) && modelPlan.regressions.length ? modelPlan.regressions.slice(0, 6).map(String) : plan.regressions,
            patch: typeof modelPlan.patch === 'string' && modelPlan.patch.length > 0 ? modelPlan.patch : undefined,
          }
        }
      } else {
        logEvent(db, changeId, 'engineer', 'no_model', { note: 'بلا نموذج: خطة حتمية من الفحص فقط — لا patch' })
      }

      if (!plan.patch) {
        setStatus(db, changeId, 'planned', { plan: JSON.stringify(plan) })
        logEvent(db, changeId, 'engineer', 'plan_ready', { summary: plan.summary, files: plan.files, note: 'لا رقعة مقترحة — التغيير يحتاج نموذجاً أو طلباً أدق' })
        return // honest stop: a plan without a diff
      }

      // L1: validate the patch in a THROWAWAY sandbox, then discard it.
      if (!gate.mayImplementInSandbox) {
        const tmp = await createSandbox(root, changeId)
        try {
          const check = await applyPatch(tmp.worktree, plan.patch)
          setStatus(db, changeId, 'planned', { plan: JSON.stringify(plan), diff: check.ok ? plan.patch : null })
          logEvent(db, changeId, 'engineer', 'diff_proposed', { valid: check.ok, error: check.error ?? null, note: 'L1: رقعة مقترحة ومتحقق منها ثم استُبعد الصندوق — لم يُنفَّذ شيء' })
        } finally {
          await destroySandbox(root, tmp.worktree)
        }
        return
      }

      // L2+: implement in the persistent sandbox branch. On resume the
      // branch/worktree come from the ROW — names are collision-proofed at
      // creation time, so reconstructing them here would be wrong.
      const sandbox = (await sandboxExists(root, changeId)) && change.branch && change.worktree
        ? { branch: change.branch, worktree: change.worktree }
        : await createSandbox(root, changeId)
      const applied = await applyPatch(sandbox.worktree, plan.patch)
      if (!applied.ok) {
        setStatus(db, changeId, 'failed', { error: applied.error, branch: sandbox.branch, worktree: sandbox.worktree })
        logEvent(db, changeId, 'engineer', 'patch_failed', { error: applied.error })
        return
      }
      // diff BEFORE the commit — after it the worktree equals HEAD and the
      // diff would be empty (the security review would then see nothing)
      const diff = await sandboxDiff(sandbox.worktree)
      const commit = await commitInSandbox(sandbox.worktree, `forge(#${changeId}): ${change.request.slice(0, 100)}`)
      setStatus(db, changeId, 'implementing', { plan: JSON.stringify(plan), diff, branch: sandbox.branch, worktree: sandbox.worktree, commit_id: commit })
      logEvent(db, changeId, 'engineer', 'implemented_in_sandbox', { branch: sandbox.branch, commit, diffLines: diff.split('\n').length })
      change = getChange(db, changeId)!
    }

    // ------------------------------------------------- 3) qa: the DIRECT
    // ACTION validation chain (LIMO #19) — install → lint → tests → build,
    // every step allowlisted, time-boxed and RECORDED; the first failure
    // stops the line and nothing is ever applied. Empty command = the step
    // is simply not in the chain (honest absence, never a fake green).
    if (change.status === 'implementing') {
      const gate = gateForLevel(level, null)
      if (!gate.mayRunTests) {
        setStatus(db, changeId, 'reviewing', { test_output: JSON.stringify({ skipped: true, steps: [], note: `L${level}: لم تُشغَّل سلسلة التحقق — مستوى الاستقلالية لا يسمح` }) })
        logEvent(db, changeId, 'qa', 'tests_skipped_by_level', { level })
        change = getChange(db, changeId)!
      } else {
        const chain: Array<{ name: string; command: string; timeoutMs: number }> = []
        if (config.forgeInstallCommand.trim() !== '') chain.push({ name: 'install', command: config.forgeInstallCommand, timeoutMs: 300_000 })
        if (config.forgeLintCommand.trim() !== '') chain.push({ name: 'lint', command: config.forgeLintCommand, timeoutMs: 180_000 })
        if (config.forgeTestCommand.trim() !== '') chain.push({ name: 'tests', command: config.forgeTestCommand, timeoutMs: 180_000 })
        if (config.forgeBuildCommand.trim() !== '') chain.push({ name: 'build', command: config.forgeBuildCommand, timeoutMs: 300_000 })
        const steps: Array<{ name: string; command: string; code: number; durationMs: number; truncated: boolean; tail: string }> = []
        let failed: { name: string; code: number } | null = null
        for (const step of chain) {
          const res = await guardedRun(change.worktree!, step.command, { timeoutMs: step.timeoutMs })
          const tail = (res.stderr.slice(-300) || res.stdout.slice(-300)).slice(0, 400)
          steps.push({ name: step.name, command: step.command, code: res.code, durationMs: res.durationMs, truncated: res.truncated, tail })
          logEvent(db, changeId, 'qa', res.code === 0 ? `${step.name}_passed` : `${step.name}_failed`, { command: step.command, code: res.code, durationMs: res.durationMs, tail })
          if (res.code !== 0) {
            failed = { name: step.name, code: res.code }
            break
          }
        }
        const output = JSON.stringify({
          code: failed ? failed.code : steps.length ? 0 : null,
          failedStep: failed?.name ?? null,
          steps,
          durationMs: steps.reduce((a, s) => a + s.durationMs, 0),
        })
        setStatus(db, changeId, 'reviewing', { test_output: output })
        if (failed) {
          setStatus(db, changeId, 'failed', { error: `فشلت خطوة «${failed.name}» في سلسلة التحقق (رمز ${failed.code}) — لم يُطبَّق شيء` })
          return
        }
        change = getChange(db, changeId)!
      }
    }

    // ------------------------------------- 4) security: static review
    if (change.status === 'reviewing') {
      const review: SecurityReview = reviewDiff(change.diff ?? '')
      setStatus(db, changeId, 'awaiting_approval', { security_review: JSON.stringify(review) })
      logEvent(db, changeId, 'security', review.verdict, {
        findings: review.findings.length,
        highRisk: review.highRiskTouched.map((h) => h.risk),
        verdict: review.verdict,
      })
      change = getChange(db, changeId)!

      // L4 + low risk + clean review ⇒ the configured policy allows the apply
      const risk = review.riskClass
      const gate = gateForLevel(level, risk)
      if (gate.mayApplyWithoutApproval && review.verdict === 'clean') {
        await applyApprovedChange(deps, changeId)
        return
      }
    }

    // awaiting_approval: the human gate — nothing more happens autonomously
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    setStatus(db, changeId, 'failed', { error: msg })
    logEvent(db, changeId, 'system', 'crashed', { error: msg })
    log.warn('forge: change failed', { changeId, err: msg })
  }
}

/** The owner decision on a change sitting at the human gate. */
export async function decideChange(deps: ForgeDeps, changeId: number, decision: 'apply' | 'reject'): Promise<ForgeChangeRow | { error: string }> {
  const { db, config } = deps
  const root = config.forgeRepoRoot
  if (!root) return { error: 'forge_disabled' }
  const change = getChange(db, changeId)
  if (!change) return { error: 'not_found' }
  if (change.status !== 'awaiting_approval') return { error: 'not_awaiting_approval' }
  if (decision === 'reject') {
    setStatus(db, changeId, 'rejected')
    logEvent(db, changeId, 'owner', 'rejected', {})
    if (change.worktree) await destroySandbox(root, change.worktree)
    return getChange(db, changeId)!
  }
  return (await applyApprovedChange(deps, changeId)) as ForgeChangeRow
}

async function applyApprovedChange(deps: ForgeDeps, changeId: number): Promise<ForgeChangeRow | { error: string }> {
  const { db, config } = deps
  const root = config.forgeRepoRoot
  if (!root) return { error: 'forge_disabled' }
  const change = getChange(db, changeId)
  if (!change) return { error: 'not_found' }
  if (!change.branch) return { error: 'no_branch' }
  try {
    const commit = await mergeToCurrent(root, change.branch, `forge(#${changeId}): apply — ${change.request.slice(0, 80)}`)
    setStatus(db, changeId, 'applied', { commit_id: commit })
    logEvent(db, changeId, 'owner', 'applied', { commit })
    if (change.worktree) await destroySandbox(root, change.worktree)
    return getChange(db, changeId)!
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    setStatus(db, changeId, 'failed', { error: `فشل الدمج: ${msg}` })
    logEvent(db, changeId, 'system', 'merge_failed', { error: msg })
    return getChange(db, changeId)!
  }
}

/** Rollback: a NEW revert commit — history and audit stay intact. */
export async function rollbackChange(deps: ForgeDeps, changeId: number): Promise<ForgeChangeRow | { error: string }> {
  const { db, config } = deps
  const root = config.forgeRepoRoot
  if (!root) return { error: 'forge_disabled' }
  const change = getChange(db, changeId)
  if (!change) return { error: 'not_found' }
  if (change.status !== 'applied' || !change.commit_id) return { error: 'not_applied' }
  try {
    const revert = await revertCommit(root, change.commit_id)
    const row = db
      .prepare('INSERT INTO forge_changes (request, model, status, level, rollback_of, commit_id, plan) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(`rollback: ${change.request.slice(0, 180)}`, change.model, 'rolled_back', change.level, change.commit_id, revert, change.plan)
    const rollbackId = Number(row.lastInsertRowid)
    logEvent(db, rollbackId, 'owner', 'rolled_back', { revertedCommit: change.commit_id, revertCommit: revert })
    logEvent(db, changeId, 'owner', 'rollback_started', { revertCommit: revert, rollbackChange: rollbackId })
    setStatus(db, changeId, 'rolled_back')
    return getChange(db, rollbackId)!
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    logEvent(db, changeId, 'system', 'rollback_failed', { error: msg })
    return { error: `فشل التراجع: ${msg}` }
  }
}

// ------------------------------------------------- change memory (LIMO #19)
// The owner's queryable engineering history: "ماذا غيّرت أمس؟", "أظهر كل
// ما مسّ لوحة القيادة", "أكمل المهمة غير المنتهية" — all answered from
// these rows, never from a model's imagination.

export type ChangeListRow = Pick<
  ForgeChangeRow,
  'id' | 'request' | 'model' | 'status' | 'level' | 'rollback_of' | 'commit_id' | 'error' | 'created_at' | 'updated_at'
>

export interface ChangeQuery {
  status?: string
  /** free-text search over the request column */
  q?: string
  /** ISO date lower bound on updated_at */
  since?: string
  limit?: number
}

/** Filtered change history — bounded, SQL-escaped by parameters only. */
export function listChanges(db: DB, query: ChangeQuery = {}): ChangeListRow[] {
  const where: string[] = []
  const params: Array<string | number> = []
  if (query.status && query.status.length <= 20) {
    where.push('status = ?')
    params.push(query.status)
  }
  if (query.q && query.q.trim()) {
    where.push('request LIKE ?')
    params.push(`%${query.q.trim().slice(0, 200)}%`)
  }
  if (query.since && /^\d{4}-\d{2}-\d{2}/.test(query.since)) {
    where.push('updated_at >= ?')
    params.push(query.since.slice(0, 32))
  }
  const limit = Math.min(Math.max(query.limit ?? 50, 1), 200)
  params.push(limit)
  return db
    .prepare(`SELECT id, request, model, status, level, rollback_of, commit_id, error, created_at, updated_at FROM forge_changes ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY id DESC LIMIT ?`)
    .all(...params) as ChangeListRow[]
}

/** The owner interrupts a non-terminal change (directive §7). Cancellation
 *  is durable: setStatus refuses to leave 'cancelled', the resume endpoint
 *  refuses terminal rows, and the sandbox worktree is cleaned up. */
export async function cancelChange(deps: ForgeDeps, changeId: number): Promise<ForgeChangeRow | { error: string }> {
  const { db, config } = deps
  const change = getChange(db, changeId)
  if (!change) return { error: 'not_found' }
  if (TERMINAL_STATUSES.includes(change.status)) return { error: 'already_finished' }
  setStatus(db, changeId, 'cancelled')
  logEvent(db, changeId, 'owner', 'cancelled', { from: change.status, note: 'إلغاء المالك — الطور الجاري يُسكَّت سجله عند حده ولا يُستأنف' })
  if (config.forgeRepoRoot && change.worktree) await destroySandbox(config.forgeRepoRoot, change.worktree).catch(() => undefined)
  return getChange(db, changeId)!
}

/** The architecture map, scanning first if none exists yet (or stale). */
export function currentMap(deps: ForgeDeps): ArchitectureMap | null {
  if (!deps.config.forgeRepoRoot) return null
  const existing = latestInventory(deps.db)
  if (existing && Date.now() - Date.parse(existing.ts) < 1000 * 60 * 30) {
    return existing.detail as ArchitectureMap
  }
  const map = scanRepository(deps.config.forgeRepoRoot)
  persistInventory(deps.db, map)
  return map
}
