import { readdirSync, readFileSync, statSync, existsSync } from 'node:fs'
import { join, relative, extname } from 'node:path'
import type { DB } from '../db/database.js'

/**
 * The self-understanding engine (RF spec §2): scan the REAL repository,
 * build the module map + import graph, detect entry points, duplicated
 * logic and debt hints, and answer "which files are affected by a request".
 * Nothing here is hardcoded about the stack — it is derived from the tree.
 */

export interface FileNode {
  path: string
  layer: string
  bytes: number
  lines: number
  imports: string[]
  exportsNames: string[]
  todos: number
}

export interface DupPair {
  a: string
  b: string
  windows: number
  sample: string
}

export interface ArchitectureMap {
  root: string
  scannedAt: string
  layers: Record<string, number>
  files: FileNode[]
  edges: Array<{ from: string; to: string }>
  entryPoints: string[]
  moduleBoundaries: string[]
  patterns: string[]
  duplication: DupPair[]
  debt: Array<{ file: string; kind: 'todo' | 'long' | 'untested'; detail: string }>
  conventions: string[]
}

const SKIP_DIRS = new Set([
  'node_modules', '.git', '.next', 'out', 'dist', 'data', '.forge', 'download',
  'tool-results', 'skills', 'coverage', 'target', '.turbo', '.zscripts', 'upload',
])
const TEXT_EXT = new Set(['.ts', '.tsx', '.js', '.mjs', '.cjs', '.json', '.css', '.md', '.sql', '.rs', '.toml', '.yml', '.yaml', '.html', '.svg', '.txt', ''])
const MAX_BYTES = 512 * 1024

function layerFor(relPath: string): string {
  const p = relPath.replaceAll('\\', '/')
  if (p.startsWith('apps/web/')) return 'web'
  if (p.startsWith('apps/desktop/')) return 'desktop'
  if (p.startsWith('apps/android/')) return 'android'
  if (p.startsWith('server/')) return 'server'
  if (p.startsWith('packages/')) return 'packages'
  if (p.startsWith('docker/') || p.startsWith('.github/') || p.startsWith('tests/')) return 'infra'
  if (p.startsWith('assets/')) return 'brand'
  if (p.startsWith('scripts/')) return 'scripts'
  if (p.startsWith('examples/') || p.startsWith('mini-services/')) return 'legacy-template'
  if (extname(p) === '.md') return 'docs'
  return 'root'
}

function walk(root: string, dir = '', out: string[] = []): string[] {
  for (const name of readdirSync(join(root, dir))) {
    if (name.startsWith('.') && name !== '.github' && name !== '.env.example') continue
    const rel = dir ? `${dir}/${name}` : name
    const abs = join(root, rel)
    let st
    try {
      st = statSync(abs)
    } catch {
      continue
    }
    if (st.isDirectory()) {
      if (SKIP_DIRS.has(name)) continue
      walk(root, rel, out)
    } else if (st.isFile() && st.size <= MAX_BYTES) {
      out.push(rel)
    }
  }
  return out
}

const IMPORT_RE = /(?:from\s+|require\()\s*['"]([^'"]+)['"]/g
const EXPORT_RE = /export\s+(?:async\s+)?(?:function|const|class|interface|type)\s+([A-Za-z0-9_$]+)/g

function parseImports(relPath: string, content: string, all: Set<string>): string[] {
  const dir = relPath.includes('/') ? relPath.slice(0, relPath.lastIndexOf('/')) : ''
  const out: string[] = []
  let m: RegExpExecArray | null
  IMPORT_RE.lastIndex = 0
  while ((m = IMPORT_RE.exec(content))) {
    const spec = m[1]!
    if (!spec.startsWith('.')) continue // package imports are not graph edges
    const base = join(dir, spec).replaceAll('\\', '/')
    const candidates = [base, `${base}.ts`, `${base}.tsx`, `${base}/index.ts`, `${base}.js`]
    for (const c of candidates) {
      if (all.has(c)) {
        out.push(c)
        break
      }
    }
  }
  return out
}

function normalizeLine(line: string): string {
  return line.replace(/\/\/.*$/, '').replace(/\s+/g, ' ').trim()
}

/** 6-line windows; identical normalized windows in 2+ files = duplication. */
function detectDuplication(files: FileNode[], root: string): DupPair[] {
  const W = 6
  const byWindow = new Map<string, Array<{ file: string; sample: string }>>()
  for (const f of files) {
    if (!/\.(ts|tsx|js|mjs|rs)$/.test(f.path)) continue
    const lines = readFileSync(join(root, f.path), 'utf8').split('\n').map(normalizeLine).filter(Boolean)
    for (let i = 0; i + W <= lines.length; i++) {
      const window = lines.slice(i, i + W)
      // skip trivial windows (all short lines / pure syntax)
      if (window.join('').length < 60) continue
      const hash = window.join('\u0001')
      const arr = byWindow.get(hash) ?? []
      if (arr.every((x) => x.file !== f.path)) arr.push({ file: f.path, sample: window[0]!.slice(0, 80) })
      if (arr.length > 1) byWindow.set(hash, arr)
      else byWindow.set(hash, arr)
    }
  }
  const pairCounts = new Map<string, DupPair>()
  for (const arr of byWindow.values()) {
    if (arr.length < 2) continue
    for (let i = 0; i < arr.length; i++) {
      for (let j = i + 1; j < arr.length; j++) {
        const key = [arr[i]!.file, arr[j]!.file].sort().join('⇄')
        const cur = pairCounts.get(key)
        if (cur) cur.windows++
        else pairCounts.set(key, { a: arr[i]!.file, b: arr[j]!.file, windows: 1, sample: arr[i]!.sample })
      }
    }
  }
  return [...pairCounts.values()].filter((p) => p.windows >= 2).sort((x, y) => y.windows - x.windows).slice(0, 20)
}

const ENTRY_PATTERNS = [
  /^server\/src\/index\.[jt]s$/,
  /^apps\/web\/src\/app\/page\.tsx$/,
  /^apps\/desktop\/src-tauri\/src\/main\.rs$/,
  /^apps\/desktop\/ui\/index\.html$/,
  /^server\/test\/fixtures\/.*\.[jt]s$/,
]

export function scanRepository(root: string): ArchitectureMap {
  const rels = walk(root).filter((r) => TEXT_EXT.has(extname(r)))
  const all = new Set(rels)
  const files: FileNode[] = []
  const edges: Array<{ from: string; to: string }> = []
  const layers: Record<string, number> = {}
  const conventions = new Set<string>()

  for (const rel of rels) {
    const content = readFileSync(join(root, rel), 'utf8')
    const node: FileNode = {
      path: rel,
      layer: layerFor(rel),
      bytes: Buffer.byteLength(content),
      lines: content.split('\n').length,
      imports: parseImports(rel, content, all),
      exportsNames: [...content.matchAll(EXPORT_RE)].map((m) => m[1]!).slice(0, 40),
      todos: (content.match(/TODO|FIXME|HACK/g) ?? []).length,
    }
    files.push(node)
    layers[node.layer] = (layers[node.layer] ?? 0) + 1
    for (const to of node.imports) edges.push({ from: rel, to })
    if (/register\w+Routes/.test(content)) conventions.add('Fastify route modules (register*Routes)')
    if (/@tauri-apps|tauri::/.test(content)) conventions.add('Tauri v2 (Rust core + webview UI)')
    if (/import.*@omnara\/tokens/.test(content)) conventions.add('@omnara/tokens as the design source of truth')
    if (/better-sqlite3/.test(content)) conventions.add('SQLite via better-sqlite3 + numbered SQL migrations')
    if (/plan\s*→|planner/.test(content)) conventions.add('planner→executor→critic agent loop')
  }

  const testedFiles = new Set(
    existsSync(join(root, 'server/test'))
      ? readdirSync(join(root, 'server/test')).map((f) => f.replace(/\.(test|spec)\.[jt]s$/, ''))
      : [],
  )
  const debt: ArchitectureMap['debt'] = []
  for (const f of files) {
    if (f.todos > 0) debt.push({ file: f.path, kind: 'todo', detail: `${f.todos} TODO/FIXME` })
    if (f.lines > 400) debt.push({ file: f.path, kind: 'long', detail: `${f.lines} سطراً` })
    if (f.layer === 'server' && f.path.startsWith('server/src/') && /\.(ts)$/.test(f.path)) {
      const stem = f.path.split('/').pop()!.replace(/\.ts$/, '')
      const hasTest = [...testedFiles].some((t) => t.includes(stem) || stem.includes(t))
      const isFixture = f.path.includes('/fixtures/')
      if (!hasTest && !isFixture && f.lines > 80) debt.push({ file: f.path, kind: 'untested', detail: 'لا اختبار مقابل واضح' })
    }
  }

  return {
    root,
    scannedAt: new Date().toISOString(),
    layers,
    files,
    edges,
    entryPoints: rels.filter((r) => ENTRY_PATTERNS.some((re) => re.test(r))),
    moduleBoundaries: [...new Set(rels.map((r) => r.split('/')[0] ?? r))].sort(),
    patterns: [
      'Monorepo TypeScript (Fastify server + Next.js web + Tauri desktop)',
      ...(conventions.size ? [...conventions] : []),
    ],
    duplication: detectDuplication(files, root),
    debt: debt.slice(0, 60),
    conventions: [...conventions],
  }
}

/** Rank files by relevance to a natural-language request (path + symbol hits). */
export function affectedFilesFor(map: ArchitectureMap, request: string, limit = 12): string[] {
  const words = request
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s/]/gu, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 2)
  const scored = map.files.map((f) => {
    let score = 0
    const lowerPath = f.path.toLowerCase()
    for (const w of words) {
      if (lowerPath.includes(w)) score += 4
      for (const e of f.exportsNames) if (e.toLowerCase().includes(w)) score += 2
    }
    // entry-ish and bigger files rank slightly higher on ties
    if (map.entryPoints.includes(f.path)) score += 1
    return { path: f.path, score }
  })
  return scored
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((s) => s.path)
}

// ------------------------------------------------------------- persistence

export function persistInventory(db: DB, map: ArchitectureMap): void {
  const summary = {
    scannedAt: map.scannedAt,
    layers: map.layers,
    files: map.files.length,
    edges: map.edges.length,
    entryPoints: map.entryPoints,
    duplication: map.duplication.length,
    debt: map.debt.length,
    patterns: map.patterns,
    conventions: map.conventions,
  }
  db.prepare('INSERT INTO forge_inventory (summary, detail) VALUES (?, ?)').run(JSON.stringify(summary), JSON.stringify(map))
}

export function latestInventory(db: DB): { id: number; ts: string; summary: unknown; detail: unknown } | undefined {
  const row = db.prepare('SELECT * FROM forge_inventory ORDER BY id DESC LIMIT 1').get() as
    | { id: number; ts: string; summary: string; detail: string }
    | undefined
  if (!row) return undefined
  return { id: row.id, ts: row.ts, summary: JSON.parse(row.summary), detail: JSON.parse(row.detail) }
}

/** The path recorded relative to the scan root, for display. */
export function relOf(root: string, abs: string): string {
  return relative(root, abs).replaceAll('\\', '/')
}
