import { execFile } from 'node:child_process'
import { existsSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { promisify } from 'node:util'

/**
 * The Reality Forge sandbox (RF spec §8): every self-modification happens in
 * an isolated git worktree, and every command inside it is allowlisted,
 * time-boxed, output-capped and runs with a SCRUBBED environment — no
 * production secrets ever reach model-generated code.
 */

const execFileAsync = promisify(execFile)

export interface GuardedResult {
  code: number
  stdout: string
  stderr: string
  durationMs: number
  truncated: boolean
}

/** Binaries the sandbox may run. Nothing else — no shells, no curl, no rm. */
const ALLOWED_BINS = new Set(['node', 'npm', 'npx', 'bun', 'tsc', 'vitest', 'python3', 'git'])

const OUTPUT_CAP = 64 * 1024

export function assertRepo(root: string): void {
  if (!existsSync(join(root, '.git'))) {
    throw new Error(`ليس مستودع git — Reality Forge يحتاج مستودعاً (المسار: ${root})`)
  }
}

async function git(root: string, args: string[]): Promise<string> {
  const { stdout } = await execFileAsync('git', args, { cwd: root, maxBuffer: OUTPUT_CAP })
  return stdout
}

/** Mutating commands carry an explicit forge identity: the sandbox runs with
 *  a scrubbed environment (no HOME), so a missing global git config must
 *  never break a commit — and forge commits are attributed to the forge. */
const FORGE_IDENTITY = ['-c', 'user.name=Omnara Forge', '-c', 'user.email=forge@omnara.local']

async function gitAs(root: string, args: string[]): Promise<string> {
  const { stdout } = await execFileAsync('git', [...FORGE_IDENTITY, ...args], { cwd: root, maxBuffer: OUTPUT_CAP })
  return stdout
}

/** Create an isolated worktree + branch for one change. Returns its path.
 *  Branch names are collision-proof: a re-initialized DB would restart the
 *  ids while the repo still holds old `forge/change-N` branches. */
export async function createSandbox(repoRoot: string, changeId: number): Promise<{ branch: string; worktree: string }> {
  assertRepo(repoRoot)
  const worktree = resolve(repoRoot, '.forge', 'worktrees', `change-${changeId}`)
  let branch = `forge/change-${changeId}`
  try {
    await git(repoRoot, ['worktree', 'add', '--force', '-b', branch, worktree])
  } catch {
    branch = `forge/change-${changeId}-${Date.now()}`
    await git(repoRoot, ['worktree', 'add', '--force', '-b', branch, worktree])
  }
  return { branch, worktree }
}

export async function sandboxExists(repoRoot: string, changeId: number): Promise<boolean> {
  const worktree = resolve(repoRoot, '.forge', 'worktrees', `change-${changeId}`)
  return existsSync(worktree)
}

/** Strictly-guarded command execution inside the sandbox. */
export async function guardedRun(
  worktree: string,
  command: string,
  opts: { timeoutMs?: number } = {},
): Promise<GuardedResult> {
  const parts = command.trim().split(/\s+/)
  const bin = parts[0] ?? ''
  if (!ALLOWED_BINS.has(bin)) {
    return { code: 126, stdout: '', stderr: `ممنوع: الأمر «${bin}» خارج قائمة السماح (${[...ALLOWED_BINS].join(' · ')})`, durationMs: 0, truncated: false }
  }
  if (bin === 'git' && !['diff', 'status', 'apply', 'add', 'commit', 'log', 'rev-parse', 'check'].includes(parts[1] ?? '')) {
    return { code: 126, stdout: '', stderr: `git مسموح فقط لـ diff/status/apply/add/commit/log/rev-parse — وصل: ${parts[1]}`, durationMs: 0, truncated: false }
  }
  const started = Date.now()
  try {
    const { stdout, stderr } = await execFileAsync(bin, parts.slice(1), {
      cwd: worktree,
      timeout: opts.timeoutMs ?? 120_000,
      maxBuffer: OUTPUT_CAP * 4,
      // scrubbed env — no secrets, no OMNARA_* keys, no vault material
      env: { PATH: process.env.PATH ?? '/usr/local/bin:/usr/bin:/bin', HOME: worktree, LANG: 'C.UTF-8', NO_COLOR: '1' },
    })
    const trunc = stdout.length > OUTPUT_CAP || stderr.length > OUTPUT_CAP
    return {
      code: 0,
      stdout: stdout.slice(0, OUTPUT_CAP),
      stderr: stderr.slice(0, OUTPUT_CAP),
      durationMs: Date.now() - started,
      truncated: trunc,
    }
  } catch (e) {
    const err = e as { code?: number | string; stdout?: string; stderr?: string; killed?: boolean; message: string }
    return {
      code: typeof err.code === 'number' ? err.code : 1,
      stdout: (err.stdout ?? '').slice(0, OUTPUT_CAP),
      stderr: (err.killed ? `انتهت المهلة (${opts.timeoutMs ?? 120_000}ms)` : (err.stderr || err.message) ?? '').slice(0, OUTPUT_CAP),
      durationMs: Date.now() - started,
      truncated: false,
    }
  }
}

/** Validate + apply a unified diff inside the sandbox (git apply --check first). */
export async function applyPatch(worktree: string, patch: string): Promise<{ ok: boolean; error?: string }> {
  const { execFile: ef } = await import('node:child_process')
  const run = (args: string[]) =>
    new Promise<{ code: number; stderr: string }>((resolvePromise) => {
      const p = ef('git', args, { cwd: worktree, timeout: 30_000 }, (err, _so, se) => {
        resolvePromise({ code: err ? ((err as { code?: number }).code ?? 1) : 0, stderr: String(se ?? '') })
      })
      if (args[0] === 'apply' && args[1] === '--check' || (args[0] === 'apply' && args[1] === '-')) {
        p.stdin?.end(patch)
      } else {
        p.stdin?.end()
      }
    })
  const check = await run(['apply', '--check', '-'])
  if (check.code !== 0) return { ok: false, error: `الرقعة لا تنطبق: ${check.stderr.slice(0, 500)}` }
  const applied = await run(['apply', '-'])
  return applied.code === 0 ? { ok: true } : { ok: false, error: applied.stderr.slice(0, 500) }
}

/** The unified diff of the sandbox vs its base (HEAD). */
export async function sandboxDiff(worktree: string): Promise<string> {
  await git(worktree, ['add', '-A'])
  return git(worktree, ['diff', 'HEAD'])
}

export async function commitInSandbox(worktree: string, message: string): Promise<string> {
  await gitAs(worktree, ['add', '-A'])
  await gitAs(worktree, ['commit', '--allow-empty', '-m', message])
  return (await git(worktree, ['rev-parse', 'HEAD'])).trim()
}

/** Merge the sandbox branch into the current branch (the apply step). */
export async function mergeToCurrent(repoRoot: string, branch: string, message: string): Promise<string> {
  await gitAs(repoRoot, ['merge', '--no-ff', '-m', message, branch])
  return (await git(repoRoot, ['rev-parse', 'HEAD'])).trim()
}

/** Rollback = a NEW revert commit (history is never rewritten). The applied
 *  commit is a --no-ff merge, so revert needs mainline parent 1; plain commits
 *  (e.g. reverting a revert) fall back to the normal path. */
export async function revertCommit(repoRoot: string, commitId: string): Promise<string> {
  try {
    await gitAs(repoRoot, ['revert', '--no-edit', '-m', '1', commitId])
  } catch {
    await gitAs(repoRoot, ['revert', '--no-edit', commitId])
  }
  return (await git(repoRoot, ['rev-parse', 'HEAD'])).trim()
}

export async function destroySandbox(repoRoot: string, worktree: string): Promise<void> {
  await git(repoRoot, ['worktree', 'remove', '--force', worktree]).catch(() => undefined)
}
