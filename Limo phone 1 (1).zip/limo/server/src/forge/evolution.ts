import type { DB } from '../db/database.js'
import type { ArchitectureMap } from './scanner.js'

/**
 * Evolution intelligence (RF spec §11): periodically analyze the map and
 * produce PRIORITIZED proposals — each with benefit, risk, affected
 * components, estimated cost and validation criteria.
 *
 * Proposals are data. There is NO code path from a proposal to a change:
 * the owner reads one and, if they want it, files it as a normal forge
 * request. Self-generated improvements are never auto-applied.
 */

export interface ProposalDraft {
  title: string
  kind: 'debt' | 'duplication' | 'tests' | 'architecture'
  benefit: string
  risk: string
  components: string[]
  cost: string
  validation: string
}

export function proposeFromMap(map: ArchitectureMap): ProposalDraft[] {
  const drafts: ProposalDraft[] = []

  for (const dup of map.duplication.slice(0, 5)) {
    drafts.push({
      title: `توحيد منطق مكرر: ${dup.a} ⇄ ${dup.b}`,
      kind: 'duplication',
      benefit: `صيانة واحدة بدل نسختين (${dup.windows} نافذة متطابقة) — أثر التغييرات يصبح موضعياً`,
      risk: 'إعادة استخدام مشتركة قد تربط ملفين مستقلين — تحتاج مراجعة واجهة موحدة',
      components: [dup.a, dup.b],
      cost: 'متوسط — استخراج دالة/وحدة + تحديث الاستيرادين',
      validation: 'typecheck واختبارات الوحدتين تمر، والسلوك لا يتغير (لا تغيير ميزة)',
    })
  }

  const untested = map.debt.filter((d) => d.kind === 'untested').slice(0, 5)
  if (untested.length > 0) {
    drafts.push({
      title: `تغطية اختبارات لـ ${untested.length} ملفات خادم بلا اختبار مقابل`,
      kind: 'tests',
      benefit: 'كل تعديل قادم في هذه الملفات يُحرس باختبار — يخفض خطر التعديل الذاتي عليها',
      risk: 'منخفض — إضافة اختبارات فقط، بلا تغيير سلوك',
      components: untested.map((u) => u.file),
      cost: 'منخفض إلى متوسط — ملف اختبار لكل وحدة',
      validation: 'vitest يمر مع ملفات جديدة، والتغطية للملفات المذكورة > 0',
    })
  }

  const longFiles = map.debt.filter((d) => d.kind === 'long').slice(0, 3)
  for (const f of longFiles) {
    drafts.push({
      title: `تقسيم الملف الطويل: ${f.file}`,
      kind: 'architecture',
      benefit: `الملف ${f.detail} — تقسيمه يسهّل على الفحص والتعديل الذاتي تحديد أثر دقيق`,
      risk: 'إعادة هيكلة تحرك استيرادات — يجب أن تتم بلا تغيير سلوك',
      components: [f.file],
      cost: 'متوسط',
      validation: 'typecheck + كل الاختبارات تمر، وعد أسطر كل ملف ناتج < 300',
    })
  }

  const todoCount = map.debt.filter((d) => d.kind === 'todo').reduce((n, d) => n + Number(d.detail.replace(/\D+/g, '') || 0), 0)
  if (todoCount > 0) {
    drafts.push({
      title: `${todoCount} علامة TODO/FIXME في الكود — جرد وحسم`,
      kind: 'debt',
      benefit: 'دين معلن بدل دين مخفي — كل علامة تُحسم (تنفَّذ أو تُحذف) لا تُترك غامضة',
      risk: 'منخفض',
      components: map.debt.filter((d) => d.kind === 'todo').map((d) => d.file),
      cost: 'منخفض',
      validation: `grep -r "TODO|FIXME" يرجع صفراً في الملفات المعالجة`,
    })
  }

  return drafts
}

export function persistProposals(db: DB, drafts: ProposalDraft[]): number {
  const insert = db.prepare(
    'INSERT INTO forge_proposals (title, kind, benefit, risk, components, cost, validation) VALUES (?, ?, ?, ?, ?, ?, ?)',
  )
  const tx = db.transaction((ds: ProposalDraft[]) => {
    for (const d of ds) insert.run(d.title, d.kind, d.benefit, d.risk, JSON.stringify(d.components), d.cost, d.validation)
  })
  tx(drafts)
  return drafts.length
}

export interface ProposalRow {
  id: number
  title: string
  kind: string
  benefit: string
  risk: string
  components: string
  cost: string
  validation: string
  status: string
  created_at: string
}

export function listProposals(db: DB, status?: string): ProposalRow[] {
  return status
    ? (db.prepare('SELECT * FROM forge_proposals WHERE status = ? ORDER BY id DESC LIMIT 100').all(status) as ProposalRow[])
    : (db.prepare('SELECT * FROM forge_proposals ORDER BY id DESC LIMIT 100').all() as ProposalRow[])
}
