import { classifyFileRisk, HIGH_RISK_AR, type HighRiskClass } from './types.js'

/**
 * The static security review (RF spec §6 Security Auditor role, rule-based —
 * honest and deterministic; a model review can be layered on top by the
 * orchestrator but never replaces these checks).
 */

export type Severity = 'high' | 'medium' | 'low'

export interface Finding {
  severity: Severity
  rule: string
  file: string
  line: number
  note: string
}

export interface SecurityReview {
  verdict: 'clean' | 'needs_attention'
  riskClass: HighRiskClass | null
  highRiskTouched: Array<{ file: string; risk: HighRiskClass; ar: string }>
  findings: Finding[]
  at: string
}

const SECRET_RULES: Array<{ re: RegExp; rule: string; note: string }> = [
  { re: /sk-[A-Za-z0-9_-]{20,}/, rule: 'secret:openai-style', note: 'مفتاح بنمط OpenRouter/OpenAI داخل الرقعة' },
  { re: /gsk_[A-Za-z0-9]{20,}/, rule: 'secret:groq', note: 'مفتاح Groq داخل الرقعة' },
  { re: /omn_live_[A-Za-z0-9]{10,}/, rule: 'secret:omnara-key', note: 'مفتاح Omnara API داخل الرقعة' },
  { re: /AKIA[A-Z0-9]{16}/, rule: 'secret:aws', note: 'مفتاح AWS داخل الرقعة' },
  { re: /-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----/, rule: 'secret:private-key', note: 'مفتاح خاص داخل الرقعة' },
]

const CODE_RULES: Array<{ re: RegExp; rule: string; severity: Severity; note: string }> = [
  { re: /\beval\s*\(/, rule: 'danger:eval', severity: 'high', note: 'استدعاء eval — تنفيذ نصي خام' },
  { re: /new\s+Function\s*\(/, rule: 'danger:function-ctor', severity: 'high', note: 'بناء دالة من نص' },
  { re: /child_process/, rule: 'danger:child-process', severity: 'medium', note: 'تشغيل عمليات من الكود الجديد — تحقق من القوائم' },
  { re: /(fetch|axios|got)\(\s*['"`]https?:\/\//, rule: 'net:new-endpoint', severity: 'medium', note: 'نقطة نهاية شبكية جديدة — ستظهر في سجل الخارج' },
  { re: /writeFile|rmSync|unlinkSync|rmdirSync/, rule: 'fs:write', severity: 'medium', note: 'كتابة/حذف ملفات — تحقق من المسارات' },
  { re: /process\.env/, rule: 'env:read', severity: 'low', note: 'قراءة متغيرات بيئة — لا تسرّب قيمها' },
]

/** Review a unified diff line by line: secrets, dangerous APIs, risk classes. */
export function reviewDiff(diff: string): SecurityReview {
  const findings: Finding[] = []
  const highRiskTouched: Array<{ file: string; risk: HighRiskClass; ar: string }> = []
  let file = '(unknown)'
  let line = 0

  for (const raw of diff.split('\n')) {
    if (raw.startsWith('+++ b/')) {
      file = raw.slice(6)
      const risk = classifyFileRisk(file)
      if (risk) highRiskTouched.push({ file, risk, ar: HIGH_RISK_AR[risk] })
      continue
    }
    if (raw.startsWith('@@')) {
      const m = /\+(\d+)/.exec(raw)
      line = m ? Number(m[1]) : 0
      continue
    }
    if (!raw.startsWith('+') || raw.startsWith('+++')) continue
    const text = raw.slice(1)
    line++
    for (const s of SECRET_RULES) {
      if (s.re.test(text)) findings.push({ severity: 'high', rule: s.rule, file, line, note: s.note })
    }
    for (const c of CODE_RULES) {
      if (c.re.test(text)) findings.push({ severity: c.severity, rule: c.rule, file, line, note: c.note })
    }
  }

  const hasHigh = findings.some((f) => f.severity === 'high') || highRiskTouched.length > 0
  return {
    verdict: hasHigh ? 'needs_attention' : 'clean',
    riskClass: highRiskTouched[0]?.risk ?? null,
    highRiskTouched,
    findings: findings.slice(0, 50),
    at: new Date().toISOString(),
  }
}
