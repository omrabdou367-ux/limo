import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import {
  activateProfile,
  clearActiveProfile,
  deleteProfile,
  getActiveProfile,
  listProfiles,
  upsertProfile,
} from '../db/router_profiles.js'
import type { ProviderRegistry } from '../providers/registry.js'
import { ProviderError } from '../providers/types.js'
import type { CircuitBreaker } from './breaker.js'

/**
 * Router routes — profiles (editable fallback chains) + live breaker states.
 * Chain entries are validated against the registry at SAVE time so a typo
 * cannot silently kill the ladder.
 */

const CHAIN_MAX = 10

export function registerRouterRoutes(
  app: FastifyInstance,
  ctx: { db: DB; registry: ProviderRegistry; breaker: CircuitBreaker },
): void {
  const { db, registry, breaker } = ctx

  app.get('/api/router', async () => {
    const profiles = listProfiles(db)
    const active = getActiveProfile(db)
    return {
      profiles,
      active: active?.name ?? null,
      breakers: breaker.snapshot(),
      semantics:
        'السلسلة النشطة سلّم الهبوط: يُجرَّب النموذج المطلوب أولًا ثم بقية السلسلة بالترتيب؛ بلا بروفايل نشط يُستخدم SIMPLE_FALLBACK.',
    }
  })

  app.put(
    '/api/router/profiles/:name',
    {
      schema: {
        params: {
          type: 'object',
          required: ['name'],
          properties: { name: { type: 'string', minLength: 2, maxLength: 64, pattern: '^[a-z0-9][a-z0-9-_]*$' } },
        },
        body: {
          type: 'object',
          required: ['chain'],
          additionalProperties: false,
          properties: {
            chain: {
              type: 'array',
              // 0 allowed: the UI creates the profile first, then fills the
              // ladder. resolveChain() degrades an empty active chain to
              // SIMPLE_FALLBACK, so an empty ladder is never dangerous.
              maxItems: CHAIN_MAX,
              items: { type: 'string', minLength: 3, maxLength: 256 },
            },
          },
        },
      },
    },
    async (request, reply) => {
      const { name } = request.params as { name: string }
      const { chain } = request.body as { chain: string[] }
      const bad: string[] = []
      for (const entry of chain) {
        try {
          registry.resolveModel(entry)
        } catch {
          bad.push(entry)
        }
      }
      if (bad.length > 0) {
        return reply.code(400).send({
          error: {
            message: `مدخلات غير قابلة للحل في السلسلة (تحقق من المزود والنموذج): ${bad.join(' · ')}`,
            type: 'invalid_chain',
            code: 400,
          },
        })
      }
      const deduped = [...new Set(chain)]
      const profile = upsertProfile(db, name, deduped)
      return { ok: true, profile }
    },
  )

  app.delete('/api/router/profiles/:name', async (request, reply) => {
    const { name } = request.params as { name: string }
    const active = getActiveProfile(db)
    if (active?.name === name) {
      return reply.code(409).send({
        error: { message: 'لا يمكن حذف البروفايل النشط — فعّل غيره أو أوقف التفعيل أولاً', type: 'active_profile', code: 409 },
      })
    }
    if (!deleteProfile(db, name)) {
      return reply.code(404).send({ error: { message: 'البروفايل غير موجود', type: 'not_found', code: 404 } })
    }
    return { ok: true }
  })

  app.post(
    '/api/router/active',
    {
      schema: {
        body: {
          type: 'object',
          additionalProperties: false,
          properties: { name: { type: 'string', minLength: 2, maxLength: 64 } },
        },
      },
    },
    async (request) => {
      const { name } = (request.body ?? {}) as { name?: string }
      if (name === undefined) {
        clearActiveProfile(db)
        return { ok: true, active: null }
      }
      if (!activateProfile(db, name)) {
        throw new ProviderError('model_not_found', `البروفايل غير موجود: ${name}`, 404)
      }
      return { ok: true, active: name }
    },
  )

  app.post('/api/router/breakers/:provider/reset', async (request) => {
    const { provider } = request.params as { provider: string }
    const ok = breaker.reset(provider)
    return { ok, provider }
  })
}
