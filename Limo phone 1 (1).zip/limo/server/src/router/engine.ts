import type { ServerConfig } from '../config.js'
import type { DB } from '../db/database.js'
import { getActiveProfile } from '../db/router_profiles.js'

/**
 * Router engine (PLAN.md §8.1.2) — resolves the ordered attempt chain for a
 * request. Semantics (locked, documented in the UI too):
 *
 *  1. Active profile chain exists:
 *     - requested model IS in the chain → try it first, then the rest of the
 *       chain in its saved order (the ladder resumes after the request).
 *     - requested model NOT in the chain → try it first, then the whole chain
 *       as the fallback ladder.
 *  2. No active profile → phase-1 behaviour: requested + SIMPLE_FALLBACK.
 *  3. Nothing configured → the requested model alone.
 *
 * The circuit breaker is consulted per attempt by the gateway, not here.
 */

export type ChainSource = 'profile' | 'simple' | 'single'

export interface ResolvedChain {
  chain: string[]
  source: ChainSource
  profileName: string | null
}

export function resolveChain(db: DB, config: ServerConfig, requestedModel: string): ResolvedChain {
  const profile = getActiveProfile(db)
  if (profile && profile.chain.length > 0) {
    const rest = profile.chain.filter((m) => m !== requestedModel)
    return {
      chain: [requestedModel, ...rest],
      source: 'profile',
      profileName: profile.name,
    }
  }
  const fallback = config.simpleFallback.filter((m) => m !== requestedModel)
  if (fallback.length > 0) {
    return { chain: [requestedModel, ...fallback], source: 'simple', profileName: null }
  }
  return { chain: [requestedModel], source: 'single', profileName: null }
}
