/**
 * Per-provider circuit breaker (PLAN.md §8.1.2).
 *
 * closed → (threshold failures within windowMs) → open
 * open   → (openMs cooldown elapsed)             → half-open (one probe allowed)
 * half-open → probe success → closed · probe failure → open again
 *
 * In-memory BY DESIGN: state is runtime health, not configuration; a restart
 * resets every breaker to closed, which the UI reports honestly. Local
 * configuration errors (vault locked, missing key) never count as provider
 * failures — only real upstream attempts do.
 */

export type BreakerState = 'closed' | 'open' | 'half-open'

export interface BreakerSnapshot {
  provider: string
  state: BreakerState
  failures: number
  lastFailureAt: string | null
  openedAt: string | null
  lastError: string | null
}

interface BreakerEntry {
  state: BreakerState
  failures: number
  windowStart: number
  lastFailureAt: number | null
  openedAt: number | null
  lastError: string | null
  probeInFlight: boolean
}

export interface BreakerOptions {
  /** Failures inside the rolling window before opening. */
  threshold: number
  /** Rolling failure window. */
  windowMs: number
  /** How long the breaker stays open before allowing a half-open probe. */
  openMs: number
  /** Injectable clock (tests). */
  now(): number
}

const DEFAULTS: BreakerOptions = {
  threshold: 3,
  windowMs: 60_000,
  openMs: 60_000,
  now: () => Date.now(),
}

export class CircuitBreaker {
  private entries = new Map<string, BreakerEntry>()

  constructor(private readonly opts: BreakerOptions = DEFAULTS) {}

  /** May this provider be attempted right now? A half-open probe is single-flight. */
  canAttempt(provider: string): boolean {
    const e = this.entries.get(provider)
    if (!e || e.state === 'closed') return true
    const now = this.opts.now()
    if (e.state === 'open') {
      if (now - (e.openedAt ?? 0) >= this.opts.openMs) {
        e.state = 'half-open'
        e.probeInFlight = false
      } else {
        return false
      }
    }
    if (e.state === 'half-open') {
      if (e.probeInFlight) return false
      e.probeInFlight = true // this call site owns the probe
      return true
    }
    return true
  }

  recordSuccess(provider: string): void {
    this.entries.delete(provider)
  }

  recordFailure(provider: string, error?: string): void {
    const now = this.opts.now()
    const e = this.entry(provider)
    e.lastFailureAt = now
    e.lastError = error?.slice(0, 300) ?? null
    if (e.state === 'half-open') {
      this.open(provider, now)
      return
    }
    if (now - e.windowStart > this.opts.windowMs) {
      e.windowStart = now
      e.failures = 0
    }
    e.failures++
    if (e.state === 'closed' && e.failures >= this.opts.threshold) this.open(provider, now)
  }

  /** Manual reset (UI button) — always allowed, always logged by the caller. */
  reset(provider: string): boolean {
    return this.entries.delete(provider)
  }

  snapshot(): BreakerSnapshot[] {
    return [...this.entries.entries()]
      .map(([provider, e]) => ({
        provider,
        state: e.state,
        failures: e.failures,
        lastFailureAt: e.lastFailureAt ? new Date(e.lastFailureAt).toISOString() : null,
        openedAt: e.openedAt ? new Date(e.openedAt).toISOString() : null,
        lastError: e.lastError,
      }))
      .sort((a, b) => a.provider.localeCompare(b.provider))
  }

  private open(provider: string, now: number): void {
    const e = this.entry(provider)
    e.state = 'open'
    e.openedAt = now
    e.probeInFlight = false
  }

  private entry(provider: string): BreakerEntry {
    let e = this.entries.get(provider)
    if (!e) {
      e = {
        state: 'closed',
        failures: 0,
        windowStart: this.opts.now(),
        lastFailureAt: null,
        openedAt: null,
        lastError: null,
        probeInFlight: false,
      }
      this.entries.set(provider, e)
    }
    return e
  }
}
