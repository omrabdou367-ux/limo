import { hash, verify } from '@node-rs/argon2'

/**
 * Passphrase hashing — argon2id with OWASP-recommended parameters
 * (m = 19 MiB, t = 2, p = 1). algorithm defaults to Argon2id in @node-rs/argon2
 * (const enum, not importable under isolatedModules) — asserted by a test that
 * the encoded hash starts with "$argon2id$". Same parameters derive the vault
 * KEK (vault/crypto.ts) but with an independent random salt.
 */
export const ARGON2_OPTS = {
  memoryCost: 19456,
  timeCost: 2,
  parallelism: 1,
}

export function hashPassphrase(passphrase: string): Promise<string> {
  return hash(passphrase, ARGON2_OPTS)
}

export function verifyPassphrase(hashValue: string, passphrase: string): Promise<boolean> {
  return verify(hashValue, passphrase)
}

export const PASSPHRASE_MIN = 10

export function passphraseIssues(passphrase: string): string[] {
  const issues: string[] = []
  if (passphrase.length < PASSPHRASE_MIN) {
    issues.push(`العبارة قصيرة — الحد الأدنى ${PASSPHRASE_MIN} محارف`)
  }
  return issues
}
