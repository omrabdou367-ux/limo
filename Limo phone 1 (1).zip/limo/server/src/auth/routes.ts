import { randomBytes } from 'node:crypto'
import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import { createApiKey, deleteApiKey, listApiKeys } from '../db/api_keys.js'
import { API_KEY_PREFIX, hashApiKey } from './guard.js'

/**
 * Auth routes — open mode (LIMO decision #8: the password system is removed).
 *
 * There is no setup, no login, no logout and no passphrase change: the local
 * owner simply IS authenticated. What remains is the programmatic surface —
 * Bearer omn_live_… API keys for curl, the OpenAI SDKs and the Tauri shell.
 */
export function registerAuthRoutes(app: FastifyInstance, ctx: { db: DB }): void {
  const { db } = ctx

  app.get('/api/auth/status', { config: { public: true } }, async () => ({
    initialized: true,
    mode: 'open' as const,
  }))

  app.get('/api/auth/me', async () => ({ ok: true, user: 'local-owner' }))

  app.get('/api/auth/api-keys', async () => listApiKeys(db))

  app.post(
    '/api/auth/api-keys',
    {
      schema: {
        body: {
          type: 'object',
          required: ['name'],
          additionalProperties: false,
          properties: { name: { type: 'string', minLength: 1, maxLength: 64 } },
        },
      },
    },
    async (request) => {
      const { name } = request.body as { name: string }
      const raw = `${API_KEY_PREFIX}${randomBytes(24).toString('hex')}`
      const row = createApiKey(db, name.trim(), raw.slice(0, 12), hashApiKey(raw))
      return { id: row.id, name: row.name, prefix: row.prefix, key: raw } // plaintext shown ONCE
    },
  )

  app.delete('/api/auth/api-keys/:id', async (request, reply) => {
    const { id } = request.params as { id: string }
    const num = Number(id)
    if (!Number.isInteger(num)) {
      return reply.code(400).send({ error: { message: 'معرّف غير صالح', type: 'bad_request', code: 400 } })
    }
    const ok = deleteApiKey(db, num)
    if (!ok) return reply.code(404).send({ error: { message: 'المفتاح غير موجود', type: 'not_found', code: 404 } })
    return { ok: true }
  })
}
