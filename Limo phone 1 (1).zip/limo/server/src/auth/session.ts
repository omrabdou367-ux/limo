import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto'
import type { DB } from '../db/database.js'
import { getSetting, setSetting } from '../db/settings.js'

/**
 * Stateless HMAC-signed session cookies.
 *
 * Key material lives in the DB (settings.session_hmac_key) so sessions
 * SURVIVE a reboot — while the VAULT locks (PLAN.md §7.2). Bumping the
 * session epoch revokes every outstanding cookie.
 */

export const SESSION_COOKIE = 'omnara_session'

export interface SessionPayload {
  sub: number // always 1 — single user
  iat: number
  exp: number
  ep: number // epoch at issue time
}

function b64url(buf: Buffer): string {
  return buf.toString('base64url')
}

export function getHmacKey(db: DB): string {
  const existing = getSetting(db, 'session_hmac_key')
  if (existing) return existing
  const key = randomBytes(32).toString('hex')
  setSetting(db, 'session_hmac_key', key)
  return key
}

export function getSessionEpoch(db: DB): number {
  return Number(getSetting(db, 'session_epoch') ?? '0')
}

export function bumpSessionEpoch(db: DB): void {
  setSetting(db, 'session_epoch', String(getSessionEpoch(db) + 1))
}

function sign(data: string, key: string): string {
  return createHmac('sha256', key).update(data).digest('base64url')
}

export function issueSession(db: DB, ttlHours: number): { token: string; payload: SessionPayload } {
  const key = getHmacKey(db)
  const now = Math.floor(Date.now() / 1000)
  const payload: SessionPayload = {
    sub: 1,
    iat: now,
    exp: Math.floor(now + ttlHours * 3600),
    ep: getSessionEpoch(db),
  }
  const body = b64url(Buffer.from(JSON.stringify(payload), 'utf8'))
  return { token: `${body}.${sign(body, key)}`, payload }
}

export function verifySession(db: DB, token: string | undefined): SessionPayload | null {
  if (!token) return null
  const dot = token.lastIndexOf('.')
  if (dot <= 0) return null
  const body = token.slice(0, dot)
  const sig = token.slice(dot + 1)
  const key = getHmacKey(db)
  const expected = sign(body, key)
  const a = Buffer.from(sig)
  const b = Buffer.from(expected)
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null
  let payload: SessionPayload
  try {
    payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')) as SessionPayload
  } catch {
    return null
  }
  const now = Math.floor(Date.now() / 1000)
  if (payload.exp <= now) return null
  if (payload.ep !== getSessionEpoch(db)) return null
  return payload
}

export function cookieOptions(maxAgeSeconds: number) {
  return {
    httpOnly: true,
    sameSite: 'lax' as const, // blocks the cookie on cross-site POSTs (CSRF)
    secure: false, // localhost / Tailscale http; https keeps working
    path: '/',
    maxAge: maxAgeSeconds,
  }
}
