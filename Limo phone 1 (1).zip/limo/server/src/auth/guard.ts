import { createHash } from 'node:crypto'
import type { FastifyReply, FastifyRequest } from 'fastify'
import type { DB } from '../db/database.js'
import { findApiKeyByHash, touchApiKey } from '../db/api_keys.js'
import type { ServerConfig } from '../config.js'

export type AuthContext =
  | { type: 'local' }
  | { type: 'key'; keyId: number; name: string }

declare module 'fastify' {
  interface FastifyRequest {
    auth?: AuthContext
  }
}

export const API_KEY_PREFIX = 'omn_live_'

export function hashApiKey(raw: string): string {
  return createHash('sha256').update(raw).digest('hex')
}

/**
 * Open-mode guard (LIMO decision #8 — the password system is removed).
 *
 * The local owner reaches every surface with NO credential: this is a
 * single-user, local-first machine and the server binds to 127.0.0.1. What
 * the guard still enforces:
 *  - a presented Bearer omn_live_… API key MUST be valid (curl, OpenAI SDKs,
 *    Tauri) — an invalid key is rejected, it never silently downgrades;
 *  - with ENFORCE_ORIGIN=true, cross-origin mutations are rejected.
 */
export async function authGuard(
  req: FastifyRequest,
  reply: FastifyReply,
  ctx: { db: DB; config: ServerConfig },
): Promise<void> {
  const authz = req.headers.authorization
  if (authz?.startsWith('Bearer ')) {
    const raw = authz.slice('Bearer '.length).trim()
    if (!raw.startsWith(API_KEY_PREFIX)) {
      return fail(reply, 'invalid_api_key', 'API key must start with omn_live_')
    }
    const row = findApiKeyByHash(ctx.db, hashApiKey(raw))
    if (!row) return fail(reply, 'invalid_api_key', 'unknown API key')
    touchApiKey(ctx.db, row.id)
    req.auth = { type: 'key', keyId: row.id, name: row.name }
    return
  }

  req.auth = { type: 'local' }

  if (ctx.config.enforceOrigin && !['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    const origin = req.headers.origin
    if (origin && !ctx.config.corsOrigins.includes(origin)) {
      return fail(reply, 'cross_origin_blocked', 'Origin not allowed')
    }
  }
}

function fail(reply: FastifyReply, code: string, message: string): void {
  reply.code(401).send({ error: { message, type: code, code: 401 } })
}
