import type { DB } from './database.js'

/** custom_providers — user-added OpenAI-compatible endpoints (PLAN.md §8.1.5). */

export interface CustomProviderRow {
  id: string
  label: string
  base_url: string
  needs_key: number
  enabled: number
  created_at: string
  updated_at: string
}

export interface CustomProvider {
  id: string
  label: string
  baseUrl: string
  needsKey: boolean
  enabled: boolean
  createdAt: string
  updatedAt: string
}

function toCustom(row: CustomProviderRow): CustomProvider {
  return {
    id: row.id,
    label: row.label,
    baseUrl: row.base_url,
    needsKey: row.needs_key === 1,
    enabled: row.enabled === 1,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  }
}

/** Ids the user may not claim for a custom provider (adapter namespace). */
export const BUILTIN_PROVIDER_IDS = new Set(['openrouter', 'groq', 'ollama'])

export const CUSTOM_ID_RE = /^[a-z][a-z0-9-]{1,31}$/

export function isValidCustomId(id: string): boolean {
  return CUSTOM_ID_RE.test(id) && !BUILTIN_PROVIDER_IDS.has(id)
}

export function listCustomProviders(db: DB): CustomProvider[] {
  return (db.prepare('SELECT * FROM custom_providers ORDER BY id').all() as CustomProviderRow[]).map(toCustom)
}

export function getCustomProvider(db: DB, id: string): CustomProvider | undefined {
  const row = db.prepare('SELECT * FROM custom_providers WHERE id = ?').get(id) as CustomProviderRow | undefined
  return row ? toCustom(row) : undefined
}

export function createCustomProvider(
  db: DB,
  p: { id: string; label: string; baseUrl: string; needsKey: boolean },
): CustomProvider {
  db.prepare('INSERT INTO custom_providers (id, label, base_url, needs_key, enabled) VALUES (?, ?, ?, ?, 1)').run(
    p.id,
    p.label,
    p.baseUrl,
    p.needsKey ? 1 : 0,
  )
  return getCustomProvider(db, p.id)!
}

export function updateCustomProvider(
  db: DB,
  id: string,
  p: { label?: string; baseUrl?: string; needsKey?: boolean; enabled?: boolean },
): CustomProvider | undefined {
  const current = getCustomProvider(db, id)
  if (!current) return undefined
  db.prepare(
    "UPDATE custom_providers SET label = ?, base_url = ?, needs_key = ?, enabled = ?, " +
      "updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?",
  ).run(
    p.label ?? current.label,
    p.baseUrl ?? current.baseUrl,
    (p.needsKey ?? current.needsKey) ? 1 : 0,
    (p.enabled ?? current.enabled) ? 1 : 0,
    id,
  )
  return getCustomProvider(db, id)
}

export function deleteCustomProvider(db: DB, id: string): boolean {
  return db.prepare('DELETE FROM custom_providers WHERE id = ?').run(id).changes > 0
}
