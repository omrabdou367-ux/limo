import type { DB } from './database.js'
import { getSettingJson, setSettingJson } from './settings.js'

/** catalog_models rows — the daily-aggregated live index (PLAN.md §8.1.1). */

export interface CatalogModelRow {
  provider: string
  model_id: string
  owned_by: string | null
  free: number
  context_length: number | null
  pricing_prompt: string | null
  pricing_completion: string | null
  source: string
  discovered_at: string
}

export interface CatalogRefreshState {
  at: string | null
  ok: boolean
  models: number
  freeModels: number
  durationMs: number
  errors: Array<{ source: string; error: string }>
}

const REFRESH_KEY = 'catalog_refresh'

export function getRefreshState(db: DB): CatalogRefreshState {
  return (
    getSettingJson<CatalogRefreshState>(db, REFRESH_KEY) ?? {
      at: null,
      ok: false,
      models: 0,
      freeModels: 0,
      durationMs: 0,
      errors: [],
    }
  )
}

export function setRefreshState(db: DB, state: CatalogRefreshState): void {
  setSettingJson(db, REFRESH_KEY, state)
}

export interface CatalogUpsert {
  provider: string
  modelId: string
  ownedBy?: string | null
  free?: boolean
  contextLength?: number | null
  pricingPrompt?: string | null
  pricingCompletion?: string | null
  source: string
  discoveredAt: string
}

/**
 * Replace one source's rows inside a caller-owned transaction: a successful
 * source refresh REPLACES its rows; a failed source keeps its stale rows so
 * the UI can show an honest "last successful aggregation" per provider.
 */
export function replaceSourceModels(db: DB, provider: string, rows: CatalogUpsert[]): void {
  db.prepare('DELETE FROM catalog_models WHERE provider = ?').run(provider)
  const insert = db.prepare(
    'INSERT INTO catalog_models (provider, model_id, owned_by, free, context_length, pricing_prompt, pricing_completion, source, discovered_at) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
  )
  for (const r of rows) {
    insert.run(
      r.provider,
      r.modelId,
      r.ownedBy ?? null,
      r.free ? 1 : 0,
      r.contextLength ?? null,
      r.pricingPrompt ?? null,
      r.pricingCompletion ?? null,
      r.source,
      r.discoveredAt,
    )
  }
}

export function listCatalogModels(db: DB): CatalogModelRow[] {
  return db
    .prepare('SELECT * FROM catalog_models ORDER BY provider, model_id')
    .all() as CatalogModelRow[]
}

export interface CatalogProviderSummary {
  provider: string
  models: number
  free: number
  discoveredAt: string | null
  source: string | null
}

export function catalogByProvider(db: DB): CatalogProviderSummary[] {
  return db
    .prepare(
      'SELECT provider, COUNT(*) AS models, SUM(free) AS free, MAX(discovered_at) AS discoveredAt, MAX(source) AS source ' +
        'FROM catalog_models GROUP BY provider ORDER BY provider',
    )
    .all() as CatalogProviderSummary[]
}

export function catalogModelFor(db: DB, provider: string, modelId: string): CatalogModelRow | undefined {
  return db
    .prepare('SELECT * FROM catalog_models WHERE provider = ? AND model_id = ?')
    .get(provider, modelId) as CatalogModelRow | undefined
}
