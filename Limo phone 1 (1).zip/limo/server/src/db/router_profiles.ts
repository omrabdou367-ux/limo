import type { DB } from './database.js'

/** router_profiles — editable fallback chains; exactly one active (PLAN.md §8.1.2). */

export interface RouterProfileRow {
  name: string
  chain: string // JSON array of prefixed model ids
  is_active: number
  created_at: string
  updated_at: string
}

export interface RouterProfile {
  name: string
  chain: string[]
  isActive: boolean
  createdAt: string
  updatedAt: string
}

function toProfile(row: RouterProfileRow): RouterProfile {
  let chain: string[] = []
  try {
    const parsed = JSON.parse(row.chain) as unknown
    if (Array.isArray(parsed)) chain = parsed.filter((m): m is string => typeof m === 'string')
  } catch {
    chain = [] // corrupted JSON never takes the router down
  }
  return {
    name: row.name,
    chain,
    isActive: row.is_active === 1,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  }
}

export function listProfiles(db: DB): RouterProfile[] {
  return (db.prepare('SELECT * FROM router_profiles ORDER BY name').all() as RouterProfileRow[]).map(toProfile)
}

export function getProfile(db: DB, name: string): RouterProfile | undefined {
  const row = db.prepare('SELECT * FROM router_profiles WHERE name = ?').get(name) as RouterProfileRow | undefined
  return row ? toProfile(row) : undefined
}

export function getActiveProfile(db: DB): RouterProfile | undefined {
  const row = db
    .prepare('SELECT * FROM router_profiles WHERE is_active = 1')
    .get() as RouterProfileRow | undefined
  return row ? toProfile(row) : undefined
}

/** Create or update a profile's chain. Activation is a separate explicit call. */
export function upsertProfile(db: DB, name: string, chain: string[]): RouterProfile {
  const tx = db.transaction((n: string, c: string[]) => {
    db.prepare(
      'INSERT INTO router_profiles (name, chain, is_active) VALUES (?, ?, 0) ' +
        "ON CONFLICT(name) DO UPDATE SET chain = excluded.chain, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')",
    ).run(n, JSON.stringify(c))
  })
  tx(name, chain)
  return getProfile(db, name)!
}

export function deleteProfile(db: DB, name: string): boolean {
  const active = getActiveProfile(db)
  if (active?.name === name) return false // refuse to delete the active chain
  return db.prepare('DELETE FROM router_profiles WHERE name = ?').run(name).changes > 0
}

/** Set the single active profile (deactivates all others in one transaction). */
export function activateProfile(db: DB, name: string): boolean {
  if (!getProfile(db, name)) return false
  const tx = db.transaction((n: string) => {
    db.prepare('UPDATE router_profiles SET is_active = 0').run()
    db.prepare(
      "UPDATE router_profiles SET is_active = 1, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE name = ?",
    ).run(n)
  })
  tx(name)
  return true
}

/** Deactivate everything — the router then uses SIMPLE_FALLBACK (phase-1 mode). */
export function clearActiveProfile(db: DB): void {
  db.prepare('UPDATE router_profiles SET is_active = 0').run()
}
