import type { DB } from './database.js'

export interface ProviderRow {
  id: string
  enabled: number
  base_url: string | null
  last_ok_at: string | null
  last_error: string | null
  updated_at: string
}

export function markProviderOk(db: DB, id: string): void {
  db.prepare(
    "INSERT INTO providers (id, last_ok_at, last_error) VALUES (?, strftime('%Y-%m-%dT%H:%M:%fZ','now'), NULL) " +
      "ON CONFLICT(id) DO UPDATE SET last_ok_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), last_error = NULL",
  ).run(id)
}

export function markProviderError(db: DB, id: string, error: string): void {
  db.prepare(
    'INSERT INTO providers (id, last_error) VALUES (?, ?) ' +
      'ON CONFLICT(id) DO UPDATE SET last_error = excluded.last_error',
  ).run(id, error.slice(0, 500))
}

export function getProviderStates(db: DB): ProviderRow[] {
  return db.prepare('SELECT * FROM providers').all() as ProviderRow[]
}
