import type { DB } from './database.js'

export interface ApiKeyRow {
  id: number
  name: string
  prefix: string
  key_hash: string
  created_at: string
  last_used_at: string | null
}

export interface ApiKeyInfo {
  id: number
  name: string
  prefix: string
  createdAt: string
  lastUsedAt: string | null
}

export function createApiKey(db: DB, name: string, prefix: string, keyHash: string): ApiKeyRow {
  const info = db
    .prepare('INSERT INTO api_keys (name, prefix, key_hash) VALUES (?, ?, ?)')
    .run(name, prefix, keyHash)
  return getApiKey(db, Number(info.lastInsertRowid))!
}

export function getApiKey(db: DB, id: number): ApiKeyRow | undefined {
  return db.prepare('SELECT * FROM api_keys WHERE id = ?').get(id) as ApiKeyRow | undefined
}

export function findApiKeyByHash(db: DB, keyHash: string): ApiKeyRow | undefined {
  return db.prepare('SELECT * FROM api_keys WHERE key_hash = ?').get(keyHash) as
    | ApiKeyRow
    | undefined
}

export function listApiKeys(db: DB): ApiKeyInfo[] {
  return db
    .prepare(
      'SELECT id, name, prefix, created_at AS createdAt, last_used_at AS lastUsedAt FROM api_keys ORDER BY id',
    )
    .all() as ApiKeyInfo[]
}

export function touchApiKey(db: DB, id: number): void {
  db.prepare(
    "UPDATE api_keys SET last_used_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?",
  ).run(id)
}

export function deleteApiKey(db: DB, id: number): boolean {
  return db.prepare('DELETE FROM api_keys WHERE id = ?').run(id).changes > 0
}
