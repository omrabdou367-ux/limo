-- Omnara schema 0001 — phase 1 (see PLAN.md §5)
-- settings      : key/value store (schema_version, passphrase hash, vault material, session HMAC key, epoch)
-- providers     : per-provider runtime state
-- keys          : BYOK secrets, AES-256-GCM encrypted per secret (vault)
-- api_keys      : Bearer tokens for OpenAI-compatible tools (hash only)
-- usage         : one row per gateway request
-- conversations : saved chats (+ messages child table — declared extension)

CREATE TABLE settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE providers (
  id           TEXT PRIMARY KEY,             -- 'openrouter' | 'groq' | 'ollama' | ...
  enabled      INTEGER NOT NULL DEFAULT 1,
  base_url     TEXT,
  last_ok_at   TEXT,
  last_error   TEXT,
  updated_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE keys (
  alias      TEXT PRIMARY KEY,               -- e.g. 'openrouter:default'
  provider   TEXT NOT NULL,
  ciphertext BLOB NOT NULL,
  iv         BLOB NOT NULL,
  tag        BLOB NOT NULL,
  hint       TEXT,                           -- last 4 chars, display only
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE api_keys (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  name         TEXT NOT NULL,
  prefix       TEXT NOT NULL,                -- first chars, display only
  key_hash     TEXT NOT NULL UNIQUE,         -- sha256 hex
  created_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  last_used_at TEXT
);

CREATE TABLE usage (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  ts                TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  provider          TEXT NOT NULL,
  model             TEXT NOT NULL,
  ok                INTEGER NOT NULL,
  prompt_tokens     INTEGER,
  completion_tokens INTEGER,
  duration_ms       INTEGER,
  error_kind        TEXT
);
CREATE INDEX idx_usage_ts ON usage(ts);

CREATE TABLE conversations (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  title      TEXT NOT NULL DEFAULT 'محادثة جديدة',
  model      TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE messages (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id    INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role       TEXT NOT NULL CHECK (role IN ('user','assistant','system')),
  content    TEXT NOT NULL,
  model      TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_messages_chat ON messages(chat_id, id);
