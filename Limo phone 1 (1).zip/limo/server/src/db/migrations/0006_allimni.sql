-- ALLIMNI v2 (LIMO #11) — the Universal Skills Ecosystem registry.
-- Extends the existing skills/skill_imports tables (never breaks old rows:
-- every new column has a default) and adds the immutable activity log.

-- registry: provenance + lifecycle (the directive's status machine)
ALTER TABLE skills ADD COLUMN skill_id TEXT;             -- skills.sh id tail (e.g. vercel-react-best-practices)
ALTER TABLE skills ADD COLUMN provider TEXT NOT NULL DEFAULT 'github';   -- skills.sh | github | local
ALTER TABLE skills ADD COLUMN installs INTEGER;          -- installs as measured by skills.sh AT DISCOVERY TIME (never live-updated)
ALTER TABLE skills ADD COLUMN risk_level TEXT;           -- NONE | LOW | MEDIUM | HIGH | CRITICAL | UNKNOWN (LIMO static scan)
ALTER TABLE skills ADD COLUMN compatibility TEXT;        -- COMPATIBLE | PARTIALLY_COMPATIBLE | INCOMPATIBLE | UNKNOWN
ALTER TABLE skills ADD COLUMN security_report TEXT;      -- full inspection report JSON at install time
ALTER TABLE skills ADD COLUMN agents TEXT NOT NULL DEFAULT '*';  -- '*' = all roles, or JSON array of role ids
ALTER TABLE skills ADD COLUMN last_check TEXT;           -- last update-check ISO time
ALTER TABLE skills ADD COLUMN update_available TEXT;     -- null | new commit hash string when upstream moved

-- the richer status machine (old rows keep 'active'|'disabled' — both are in the new set)
ALTER TABLE skills ADD COLUMN status2 TEXT;              -- discovered|inspecting|approval_required|installing|installed|active|disabled|update_available|failed|quarantined|removed

-- immutable activity log: every ALLIMNI action is recorded (never rewritten)
CREATE TABLE IF NOT EXISTS skill_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  skill_slug TEXT NOT NULL,
  action TEXT NOT NULL,          -- discovered|inspected|approved|rejected|installed|enabled|disabled|update_check|update_available|removed|agent_assigned|permission_denied
  detail TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_skill_events_slug ON skill_events (skill_slug, created_at);
