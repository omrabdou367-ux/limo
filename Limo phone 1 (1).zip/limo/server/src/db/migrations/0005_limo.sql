-- 0005_limo — LIMO AGENT transformation layer 1: projects (workspaces),
-- agent roles (multi-agent director), Allimni skill imports, workflows.
-- Forward-only (never edit shipped migrations); id 5.

CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  kind TEXT NOT NULL DEFAULT 'general',   -- general | web_app | creative | workflow
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- HYPERBRAIN: a task may be bound to a project workspace (sandboxed FS root)
ALTER TABLE agent_tasks ADD COLUMN project_id TEXT REFERENCES projects(id) ON DELETE SET NULL;
-- execution modes: auto | research | build | creative
ALTER TABLE agent_tasks ADD COLUMN mode TEXT NOT NULL DEFAULT 'auto';
-- multi-agent director: which specialized agent owns this step
ALTER TABLE agent_steps ADD COLUMN role TEXT;

-- ALLIMNI: the capability library (installed skills, never executed on install)
CREATE TABLE IF NOT EXISTS skills (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  version TEXT,
  description TEXT NOT NULL DEFAULT '',
  source TEXT NOT NULL DEFAULT 'allimni',  -- allimni | builtin
  source_url TEXT,
  repo_owner TEXT,
  repo_name TEXT,
  commit_hash TEXT,
  license TEXT,
  status TEXT NOT NULL DEFAULT 'active',   -- active | disabled
  manifest TEXT NOT NULL DEFAULT '{}',     -- parsed SKILL.md + file manifest + audit summary
  file_count INTEGER NOT NULL DEFAULT 0,
  installed_at TEXT NOT NULL
);

-- ALLIMNI: import pipeline audit trail (inspect -> approve/reject -> install)
CREATE TABLE IF NOT EXISTS skill_imports (
  id TEXT PRIMARY KEY,
  url TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'inspecting', -- inspecting | awaiting_approval | installed | rejected | failed
  report TEXT,                               -- full inspection report JSON
  error TEXT,
  requested_at TEXT NOT NULL,
  decided_at TEXT
);

-- Workflow Lab: editable ordered prompt chains run through the agent engine
CREATE TABLE IF NOT EXISTS workflows (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  steps TEXT NOT NULL DEFAULT '[]',          -- JSON: [{ title, prompt, role? }]
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS workflow_runs (
  id TEXT PRIMARY KEY,
  workflow_id TEXT NOT NULL REFERENCES workflows(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'running',    -- running | completed | partial | failed
  task_ids TEXT NOT NULL DEFAULT '[]',       -- JSON array of agent task ids
  detail TEXT,
  started_at TEXT NOT NULL,
  finished_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_workflow_runs_wf ON workflow_runs (workflow_id);
CREATE INDEX IF NOT EXISTS idx_agent_tasks_project ON agent_tasks (project_id);
