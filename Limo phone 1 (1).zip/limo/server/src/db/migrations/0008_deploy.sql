-- 0008_deploy — LIMO DEPLOYMENT COMMAND CENTER (directive §11–12, LIMO #20).
-- A real local ledger of real deployments: one row per deployment Vercel
-- actually accepted. State is updated from the API, never assumed.

CREATE TABLE IF NOT EXISTS deployments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  deployment_id TEXT NOT NULL UNIQUE,
  project TEXT NOT NULL,
  url TEXT,
  target TEXT NOT NULL CHECK (target IN ('preview', 'production')),
  state TEXT NOT NULL DEFAULT 'QUEUED',
  file_count INTEGER,
  total_bytes INTEGER,
  note TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_deployments_created ON deployments(created_at);
