-- Omnara schema 0003 — phase 3: the agent engine + the egress log
-- (PLAN.md §6 stage 3 + owner directive v2.2 #7)
--
-- egress_log        : «ما غادر الجهاز» — one row per OUTBOUND request:
--                     provider, model, payload SIZE + sha256 fingerprint.
--                     NO content is ever stored. left_machine=0 marks
--                     loopback endpoints (local Ollama etc.) so the screen
--                     can separate "left the machine" from "stayed local".
-- agent_tasks       : one planner→executor→critic run
-- agent_steps       : the plan steps with per-step evidence + critic verdicts
-- agent_events      : append-only timeline powering the SSE live console
-- agent_actions     : the action log — every tool call, risk class, approval
-- agent_approvals   : human-approval gate for dangerous categories
-- agent_memories    : vector memory (sqlite-vec runtime table) + user notes
-- agent_routines    : scheduled routines with the vault lock policy (§7.2)
--                     allow_downgrade defaults to 0 (owner directive v2.2 #5)
-- agent_routine_runs: honest per-run status (ok | skipped_vault_locked |
--                     degraded_vault_locked | error) — no fake success

CREATE TABLE egress_log (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  ts             TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  source         TEXT NOT NULL,             -- 'gateway' | 'compare' | 'agent' | 'forge' | 'catalog'
  provider       TEXT NOT NULL,
  model          TEXT,
  payload_bytes  INTEGER NOT NULL DEFAULT 0,
  payload_sha256 TEXT NOT NULL,             -- first 16 hex chars; content is NEVER stored
  left_machine   INTEGER NOT NULL DEFAULT 1, -- 0 = loopback endpoint (never left the machine)
  ok             INTEGER,                   -- null = dispatched, result not yet known
  error_kind     TEXT
);
CREATE INDEX idx_egress_ts ON egress_log(ts);
CREATE INDEX idx_egress_left ON egress_log(left_machine);

CREATE TABLE agent_tasks (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  goal       TEXT NOT NULL,
  model      TEXT NOT NULL,                 -- prefixed model id used by the engine
  status     TEXT NOT NULL DEFAULT 'queued',-- queued|planning|running|awaiting_approval|completed|failed|cancelled
  source     TEXT NOT NULL DEFAULT 'user',  -- 'user' | 'routine:<id>'
  plan       TEXT,                          -- JSON steps (validated)
  report     TEXT,                          -- JSON final report (deterministic, evidence-based)
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_agent_tasks_status ON agent_tasks(status);

CREATE TABLE agent_steps (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id    INTEGER NOT NULL REFERENCES agent_tasks(id) ON DELETE CASCADE,
  idx        INTEGER NOT NULL,
  title      TEXT NOT NULL,
  tool       TEXT,
  args       TEXT,                          -- JSON (secret-scrubbed)
  acceptance TEXT,                          -- what the critic checks
  status     TEXT NOT NULL DEFAULT 'pending', -- pending|running|done|failed|skipped
  result     TEXT,                          -- JSON evidence
  critic     TEXT,                          -- JSON verdict {pass, reason}
  attempts   INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_agent_steps_task ON agent_steps(task_id);

CREATE TABLE agent_events (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL REFERENCES agent_tasks(id) ON DELETE CASCADE,
  ts      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  kind    TEXT NOT NULL,
  data    TEXT                              -- JSON payload
);
CREATE INDEX idx_agent_events_task ON agent_events(task_id);

CREATE TABLE agent_actions (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id      INTEGER REFERENCES agent_tasks(id) ON DELETE CASCADE,
  ts           TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  tool         TEXT NOT NULL,
  args         TEXT NOT NULL,               -- JSON (secret-scrubbed)
  ok           INTEGER NOT NULL,
  result       TEXT,                        -- JSON evidence digest
  risk         TEXT,                        -- null for safe tools
  approval_id  INTEGER REFERENCES agent_approvals(id)
);
CREATE INDEX idx_agent_actions_task ON agent_actions(task_id);

CREATE TABLE agent_approvals (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id    INTEGER REFERENCES agent_tasks(id) ON DELETE CASCADE,
  category   TEXT NOT NULL,   -- payment|deletion|send|settings_change|software_install|secret_share
  summary    TEXT NOT NULL,   -- human-readable Arabic summary — never a secret
  payload    TEXT NOT NULL,   -- JSON of what will run (scrubbed)
  status     TEXT NOT NULL DEFAULT 'pending', -- pending|approved|rejected|expired
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  decided_at TEXT,
  decided_by TEXT
);

CREATE TABLE agent_memories (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  kind       TEXT NOT NULL DEFAULT 'note',  -- 'note' (user-owned) | 'episode' (task outcome)
  title      TEXT NOT NULL,
  content    TEXT NOT NULL,
  source     TEXT,                          -- 'user' | 'task:12' | 'routine:3'
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_agent_memories_kind ON agent_memories(kind);

CREATE TABLE agent_routines (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  name                TEXT NOT NULL UNIQUE,
  prompt              TEXT NOT NULL,
  model               TEXT NOT NULL,
  interval_sec        INTEGER NOT NULL DEFAULT 3600,
  enabled             INTEGER NOT NULL DEFAULT 1,
  allow_downgrade     INTEGER NOT NULL DEFAULT 0, -- v2.2 #5: default FALSE
  catch_up_on_unlock  INTEGER NOT NULL DEFAULT 0,
  pending_catchup     INTEGER NOT NULL DEFAULT 0,
  last_run_at         TEXT,
  next_run_at         TEXT NOT NULL,
  created_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE agent_routine_runs (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  routine_id INTEGER NOT NULL REFERENCES agent_routines(id) ON DELETE CASCADE,
  ts         TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  status     TEXT NOT NULL,  -- ok | skipped_vault_locked | degraded_vault_locked | error
  detail     TEXT,           -- model actually used / skip reason
  task_id    INTEGER REFERENCES agent_tasks(id)
);
CREATE INDEX idx_agent_routine_runs ON agent_routine_runs(routine_id);
