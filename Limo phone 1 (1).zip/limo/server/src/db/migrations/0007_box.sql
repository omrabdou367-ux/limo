-- 0007_box — the Black Box becomes a REAL chatbot (owner directive
-- 2026-11-01): a persistent chat log + an append-only audit trail of every
-- modification the box executed. Forward-only; id 7.

-- The Black Box conversation (survives reloads; the brain reads the tail)
CREATE TABLE IF NOT EXISTS box_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  role TEXT NOT NULL CHECK (role IN ('user', 'box')),
  content TEXT NOT NULL,
  -- JSON array of executed tool calls: [{ tool, args, ok, result }]
  actions TEXT,
  model TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Append-only audit: EVERY modification tool the box ran, success or failure
CREATE TABLE IF NOT EXISTS box_modifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tool TEXT NOT NULL,
  args TEXT NOT NULL,
  ok INTEGER NOT NULL DEFAULT 0,
  result TEXT,
  model TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE INDEX IF NOT EXISTS idx_box_messages_created ON box_messages(created_at);
CREATE INDEX IF NOT EXISTS idx_box_modifications_created ON box_modifications(created_at);
