-- Omnara schema 0004 — Reality Forge: the self-modification engine's records
-- (time machine). The audit trail is APPEND-ONLY by construction: the code
-- exposes no UPDATE/DELETE path for forge_change_events — rollback is a NEW
-- git commit + a NEW event, never history rewriting.

CREATE TABLE forge_changes (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  request        TEXT NOT NULL,               -- the natural-language request
  model          TEXT,                        -- model used by the agent team (null = deterministic analysis)
  status         TEXT NOT NULL DEFAULT 'analyzing',
                 -- analyzing|planned|implementing|testing|reviewing|awaiting_approval|applied|rejected|rolled_back|failed
  level          INTEGER NOT NULL DEFAULT 0,  -- autonomy level this run executes under (0..4)
  plan           TEXT,                        -- JSON: analysis + steps + affected files + risks
  branch         TEXT,                        -- sandbox branch (forge/<id>)
  worktree       TEXT,                        -- sandbox worktree path
  diff           TEXT,                        -- unified diff (proposed at L1, real at L2+)
  test_output    TEXT,                        -- guarded test run output digest
  security_review TEXT,                       -- JSON static findings
  commit_id      TEXT,                        -- merge commit after apply
  rollback_of    TEXT,                        -- the commit this change reverted (rollback rows)
  error          TEXT,
  created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_forge_changes_status ON forge_changes(status);

CREATE TABLE forge_change_events (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  change_id INTEGER NOT NULL REFERENCES forge_changes(id) ON DELETE CASCADE,
  ts        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  actor     TEXT NOT NULL,                    -- master|architect|engineer|qa|security|owner|system
  kind      TEXT NOT NULL,                    -- phase transitions & decisions
  data      TEXT NOT NULL                     -- JSON summary (secret-scrubbed)
);
CREATE INDEX idx_forge_change_events ON forge_change_events(change_id);

CREATE TABLE forge_inventory (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  ts      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  summary TEXT NOT NULL,                      -- JSON: layers, counts, edges, debt, dup pairs
  detail  TEXT NOT NULL                       -- JSON: full architecture map
);

CREATE TABLE forge_proposals (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  title      TEXT NOT NULL,
  kind       TEXT NOT NULL,                   -- debt|duplication|tests|architecture
  benefit    TEXT NOT NULL,                   -- expected benefit (required by the spec)
  risk       TEXT NOT NULL,                   -- risk of doing it
  components TEXT NOT NULL,                   -- affected components (JSON array)
  cost       TEXT NOT NULL,                   -- estimated cost
  validation TEXT NOT NULL,                   -- validation criteria
  status     TEXT NOT NULL DEFAULT 'proposed', -- proposed|accepted|dismissed — NEVER auto-applied
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
