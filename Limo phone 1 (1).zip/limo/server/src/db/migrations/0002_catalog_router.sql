-- Omnara schema 0002 — phase 2: live catalog, smart router, custom providers
-- (see PLAN.md §8.1)
--
-- catalog_models  : the daily-aggregated live model index (per-source refresh;
--                   rows from a source are REPLACED on success and KEPT stale
--                   when that source fails — the UI shows the honest timestamp)
-- router_profiles : editable fallback chains; exactly one is active (enforced
--                   in code inside one transaction)
-- custom_providers: user-added OpenAI-compatible endpoints (LM Studio,
--                   llama.cpp, vLLM, any /v1 provider) — dynamic adapters

CREATE TABLE catalog_models (
  provider           TEXT NOT NULL,               -- 'openrouter' | 'groq' | 'ollama' | custom id
  model_id           TEXT NOT NULL,               -- UNPREFIXED id, as the provider names it
  owned_by           TEXT,
  free               INTEGER NOT NULL DEFAULT 0,
  context_length     INTEGER,
  pricing_prompt     TEXT,                        -- declared $/1M prompt tokens (string decimal) or NULL
  pricing_completion TEXT,                        -- declared $/1M completion tokens or NULL
  source             TEXT NOT NULL,               -- which fetch produced this row, e.g. 'openrouter:/models'
  discovered_at      TEXT NOT NULL,               -- ISO timestamp of the refresh that wrote this row
  PRIMARY KEY (provider, model_id)
);
CREATE INDEX idx_catalog_provider ON catalog_models(provider);
CREATE INDEX idx_catalog_free ON catalog_models(free);

CREATE TABLE router_profiles (
  name       TEXT PRIMARY KEY,                    -- slug, e.g. 'free-ladder'
  chain      TEXT NOT NULL,                       -- JSON array of PREFIXED model ids, ordered
  is_active  INTEGER NOT NULL DEFAULT 0,          -- exactly one row may carry 1 (enforced in code)
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE custom_providers (
  id         TEXT PRIMARY KEY,                    -- slug; must NOT collide with builtin ids
  label      TEXT NOT NULL,
  base_url   TEXT NOT NULL,                       -- OpenAI-compatible root, e.g. http://127.0.0.1:1234/v1
  needs_key  INTEGER NOT NULL DEFAULT 1,
  enabled    INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
