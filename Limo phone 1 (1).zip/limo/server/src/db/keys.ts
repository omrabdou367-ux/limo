import type { DB } from './database.js'

/** Encrypted BYOK secret row — plaintext never touches this module. */
export interface KeyRow {
  alias: string
  provider: string
  ciphertext: Buffer
  iv: Buffer
  tag: Buffer
  hint: string | null
  created_at: string
  updated_at: string
}

export interface SecretInfo {
  alias: string
  provider: string
  hint: string | null
  updatedAt: string
}

export function putKey(
  db: DB,
  data: { alias: string; provider: string; ciphertext: Buffer; iv: Buffer; tag: Buffer; hint: string },
): void {
  db.prepare(
    "INSERT INTO keys (alias, provider, ciphertext, iv, tag, hint) VALUES (?, ?, ?, ?, ?, ?) " +
      "ON CONFLICT(alias) DO UPDATE SET provider = excluded.provider, ciphertext = excluded.ciphertext, " +
      "iv = excluded.iv, tag = excluded.tag, hint = excluded.hint, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')",
  ).run(data.alias, data.provider, data.ciphertext, data.iv, data.tag, data.hint)
}

export function getKey(db: DB, alias: string): KeyRow | undefined {
  return db.prepare('SELECT * FROM keys WHERE alias = ?').get(alias) as KeyRow | undefined
}

export function listKeys(db: DB): SecretInfo[] {
  return db
    .prepare('SELECT alias, provider, hint, updated_at AS updatedAt FROM keys ORDER BY alias')
    .all() as SecretInfo[]
}

export function deleteKey(db: DB, alias: string): boolean {
  return db.prepare('DELETE FROM keys WHERE alias = ?').run(alias).changes > 0
}
