import type { DB } from './database.js'
import { markProviderError, markProviderOk } from './providers.js'

export interface UsageRow {
  id: number
  ts: string
  provider: string
  model: string
  ok: number
  prompt_tokens: number | null
  completion_tokens: number | null
  duration_ms: number | null
  error_kind: string | null
}

export function recordUsage(
  db: DB,
  e: {
    provider: string
    model: string
    ok: boolean
    promptTokens?: number | null
    completionTokens?: number | null
    durationMs?: number | null
    errorKind?: string | null
  },
): void {
  db.prepare(
    'INSERT INTO usage (provider, model, ok, prompt_tokens, completion_tokens, duration_ms, error_kind) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?)',
  ).run(e.provider, e.model, e.ok ? 1 : 0, e.promptTokens ?? null, e.completionTokens ?? null, e.durationMs ?? null, e.errorKind ?? null)
  // The providers table doubles as the "last verified" clock (PLAN.md §8.1.3):
  // every real attempt — models fetch OR chat — updates it, so the usage board
  // can show an honest timestamp instead of a guessed quota state. Resolution
  // and configuration errors (typo'd model, locked vault, open breaker) are
  // NOT provider health signals and never touch it.
  if (e.ok) markProviderOk(db, e.provider)
  else if (
    e.errorKind &&
    e.errorKind !== 'vault_locked' &&
    e.errorKind !== 'breaker_open' &&
    e.errorKind !== 'model_not_found'
  ) {
    markProviderError(db, e.provider, `${e.errorKind}: ${e.model}`)
  }
}

export function recentUsage(db: DB, limit: number): UsageRow[] {
  return db.prepare('SELECT * FROM usage ORDER BY id DESC LIMIT ?').all(limit) as UsageRow[]
}

// ------------------------------------------------------------ aggregations

export interface UsageTotals {
  calls: number
  ok: number
  failed: number
  promptTokens: number
  completionTokens: number
  avgMs: number | null
}

export interface UsageByProvider {
  provider: string
  calls: number
  ok: number
  failed: number
  promptTokens: number
  completionTokens: number
  avgMs: number | null
  lastUsedAt: string | null
  lastOkAt: string | null
  lastError: string | null
}

export interface UsageByModel {
  provider: string
  model: string
  calls: number
  ok: number
  failed: number
  tokens: number
  lastUsedAt: string | null
}

export function usageTotalsSince(db: DB, sinceTs: string): UsageTotals {
  const row = db
    .prepare(
      'SELECT COUNT(*) AS calls, SUM(ok) AS ok, SUM(1-ok) AS failed, ' +
        'TOTAL(prompt_tokens) AS promptTokens, TOTAL(completion_tokens) AS completionTokens, AVG(duration_ms) AS avgMs ' +
        'FROM usage WHERE ts >= ?',
    )
    .get(sinceTs) as {
    calls: number
    ok: number | null
    failed: number | null
    promptTokens: number | null
    completionTokens: number | null
    avgMs: number | null
  }
  return {
    calls: row.calls ?? 0,
    ok: row.ok ?? 0,
    failed: row.failed ?? 0,
    promptTokens: Math.round(row.promptTokens ?? 0),
    completionTokens: Math.round(row.completionTokens ?? 0),
    avgMs: row.avgMs === null ? null : Math.round(row.avgMs),
  }
}

export function usageByProviderSince(db: DB, sinceTs: string): UsageByProvider[] {
  const rows = db
    .prepare(
      'SELECT provider, COUNT(*) AS calls, SUM(ok) AS ok, SUM(1-ok) AS failed, ' +
        'TOTAL(prompt_tokens) AS promptTokens, TOTAL(completion_tokens) AS completionTokens, ' +
        'AVG(duration_ms) AS avgMs, MAX(ts) AS lastUsedAt ' +
        'FROM usage WHERE ts >= ? GROUP BY provider ORDER BY calls DESC',
    )
    .all(sinceTs) as Array<Omit<UsageByProvider, 'lastOkAt' | 'lastError'> & { avgMs: number | null }>
  const providerState = new Map(
    (db.prepare('SELECT id, last_ok_at, last_error FROM providers').all() as Array<{
      id: string
      last_ok_at: string | null
      last_error: string | null
    }>).map((p) => [p.id, p]),
  )
  return rows.map((r) => ({
    provider: r.provider,
    calls: r.calls,
    ok: r.ok ?? 0,
    failed: r.failed ?? 0,
    promptTokens: Math.round(r.promptTokens ?? 0),
    completionTokens: Math.round(r.completionTokens ?? 0),
    avgMs: r.avgMs === null ? null : Math.round(r.avgMs),
    lastUsedAt: r.lastUsedAt,
    lastOkAt: providerState.get(r.provider)?.last_ok_at ?? null,
    lastError: providerState.get(r.provider)?.last_error ?? null,
  }))
}

export function usageByModelSince(db: DB, sinceTs: string, limit = 15): UsageByModel[] {
  return db
    .prepare(
      'SELECT provider, model, COUNT(*) AS calls, SUM(ok) AS ok, SUM(1-ok) AS failed, ' +
        'TOTAL(prompt_tokens) + TOTAL(completion_tokens) AS tokens, MAX(ts) AS lastUsedAt ' +
        'FROM usage WHERE ts >= ? GROUP BY provider, model ORDER BY calls DESC LIMIT ?',
    )
    .all(sinceTs, limit) as UsageByModel[]
}

export function recentErrors(db: DB, limit = 10): UsageRow[] {
  return db
    .prepare('SELECT * FROM usage WHERE ok = 0 ORDER BY id DESC LIMIT ?')
    .all(limit) as UsageRow[]
}
