import type { DB } from './database.js'

export interface ConversationRow {
  id: number
  title: string
  model: string | null
  created_at: string
  updated_at: string
}

export interface ConversationInfo {
  id: number
  title: string
  model: string | null
  createdAt: string
  updatedAt: string
}

export interface MessageRow {
  id: number
  chatId: number
  role: 'user' | 'assistant' | 'system'
  content: string
  model: string | null
  createdAt: string
}

const DEFAULT_TITLE = 'محادثة جديدة'

export function createConversation(db: DB, title?: string, model?: string): ConversationRow {
  const info = db
    .prepare('INSERT INTO conversations (title, model) VALUES (?, ?)')
    .run(title?.trim() || DEFAULT_TITLE, model ?? null)
  return getConversation(db, Number(info.lastInsertRowid))!
}

export function getConversation(db: DB, id: number): ConversationRow | undefined {
  return db.prepare('SELECT * FROM conversations WHERE id = ?').get(id) as
    | ConversationRow
    | undefined
}

export function listConversations(db: DB): ConversationInfo[] {
  return db
    .prepare(
      'SELECT id, title, model, created_at AS createdAt, updated_at AS updatedAt ' +
        'FROM conversations ORDER BY updated_at DESC, id DESC',
    )
    .all() as ConversationInfo[]
}

export function updateConversation(
  db: DB,
  id: number,
  patch: { title?: string; model?: string },
): boolean {
  const cur = getConversation(db, id)
  if (!cur) return false
  db.prepare(
    "UPDATE conversations SET title = ?, model = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?",
  ).run(patch.title?.trim() || cur.title, patch.model ?? cur.model, id)
  return true
}

export function deleteConversation(db: DB, id: number): boolean {
  return db.prepare('DELETE FROM conversations WHERE id = ?').run(id).changes > 0
}

export function addMessage(
  db: DB,
  chatId: number,
  role: MessageRow['role'],
  content: string,
  model?: string | null,
): MessageRow {
  const conv = getConversation(db, chatId)
  if (!conv) throw Object.assign(new Error('conversation not found'), { statusCode: 404 })
  const info = db
    .prepare('INSERT INTO messages (chat_id, role, content, model) VALUES (?, ?, ?, ?)')
    .run(chatId, role, content, model ?? null)
  // auto-title from the first user message (first 48 chars, no newlines)
  if (role === 'user' && (conv.title === DEFAULT_TITLE || conv.title === '')) {
    const t = content.replace(/\s+/g, ' ').trim().slice(0, 48)
    if (t) db.prepare('UPDATE conversations SET title = ? WHERE id = ?').run(t, chatId)
  }
  db.prepare(
    "UPDATE conversations SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?",
  ).run(chatId)
  return getMessage(db, Number(info.lastInsertRowid))!
}

export function getMessage(db: DB, id: number): MessageRow | undefined {
  const row = db
    .prepare(
      'SELECT id, chat_id AS chatId, role, content, model, created_at AS createdAt FROM messages WHERE id = ?',
    )
    .get(id) as MessageRow | undefined
  return row
}

export function listMessages(db: DB, chatId: number): MessageRow[] {
  return db
    .prepare(
      'SELECT id, chat_id AS chatId, role, content, model, created_at AS createdAt ' +
        'FROM messages WHERE chat_id = ? ORDER BY id',
    )
    .all(chatId) as MessageRow[]
}
