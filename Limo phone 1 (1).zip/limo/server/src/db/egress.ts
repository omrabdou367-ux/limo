import { createHash } from 'node:crypto'
import type { DB } from './database.js'
import type { ServerConfig } from '../config.js'
import { listCustomProviders } from './custom_providers.js'

/**
 * The egress log — «ما غادر الجهاز» (owner directive v2.2 #7).
 *
 * One row per OUTBOUND request: provider, model, payload SIZE and a sha256
 * FINGERPRINT. Content is NEVER stored — not the messages, not the key, not
 * a snippet. loopback endpoints (local Ollama / localhost custom providers)
 * are recorded with left_machine = 0 so the screen can tell "left the
 * machine" apart from "stayed local".
 *
 * Recorded from: the /v1 gateway, comparison mode, the agent engine and the
 * catalog aggregator. Any future outbound path MUST record here too.
 */

export type EgressSource = 'gateway' | 'compare' | 'agent' | 'forge' | 'catalog' | 'workflow' | 'box'

export interface EgressRow {
  id: number
  ts: string
  source: string
  provider: string
  model: string | null
  payload_bytes: number
  payload_sha256: string
  left_machine: number
  ok: number | null
  error_kind: string | null
}

/** Fingerprint a payload WITHOUT keeping it: byte length + first 16 hex of sha256. */
export function fingerprint(payload: string): { bytes: number; sha256: string } {
  const buf = Buffer.from(payload, 'utf8')
  return { bytes: buf.length, sha256: createHash('sha256').update(buf).digest('hex').slice(0, 16) }
}

const LOOPBACK_HOSTS = new Set(['localhost', '127.0.0.1', '::1', '[::1]', '0.0.0.0', ''])

/** Does a base URL point at this machine? (loopback = the request never left) */
export function isLoopbackUrl(url: string): boolean {
  try {
    const u = new URL(url)
    return LOOPBACK_HOSTS.has(u.hostname) || u.hostname.endsWith('.localhost') || u.hostname.endsWith('.local')
  } catch {
    return false
  }
}

/**
 * Which provider endpoints are loopback? Resolved per provider id:
 *  - ollama            → config.ollamaBaseUrl
 *  - openrouter / groq → always remote (their documented clouds)
 *  - anything else     → the custom_providers table row's base_url
 */
export function providerIsLocal(db: DB, config: ServerConfig, providerId: string): boolean {
  if (providerId === 'openrouter' || providerId === 'groq') return false
  if (providerId === 'ollama') return isLoopbackUrl(config.ollamaBaseUrl)
  const row = listCustomProviders(db).find((p) => p.id === providerId)
  return row ? isLoopbackUrl(row.baseUrl) : true
}

/** Record a dispatch. Returns the row id so the caller can update ok/error later. */
export function recordEgress(
  db: DB,
  e: {
    source: EgressSource
    provider: string
    model?: string | null
    payload: string
    config: ServerConfig
    ok?: boolean | null
    errorKind?: string | null
  },
): number {
  const { bytes, sha256 } = fingerprint(e.payload)
  const info = db
    .prepare(
      'INSERT INTO egress_log (source, provider, model, payload_bytes, payload_sha256, left_machine, ok, error_kind) ' +
        'VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    )
    .run(
      e.source,
      e.provider,
      e.model ?? null,
      bytes,
      sha256,
      providerIsLocal(db, e.config, e.provider) ? 0 : 1,
      e.ok === undefined || e.ok === null ? null : e.ok ? 1 : 0,
      e.errorKind ?? null,
    )
  return Number(info.lastInsertRowid)
}

/** Fill in the outcome once the upstream call finished (dispatch happened first). */
export function updateEgress(db: DB, id: number, ok: boolean, errorKind?: string | null): void {
  db.prepare('UPDATE egress_log SET ok = ?, error_kind = ? WHERE id = ?').run(ok ? 1 : 0, errorKind ?? null, id)
}

export function listEgress(
  db: DB,
  opts: { leftOnly?: boolean; limit?: number; source?: string } = {},
): EgressRow[] {
  const limit = Math.min(Math.max(opts.limit ?? 100, 1), 500)
  const where: string[] = []
  const params: unknown[] = []
  if (opts.leftOnly) {
    where.push('left_machine = 1')
  }
  if (opts.source) {
    where.push('source = ?')
    params.push(opts.source)
  }
  const sql =
    'SELECT * FROM egress_log' +
    (where.length ? ` WHERE ${where.join(' AND ')}` : '') +
    ' ORDER BY id DESC LIMIT ?'
  return db.prepare(sql).all(...params, limit) as EgressRow[]
}

export interface EgressCounts {
  total: number
  leftMachine: number
  local: number
  bytesLeft: number
}

export function egressCounts(db: DB): EgressCounts {
  const row = db
    .prepare(
      'SELECT COUNT(*) AS total, TOTAL(left_machine) AS leftMachine, TOTAL(payload_bytes * left_machine) AS bytesLeft FROM egress_log',
    )
    .get() as { total: number; leftMachine: number | null; bytesLeft: number | null }
  return {
    total: row.total ?? 0,
    leftMachine: Math.round(row.leftMachine ?? 0),
    local: (row.total ?? 0) - Math.round(row.leftMachine ?? 0),
    bytesLeft: Math.round(row.bytesLeft ?? 0),
  }
}
