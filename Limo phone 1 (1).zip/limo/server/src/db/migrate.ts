import { readFileSync } from 'node:fs'
import type { DB } from './database.js'

interface Migration {
  id: number
  name: string
  sql: string
}

function read(name: string): string {
  // ESM + tsx: resolve relative to this module file
  return readFileSync(new URL(`./migrations/${name}.sql`, import.meta.url), 'utf8')
}

/** Append new migrations here — ids strictly increasing, never edit shipped ones. */
const MIGRATIONS: Migration[] = [
  { id: 1, name: '0001_init', sql: read('0001_init') },
  { id: 2, name: '0002_catalog_router', sql: read('0002_catalog_router') },
  { id: 3, name: '0003_agent_egress', sql: read('0003_agent_egress') },
  { id: 4, name: '0004_forge', sql: read('0004_forge') },
  { id: 5, name: '0005_limo', sql: read('0005_limo') },
  { id: 6, name: '0006_allimni', sql: read('0006_allimni') },
  { id: 7, name: '0007_box', sql: read('0007_box') },
  { id: 8, name: '0008_deploy', sql: read('0008_deploy') },
]

export function migrate(db: DB): void {
  // Migrations own ALL DDL (including the settings table itself); reading
  // the version on a brand-new DB just fails softly.
  let current = 0
  try {
    const row = db.prepare("SELECT value FROM settings WHERE key = 'schema_version'").get() as
      | { value: string }
      | undefined
    current = row ? Number(row.value) : 0
  } catch {
    current = 0
  }
  const pending = MIGRATIONS.filter((m) => m.id > current)
  if (pending.length === 0) return
  const apply = db.transaction((migs: Migration[]) => {
    for (const m of migs) {
      db.exec(m.sql)
      db.prepare(
        "INSERT INTO settings (key, value) VALUES ('schema_version', ?) " +
          'ON CONFLICT(key) DO UPDATE SET value = excluded.value',
      ).run(String(m.id))
    }
  })
  apply(pending)
}
