import { randomBytes } from 'node:crypto'
import type { DB } from '../db/database.js'
import { getSettingJson, setSettingJson } from '../db/settings.js'
import { getKey, listKeys, putKey, deleteKey } from '../db/keys.js'
import { aesGcmDecrypt, aesGcmEncrypt, deriveKek, deriveKekSync, newSalt } from './crypto.js'

/**
 * The key vault — open mode (LIMO decision #8: the password system is removed).
 *
 * Lock policy:
 *  - process start  -> the vault unwraps ITSELF with the machine key file
 *    (dataDir/vault.key, 0600) — no passphrase, no setup, no login.
 *  - process exit   -> locked again (master key buffer zeroed); next boot
 *    re-unwraps automatically.
 *  - legacy vaults  -> pre-#8 vaults were wrapped with a passphrase KEK
 *    (argon2id). They cannot self-unwrap; boot logs a warning and
 *    scripts/migrate-vault.ts converts them once, keeping every secret.
 *
 * Secrets are never returned to any client — only alias + provider + last 4.
 */

const VAULT_SALT_KEY = 'vault_salt'
const VAULT_WRAPPED_KEY = 'vault_wrapped_master'
const VAULT_CHECK = 'vault_check'
/** 'scrypt' = machine key (open mode) · missing/'argon2id' = legacy passphrase. */
const VAULT_KEK_ALGO_KEY = 'vault_kek_algo'
const CHECK_PLAINTEXT = 'omnara-vault-check-v1'

interface WrappedMaster {
  ciphertext: string // base64
  iv: string
  tag: string
}

interface CheckBlob {
  ciphertext: string
  iv: string
  tag: string
}

export type VaultState = 'locked' | 'unlocked' | 'uninitialized'

export class Vault {
  private master: Buffer | null = null
  state: VaultState = 'uninitialized'

  constructor(private readonly db: DB) {
    const salt = getSettingJson<Buffer>(db, VAULT_SALT_KEY)
    const wrapped = getSettingJson<WrappedMaster>(db, VAULT_WRAPPED_KEY)
    this.state = salt && wrapped ? 'locked' : 'uninitialized'
  }

  get isUnlocked(): boolean {
    return this.state === 'unlocked'
  }

  /** True when the stored material is a legacy passphrase (argon2id) wrap. */
  get isLegacy(): boolean {
    if (this.state === 'uninitialized') return false
    const algo = getSettingJson<string>(this.db, VAULT_KEK_ALGO_KEY)
    return algo !== 'scrypt'
  }

  /** First-run initialization: create the master key wrapped by the machine secret. */
  setup(secret: string): void {
    if (this.state !== 'uninitialized') throw new Error('vault already initialized')
    this.writeMaterial(secret, randomBytes(32))
    this.state = 'unlocked'
  }

  /** Unwrap with the machine secret (scrypt KEK). Legacy wraps return false. */
  unlock(secret: string): boolean {
    if (this.state === 'uninitialized') return false
    if (this.isUnlocked) return true
    if (this.isLegacy) return false // run scripts/migrate-vault.ts once
    const master = this.unwrapScrypt(secret)
    if (!master) return false
    this.master = master
    this.state = 'unlocked'
    return true
  }

  /** Boot helper: initialize-or-unwrap with the machine secret. false ⇒ legacy. */
  bootWithMachineSecret(secret: string): boolean {
    if (this.state === 'uninitialized') {
      this.setup(secret)
      return true
    }
    return this.unlock(secret)
  }

  lock(): void {
    if (this.master) this.master.fill(0)
    this.master = null
    if (this.state === 'unlocked') this.state = 'locked'
  }

  /** Re-wrap the SAME master key under a new machine secret. */
  rewrap(currentSecret: string, nextSecret: string): boolean {
    if (this.state === 'uninitialized') return false
    if (this.isLegacy) return false
    const master = this.unwrapScrypt(currentSecret)
    if (!master) return false
    this.writeMaterial(nextSecret, master)
    this.state = 'unlocked'
    return true
  }

  /**
   * One-time legacy migration (argon2id passphrase wrap → machine-key wrap).
   * Keeps the SAME master key, so every stored secret survives untouched.
   */
  async migrateLegacyPassphrase(passphrase: string, machineSecret: string): Promise<boolean> {
    if (this.state === 'uninitialized') return false
    const saltRow = getSettingJson<{ b64: string }>(this.db, VAULT_SALT_KEY)
    const wrapped = getSettingJson<WrappedMaster>(this.db, VAULT_WRAPPED_KEY)
    const check = getSettingJson<CheckBlob>(this.db, VAULT_CHECK)
    if (!saltRow || !wrapped || !check) return false
    try {
      const kek = await deriveKek(passphrase, Buffer.from(saltRow.b64, 'base64'))
      const master = aesGcmDecrypt(kek, fromB64(wrapped))
      const checkPlain = aesGcmDecrypt(master, fromB64(check)).toString('utf8')
      if (checkPlain !== CHECK_PLAINTEXT) return false
      this.writeMaterial(machineSecret, master)
      this.state = 'unlocked'
      return true
    } catch {
      return false // wrong passphrase (GCM auth failure) — no details leaked
    }
  }

  /** Store a provider secret (requires unlocked vault). */
  putSecret(alias: string, provider: string, value: string): void {
    const master = this.requireMaster()
    const sealed = aesGcmEncrypt(master, value)
    const hint = value.length <= 4 ? '••••' : value.slice(-4)
    putKey(this.db, { alias, provider, ...sealed, hint })
  }

  /** Fetch plaintext for an adapter — server-side only, never logged. */
  getSecret(alias: string): string | null {
    if (!this.isUnlocked) return null
    const row = getKey(this.db, alias)
    if (!row) return null
    try {
      return aesGcmDecrypt(this.master!, {
        ciphertext: row.ciphertext,
        iv: row.iv,
        tag: row.tag,
      }).toString('utf8')
    } catch {
      return null
    }
  }

  hasSecret(alias: string): boolean {
    return getKey(this.db, alias) !== undefined
  }

  removeSecret(alias: string): boolean {
    return deleteKey(this.db, alias)
  }

  /** Display-safe listing — no plaintext, no full keys. */
  listSecrets() {
    return listKeys(this.db)
  }

  /** (Re)write the wrapped material under a scrypt KEK from `secret`. */
  private writeMaterial(secret: string, master: Buffer): void {
    const salt = newSalt()
    const kek = deriveKekSync(secret, salt)
    const wrapped = aesGcmEncrypt(kek, master)
    const check = aesGcmEncrypt(master, CHECK_PLAINTEXT)
    setSettingJson(this.db, VAULT_SALT_KEY, { b64: salt.toString('base64') })
    setSettingJson(this.db, VAULT_WRAPPED_KEY, toB64(wrapped))
    setSettingJson(this.db, VAULT_CHECK, toB64(check))
    setSettingJson(this.db, VAULT_KEK_ALGO_KEY, 'scrypt')
    this.master = master
  }

  /** Unwrap via scrypt; also verifies the check blob. null ⇒ wrong secret. */
  private unwrapScrypt(secret: string): Buffer | null {
    const saltRow = getSettingJson<{ b64: string }>(this.db, VAULT_SALT_KEY)
    const wrapped = getSettingJson<WrappedMaster>(this.db, VAULT_WRAPPED_KEY)
    const check = getSettingJson<CheckBlob>(this.db, VAULT_CHECK)
    if (!saltRow || !wrapped || !check) return null
    try {
      const kek = deriveKekSync(secret, Buffer.from(saltRow.b64, 'base64'))
      const master = aesGcmDecrypt(kek, fromB64(wrapped))
      const checkPlain = aesGcmDecrypt(master, fromB64(check)).toString('utf8')
      if (checkPlain !== CHECK_PLAINTEXT) return null
      return master
    } catch {
      return null // wrong secret (GCM auth failure) — no details leaked
    }
  }

  private requireMaster(): Buffer {
    if (!this.isUnlocked || !this.master) {
      const err = new Error('vault is locked') as Error & { statusCode?: number; code?: string }
      err.statusCode = 409
      err.code = 'vault_locked'
      throw err
    }
    return this.master
  }
}

function toB64(s: { ciphertext: Buffer; iv: Buffer; tag: Buffer }) {
  return {
    ciphertext: s.ciphertext.toString('base64'),
    iv: s.iv.toString('base64'),
    tag: s.tag.toString('base64'),
  }
}

function fromB64(s: { ciphertext: string; iv: string; tag: string }) {
  return {
    ciphertext: Buffer.from(s.ciphertext, 'base64'),
    iv: Buffer.from(s.iv, 'base64'),
    tag: Buffer.from(s.tag, 'base64'),
  }
}
