import { createCipheriv, createDecipheriv, randomBytes, scryptSync } from 'node:crypto'
import { hashRaw } from '@node-rs/argon2'

/**
 * Vault cryptography (PLAN.md §7, LIMO decision #8 — open mode):
 *  - KEK  = scrypt(machine_secret, vault_salt) — the machine secret is a
 *    256-bit random key file, so a heavy KDF adds nothing; scrypt keeps it
 *    synchronous (the vault unwraps itself at boot, before any request).
 *  - master key = random 32 bytes, stored ONLY wrapped by the KEK (AES-256-GCM)
 *  - each secret = AES-256-GCM(master, secret) with its own random 12-byte IV
 * The master key lives in process memory only; process exit = locked (§7.2).
 * deriveKek (argon2id) survives ONLY for the one-time legacy migration
 * (scripts/migrate-vault.ts) — pre-#8 vaults were wrapped with a passphrase.
 */

export interface Sealed {
  ciphertext: Buffer
  iv: Buffer
  tag: Buffer
}

export const ARGON2_KEK_OPTS = {
  memoryCost: 19456,
  timeCost: 2,
  parallelism: 1,
}

export function newSalt(): Buffer {
  return randomBytes(16)
}

/** LEGACY (pre-#8) passphrase KEK — used only by the one-time migration. */
export async function deriveKek(passphrase: string, salt: Buffer): Promise<Buffer> {
  return Buffer.from(await hashRaw(passphrase, { salt, ...ARGON2_KEK_OPTS }))
}

/** Machine-secret KEK (open mode) — synchronous by design. */
export function deriveKekSync(secret: string, salt: Buffer): Buffer {
  return scryptSync(secret, salt, 32, { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 })
}

export function aesGcmEncrypt(key: Buffer, plaintext: Buffer | string): Sealed {
  const iv = randomBytes(12)
  const cipher = createCipheriv('aes-256-gcm', key, iv)
  const data = Buffer.isBuffer(plaintext) ? plaintext : Buffer.from(plaintext, 'utf8')
  const ciphertext = Buffer.concat([cipher.update(data), cipher.final()])
  return { ciphertext, iv, tag: cipher.getAuthTag() }
}

export function aesGcmDecrypt(key: Buffer, sealed: Sealed): Buffer {
  const decipher = createDecipheriv('aes-256-gcm', key, sealed.iv)
  decipher.setAuthTag(sealed.tag)
  return Buffer.concat([decipher.update(sealed.ciphertext), decipher.final()])
}
