import { chmodSync, existsSync, readFileSync, writeFileSync } from 'node:fs'
import { randomBytes } from 'node:crypto'
import { join } from 'node:path'

/**
 * The machine key (LIMO decision #8 — password system removed).
 *
 * A 256-bit random secret generated once per data directory and stored beside
 * the database (vault.key, mode 0600). The vault wraps its master key with a
 * KEK derived from THIS file, so the vault unwraps itself at every boot —
 * no passphrase, no setup screen, no login. Anyone who can read the data
 * directory already owns the machine; the file just keeps `vault.key` from
 * leaking casually with the (worldlier) database file.
 */
export const MACHINE_KEY_FILE = 'vault.key'

export function ensureMachineKey(dataDir: string): string {
  const file = join(dataDir, MACHINE_KEY_FILE)
  if (existsSync(file)) {
    const existing = readFileSync(file, 'utf8').trim()
    if (existing.length >= 64) return existing
  }
  const key = randomBytes(32).toString('hex')
  writeFileSync(file, `${key}\n`, { mode: 0o600 })
  chmodSync(file, 0o600)
  return key
}
