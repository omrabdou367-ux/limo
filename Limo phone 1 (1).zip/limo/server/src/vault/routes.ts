import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Vault } from '../vault/vault.js'
import { KEY_ALIASES, type ProviderRegistry } from '../providers/registry.js'

/**
 * Vault routes (open mode, LIMO decision #8). The vault unlocks itself at
 * boot with the machine key — there is no unlock/lock endpoint anymore.
 * Plaintext secrets are WRITE-ONLY: PUT accepts a value, nothing ever
 * returns it (display uses the last-4 hint only).
 */
export function registerVaultRoutes(
  app: FastifyInstance,
  ctx: { db: DB; config: ServerConfig; vault: Vault; registry: ProviderRegistry },
): void {
  const { vault, registry, config, db } = ctx

  app.get('/api/vault/status', async () => ({
    state: vault.state, // 'uninitialized' | 'locked' | 'unlocked'
    legacy: vault.isLegacy,
  }))

  app.get('/api/vault/secrets', async () => ({
    state: vault.state,
    secrets: vault.listSecrets(), // alias/provider/hint only
  }))

  app.put(
    '/api/vault/secrets',
    {
      schema: {
        body: {
          type: 'object',
          required: ['alias', 'provider', 'value'],
          additionalProperties: false,
          properties: {
            alias: { type: 'string', minLength: 3, maxLength: 128 },
            provider: { type: 'string', minLength: 2, maxLength: 64 },
            value: { type: 'string', minLength: 8, maxLength: 4096 },
          },
        },
      },
    },
    async (request, reply) => {
      const { alias, provider, value } = request.body as { alias: string; provider: string; value: string }
      try {
        vault.putSecret(alias, provider, value)
      } catch (e) {
        const code = (e as { code?: string }).code
        if (code === 'vault_locked') {
          return reply.code(409).send({ error: { message: 'الخزنة مقفلة', type: 'vault_locked', code: 409 } })
        }
        throw e
      }
      registry.invalidateCache(provider)
      const stored = vault.listSecrets().find((s) => s.alias === alias)!
      return { ok: true, secret: stored }
    },
  )

  app.delete('/api/vault/secrets/:alias', async (request, reply) => {
    const { alias } = request.params as { alias: string }
    const ok = vault.removeSecret(alias)
    if (!ok) return reply.code(404).send({ error: { message: 'السر غير موجود', type: 'not_found', code: 404 } })
    registry.invalidateCache(alias.split(':')[0] ?? alias)
    return { ok: true }
  })

  /** Test a stored key against its provider's /models (or Ollama reachability). */
  app.post('/api/vault/secrets/:alias/test', async (request, reply) => {
    const { alias } = request.params as { alias: string }
    const providerId = alias.split(':')[0] ?? alias
    const adapter = registry.get(providerId)
    if (!adapter) {
      return reply.code(404).send({ error: { message: `مزود غير معروف: ${providerId}`, type: 'not_found', code: 404 } })
    }
    if (adapter.needsKey && !vault.isUnlocked) {
      return reply.code(409).send({ error: { message: 'الخزنة مقفلة', type: 'vault_locked', code: 409 } })
    }
    try {
      const models = await registry.listModels(providerId, config, db)
      return { ok: true, provider: providerId, models: models.length }
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e)
      return reply.code(502).send({ error: { message: msg, type: 'provider_test_failed', code: 502 } })
    }
  })
}
