/**
 * LIMO DEPLOYMENT COMMAND CENTER — artifact collection (LIMO #20).
 *
 * Walks the REAL static export directory (the exact artifact the phone serves,
 * config.webDist) and produces Vercel inline files. Honesty invariants:
 *  - missing/empty dist ⇒ a thrown honest error, never a fake deployment;
 *  - binary assets go base64 (`encoding: 'base64'`), text goes as-is;
 *  - hard caps (files/bytes) so a runaway tree cannot brick the request;
 *  - the returned summary carries measured file/byte counts for the audit trail.
 */
import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join, relative, sep } from 'node:path'
import type { InlineFile } from './vercel.js'

const BINARY_EXTENSIONS = new Set([
  'png', 'jpg', 'jpeg', 'gif', 'webp', 'avif', 'ico', 'woff', 'woff2', 'ttf', 'otf', 'eot',
  'mp3', 'mp4', 'webm', 'wasm', 'zip', 'gz', 'pdf',
])

export interface ArtifactCaps {
  maxFiles: number
  maxTotalBytes: number
  maxFileBytes: number
}

export const DEFAULT_CAPS: ArtifactCaps = {
  maxFiles: 2000,
  maxTotalBytes: 40 * 1024 * 1024,
  maxFileBytes: 12 * 1024 * 1024,
}

export interface CollectedArtifact {
  files: InlineFile[]
  fileCount: number
  totalBytes: number
  distDir: string
}

export class ArtifactError extends Error {}

function walk(dir: string, root: string, out: string[]): void {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name)
    const st = statSync(p)
    if (st.isDirectory()) walk(p, root, out)
    else if (st.isFile()) out.push(p)
  }
}

export function collectArtifact(distDir: string, caps: ArtifactCaps = DEFAULT_CAPS): CollectedArtifact {
  const roots: string[] = []
  walk(distDir, distDir, roots)
  if (roots.length === 0) throw new ArtifactError(`مجلد النشر فارغ (${distDir}) — لا شيء يُرفع فعلًا`)
  if (roots.length > caps.maxFiles) {
    throw new ArtifactError(`عدد ملفات النشر ${roots.length} يتجاوز الحد (${caps.maxFiles})`)
  }
  const files: InlineFile[] = []
  let total = 0
  for (const abs of roots) {
    const rel = relative(distDir, abs).split(sep).join('/')
    const buf = readFileSync(abs)
    if (buf.byteLength > caps.maxFileBytes) {
      throw new ArtifactError(`الملف ${rel} (${(buf.byteLength / 1024).toFixed(0)}KB) يتجاوز حد الملف الواحد`)
    }
    total += buf.byteLength
    if (total > caps.maxTotalBytes) {
      throw new ArtifactError(`حجم النشر ${(total / 1024 / 1024).toFixed(1)}MB يتجاوز الحد (${(caps.maxTotalBytes / 1024 / 1024).toFixed(0)}MB)`)
    }
    const ext = rel.split('.').pop()?.toLowerCase() ?? ''
    if (BINARY_EXTENSIONS.has(ext)) {
      files.push({ file: rel, data: buf.toString('base64'), encoding: 'base64' })
    } else {
      files.push({ file: rel, data: buf.toString('utf8') })
    }
  }
  return { files, fileCount: files.length, totalBytes: total, distDir }
}
