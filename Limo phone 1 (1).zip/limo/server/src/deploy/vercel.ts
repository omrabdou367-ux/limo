/**
 * LIMO DEPLOYMENT COMMAND CENTER — the real Vercel REST client (LIMO #20).
 *
 * Directive §11–12 made this conditional on the OWNER's real token; the token
 * arrived (account verified via GET /v2/user, 0 projects) and was stored only
 * in the AES-256-GCM vault under the alias `vercel`. Nothing here fabricates:
 *  - every function returns what the official API actually answered;
 *  - a non-2xx becomes an honest error carrying Vercel's own status/body;
 *  - NO deployment is ever reported successful before its readyState is READY
 *    as measured from the API; build failures surface the real log tail.
 *
 * Endpoints used (official REST, bearer token):
 *  GET  /v2/user                     — identity (also the token validity probe)
 *  GET  /v9/projects                 — discovery
 *  GET/POST /v9/projects/{name}      — link-or-create the LIMO project
 *  POST /v13/deployments             — inline prebuilt-file deployment
 *                                      (target: 'preview' | 'production')
 *  GET  /v13/deployments/{id}        — readyState polling
 *  GET  /v3/deployments/{id}/events  — real build/runtime event stream (NDJSON)
 *  GET  /v6/deployments              — history for the project
 *  POST /v2/deployments/{id}/aliases — instant production alias move (rollback)
 */

const API = 'https://api.vercel.com'
export const FETCH_TIMEOUT_MS = 30_000

export class VercelError extends Error {
  constructor(
    public readonly status: number,
    public readonly path: string,
    public readonly bodyExcerpt: string,
  ) {
    super(`Vercel ${status} on ${path} — ${bodyExcerpt}`)
    this.name = 'VercelError'
  }
}

async function vfetch(token: string, path: string, init?: RequestInit): Promise<unknown> {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS)
  try {
    const res = await fetch(`${API}${path}`, {
      ...init,
      signal: ctrl.signal,
      headers: {
        authorization: `Bearer ${token}`,
        'content-type': 'application/json',
        'user-agent': 'limo-deployment-center/1.0',
        ...(init?.headers ?? {}),
      },
    })
    const body = await res.text()
    if (!res.ok) throw new VercelError(res.status, path, body.slice(0, 240))
    return body.length > 0 ? (JSON.parse(body) as unknown) : {}
  } finally {
    clearTimeout(timer)
  }
}

export interface VercelUser {
  uid: string
  username: string
}

export async function vercelUser(token: string): Promise<VercelUser> {
  const d = (await vfetch(token, '/v2/user')) as { user?: { uid?: string; username?: string }; uid?: string; username?: string }
  const u = d.user ?? d
  return { uid: String(u.uid ?? ''), username: String(u.username ?? '') }
}

export interface VercelProject {
  id: string
  name: string
}

export async function vercelProjects(token: string): Promise<VercelProject[]> {
  const d = (await vfetch(token, '/v9/projects?limit=100')) as { projects?: Array<{ id: string; name: string }> }
  return (d.projects ?? []).map((p) => ({ id: p.id, name: p.name }))
}

/** GET the named project; create it when truly absent (measured 404, not assumed). */
export async function vercelEnsureProject(token: string, name: string): Promise<VercelProject> {
  try {
    const p = (await vfetch(token, `/v9/projects/${encodeURIComponent(name)}`)) as { id: string; name: string }
    return { id: p.id, name: p.name }
  } catch (e) {
    if (!(e instanceof VercelError) || e.status !== 404) throw e
  }
  const created = (await vfetch(token, '/v9/projects', {
    method: 'POST',
    body: JSON.stringify({ name, framework: null }),
  })) as { id: string; name: string }
  return { id: created.id, name: created.name }
}

export interface InlineFile {
  file: string
  data: string
  encoding?: 'base64'
}

export interface VercelDeploymentRef {
  id: string
  readyState: string
  url: string | null
  target: string | null
}

/** Upload the prebuilt artifact. `files` are inline; no server-side build runs.
 *  Measured live (LIMO #20): Vercel 400s on `target: 'preview'`
 *  («target should be 'production', 'staging', or a custom environment») —
 *  previews are the API default, so the field is sent only for production. */
export async function vercelDeployFiles(opts: {
  token: string
  projectName: string
  files: InlineFile[]
  target: 'preview' | 'production'
}): Promise<VercelDeploymentRef> {
  const d = (await vfetch(opts.token, '/v13/deployments', {
    method: 'POST',
    body: JSON.stringify({
      name: opts.projectName,
      ...(opts.target === 'production' ? { target: 'production' } : {}),
      files: opts.files,
      projectSettings: { framework: null },
    }),
  })) as { id?: string; uid?: string; readyState?: string; url?: string; target?: string }
  const id = d.id ?? d.uid
  if (!id) throw new VercelError(502, '/v13/deployments', 'response carried no deployment id')
  return { id, readyState: d.readyState ?? 'QUEUED', url: d.url ?? null, target: d.target ?? opts.target }
}

export interface VercelDeploymentState extends VercelDeploymentRef {
  createdAt: number | null
  ready: number | null
  alias: string[]
}

export async function vercelDeployment(token: string, id: string): Promise<VercelDeploymentState> {
  const d = (await vfetch(token, `/v13/deployments/${encodeURIComponent(id)}`)) as {
    readyState?: string
    url?: string
    alias?: string[]
    target?: string
    createdAt?: number
    ready?: number
  }
  return {
    id,
    readyState: d.readyState ?? 'UNKNOWN',
    url: d.url ?? null,
    alias: d.alias ?? [],
    target: d.target ?? null,
    createdAt: d.createdAt ?? null,
    ready: d.ready ?? null,
  }
}

/** The real event stream (NDJSON) parsed into human-readable lines. */
export async function vercelDeploymentLogs(token: string, id: string, limit = 60): Promise<Array<{ at: string | null; text: string }>> {
  const d = (await vfetch(token, `/v3/deployments/${encodeURIComponent(id)}/events?limit=${limit}&builds=1`)) as
    | Array<{ type?: string; payload?: { text?: string }; created?: number; date?: number }>
    | { events?: Array<{ type?: string; payload?: { text?: string }; created?: number; date?: number }> }
  const list = Array.isArray(d) ? d : (d.events ?? [])
  return list
    .map((e) => {
      const text = (e.payload?.text ?? '').slice(0, 400)
      const ts = e.created ?? e.date ?? null
      return { at: ts ? new Date(ts).toISOString() : null, text }
    })
    .filter((l) => l.text.length > 0)
}

export interface VercelDeploymentRow {
  id: string
  state: string
  url: string | null
  target: string | null
  createdAt: number | null
}

export async function vercelDeployments(token: string, projectId: string, limit = 12): Promise<VercelDeploymentRow[]> {
  const d = (await vfetch(token, `/v6/deployments?projectId=${encodeURIComponent(projectId)}&limit=${limit}`)) as {
    deployments?: Array<{ uid?: string; id?: string; readyState?: string; state?: string; url?: string; target?: string; createdAt?: number }>
  }
  return (d.deployments ?? []).map((x) => ({
    id: String(x.uid ?? x.id ?? ''),
    state: x.readyState ?? x.state ?? 'UNKNOWN',
    url: x.url ?? null,
    target: x.target ?? null,
    createdAt: x.createdAt ?? null,
  }))
}

/**
 * Preview-protection control (measured live, LIMO #20): new accounts ship with
 * `ssoProtection: { deploymentType: 'all_except_custom_domains' }` — every
 * preview URL answers a Vercel auth wall. This reads and sets that exact
 * field via the official PATCH; `null` = public previews. It is an OWNER
 * decision exposed in the System Map, never changed silently.
 */
export async function vercelPreviewProtection(token: string, name: string): Promise<string | null> {
  const d = (await vfetch(token, `/v9/projects/${encodeURIComponent(name)}`)) as {
    ssoProtection?: { deploymentType?: string | null } | null
  }
  return d.ssoProtection?.deploymentType ?? null
}

export async function vercelSetPreviewProtection(token: string, name: string, deploymentType: string | null): Promise<string | null> {
  const d = (await vfetch(token, `/v9/projects/${encodeURIComponent(name)}`, {
    method: 'PATCH',
    body: JSON.stringify({ ssoProtection: deploymentType ? { deploymentType } : null }),
  })) as { ssoProtection?: { deploymentType?: string | null } | null }
  return d.ssoProtection?.deploymentType ?? null
}

/**
 * Instant production alias move — the REAL rollback/promote primitive.
 * Assigns `alias` (e.g. limo-agent.vercel.app) onto the chosen deployment.
 * Verified live in LIMO #20 before being wired to any owner-facing button.
 */
export async function vercelAssignAlias(token: string, deploymentId: string, alias: string): Promise<{ assigned: boolean; detail: string }> {
  try {
    const d = (await vfetch(token, `/v2/deployments/${encodeURIComponent(deploymentId)}/aliases`, {
      method: 'POST',
      body: JSON.stringify({ alias }),
    })) as { alias?: unknown }
    return { assigned: true, detail: typeof d?.alias === 'string' ? d.alias : 'assigned' }
  } catch (e) {
    const status = e instanceof VercelError ? e.status : 0
    return { assigned: false, detail: e instanceof Error ? `Vercel ${status}: ${e.message.slice(0, 160)}` : String(e) }
  }
}
