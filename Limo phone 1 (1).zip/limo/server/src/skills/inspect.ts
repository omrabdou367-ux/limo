/**
 * ALLIMNI (علّمني) — the skill inspection pipeline (LIMO #11 upgrade).
 *
 * v2 additions over the 12-step pipeline (all preserved):
 *  - multi-skill repositories: every "…/SKILL.md" is a candidate root; a
 *    skills.sh skillId (e.g. vercel-react-best-practices) resolves to the
 *    directory whose frontmatter name (or basename) matches — measured:
 *    dir names do NOT always equal the skill id;
 *  - /tree/<branch>/<path> URLs import one specific skill directory;
 *  - jsDelivr fallback when GitHub's unauthenticated API answers 403/429
 *    (60 req/h per IP — measured in this sandbox); same content, different
 *    legitimate public mirror, never a bypass of any access control;
 *  - the inspection is SCOPED to the chosen skill directory, not the repo;
 *  - the head commit is recorded so the update manager can detect drift.
 *
 * Honesty contract (never violated):
 *  - A check that could not run is `not_tested` — NEVER `verified`.
 *  - Blockers make the verdict `fail`; the route refuses approval outright.
 *  - Warnings make it `needs_review` — the owner reads and decides.
 *  - README claims are never trusted as security evidence.
 *  - Everything is bounded: files, bytes, deep-scan count, network time.
 */

export type SkillCheckStatus = 'verified' | 'not_detected' | 'not_tested' | 'failed' | 'unknown'

export interface SkillInspectionReport {
  url: string
  repo: { owner: string; name: string; branch: string; license?: string | null }
  /** v2: the chosen skill directory ('' = repo root) + requested skillId */
  target: { dir: string; skillId: string | null }
  /** v2: every SKILL.md found in the repo (multi-skill awareness) */
  skillRoots: Array<{ dir: string; name: string | null }>
  /** v2: head commit when GitHub was reachable; null = honestly unavailable */
  commit: string | null
  /** v2: 'github-api' | 'jsdelivr' — where the data came from */
  dataSource: 'github-api' | 'jsdelivr'
  checks: Array<{ id: string; label: string; status: SkillCheckStatus; detail: string; evidence?: string[] }>
  blockers: string[]
  warnings: string[]
  coverage: { scanned: number; total: number }
  frontmatter: Record<string, string> | null
  dependencies: Array<{ file: string; deps: number }>
  /** v2: the file manifest that WOULD be installed (scoped to target dir) */
  files: Array<{ path: string; bytes: number }>
  verdict: 'pass' | 'needs_review' | 'fail'
  inspectedAt: string
}

// ------------------------------------------------------------ bounds (by design)
/** Scope-aware since LIMO #20: MAX_FILES bounds the SCOPED skill directory
 *  (what would actually be inspected + installed), NOT the whole repo — the
 *  phone blocker «عدد الملفات يتجاوز الحد (500)» fired on vercel-labs/
 *  open-agents (776 files) whose agent-browser/ skill is 10 small files.
 *  MAX_REPO_TREE is only a pathological-response guard, far above any real
 *  skill collection; beyond it even listing is refused honestly. */
export const MAX_FILES = 500
export const MAX_REPO_TREE = 5000
export const MAX_TOTAL_BYTES = 2 * 1024 * 1024
export const DEEP_SCAN_LIMIT = 60
export const PER_FILE_SCAN_BYTES = 64 * 1024
export const FETCH_TIMEOUT_MS = 15_000

/** Text-only allowlist — the install copy is text, nothing binary ever lands. */
export const TEXT_EXTENSIONS: ReadonlySet<string> = new Set([
  'md', 'txt', 'json', 'yaml', 'yml', 'toml', 'csv', 'js', 'mjs', 'cjs', 'ts', 'tsx',
  'jsx', 'py', 'rb', 'go', 'rs', 'java', 'c', 'h', 'cpp', 'hpp', 'css', 'scss', 'html',
  'xml', 'sql', 'sh', 'ini', 'cfg',
])

// ------------------------------------------------------------ pattern tables
export const SECRET_PATTERNS: ReadonlyArray<{ id: string; label: string; re: RegExp }> = [
  { id: 'openai-key', label: 'مفتاح بنمط OpenAI', re: /sk-[A-Za-z0-9_-]{16,}/ },
  { id: 'github-token', label: 'رمز GitHub', re: /gh[pousr]_[A-Za-z0-9]{20,}/ },
  { id: 'aws-key', label: 'مفتاح وصول AWS', re: /AKIA[0-9A-Z]{16}/ },
  { id: 'private-key', label: 'كتلة مفتاح خاص', re: /-----BEGIN (RSA |EC |OPENSSH |PGP )?PRIVATE KEY-----/ },
  { id: 'bearer', label: 'رمز bearer مثبّت', re: /bearer\s+[A-Za-z0-9._-]{20,}/i },
  { id: 'key-assign', label: 'إسناد مفتاح/سر في النص', re: /(?:api[_-]?key|apikey|secret|token)\s*[:=]\s*['"][A-Za-z0-9+/_-]{16,}['"]/i },
]

export const DANGEROUS_PATTERNS: ReadonlyArray<{ id: string; label: string; re: RegExp }> = [
  { id: 'pipe-to-shell', label: 'تنزيل يُمرَّر مباشرة إلى shell', re: /(curl|wget)[^\n;]{0,200}\|\s*(sudo\s+)?(ba|z|da)?sh\b/i },
  { id: 'b64-exec', label: 'تنفيذ مشفّر base64', re: /\b(echo|printf)\s+[A-Za-z0-9+/=]{20,}\s*\|\s*(ba|z|da)?sh\b/ },
  { id: 'eval', label: 'استدعاء eval ديناميكي', re: /\beval\s*\(/ },
  { id: 'rm-rf', label: 'حذف قسري متكرر', re: /\brm\s+-[a-z]*r[a-z]*f[a-z]*\b|\brm\s+-[a-z]*f[a-z]*r[a-z]*\b/ },
  { id: 'sudo', label: 'تصعيد صلاحيات', re: /\bsudo\s+\S+/ },
  { id: 'child-proc', label: 'تشغيل عمليات من الشيفرة', re: /\b(child_process|subprocess\.(run|call|Popen)|Process\.Start)\b/ },
  { id: 'chmod-exec', label: 'منح صلاحية تنفيذ', re: /\bchmod\s+\+x\b/ },
]

export const INJECTION_PATTERNS: ReadonlyArray<{ id: string; label: string; re: RegExp }> = [
  { id: 'ignore-previous', label: 'تجاهل التعليمات السابقة', re: /ignore (all )?(your )?previous instructions/i },
  { id: 'reveal-key', label: 'طلب كشف مفتاح', re: /reveal (your )?(api )?key/i },
  { id: 'disregard-above', label: 'تجاهل ما سبق', re: /disregard (all )?(the )?above/i },
  { id: 'system-prompt', label: 'طلب إبراز موجّه النظام', re: /(reveal|print|show|output) (me )?(your )?system prompt/i },
  { id: 'you-are-now', label: 'إعادة تعريف الدور', re: /you are now (a|an|in|free)/i },
  { id: 'no-limits', label: 'ادعاء انعدام القيود', re: /\b(jailbreak|developer mode|no limits|unrestricted mode)\b/i },
]

// ------------------------------------------------------------ URL contract
export function parseGitHubUrl(raw: string): { owner: string; name: string } | null {
  let u: URL
  try {
    u = new URL(raw.trim())
  } catch {
    return null
  }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return null
  if (u.hostname !== 'github.com' && u.hostname !== 'www.github.com') return null
  const parts = u.pathname.split('/').filter(Boolean)
  if (parts.length < 2) return null
  const owner = parts[0]!
  let name = parts[1]!
  if (!owner || !name) return null
  if (name.endsWith('.git')) name = name.slice(0, -4)
  if (name === 'settings' || name === 'orgs') return null
  return { owner, name }
}

/** /tree/<branch>/<path…> URLs → the specific directory the owner pointed at. */
export function parseGitHubTreeUrl(raw: string): { branch: string | null; dir: string | null } {
  try {
    const u = new URL(raw.trim())
    const parts = u.pathname.split('/').filter(Boolean)
    const i = parts.indexOf('tree')
    if (i === -1 || parts.length < i + 2) return { branch: null, dir: null }
    const branch = parts[i + 1]!
    const dir = parts.slice(i + 2).join('/')
    return { branch, dir: dir || null }
  } catch {
    return { branch: null, dir: null }
  }
}

// ------------------------------------------------------------ bounded GitHub access
class RateLimitedError extends Error {}

async function gh(path: string, accept: 'json' | 'raw'): Promise<string> {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS)
  try {
    const res = await fetch(`https://api.github.com${path}`, {
      signal: ctrl.signal,
      headers: {
        accept: accept === 'json' ? 'application/vnd.github+json' : 'application/vnd.github.raw',
        'user-agent': 'limo-allimni-inspector/2.0',
      },
    })
    const body = await res.text()
    if (!res.ok) {
      if (res.status === 403 || res.status === 429) throw new RateLimitedError(`GitHub ${res.status} — حد المعدل غير المصادق (60/ساعة)`)
      throw new Error(`GitHub ${res.status} ${res.statusText} — ${body.slice(0, 120)}`)
    }
    return body
  } finally {
    clearTimeout(timer)
  }
}

export async function ghJson<T = unknown>(path: string): Promise<T> {
  return JSON.parse(await gh(path, 'json')) as T
}

export async function ghText(path: string): Promise<string> {
  return gh(path, 'raw')
}

// ------------------------------------------------------------ jsDelivr fallback
/** Live-verified mirror shapes (2026-11-01):
 *  tree:   GET https://data.jsdelivr.com/v1/packages/gh/{o}/{r}@{branch}?structure=flat
 *          → { files: [{ name: '/path', hash, size }] }
 *  content GET https://cdn.jsdelivr.net/gh/{o}/{r}@{branch}/{path} → raw bytes */
export interface MirrorRepo {
  owner: string
  name: string
  branch: string
}

async function mirrorFetch(path: string): Promise<string> {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS)
  try {
    const res = await fetch(`https://cdn.jsdelivr.net/gh/${path}`, {
      signal: ctrl.signal,
      headers: { 'user-agent': 'limo-allimni-inspector/2.0' },
    })
    const body = await res.text()
    if (!res.ok) throw new Error(`jsDelivr ${res.status} ${res.statusText} — ${body.slice(0, 100)}`)
    return body
  } finally {
    clearTimeout(timer)
  }
}

async function mirrorTree(repo: MirrorRepo): Promise<Array<{ path: string; type: string; size?: number }>> {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS)
  try {
    const res = await fetch(`https://data.jsdelivr.com/v1/packages/gh/${repo.owner}/${repo.name}@${repo.branch}?structure=flat`, {
      signal: ctrl.signal,
      headers: { 'user-agent': 'limo-allimni-inspector/2.0' },
    })
    if (!res.ok) throw new Error(`jsDelivr ${res.status}`)
    const body = (await res.json()) as { files?: Array<{ name: string; size?: number }> }
    return (body.files ?? []).map((f) => ({ path: f.name.replace(/^\//, ''), type: 'blob', size: f.size }))
  } finally {
    clearTimeout(timer)
  }
}

// ------------------------------------------------------------ frontmatter
export function parseFrontmatter(text: string): Record<string, string> | null {
  const m = /^---\r?\n([\s\S]*?)\r?\n---/.exec(text)
  if (!m) return null
  const out: Record<string, string> = {}
  for (const line of m[1]!.split(/\r?\n/)) {
    const idx = line.indexOf(':')
    if (idx <= 0) continue
    const key = line.slice(0, idx).trim()
    let val = line.slice(idx + 1).trim()
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1)
    if (key && !(key in out)) out[key] = val
  }
  return Object.keys(out).length > 0 ? out : null
}

// ------------------------------------------------------------ the pipeline
interface TreeEntry { path: string; type: string; size?: number }

/** Bounded parallel map — keeps the mirror path fast without hammering hosts. */
async function pooled<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length)
  let i = 0
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (i < items.length) {
      const idx = i++
      out[idx] = await fn(items[idx]!)
    }
  })
  await Promise.all(workers)
  return out
}

export interface InspectOptions {
  /** skills.sh skillId — resolves the skill directory inside a multi-skill repo */
  skillId?: string
}

export async function inspectSkill(url: string, opts: InspectOptions = {}): Promise<SkillInspectionReport> {
  const checks: SkillInspectionReport['checks'] = []
  const blockers: string[] = []
  const warnings: string[] = []
  const deps: Array<{ file: string; deps: number }> = []
  const repo: SkillInspectionReport['repo'] = { owner: '', name: '', branch: 'main', license: null }
  const coverage = { scanned: 0, total: 0 }
  let frontmatter: Record<string, string> | null = null
  let commit: string | null = null
  let dataSource: 'github-api' | 'jsdelivr' = 'github-api'
  const skillRoots: Array<{ dir: string; name: string | null }> = []
  const files: Array<{ path: string; bytes: number }> = []
  const treeUrl = parseGitHubTreeUrl(url)
  const target: SkillInspectionReport['target'] = { dir: treeUrl.dir ?? '', skillId: opts.skillId ?? null }

  const push = (id: string, label: string, status: SkillCheckStatus, detail: string, evidence?: string[]) => {
    checks.push({ id, label, status, detail, ...(evidence && evidence.length > 0 ? { evidence } : {}) })
  }
  const finish = (): SkillInspectionReport => ({
    url,
    repo,
    target,
    skillRoots,
    commit,
    dataSource,
    checks,
    blockers,
    warnings,
    coverage,
    frontmatter,
    dependencies: deps,
    files,
    verdict: blockers.length > 0 ? 'fail' : warnings.length > 0 ? 'needs_review' : 'pass',
    inspectedAt: new Date().toISOString(),
  })

  // 1 — URL shape
  const parsed = parseGitHubUrl(url)
  if (!parsed) {
    push('url_shape', 'صياغة العنوان', 'failed', 'العنوان لا يستهدف مستودع GitHub بالشكل المطلوب (https://github.com/{owner}/{repo})')
    blockers.push('عنوان غير صالح — ليس مستودع GitHub')
    return finish()
  }
  repo.owner = parsed.owner
  repo.name = parsed.name
  if (treeUrl.branch) repo.branch = treeUrl.branch
  push('url_shape', 'صياغة العنوان', 'verified', `مستودع GitHub سليم: ${parsed.owner}/${parsed.name}${treeUrl.dir ? ` · مجلد محدد: ${treeUrl.dir}` : ''}`)

  // 2 — repo metadata + tree (GitHub API primary, jsDelivr fallback on rate limit)
  let entries: TreeEntry[] = []
  let treeTruncated = false
  try {
    interface RepoMeta { default_branch?: string; license?: { spdx_id?: string } | null }
    const meta = await ghJson<RepoMeta>(`/repos/${parsed.owner}/${parsed.name}`)
    if (!treeUrl.branch) repo.branch = meta.default_branch || 'main'
    repo.license = meta.license?.spdx_id && meta.license.spdx_id !== 'NOASSERTION' ? meta.license.spdx_id : null
    const tree = await ghJson<{ tree: TreeEntry[]; truncated?: boolean }>(`/repos/${parsed.owner}/${parsed.name}/git/trees/${repo.branch}?recursive=1`)
    treeTruncated = tree.truncated === true
    entries = (tree.tree ?? []).filter((e) => e.type === 'blob')
    const head = await ghJson<{ sha?: string }>(`/repos/${parsed.owner}/${parsed.name}/commits/${repo.branch}`)
    commit = head.sha ?? null
    dataSource = 'github-api'
  } catch (e) {
    if (e instanceof RateLimitedError) {
      // honest fallback: jsDelivr mirror (public CDN, same content)
      try {
        const tree = await mirrorTree({ owner: parsed.owner, name: parsed.name, branch: repo.branch })
        entries = tree
        dataSource = 'jsdelivr'
        warnings.push('واجهة GitHub API محدودة المعدل — الفحص تم عبر مرآة jsDelivr العامة؛ رقم الالتزام (commit) غير متاح الآن')
        push('repo_metadata', 'بيانات المستودع', 'verified', `عبر مرآة jsDelivr (${repo.branch}) — ${entries.length} ملفًا`)
      } catch (e2) {
        push('repo_metadata', 'بيانات المستودع', 'not_tested', `تعذر جلب المستودع (GitHub محدود المعدل، والمرآة فشلت) — ${e2 instanceof Error ? e2.message : String(e2)}`)
        blockers.push('تعذر الوصول إلى المستودع من أي مصدر عام — لا يُعرض شيء للموافقة دون فحص')
        return finish()
      }
    } else {
      push('repo_metadata', 'بيانات المستودع', 'not_tested', `تعذر جلب بيانات المستودع — ${e instanceof Error ? e.message : String(e)}`)
      blockers.push('تعذر الوصول إلى بيانات المستودع من GitHub — لا يُعرض شيء للموافقة دون فحص')
      return finish()
    }
  }

  coverage.total = entries.length
  if (treeTruncated) {
    push('repo_tree', 'شجرة الملفات', 'failed', 'واجهة GitHub أعادت شجرة مبتورة (truncated) — لا يمكن فحص ما لا يُرى كاملًا')
    blockers.push('شجرة المستودع مبتورة من واجهة GitHub — الفحص مرفوض بلا رؤية كاملة')
    return finish()
  }
  if (entries.length > MAX_REPO_TREE) {
    push('repo_tree', 'شجرة الملفات', 'failed', `عدد ملفات المستودع ${entries.length} يتجاوز سقف الاستجابة ${MAX_REPO_TREE} — مستودع شاذ الحجم`)
    blockers.push(`شجرة المستودع تتجاوز سقف الاستجابة (${MAX_REPO_TREE})`)
    return finish()
  }

  // 3 — resolve the skill directory (multi-skill repos + skills.sh skillId)
  // LIMO #20: per-file mirror fallback. The unauthenticated GitHub contents API
  // is 60 req/h per IP — on shared/mobile NATs it runs out MID-inspection (the
  // tree succeeds, then every file read silently fails → honest-looking
  // «تعذر قراءة SKILL.md» that is really a rate limit). Same public mirror
  // already used for the tree; same content, no access control bypassed.
  const readViaSource = async (path: string): Promise<string | null> => {
    if (dataSource === 'github-api') {
      try {
        const enc = path.split('/').map(encodeURIComponent).join('/')
        return await ghText(`/repos/${parsed.owner}/${parsed.name}/contents/${enc}?ref=${repo.branch}`)
      } catch {
        try {
          return await mirrorFetch(`${parsed.owner}/${parsed.name}@${repo.branch}/${path}`)
        } catch {
          return null
        }
      }
    }
    try {
      return await mirrorFetch(`${parsed.owner}/${parsed.name}@${repo.branch}/${path}`)
    } catch {
      return null
    }
  }

  const skillMdPaths = entries.filter((e) => /^(.*\/)?SKILL\.md$/i.test(e.path)).map((e) => e.path)
  if (skillMdPaths.length === 0) {
    push('skill_md', 'ملف SKILL.md', 'failed', 'لا يوجد SKILL.md في أي مجلد — ليس مهارة وفق العقد')
    blockers.push('SKILL.md مفقود')
    return finish()
  }

  // parse each candidate's frontmatter (bounded, pooled) to resolve the target dir
  let resolvedDir = target.dir
  const rootTexts = await pooled(skillMdPaths.slice(0, 30), 6, async (p) => {
    try {
      return { path: p, text: await readViaSource(p) }
    } catch {
      return { path: p, text: null }
    }
  })
  for (const { path: p, text } of rootTexts) {
    const dir = p.replace(/\/?SKILL\.md$/i, '')
    const name = text ? (parseFrontmatter(text)?.name ?? null) : null
    skillRoots.push({ dir, name })
  }
  if (opts.skillId) {
    const id = opts.skillId.toLowerCase()
    const byName = skillRoots.find((r) => (r.name ?? '').toLowerCase() === id)
    const byBasename = skillRoots.find((r) => r.dir.split('/').pop()!.toLowerCase() === id)
    const chosen = byName ?? byBasename ?? null
    if (!chosen) {
      push('skill_resolve', 'تحديد المهارة', 'failed', `المستودع لا يحتوي مهارة بالمعرّف «${opts.skillId}» — المتاح: ${skillRoots.map((r) => r.name ?? r.dir).slice(0, 8).join(' · ')}`)
      blockers.push(`المهارة «${opts.skillId}» غير موجودة في المستودع`)
      return finish()
    }
    resolvedDir = chosen.dir
    target.dir = chosen.dir
    push('skill_resolve', 'تحديد المهارة', 'verified', `طُابقت «${opts.skillId}» على المجلد ${chosen.dir || '(الجذر)'}${chosen.name ? ` (name: ${chosen.name})` : ''}`)
  } else if (treeUrl.dir) {
    const exists = skillRoots.some((r) => r.dir === treeUrl.dir)
    if (!exists) {
      push('skill_resolve', 'تحديد المهارة', 'failed', `المجلد المطلوب «${treeUrl.dir}» لا يحتوي SKILL.md`)
      blockers.push('المجلد المحدد في العنوان ليس مهارة (لا SKILL.md)')
      return finish()
    }
    push('skill_resolve', 'تحديد المهارة', 'verified', `المجلد المحدد من العنوان: ${treeUrl.dir}`)
  } else if (skillRoots.length > 1) {
    warnings.push(`المستودع متعدد المهارات (${skillRoots.length} مهارة) — سيُستورد كل النص فيه ما لم تحدد مهارة`)
    push('skill_resolve', 'تحديد المهارة', 'verified', `مستودع متعدد (${skillRoots.length} مهارة) — الاستيراد على مستوى المستودع`)
  } else {
    push('skill_resolve', 'تحديد المهارة', 'verified', `مهارة واحدة في ${skillRoots[0]!.dir || 'الجذر'}`)
  }

  // scope: only files under the resolved dir are inspected AND installed
  const scopePrefix = resolvedDir ? `${resolvedDir}/` : ''
  const scoped = entries.filter((e) => e.path.startsWith(scopePrefix))
  const totalBytes = scoped.reduce((acc, e) => acc + (e.size ?? 0), 0)
  // LIMO #20: the count bound applies to the SCOPED set — a 776-file multi-skill
  // collection is importable skill-by-skill; refusing it wholesale was the bug
  // the owner hit on the phone. Whole-repo (unscoped) imports of huge repos are
  // still refused, honestly, with the way out named.
  if (scoped.length > MAX_FILES) {
    const wayOut = skillRoots.length > 1
      ? ` — المستودع متعدد المهارات (${skillRoots.length})؛ حدد مهارة واحدة بمعرّفها: ${skillRoots.map((r) => r.name ?? r.dir).filter(Boolean).slice(0, 6).join(' · ')}`
      : ''
    push('repo_tree', 'شجرة الملفات', 'failed', `عدد ملفات نطاق المهارة ${scoped.length} يتجاوز الحد ${MAX_FILES}`)
    blockers.push(`عدد الملفات يتجاوز الحد (${MAX_FILES})${wayOut}`)
    return finish()
  }
  if (totalBytes > MAX_TOTAL_BYTES) {
    push('repo_tree', 'شجرة الملفات', 'failed', `حجم المهارة ${(totalBytes / 1024).toFixed(0)}KB يتجاوز الحد ${(MAX_TOTAL_BYTES / 1024).toFixed(0)}KB`)
    blockers.push('حجم الملفات يتجاوز الحد المسموح')
    return finish()
  }
  push('repo_tree', 'شجرة الملفات', 'verified', `${scoped.length} ملفًا ضمن نطاق المهارة · ${(totalBytes / 1024).toFixed(1)}KB${entries.length > scoped.length ? ` (من ${entries.length} في المستودع كله)` : ''}`)
  for (const e of scoped) files.push({ path: e.path, bytes: e.size ?? 0 })

  // 4 — SKILL.md (the skill contract)
  const skillMdPath = scopePrefix ? `${scopePrefix}SKILL.md` : 'SKILL.md'
  const skillMdRaw = await readViaSource(skillMdPath)
  if (!skillMdRaw) {
    push('skill_md', 'ملف SKILL.md', 'not_tested', 'تعذر جلب محتوى SKILL.md')
    blockers.push('تعذر قراءة SKILL.md — رفض بلا فحص')
  } else {
    frontmatter = parseFrontmatter(skillMdRaw)
    if (!frontmatter) {
      push('skill_md', 'ملف SKILL.md', 'verified', 'موجود لكن بلا بيانات أمامية — تحذير')
      warnings.push('SKILL.md بلا بيانات أمامية (name/version)')
    } else {
      push('skill_md', 'ملف SKILL.md', 'verified', `بيانات: ${frontmatter.name ?? 'بلا اسم'}${frontmatter.version ? ` · ${frontmatter.version}` : ''}`)
    }
  }

  // 5 — file types (text-only allowlist)
  const nonText = scoped.filter((e) => {
    const ext = e.path.split('.').pop()?.toLowerCase() ?? ''
    return !TEXT_EXTENSIONS.has(ext)
  })
  if (nonText.length > 0) {
    push('file_types', 'أنواع الملفات', 'failed', `ملفات غير نصية: ${nonText.slice(0, 5).map((e) => e.path).join(' · ')}${nonText.length > 5 ? ' …' : ''}`)
    blockers.push(`ملفات غير نصية (${nonText.length}) — التثبيت نسخ نصي فقط`)
  } else {
    push('file_types', 'أنواع الملفات', 'verified', 'كل الملفات نصية ضمن القائمة المسموحة')
  }

  // 6–8 — deep content scan (bounded, prioritized)
  const priority = (p: string) => (p.endsWith('SKILL.md') ? 0 : p.startsWith('README') ? 1 : p.includes('/') ? 3 : 2)
  const deep = [...scoped].sort((a, b) => priority(a.path) - priority(b.path)).slice(0, DEEP_SCAN_LIMIT)
  const fetched: Array<{ path: string; text: string }> = []
  const deepTexts = await pooled(deep, 6, async (entry) => {
    try {
      const text = await readViaSource(entry.path)
      return text === null ? null : { path: entry.path, text: text.slice(0, PER_FILE_SCAN_BYTES) }
    } catch {
      return null
    }
  })
  for (const r of deepTexts) {
    if (r) {
      fetched.push(r)
      coverage.scanned += 1
    }
  }
  const secretHits: string[] = []
  const dangerHits: string[] = []
  const injectHits: string[] = []
  for (const { path, text } of fetched) {
    for (const p of SECRET_PATTERNS) if (p.re.test(text)) secretHits.push(`${path} — ${p.label}`)
    for (const p of DANGEROUS_PATTERNS) if (p.re.test(text)) dangerHits.push(`${path} — ${p.label}`)
    for (const p of INJECTION_PATTERNS) if (p.re.test(text)) injectHits.push(`${path} — ${p.label}`)
  }
  if (fetched.length === 0) {
    push('secrets_scan', 'فحص الأسرار', 'not_tested', 'تعذر جلب محتوى أي ملف للفحص العميق')
    push('dangerous_exec', 'أنماط التنفيذ الخطرة', 'not_tested', 'تعذر جلب محتوى أي ملف للفحص العميق')
    push('prompt_injection', 'حقن التعليمات', 'not_tested', 'تعذر جلب محتوى أي ملف للفحص العميق')
    blockers.push('تعذر الفحص العميق للمحتوى — رفض بلا فحص')
  } else {
    push('secrets_scan', 'فحص الأسرار', secretHits.length > 0 ? 'failed' : 'not_detected', secretHits.length > 0 ? `أسرار مكشوفة في ${secretHits.length} موضعًا` : 'لا أسرار مكشوفة فيما فُحص', secretHits.slice(0, 8))
    if (secretHits.length > 0) blockers.push(`أسرار مكشوفة (${secretHits.length})`)
    push('dangerous_exec', 'أنماط التنفيذ الخطرة', dangerHits.length > 0 ? 'failed' : 'not_detected', dangerHits.length > 0 ? `أنماط خطرة في ${dangerHits.length} موضعًا` : 'لا أنماط تنفيذ خطرة فيما فُحص', dangerHits.slice(0, 8))
    if (dangerHits.length > 0) blockers.push(`أنماط تنفيذ خطرة (${dangerHits.length})`)
    push('prompt_injection', 'حقن التعليمات', injectHits.length > 0 ? 'failed' : 'not_detected', injectHits.length > 0 ? 'تعليمات مشبوهة داخل الملفات — تُعرض كبيانات فقط ولا تُنفَّذ' : 'لا مؤشرات حقن فيما فُحص', injectHits.slice(0, 8))
    if (injectHits.length > 0) warnings.push(`تعليمات مشبوهة داخل الملفات (${injectHits.length}) — اقرأها بنفسك قبل أي موافقة`)
  }

  // 9 — declared dependencies
  const depFiles = scoped.filter((e) => ['package.json', 'requirements.txt', 'pyproject.toml', 'Gemfile', 'go.mod'].includes(e.path.split('/').pop() ?? ''))
  if (depFiles.length === 0) {
    push('dependencies', 'الاعتماديات المعلنة', 'not_detected', 'لا ملفات اعتماديات — لا شيء يُثبَّت عند الاستيراد أصلًا')
  } else {
    for (const df of depFiles) {
      const text = fetched.find((f) => f.path === df.path)?.text
      let n = 0
      if (text) {
        try {
          const pkg = JSON.parse(text) as { dependencies?: Record<string, unknown>; devDependencies?: Record<string, unknown> }
          n = Object.keys(pkg.dependencies ?? {}).length + Object.keys(pkg.devDependencies ?? {}).length
        } catch {
          n = 0
        }
      }
      deps.push({ file: df.path, deps: n })
    }
    push('dependencies', 'الاعتماديات المعلنة', 'verified', deps.map((d) => `${d.file} (${d.deps})`).join(' · '))
    warnings.push('اعتماديات معلنة — لا شيء يُثبَّت هنا؛ النسخ نصية فقط')
  }

  // 10 — license
  if (repo.license) {
    push('license', 'الترخيص', 'verified', `ترخيص معلن: ${repo.license}`)
  } else {
    push('license', 'الترخيص', 'not_detected', 'لا ترخيص معلن في بيانات المستودع')
    warnings.push('المستودع بلا ترخيص معلن')
  }

  // 11 — README is never trusted
  const readme = scoped.find((e) => /^README/i.test(e.path.split('/').pop() ?? ''))
  push(
    'readme_trust',
    'عدم الثقة بـREADME',
    readme ? 'verified' : 'not_detected',
    readme ? `README موجود (${readme.path}) ولا يُعتمد منه أي ادعاء أمني — الفيصل هو هذا الفحص فقط` : 'لا README',
  )

  // 12 — execution isolation (the guarantee)
  push('execution_isolation', 'عزل التنفيذ', 'verified', 'التثبيت نسخ نصي فقط إلى قرصك ولا يُنفَّذ منه شيء عند الاستيراد أبدًا؛ يُعاد فحص ما يصل القرص قبل الإقرار')

  return finish()
}
