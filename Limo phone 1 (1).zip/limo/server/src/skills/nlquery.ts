/**
 * ALLIMNI — natural-language → search-keyword conversion.
 *
 * Measured reality (2026-11-01, against the same endpoint the official
 * `npx skills find` CLI uses — https://skills.sh/api/search):
 *  - keyword queries ("react performance") return results;
 *  - full sentences ("I need a skill that improves React performance") return 0;
 *  - Arabic queries return 0 (the backend is English-only).
 *
 * So discovery converts the owner's sentence into keywords. The conversion is
 * ALWAYS shown back — the UI displays «تم البحث عن: react performance» — and
 * never silently rewrites intent. No results are invented: if the converted
 * query has no terms, we say so.
 */

/** Arabic dev-term → English search terms. Kept deliberately small and real.
 *  NOTE: no \b anchors — JS word boundaries are [A-Za-z0-9_]-based and never
 *  fire between Arabic letters (measured). Plain substrings instead. */
const AR_TERMS: ReadonlyArray<[RegExp, string]> = [
  [/رياكت|ريست/, 'react'],
  [/نيكست/, 'nextjs'],
  [/واجهات|واجهة|فرونت|واجهة المستخدم/, 'frontend ui'],
  [/خلفية|باكند|خدمات خلفية/, 'backend'],
  [/تصميم|واجهات جميلة|تجربة المستخدم/, 'ui design'],
  [/أمان|امن|حماية|تدقيق أمني/, 'security auditing'],
  [/بايثون/, 'python'],
  [/قواعد بيانات|قاعدة بيانات|ديتابيس/, 'database'],
  [/أتمتة|اتمتة|تلقائي/, 'automation'],
  [/متصفح|براوزر/, 'browser automation'],
  [/وكلاء ذكاء|وكيل ذكاء|وكلاء/, 'ai agents'],
  [/توليد صور|صور/, 'image generation'],
  [/توليد فيديو|فيديو/, 'video generation'],
  [/اختبار|اختبارات|تست/, 'testing'],
  [/تصحيح|تنقيح|دبوغ/, 'debugging'],
  [/توثيق|مستندات/, 'documentation'],
  [/بحث علمي|بحث/, 'research'],
  [/تسويق/, 'marketing'],
  [/نشر التطبيقات|نشر|دبلوي/, 'deployment'],
  [/أداء|سرعة|تحسين الأداء/, 'performance'],
  [/جيت/, 'git'],
  [/واجهات برمجية|واجهة برمجية|API/, 'api'],
  [/نودجيس|نود/, 'nodejs'],
  [/تايلويند/, 'tailwind'],
]

/** English filler/intent wrappers to strip (measured: sentences return 0). */
const EN_WRAPPERS: RegExp[] = [
  /^(i\s+)?(need|want|am looking for|looking for)\s+(a|an|some|the)?\s*/i,
  /^(please\s+)?(find|search|show|get|locate)\s+(me\s+)?(a|an|some|the)?\s*(best\s+)?(skills?|plugins?|tools?)?\s*(for|about|that|which|to)?\s*/i,
  /\bskill(s)?\s+(that|which|for|to|helps?|helps me)\b/gi,
  /\b(improves?|improve|enhance[sd]?|boost[sr]?|optimize[sd]?)\b/gi,
  /\b(building|creating|making|developing|professional|modern|best)\b/gi,
  /\b(websites?|web\s?apps?|applications?|apps?)\b/gi,
]

export interface PreparedQuery {
  /** the keyword query actually sent to providers */
  query: string
  /** the original user sentence (shown back verbatim) */
  original: string
  /** true when an Arabic term was translated — UI shows the mapping honestly */
  translatedFromArabic: boolean
  /** the Arabic→English mappings applied, for the transparency line */
  mappings: Array<{ from: string; to: string }>
}

/** Pure + synchronous — trivially testable, no network. */
export function prepareQuery(raw: string): PreparedQuery {
  const original = raw.trim()
  let q = original

  // 1) Arabic terms → English (recorded for the transparency line)
  const mappings: Array<{ from: string; to: string }> = []
  for (const [re, en] of AR_TERMS) {
    if (re.test(q)) {
      const from = (re.exec(q) ?? ['', ''])[0] || en
      mappings.push({ from, to: en })
      q = `${q} ${en}`
    }
  }

  // 2) strip English intent wrappers
  for (const re of EN_WRAPPERS) q = q.replace(re, ' ')

  // 3) drop Arabic characters (the backend is English-only — measured) but
  //    ONLY when we already extracted an English mapping; otherwise keep them
  //    so an all-Arabic query surfaces honestly as "no results", not as a lie.
  if (mappings.length > 0) q = q.replace(/[\u0600-\u06FF]{2,}/g, ' ')

  // 4) keep meaningful tokens: 2+ chars, dedup, cap at 6 terms
  const seen = new Set<string>()
  const tokens = q
    .toLowerCase()
    .split(/[^a-z0-9.+#-]+/i)
    .map((t) => t.replace(/^[-.]+|[-.]+$/g, ''))
    .filter((t) => t.length >= 2 && !seen.has(t) && seen.add(t))
    .slice(0, 6)

  return {
    query: tokens.join(' '),
    original,
    translatedFromArabic: mappings.length > 0,
    mappings,
  }
}
