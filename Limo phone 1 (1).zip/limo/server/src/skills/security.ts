/**
 * ALLIMNI — security assessment (LIMO #11).
 *
 * The directive is explicit: popularity is never proof of safety, and static
 * inspection is never a guarantee. So every assessment carries its PROVENANCE:
 *
 *   - external audit  → only when a real external audit body returned data
 *                       (skills.sh partner audits need Vercel OIDC — for local
 *                       LIMO deployments these stay `unavailable`, shown as-is)
 *   - limo static     → THIS scanner: deterministic pattern analysis of what
 *                       was actually fetched (bounded, evidenced, replayable)
 *   - dynamic sandbox → NOT run at import (nothing executes, ever) → honest
 *                       `not_run` status, never implied
 *   - unknown         → could not inspect (network/bounds) → no verdict at all
 *
 * Risk levels: NONE | LOW | MEDIUM | HIGH | CRITICAL | UNKNOWN.
 * HIGH/CRITICAL block automatic install — the approval gate refuses them.
 */

import type { SkillInspectionReport } from './inspect.js'

export type RiskLevel = 'NONE' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' | 'UNKNOWN'

export interface SecurityAssessment {
  riskLevel: RiskLevel
  /** where each dimension stands — provenance is part of the honesty contract */
  dimensions: Array<{
    id: string
    label: string
    /** external_audit | limo_static | dynamic_sandbox | not_run | unavailable */
    provenance: 'external_audit' | 'limo_static' | 'dynamic_sandbox' | 'not_run' | 'unavailable'
    status: 'clean' | 'findings' | 'not_run' | 'unavailable'
    detail: string
  }>
  /** true when the risk level forbids install outright (route enforces too) */
  installBlocked: boolean
  assessedAt: string
}

/** Derive the LIMO static risk level from a measured inspection report. */
export function assessSecurity(report: SkillInspectionReport): SecurityAssessment {
  const dims: SecurityAssessment['dimensions'] = []
  const now = new Date().toISOString()

  const blockers = report.blockers.length
  const failed = report.checks.filter((c) => c.status === 'failed').length
  const warnings = report.warnings.length
  const notTested = report.checks.filter((c) => c.status === 'not_tested').length
  const couldNotInspect = blockers > 0 && notTested > 0

  // ---- secrets / dangerous execution / injection (measured by the 12-step scan)
  const secretFail = report.checks.find((c) => c.id === 'secrets_scan')
  const dangerFail = report.checks.find((c) => c.id === 'dangerous_exec')
  const inject = report.checks.find((c) => c.id === 'prompt_injection')

  dims.push({
    id: 'secrets',
    label: 'الأسرار المكشوفة',
    provenance: secretFail?.status === 'not_tested' ? 'not_run' : 'limo_static',
    status: secretFail?.status === 'failed' ? 'findings' : secretFail?.status === 'not_tested' ? 'not_run' : 'clean',
    detail: secretFail?.detail ?? '',
  })
  dims.push({
    id: 'dangerous_exec',
    label: 'أنماط التنفيذ الخطرة',
    provenance: dangerFail?.status === 'not_tested' ? 'not_run' : 'limo_static',
    status: dangerFail?.status === 'failed' ? 'findings' : dangerFail?.status === 'not_tested' ? 'not_run' : 'clean',
    detail: dangerFail?.detail ?? '',
  })
  dims.push({
    id: 'prompt_injection',
    label: 'حقن التعليمات',
    provenance: inject?.status === 'not_tested' ? 'not_run' : 'limo_static',
    status: inject?.status === 'failed' ? 'findings' : inject?.status === 'not_tested' ? 'not_run' : 'clean',
    detail: inject?.detail ?? '',
  })

  // ---- external audit (skills.sh partners) — honestly unavailable locally
  dims.push({
    id: 'external_audit',
    label: 'تدقيق أمني خارجي',
    provenance: 'unavailable',
    status: 'unavailable',
    detail: 'تدقيقات skills.sh الشريكة تتطلب مصادقة Vercel OIDC — غير متاحة لعميل محلي؛ لا يُعرض أي تدقيق خارجي مزعوم',
  })

  // ---- dynamic sandbox — never run at import, by design
  dims.push({
    id: 'dynamic_sandbox',
    label: 'اختبار صندوق معزول',
    provenance: 'not_run',
    status: 'not_run',
    detail: 'لا يُنفَّذ شيء عند الاستيراد إطلاقًا — النسخ نصية فقط؛ أي اختبار ديناميكي لاحق يُعلن صراحة عند تشغيله',
  })

  let riskLevel: RiskLevel
  if (couldNotInspect) {
    riskLevel = 'UNKNOWN'
  } else if (secretFail?.status === 'failed' || dangerFail?.status === 'failed' || report.verdict === 'fail') {
    // hard findings on secrets or execution = HIGH; many failed dimensions = CRITICAL
    riskLevel = failed >= 3 ? 'CRITICAL' : 'HIGH'
  } else if (inject?.status === 'failed' || warnings >= 3) {
    riskLevel = 'MEDIUM'
  } else if (warnings > 0) {
    riskLevel = 'LOW'
  } else {
    riskLevel = report.verdict === 'pass' ? 'LOW' : 'UNKNOWN'
  }

  return {
    riskLevel,
    dimensions: dims,
    installBlocked: riskLevel === 'HIGH' || riskLevel === 'CRITICAL',
    assessedAt: now,
  }
}
