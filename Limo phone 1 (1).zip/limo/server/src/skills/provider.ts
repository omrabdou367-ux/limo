/**
 * ALLIMNI — the unified discovery provider interface (LIMO #11).
 *
 * Every capability source implements the same contract; the discovery service
 * fans a query out to all providers and normalizes what comes back. Adding a
 * future registry = one more object in PROVIDERS — no redesign anywhere else.
 *
 * Honesty contract (directive §2/§18):
 *  - fields a provider does not supply stay `null` — never fabricated;
 *  - a provider that fails returns `unavailable: true` + a reason — never
 *    silently dropped, never faked;
 *  - installs/counts are labelled with the provider + measured-at time.
 */

export interface DiscoveredSkill {
  /** provider-scoped unique id — for skills.sh: "owner/repo/skillId" */
  id: string
  name: string
  /** source string as the provider reports it — skills.sh: "owner/repo" */
  source: string
  /** direct human link to the source page when the provider gives one */
  sourceUrl: string | null
  /** skills.sh reports install counts; other providers may not */
  installs: number | null
  provider: 'skills.sh' | 'local' | 'github'
  /** only local: the installed slug */
  slug?: string
  /** only local: current status */
  status?: string
}

export interface ProviderResult {
  provider: string
  skills: DiscoveredSkill[]
  /** true when the provider errored / was unreachable — shown honestly */
  unavailable: boolean
  /** why it was unavailable (rate limit, network, auth) */
  reason?: string
  /** when this result was fetched (cache transparency) */
  fetchedAt: string
}

export interface SkillsProvider {
  id: string
  label: string
  /** true when the provider can resolve arbitrary keywords */
  supportsSearch: boolean
  search(query: string, opts: { limit: number; owner?: string }): Promise<ProviderResult>
}
