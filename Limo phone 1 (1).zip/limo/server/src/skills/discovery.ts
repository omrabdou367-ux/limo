/**
 * ALLIMNI — the discovery service (LIMO #11).
 *
 * Fans one natural-language request out to every provider, normalizes results,
 * caches them briefly (the owner types fast; skills.sh does not need to know),
 * and reports provider failures HONESTLY (unavailable + reason), never by
 * hiding the provider or inventing rows.
 *
 * Sources wired today:
 *  - skills.sh (the same public /api/search the official CLI uses)
 *  - local registry (installed skills — search your own library)
 * Future registries: add a SkillsProvider to PROVIDERS. Nothing else changes.
 */

import type { DB } from '../db/database.js'
import type { DiscoveredSkill, ProviderResult, SkillsProvider } from './provider.js'
import { skillsShProvider } from './provider-skills-sh.js'
import { prepareQuery, type PreparedQuery } from './nlquery.js'

const CACHE_TTL_MS = 10 * 60 * 1000
const cache = new Map<string, { at: number; results: DiscoveryResponse }>()

export interface DiscoveryResponse {
  /** what the owner typed, verbatim */
  originalQuery: string
  /** the keyword query actually sent to providers (transparency) */
  effectiveQuery: string
  /** Arabic→English mappings applied (shown in the UI when non-empty) */
  mappings: PreparedQuery['mappings']
  providers: ProviderResult[]
  /** merged + de-duplicated by provider:id */
  skills: DiscoveredSkill[]
  discoveredAt: string
}

/** Local provider — searches the installed library by name/description. */
function localProvider(db: DB): SkillsProvider {
  return {
    id: 'local',
    label: 'المكتبة المحلية',
    supportsSearch: true,
    async search(query, opts): Promise<ProviderResult> {
      const now = new Date().toISOString()
      const like = `%${query.replace(/[%_]/g, '')}%`
      const rows = db
        .prepare('SELECT slug, name, description, status, source_url FROM skills ORDER BY installed_at DESC LIMIT 200')
        .all() as Array<{ slug: string; name: string; description: string; status: string; source_url: string | null }>
      const q = query.toLowerCase()
      const hits = rows
        .filter((r) => r.name.toLowerCase().includes(q) || r.description.toLowerCase().includes(q))
        .slice(0, opts.limit)
        .map<DiscoveredSkill>((r) => ({
          id: `local/${r.slug}`,
          name: r.name,
          source: 'installed',
          sourceUrl: r.source_url,
          installs: null,
          provider: 'local',
          slug: r.slug,
          status: r.status,
        }))
      void like
      return { provider: 'local', skills: hits, unavailable: false, fetchedAt: now }
    },
  }
}

export async function discoverSkills(
  db: DB,
  rawQuery: string,
  opts: { limit?: number; owner?: string } = {},
): Promise<DiscoveryResponse> {
  const limit = Math.min(Math.max(opts.limit ?? 20, 1), 50)
  const prepared = prepareQuery(rawQuery)
  const cacheKey = `${prepared.query}|${limit}|${opts.owner ?? ''}`

  const cached = cache.get(cacheKey)
  if (cached && Date.now() - cached.at < CACHE_TTL_MS) {
    return { ...cached.results, discoveredAt: new Date(cached.at).toISOString(), originalQuery: rawQuery }
  }

  const providers: SkillsProvider[] = [skillsShProvider, localProvider(db)]
  const results = await Promise.all(
    providers.map(async (p) => {
      if (!prepared.query) {
        // no keywords to search — honest empty, not a fake success
        return { provider: p.id, skills: [], unavailable: false, reason: 'لا كلمات مفتاحية للبحث', fetchedAt: new Date().toISOString() } satisfies ProviderResult
      }
      try {
        return await p.search(prepared.query, { limit, owner: opts.owner })
      } catch (e) {
        return { provider: p.id, skills: [], unavailable: true, reason: e instanceof Error ? e.message : String(e), fetchedAt: new Date().toISOString() } satisfies ProviderResult
      }
    }),
  )

  // merge: skills.sh first, then local; dedup by provider:id
  const seen = new Set<string>()
  const skills: DiscoveredSkill[] = []
  for (const r of results) {
    for (const s of r.skills) {
      const key = `${r.provider}:${s.id}`
      if (seen.has(key)) continue
      seen.add(key)
      skills.push(s)
    }
  }

  const response: DiscoveryResponse = {
    originalQuery: rawQuery,
    effectiveQuery: prepared.query,
    mappings: prepared.mappings,
    providers: results,
    skills,
    discoveredAt: new Date().toISOString(),
  }
  cache.set(cacheKey, { at: Date.now(), results: response })
  if (cache.size > 50) {
    // tiny bounded cache — drop the oldest entry
    const first = cache.keys().next().value
    if (first) cache.delete(first)
  }
  return response
}
