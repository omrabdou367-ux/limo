/**
 * ALLIMNI (علّمني) — install + on-disk library. The install is a TEXT-ONLY
 * copy: nothing executes at import time, ever. What lands on disk is re-scanned
 * before the skill is acknowledged — a blocker found after the copy removes
 * the directory and fails the install honestly.
 *
 * v2 (LIMO #11): the copy is SCOPED to the inspected skill directory (report.
 * target.dir) and reads through the same data source the inspection used
 * (GitHub API, or the jsDelivr mirror when GitHub is rate-limited), so what
 * was scanned is exactly what is written.
 */

import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import type { ServerConfig } from '../config.js'
import type { SkillInspectionReport } from './inspect.js'
import {
  DANGEROUS_PATTERNS, INJECTION_PATTERNS, MAX_FILES, MAX_TOTAL_BYTES, SECRET_PATTERNS, TEXT_EXTENSIONS,
  parseGitHubUrl,
} from './inspect.js'

const PER_FILE_WRITE_BYTES = 256 * 1024
const LIST_CAP = 1000
const SLUG_RE = /^[a-z0-9][a-z0-9-]{0,63}$/
const FETCH_TIMEOUT_MS = 15_000

export function slugify(input: string): string {
  const s = input
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64)
  return SLUG_RE.test(s) ? s : 'skill'
}

function skillRoot(config: ServerConfig): string {
  return join(config.dataDir, 'skills')
}

function skillDir(config: ServerConfig, slug: string): string {
  if (!SLUG_RE.test(slug)) throw new Error(`slug غير صالح: ${slug}`)
  return join(skillRoot(config), slug)
}

/** A path is jail-safe when it has no traversal and is not absolute. */
function jailed(rel: string): boolean {
  if (rel.length === 0 || rel.startsWith('/') || rel.includes('\\')) return false
  return rel.split('/').every((seg) => seg.length > 0 && seg !== '.' && seg !== '..')
}

// ------------------------------------------------------------ the library
export function listSkillFiles(config: ServerConfig, slug: string): Array<{ path: string; bytes: number }> {
  const dir = skillDir(config, slug)
  if (!existsSync(dir)) return []
  const out: Array<{ path: string; bytes: number }> = []
  const walk = (rel: string) => {
    if (out.length >= LIST_CAP) return
    for (const name of readdirSync(join(dir, rel))) {
      if (out.length >= LIST_CAP) return
      const childRel = rel ? `${rel}/${name}` : name
      const full = join(dir, childRel)
      const st = statSync(full)
      if (st.isDirectory()) walk(childRel)
      else out.push({ path: childRel, bytes: st.size })
    }
  }
  walk('')
  return out.sort((a, b) => a.path.localeCompare(b.path))
}

export function readSkillFile(config: ServerConfig, slug: string, path: string): { path: string; content: string } | null {
  if (!jailed(path)) return null
  const dir = skillDir(config, slug)
  const full = join(dir, path)
  if (!existsSync(full)) return null
  const st = statSync(full)
  if (st.size > PER_FILE_WRITE_BYTES) return null
  return { path, content: readFileSync(full, 'utf8') }
}

export function removeSkillDir(config: ServerConfig, slug: string): void {
  if (!SLUG_RE.test(slug)) return
  rmSync(skillDir(config, slug), { recursive: true, force: true })
}

/** Active skills for the agent link (HYPERBRAIN) — reads the registry rows' slugs. */
export function skillDirFor(config: ServerConfig, slug: string): string | null {
  const dir = skillDir(config, slug)
  return existsSync(dir) ? dir : null
}

// ------------------------------------------------------------ content readers
async function readViaGithub(owner: string, name: string, branch: string, path: string): Promise<string> {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS)
  try {
    const res = await fetch(`https://api.github.com/repos/${owner}/${name}/contents/${path.split('/').map(encodeURIComponent).join('/')}?ref=${branch}`, {
      signal: ctrl.signal,
      headers: { accept: 'application/vnd.github.raw', 'user-agent': 'limo-allimni-installer/2.0' },
    })
    if (!res.ok) throw new Error(`GitHub ${res.status} ${res.statusText}`)
    return await res.text()
  } finally {
    clearTimeout(timer)
  }
}

async function readViaMirror(owner: string, name: string, branch: string, path: string): Promise<string> {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS)
  try {
    const res = await fetch(`https://cdn.jsdelivr.net/gh/${owner}/${name}@${branch}/${path}`, {
      signal: ctrl.signal,
      headers: { 'user-agent': 'limo-allimni-installer/2.0' },
    })
    if (!res.ok) throw new Error(`jsDelivr ${res.status} ${res.statusText}`)
    return await res.text()
  } finally {
    clearTimeout(timer)
  }
}

// ------------------------------------------------------------ install
export interface InstalledSkill {
  slug: string
  files: Array<{ path: string; bytes: number }>
  totalBytes: number
  commit: string | null
}

export async function installSkill(config: ServerConfig, report: SkillInspectionReport): Promise<InstalledSkill> {
  const parsed = parseGitHubUrl(report.url)
  if (!parsed) throw new Error('تقرير بلا عنوان GitHub صالح — لا تثبيت')

  const branch = report.repo.branch || 'main'
  const useMirror = report.dataSource === 'jsdelivr'
  const read = (path: string) =>
    useMirror ? readViaMirror(parsed.owner, parsed.name, branch, path) : readViaGithub(parsed.owner, parsed.name, branch, path)

  // the install copies EXACTLY the manifest the inspection measured — the
  // scoped file list in report.files (text-only, jailed, bounded). Paths are
  // re-based onto the SKILL's own root (measured: the official CLI installs a
  // skill as <dir>/SKILL.md at the top level, and the agent link expects that).
  const scopePrefix = report.target.dir ? `${report.target.dir}/` : ''
  const entries = report.files
    .map((f) => ({ repoPath: f.path, skillPath: scopePrefix && f.path.startsWith(scopePrefix) ? f.path.slice(scopePrefix.length) : f.path }))
    .filter((f) => {
      if (f.skillPath.length === 0) return false
      if (!jailed(f.skillPath)) return false
      const ext = f.skillPath.split('.').pop()?.toLowerCase() ?? ''
      return TEXT_EXTENSIONS.has(ext)
    })
  if (entries.length === 0) throw new Error('لا ملفات صالحة للنسخ ضمن نطاق المهارة')
  if (entries.length > MAX_FILES) throw new Error(`عدد الملفات ${entries.length} يتجاوز الحد ${MAX_FILES}`)

  const slug = slugify(report.frontmatter?.name ?? report.target.skillId ?? report.repo.name)
  const dir = skillDir(config, slug)
  const written: Array<{ path: string; bytes: number }> = []
  let totalBytes = 0
  let counter = 0

  try {
    // bounded parallel copy — the mirror path stays fast without hammering
    const perFile = await Promise.all(
      Array.from({ length: Math.min(6, entries.length) }, async () => {
        const out: Array<{ path: string; bytes: number; text: string }> = []
        let i = counter++
        while (i < entries.length) {
          const entry = entries[i]!
          counter++
          const text = await read(entry.repoPath)
          if (text.length > PER_FILE_WRITE_BYTES) throw new Error(`الملف ${entry.repoPath} يتجاوز حد الكتابة`)
          out.push({ path: entry.skillPath, bytes: Buffer.byteLength(text, 'utf8'), text })
          i = counter++
        }
        return out
      }),
    ).then((chunks) => chunks.flat())
    for (const f of perFile) {
      if (totalBytes > MAX_TOTAL_BYTES) throw new Error('تجاوز الحد الكلي للنسخة')
      const full = join(dir, f.path)
      mkdirSync(dirname(full), { recursive: true })
      writeFileSync(full, f.text, 'utf8')
      written.push({ path: f.path, bytes: f.bytes })
      totalBytes += f.bytes
    }
  } catch (e) {
    rmSync(dir, { recursive: true, force: true })
    throw e instanceof Error ? e : new Error(String(e))
  }

  // re-scan what actually landed on disk — the report is not enough
  for (const f of written) {
    const text = readFileSync(join(dir, f.path), 'utf8')
    for (const p of SECRET_PATTERNS) {
      if (p.re.test(text)) {
        rmSync(dir, { recursive: true, force: true })
        throw new Error(`مانع بعد الكتابة على القرص — ${p.label} في ${f.path}`)
      }
    }
    for (const p of DANGEROUS_PATTERNS) {
      if (p.re.test(text)) {
        rmSync(dir, { recursive: true, force: true })
        throw new Error(`مانع بعد الكتابة على القرص — ${p.label} في ${f.path}`)
      }
    }
    void INJECTION_PATTERNS // injection on disk is surfaced by the report; secrets/exec are the hard stops
  }

  return { slug, files: written, totalBytes, commit: report.commit }
}

// ------------------------------------------------------------ update check
/** Fetch the current head commit of a repo's branch (GitHub primary, mirror best-effort). */
export async function fetchHeadCommit(owner: string, repo: string, branch: string): Promise<string | null> {
  try {
    const ctrl = new AbortController()
    const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS)
    try {
      const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/commits/${branch}`, {
        signal: ctrl.signal,
        headers: { accept: 'application/vnd.github+json', 'user-agent': 'limo-allimni-updater/2.0' },
      })
      if (!res.ok) return null
      const body = (await res.json()) as { sha?: string }
      return body.sha ?? null
    } finally {
      clearTimeout(timer)
    }
  } catch {
    return null
  }
}
