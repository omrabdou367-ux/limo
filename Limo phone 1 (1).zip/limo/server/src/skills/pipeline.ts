import { randomBytes } from 'node:crypto'
import type { DB } from '../db/database.js'
import { inspectSkill, type SkillInspectionReport } from './inspect.js'
import { assessSecurity, type SecurityAssessment } from './security.js'
import { assessCompatibility, type CompatibilityAssessment } from './compatibility.js'
import { recordSkillEvent } from './registry.js'

/**
 * The shared 10-step import pipeline (LIMO #11) — ONE implementation used by
 * BOTH the ALLIMNI HTTP route (POST /api/skills/import) and the Black Box
 * brain tool `request_skill_install` (LIMO #13: «يضيف ميزات جديدة»).
 *
 * Honesty invariants preserved:
 *  - inspection is REAL (bounded fetch of the actual repo files);
 *  - nothing here installs anything — the result is a persisted import row in
 *    'awaiting_approval' and the OWNER decides in the ALLIMNI screen (the
 *    HIGH/CRITICAL risk gate stays in the decision route, unreachable here);
 *  - a failed inspection is persisted as 'rejected' with its real blockers.
 */

export type StartImportResult =
  | { kind: 'not_supported'; source: string; reason: string }
  | {
      kind: 'inspection_failed'
      importId: string
      url: string
      blockers: string[]
      report: SkillInspectionReport
      security: SecurityAssessment
      compatibility: CompatibilityAssessment
    }
  | {
      kind: 'awaiting_approval'
      importId: string
      url: string
      report: SkillInspectionReport
      security: SecurityAssessment
      compatibility: CompatibilityAssessment
      installs: number | null
    }

const GITHUB_SOURCE_RE = /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/

export async function startSkillImport(
  db: DB,
  input: { url?: string; source?: string; skillId?: string; installs?: number | null },
): Promise<StartImportResult> {
  // resolve skills.sh search results to their GitHub repository
  let url: string
  let skillId: string | undefined
  let provider: string
  if (input.url) {
    url = input.url
    provider = 'github'
  } else {
    const source = (input.source ?? '').trim()
    const isGitHub = GITHUB_SOURCE_RE.test(source) && !source.includes(' ')
    if (!isGitHub) {
      return {
        kind: 'not_supported',
        source,
        reason: `المصدر «${source}» ليس مستودع GitHub — الاستيراد متاح لمصادر GitHub فقط في هذه النسخة؛ المهارة تبقى قابلة للاكتشاف`,
      }
    }
    url = `https://github.com/${source}`
    skillId = input.skillId
    provider = 'skills.sh'
  }
  void provider

  const id = randomBytes(5).toString('hex')
  db.prepare("INSERT INTO skill_imports (id, url, status, requested_at) VALUES (?, ?, 'inspecting', ?)").run(id, url, new Date().toISOString())

  // inspection is bounded by design (file/size/scan caps + fetch timeout)
  const report = await inspectSkill(url, skillId ? { skillId } : {})
  const security = assessSecurity(report)
  const compatibility = assessCompatibility(report)

  if (report.verdict === 'fail') {
    db.prepare("UPDATE skill_imports SET status = 'rejected', report = ?, error = ?, decided_at = ? WHERE id = ?").run(
      JSON.stringify({ report, security, compatibility }),
      `مانعات: ${report.blockers.join(' · ')}`,
      new Date().toISOString(),
      id,
    )
    recordSkillEvent(db, report.frontmatter?.name ?? url, 'inspected', `فحص فاشل: ${report.blockers.join(' · ')}`)
    return { kind: 'inspection_failed', importId: id, url, blockers: report.blockers, report, security, compatibility }
  }

  db.prepare("UPDATE skill_imports SET status = 'awaiting_approval', report = ? WHERE id = ?").run(
    JSON.stringify({ report, security, compatibility, installs: input.installs ?? null }),
    id,
  )
  recordSkillEvent(db, report.frontmatter?.name ?? url, 'inspected', `الحكم: ${report.verdict} · الخطر: ${security.riskLevel} · التوافق: ${compatibility.state}`)
  return {
    kind: 'awaiting_approval',
    importId: id,
    url,
    report,
    security,
    compatibility,
    installs: input.installs ?? null,
  }
}
