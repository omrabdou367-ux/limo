/**
 * ALLIMNI — compatibility engine (LIMO #11).
 *
 * How LIMO consumes a skill: the agent reads the skill's SKILL.md (and its
 * bundled reference files) as INSTRUCTION DOCUMENTS through a bounded reader —
 * nothing executes. So compatibility is mostly about FORMAT (does it carry
 * parseable instructions?) and DECLARED REQUIREMENTS (tools/network the text
 * assumes), never about blind trust in the author's target agent.
 *
 * States: COMPATIBLE | PARTIALLY_COMPATIBLE | INCOMPATIBLE | UNKNOWN
 * (the directive also allows COMPATIBLE_WITH_ADAPTER — LIMO's reader IS the
 *  adapter for text skills, so a text skill with extra runtime needs lands in
 *  PARTIALLY_COMPATIBLE with the gap spelled out.)
 */

import type { SkillInspectionReport } from './inspect.js'

export type CompatibilityState = 'COMPATIBLE' | 'PARTIALLY_COMPATIBLE' | 'INCOMPATIBLE' | 'UNKNOWN'

export interface CompatibilityAssessment {
  state: CompatibilityState
  requirements: Array<{ id: string; label: string; met: boolean; detail: string }>
  /** "ما الذي تتيحه هذه المهارة لليمو؟" — generated from measured fields only */
  capabilitySummary: string
  /** honest limits: what it will NOT do inside LIMO */
  limitations: string[]
  assessedAt: string
}

export function assessCompatibility(report: SkillInspectionReport): CompatibilityAssessment {
  const reqs: CompatibilityAssessment['requirements'] = []
  const now = new Date().toISOString()

  // 1) format: SKILL.md with parseable frontmatter + instruction body
  const hasFrontmatter = report.frontmatter !== null && Object.keys(report.frontmatter ?? {}).length > 0
  const hasBody = report.frontmatter !== null || report.coverage.total > 0
  reqs.push({
    id: 'format',
    label: 'صيغة المهارة (SKILL.md)',
    met: hasFrontmatter,
    detail: hasFrontmatter
      ? `بيانات أمامية سليمة${report.frontmatter?.name ? `: ${report.frontmatter.name}` : ''}`
      : hasBody
        ? 'SKILL.md موجود لكن بلا بيانات أمامية — يعمل لكن بتعريف أضعف'
        : 'لا SKILL.md — ليس مهارة بالصيغة المعتمدة',
  })

  // 2) declared dependencies — nothing installs them here (text-only copy)
  const depCount = (report.dependencies ?? []).reduce((acc, d) => acc + d.deps, 0)
  reqs.push({
    id: 'dependencies',
    label: 'الاعتماديات المعلنة',
    met: depCount === 0,
    detail: depCount === 0 ? 'لا اعتماديات معلنة — المكتبة نصية كاملة' : `${depCount} اعتمادية معلنة — لا تُثبَّت هنا؛ المهارة تعمل كمَرْجَع تعليمات فقط`,
  })

  // 3) text-only payload — measured by the file-types check
  const fileTypes = report.checks.find((c) => c.id === 'file_types')
  const textOnly = fileTypes?.status === 'verified'
  reqs.push({
    id: 'payload',
    label: 'حمولة نصية فقط',
    met: textOnly,
    detail: fileTypes?.detail ?? '',
  })

  // 4) shell/scripts present? they are stored as DATA; the agent reads them
  //    but never executes them through the import path
  const hasScripts = (report.dependencies ?? []).length > 0 || report.checks.some((c) => c.id === 'dangerous_exec' && c.status === 'failed')
  reqs.push({
    id: 'runtime',
    label: 'بيئة تشغيل',
    met: !hasScripts,
    detail: hasScripts
      ? 'توجد نصوص/تنفيذيات في المحتوى — تُخزَّن كبيانات؛ تشغيلها خارج نطاق الاستيراد ويتطلب قرارًا منفصلًا'
      : 'لا حاجة لبيئة تشغيل — تعليمات ومراجع نصية',
  })

  const name = report.frontmatter?.name ?? `${report.repo.owner}/${report.repo.name}`
  const desc = report.frontmatter?.description ?? ''
  const failed = reqs.filter((r) => !r.met)

  const state: CompatibilityState =
    report.verdict === 'fail' ? 'INCOMPATIBLE'
    : !hasBody ? 'INCOMPATIBLE'
    : failed.length === 0 ? 'COMPATIBLE'
    : failed.length <= 2 ? 'PARTIALLY_COMPATIBLE'
    : 'UNKNOWN'

  const capabilitySummary =
    `تتيح لوكيل LIMO قراءة تعليمات «${name}»${desc ? ` — ${desc.slice(0, 180)}` : ''} واستخدامها كمرجع أثناء التخطيط والتنفيذ عبر أداة القراءة المقيّدة (لا تنفيذ للأوامر).`

  const limitations: string[] = [
    'المهارة تُقرأ كنص — لا تُنفَّذ أوامرها عبر مسار الاستيراد إطلاقًا',
  ]
  if (depCount > 0) limitations.push('اعتمادياتها المعلنة لا تُثبَّت تلقائيًا — تعمل كمرجع معرفي فقط')
  if (hasScripts) limitations.push('النصوص البرمجية داخلها مخزّنة كبيانات ولا تشغّلها LIMO')
  limitations.push('إسنادها لوكلاء محددين وتعطيلها يتم من مركز الإدارة')

  return { state, requirements: reqs, capabilitySummary, limitations, assessedAt: now }
}
