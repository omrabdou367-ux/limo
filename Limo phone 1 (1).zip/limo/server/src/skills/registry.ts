/**
 * ALLIMNI — registry helpers + the immutable activity log (LIMO #11).
 * Every state transition is recorded in skill_events; rows are append-only.
 */

import type { DB } from '../db/database.js'

export type SkillAction =
  | 'discovered' | 'inspected' | 'approved' | 'rejected' | 'installed' | 'enabled' | 'disabled'
  | 'update_check' | 'update_available' | 'removed' | 'permission_denied'

export function recordSkillEvent(db: DB, slug: string, action: SkillAction, detail = ''): void {
  db.prepare('INSERT INTO skill_events (skill_slug, action, detail, created_at) VALUES (?, ?, ?, ?)').run(
    slug,
    action,
    detail,
    new Date().toISOString(),
  )
}

export function skillEvents(db: DB, slug?: string, limit = 100) {
  const cap = Math.min(Math.max(limit, 1), 500)
  if (slug) {
    return db.prepare('SELECT * FROM skill_events WHERE skill_slug = ? ORDER BY id DESC LIMIT ?').all(slug, cap)
  }
  return db.prepare('SELECT * FROM skill_events ORDER BY id DESC LIMIT ?').all(cap)
}

/** The lifecycle status for a registry row (status2 supersedes status; old rows migrate lazily). */
export function lifecycleStatus(row: { status: string; status2: string | null }): string {
  return row.status2 ?? (row.status === 'active' ? 'active' : row.status === 'disabled' ? 'disabled' : row.status)
}
