/**
 * ALLIMNI — skills.sh provider.
 *
 * REALITY (measured 2026-11-01, before writing a single line):
 *  - The documented public API at https://skills.sh/docs/api (`/api/v1/skills`,
 *    `/api/v1/skills/search`, `/api/v1/skills/curated`, `/api/v1/skills/audit/…`)
 *    requires a Vercel OIDC bearer token — it is built for skills running ON
 *    Vercel. A local LIMO deployment cannot obtain that token, and this
 *    provider does NOT bypass the access control. Trending / curated / the
 *    partner audits stay honestly "unavailable" in the UI.
 *  - The official CLI (`npx skills find`, npm package `skills`) itself searches
 *    an UNAUTHENTICATED endpoint — `GET https://skills.sh/api/search?q=…&limit=…`
 *    (verified in the CLI's shipped source, dist/cli.mjs:searchSkillsAPI, and
 *    live: 200 with real results). This provider calls exactly that endpoint,
 *    with exactly those parameters — the same public interface the official
 *    client uses. That is discovery done legitimately, not scraping.
 *
 * Response schema (live-verified):
 *   { query, searchType, searchVersion, skills: [{ id, source, skillId, name,
 *     installs }], count, duration_ms }
 */

import type { DiscoveredSkill, ProviderResult, SkillsProvider } from './provider.js'

const SEARCH_API = 'https://skills.sh/api/search'
const FETCH_TIMEOUT_MS = 12_000

interface ShSearchResponse {
  skills?: Array<{ id?: string; source?: string; skillId?: string; name?: string; installs?: number }>
}

async function shSearch(query: string, opts: { limit: number; owner?: string }): Promise<ProviderResult> {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS)
  const now = new Date().toISOString()
  try {
    const params = new URLSearchParams({ q: query, limit: String(Math.min(Math.max(opts.limit, 1), 50)) })
    if (opts.owner) params.set('owner', opts.owner)
    const res = await fetch(`${SEARCH_API}?${params.toString()}`, {
      signal: ctrl.signal,
      headers: { accept: 'application/json', 'user-agent': 'limo-allimni/2.0 (+local agent skill discovery)' },
    })
    if (res.status === 429) {
      const retry = res.headers.get('retry-after') ?? '60'
      return { provider: 'skills.sh', skills: [], unavailable: true, reason: `محدودية معدل — أعد المحاولة بعد ${retry}ث`, fetchedAt: now }
    }
    if (!res.ok) {
      return { provider: 'skills.sh', skills: [], unavailable: true, reason: `skills.sh أجاب ${res.status}`, fetchedAt: now }
    }
    const body = (await res.json()) as ShSearchResponse
    const skills: DiscoveredSkill[] = (body.skills ?? []).map((s) => {
      const source = (s.source ?? '').trim()
      const skillId = (s.skillId ?? s.name ?? '').trim()
      const isGitHub = /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(source) && !source.includes(' ')
      return {
        id: (s.id ?? `${source}/${skillId}`).trim(),
        name: (s.name ?? skillId).trim(),
        source,
        // live-verified page pattern: https://www.skills.sh/{source} (200 OK);
        // GitHub link additionally when the source is a GitHub owner/repo
        sourceUrl: source ? (isGitHub ? `https://github.com/${source}` : `https://www.skills.sh/${source}`) : null,
        installs: typeof s.installs === 'number' ? s.installs : null,
        provider: 'skills.sh',
      }
    })
    return { provider: 'skills.sh', skills, unavailable: false, fetchedAt: now }
  } catch (e) {
    const msg = e instanceof Error ? (e.name === 'AbortError' ? 'انتهت المهلة' : e.message) : String(e)
    return { provider: 'skills.sh', skills: [], unavailable: true, reason: `تعذر الوصول إلى skills.sh — ${msg}`, fetchedAt: now }
  } finally {
    clearTimeout(timer)
  }
}

export const skillsShProvider: SkillsProvider = {
  id: 'skills.sh',
  label: 'skills.sh',
  supportsSearch: true,
  search: shSearch,
}
