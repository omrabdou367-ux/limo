/**
 * ALLIMNI — skill resolution inside a repository (LIMO #11).
 *
 * Measured reality: modern skill repositories are MULTI-SKILL —
 * e.g. vercel-labs/agent-skills keeps its skills at skills/<dir>/SKILL.md,
 * and the directory name does NOT always equal the skills.sh skillId
 * (dir: skills/react-best-practices, frontmatter name: vercel-react-best-practices).
 *
 * So the resolver walks the tree, finds every SKILL.md, parses its frontmatter
 * `name`, and matches the requested skillId against (a) frontmatter name and
 * (b) the directory basename — the same way the official CLI's `--skill`
 * selection works. Repos with a single root SKILL.md resolve to the root.
 */

export interface RepoTreeEntry {
  path: string
  type: string
  size?: number
}

export interface SkillRoot {
  /** repository-relative directory containing SKILL.md ('' = repo root) */
  dir: string
  /** frontmatter name when present */
  name: string | null
  /** frontmatter description when present */
  description: string | null
  /** directory basename */
  basename: string
}

/** All SKILL.md locations in a tree (bounded — mirrors the inspector's caps). */
export function findSkillRoots(entries: RepoTreeEntry[]): SkillRoot[] {
  const out: SkillRoot[] = []
  for (const e of entries) {
    if (e.type !== 'blob') continue
    const m = /^(.*\/)?SKILL\.md$/i.exec(e.path)
    if (!m) continue
    const dir = (m[1] ?? '').replace(/\/$/, '')
    out.push({ dir, name: null, description: null, basename: dir.split('/').pop() ?? '' })
  }
  return out
}

/**
 * Attach frontmatter (name/description) to each root. `readFile` is injected
 * so this stays pure/testable — the caller bounds and caches the reads.
 */
export async function enrichSkillRoots(
  roots: SkillRoot[],
  readFile: (path: string) => Promise<string | null>,
  maxRoots = 30,
): Promise<SkillRoot[]> {
  const bounded = roots.slice(0, maxRoots)
  return Promise.all(
    bounded.map(async (r) => {
      try {
        const text = await readFile(r.dir ? `${r.dir}/SKILL.md` : 'SKILL.md')
        if (!text) return r
        const fm = parseSkillFrontmatter(text)
        return { ...r, name: fm.name ?? r.name, description: fm.description ?? r.description }
      } catch {
        return r
      }
    }),
  )
}

/**
 * Match a skills.sh skillId against the enriched roots:
 * frontmatter name first (measured to be the authoritative id), then dir
 * basename. Returns null when the repo does not contain that skill.
 */
export function matchSkillRoot(roots: SkillRoot[], skillId: string): SkillRoot | null {
  if (roots.length === 0) return null
  const id = skillId.trim().toLowerCase()
  const byName = roots.find((r) => (r.name ?? '').toLowerCase() === id)
  if (byName) return byName
  const byBasename = roots.find((r) => r.basename.toLowerCase() === id)
  if (byBasename) return byBasename
  // single-skill repo: the skillId may just differ — accept the lone root
  if (roots.length === 1 && roots[0]!.dir === '') return roots[0]!
  return null
}

/** Parse the SKILL.md frontmatter block (name/description/license/author/version). */
export function parseSkillFrontmatter(text: string): { name: string | null; description: string | null; license: string | null; author: string | null; version: string | null; raw: Record<string, string> } {
  const m = /^---\r?\n([\s\S]*?)\r?\n---/.exec(text)
  const raw: Record<string, string> = {}
  if (m) {
    for (const line of m[1]!.split(/\r?\n/)) {
      const idx = line.indexOf(':')
      if (idx <= 0) continue
      const key = line.slice(0, idx).trim()
      let val = line.slice(idx + 1).trim()
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1)
      if (key && !(key in raw)) raw[key] = val
    }
  }
  return {
    name: raw.name ?? null,
    description: raw.description ?? null,
    license: raw.license ?? null,
    author: raw.author ?? raw.metadata ?? null,
    version: raw.version ?? null,
    raw,
  }
}
