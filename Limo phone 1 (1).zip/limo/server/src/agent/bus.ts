import type { AgentEvent } from './types'

/**
 * In-process pub/sub bridging engine events to SSE subscribers.
 * The DB (agent_events) is the durable record; this bus is live-only.
 */

type Listener = (event: AgentEvent) => void

const listeners = new Map<number, Set<Listener>>()

export function publish(taskId: number, event: AgentEvent): void {
  const set = listeners.get(taskId)
  if (set) for (const l of set) l(event)
}

export function subscribe(taskId: number, listener: Listener): () => void {
  let set = listeners.get(taskId)
  if (!set) {
    set = new Set()
    listeners.set(taskId, set)
  }
  set.add(listener)
  return () => {
    set!.delete(listener)
    if (set!.size === 0) listeners.delete(taskId)
  }
}

// ------------------------------------------------------------------ hooks

/** Vault-unlock listeners (§7.2: catch-up of skipped one-shot routines). */
const unlockListeners = new Set<() => void>()

export function onVaultUnlocked(listener: () => void): () => void {
  unlockListeners.add(listener)
  return () => unlockListeners.delete(listener)
}

export function notifyVaultUnlocked(): void {
  for (const l of unlockListeners) l()
}
