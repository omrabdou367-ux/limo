import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import type { Logger } from '../logger.js'
import { subscribe, publish } from './bus.js'
import { buildModelFn } from './model.js'
import { startAgentTask } from './start.js'
import { RoutineScheduler } from './routines.js'
import { VectorMemory } from './memory.js'
import { decideApproval, getApproval, listApprovals } from './approvals.js'
import { getProject } from '../projects/store.js'
import { autoModelFn, getAutoPrefs, pickAutoModel, setAutoPrefs, type AutoModelPrefs } from './autoselect.js'
import { openSse, startHeartbeat, writeSseData, writeSseDone } from '../gateway/sse.js'
import type { AgentEvent, RoutineRow } from './types'

/**
 * Agent + memory + routines + egress routes (PLAN.md §6 stage 3, v2.2 #5/#7).
 * All routes sit behind the auth guard (session cookie or Bearer omn_live_…).
 */

export interface AgentRouteDeps {
  db: DB
  config: ServerConfig
  registry: ProviderRegistry
  vault: Vault
  log: Logger
  memory: VectorMemory
  scheduler: RoutineScheduler
}

const sqlTs = 'strftime(\'%Y-%m-%dT%H:%M:%fZ\',\'now\')'

export function registerAgentRoutes(app: FastifyInstance, deps: AgentRouteDeps): void {
  const { db, config, registry, vault, log, memory, scheduler } = deps

  // ------------------------------------------------------------- tasks

  app.post(
    '/api/agent/tasks',
    {
      schema: {
        body: {
          type: 'object',
          required: ['goal', 'model'],
          additionalProperties: false,
          properties: {
            goal: { type: 'string', minLength: 4, maxLength: 4000 },
            // 'auto' = اختيار النماذج تلقائيًا لكل غرض (planner/critic/recovery)
            model: { type: 'string', minLength: 3, maxLength: 256 },
            projectId: { type: 'string', minLength: 8, maxLength: 12 },
            mode: { type: 'string', enum: ['auto', 'research', 'build', 'creative', 'super'] },
          },
        },
      },
    },
    async (request, reply) => {
      const { goal, model, projectId, mode } = request.body as {
        goal: string
        model: string
        projectId?: string
        mode?: 'auto' | 'research' | 'build' | 'creative' | 'super'
      }
      // ONE shared starter (LIMO #14) — the Black Box `launch_agent_task` tool
      // runs the exact same path; only the provenance column differs
      const started = await startAgentTask({ db, config, registry, vault, log, memory }, {
        goal,
        model,
        projectId: projectId ?? null,
        mode,
        source: 'user',
      })
      if (!started.ok) {
        return reply.code(started.code).send({ error: { message: started.error, type: started.code === 409 ? 'no_usable_models' : 'invalid_request_error', code: started.code } })
      }
      return reply.code(201).send({ task: getTask(db, started.id) })
    },
  )

  app.get('/api/agent/tasks', async () => ({
    tasks: db.prepare('SELECT * FROM agent_tasks ORDER BY id DESC LIMIT 50').all(),
  }))

  app.get('/api/agent/tasks/:id', async (request, reply) => {
    const { id } = request.params as { id: string }
    const task = getTask(db, Number(id))
    if (!task) return reply.code(404).send({ error: { message: 'المهمة غير موجودة', type: 'not_found', code: 404 } })
    const steps = db.prepare('SELECT * FROM agent_steps WHERE task_id = ? ORDER BY idx').all(task.id)
    const events = db.prepare('SELECT * FROM agent_events WHERE task_id = ? ORDER BY id').all(task.id)
    const actions = db.prepare('SELECT * FROM agent_actions WHERE task_id = ? ORDER BY id').all(task.id)
    return { task, steps, events, actions }
  })

  app.post('/api/agent/tasks/:id/cancel', async (request, reply) => {
    const { id } = request.params as { id: string }
    const task = getTask(db, Number(id))
    if (!task) return reply.code(404).send({ error: { message: 'المهمة غير موجودة', type: 'not_found', code: 404 } })
    if (['completed', 'failed', 'cancelled'].includes(task.status)) {
      return reply.code(409).send({ error: { message: 'المهمة منتهية بالفعل', type: 'already_finished', code: 409 } })
    }
    db.prepare(`UPDATE agent_tasks SET status = 'cancelled', updated_at = ${sqlTs} WHERE id = ?`).run(task.id)
    return { ok: true, task: getTask(db, task.id) }
  })

  /** Live SSE stream: replays the durable timeline, then follows the bus. */
  app.get('/api/agent/tasks/:id/events', async (request, reply) => {
    const { id } = request.params as { id: string }
    const task = getTask(db, Number(id))
    if (!task) return reply.code(404).send({ error: { message: 'المهمة غير موجودة', type: 'not_found', code: 404 } })
    openSse(reply)
    const heart = startHeartbeat(reply)
    let finished = ['completed', 'failed', 'cancelled'].includes(task.status)
    for (const row of db.prepare('SELECT * FROM agent_events WHERE task_id = ? ORDER BY id').all(task.id) as Array<{ kind: string; ts: string; data: string }>) {
      writeSseData(reply, { kind: row.kind, ts: row.ts, data: safeParse(row.data) })
    }
    if (finished) {
      writeSseDone(reply)
      clearInterval(heart)
      return
    }
    const unsubscribe = subscribe(task.id, (event: AgentEvent) => {
      writeSseData(reply, event)
      if (event.kind === 'task_completed' || event.kind === 'task_failed' || event.kind === 'task_cancelled') {
        finished = true
        writeSseDone(reply)
        clearInterval(heart)
        unsubscribe()
      }
    })
    request.raw.on('close', () => {
      clearInterval(heart)
      unsubscribe()
    })
  })

  // ---------------------------------------------------------- approvals

  app.get('/api/agent/approvals', async (request) => {
    const status = (request.query as { status?: string }).status
    const allowed = ['pending', 'approved', 'rejected', 'expired'] as const
    const filter = allowed.includes((status ?? '') as (typeof allowed)[number]) ? (status as (typeof allowed)[number]) : undefined
    return { approvals: listApprovals(db, filter) }
  })

  app.post(
    '/api/agent/approvals/:id/decision',
    {
      schema: {
        body: {
          type: 'object',
          required: ['decision'],
          additionalProperties: false,
          properties: { decision: { type: 'string', enum: ['approve', 'reject'] } },
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params as { id: string }
      const { decision } = request.body as { decision: 'approve' | 'reject' }
      const row = decideApproval(db, Number(id), decision === 'approve' ? 'approved' : 'rejected')
      if ('error' in row) {
        const code = row.error === 'not_found' ? 404 : 409
        return reply.code(code).send({ error: { message: row.error === 'not_found' ? 'الموافقة غير موجودة' : 'حُسم القرار من قبل', type: row.error, code } })
      }
      return { approval: row }
    },
  )

  // ------------------------------------------------------------- memory

  app.get('/api/agent/memory', async () => ({ mode: memory.mode, notes: memory.listUser() }))

  app.post(
    '/api/agent/memory',
    {
      schema: {
        body: {
          type: 'object',
          required: ['title', 'content'],
          additionalProperties: false,
          properties: {
            title: { type: 'string', minLength: 1, maxLength: 200 },
            content: { type: 'string', minLength: 1, maxLength: 8000 },
          },
        },
      },
    },
    async (request, reply) => {
      const { title, content } = request.body as { title: string; content: string }
      const id = memory.upsert({ kind: 'note', title, content, source: 'user' })
      return reply.code(201).send({ note: memory.getUser(id) })
    },
  )

  app.patch(
    '/api/agent/memory/:id',
    {
      schema: {
        body: {
          type: 'object',
          additionalProperties: false,
          properties: {
            title: { type: 'string', minLength: 1, maxLength: 200 },
            content: { type: 'string', minLength: 1, maxLength: 8000 },
          },
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params as { id: string }
      const patch = request.body as { title?: string; content?: string }
      const note = memory.updateUser(Number(id), patch)
      if (!note) return reply.code(404).send({ error: { message: 'الملاحظة غير موجودة', type: 'not_found', code: 404 } })
      return { note }
    },
  )

  app.delete('/api/agent/memory/:id', async (request, reply) => {
    const { id } = request.params as { id: string }
    const ok = memory.deleteUser(Number(id))
    if (!ok) return reply.code(404).send({ error: { message: 'الملاحظة غير موجودة', type: 'not_found', code: 404 } })
    return { ok: true }
  })

  app.post(
    '/api/agent/memory/search',
    {
      schema: {
        body: {
          type: 'object',
          required: ['query'],
          additionalProperties: false,
          properties: { query: { type: 'string', minLength: 1, maxLength: 1024 }, k: { type: 'integer', minimum: 1, maximum: 20 } },
        },
      },
    },
    async (request) => {
      const { query, k } = request.body as { query: string; k?: number }
      return { mode: memory.mode, hits: memory.search(query, k ?? 5) }
    },
  )

  // ------------------------------------------------------------ routines

  app.get('/api/agent/routines', async () => ({
    routines: db.prepare('SELECT * FROM agent_routines ORDER BY id').all() as RoutineRow[],
  }))

  app.post(
    '/api/agent/routines',
    {
      schema: {
        body: {
          type: 'object',
          required: ['name', 'prompt', 'model', 'interval_sec'],
          additionalProperties: false,
          properties: {
            name: { type: 'string', minLength: 2, maxLength: 64 },
            prompt: { type: 'string', minLength: 4, maxLength: 4000 },
            model: { type: 'string', minLength: 3, maxLength: 256 },
            interval_sec: { type: 'integer', minimum: 60, maximum: 2_592_000 },
            allow_downgrade: { type: 'boolean' },
            catch_up_on_unlock: { type: 'boolean' },
          },
        },
      },
    },
    async (request, reply) => {
      const b = request.body as {
        name: string
        prompt: string
        model: string
        interval_sec: number
        allow_downgrade?: boolean
        catch_up_on_unlock?: boolean
      }
      try {
        registry.resolveModel(b.model)
      } catch (e) {
        return reply.code(400).send({ error: { message: e instanceof Error ? e.message : 'نموذج غير صالح', type: 'invalid_request_error', code: 400 } })
      }
      const exists = db.prepare('SELECT id FROM agent_routines WHERE name = ?').get(b.name)
      if (exists) return reply.code(409).send({ error: { message: 'يوجد روتين بهذا الاسم', type: 'already_exists', code: 409 } })
      const info = db
        .prepare(
          'INSERT INTO agent_routines (name, prompt, model, interval_sec, allow_downgrade, catch_up_on_unlock, next_run_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        )
        .run(
          b.name,
          b.prompt,
          b.model,
          b.interval_sec,
          b.allow_downgrade === true ? 1 : 0, // v2.2 #5: default FALSE
          b.catch_up_on_unlock === true ? 1 : 0,
          new Date(Date.now() + b.interval_sec * 1000).toISOString(),
        )
      return reply.code(201).send({ routine: db.prepare('SELECT * FROM agent_routines WHERE id = ?').get(Number(info.lastInsertRowid)) })
    },
  )

  app.patch(
    '/api/agent/routines/:id',
    {
      schema: {
        body: {
          type: 'object',
          additionalProperties: false,
          properties: {
            prompt: { type: 'string', minLength: 4, maxLength: 4000 },
            interval_sec: { type: 'integer', minimum: 60, maximum: 2_592_000 },
            enabled: { type: 'boolean' },
            allow_downgrade: { type: 'boolean' },
            catch_up_on_unlock: { type: 'boolean' },
          },
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params as { id: string }
      const b = request.body as Record<string, unknown>
      const cur = db.prepare('SELECT * FROM agent_routines WHERE id = ?').get(Number(id)) as RoutineRow | undefined
      if (!cur) return reply.code(404).send({ error: { message: 'الروتين غير موجود', type: 'not_found', code: 404 } })
      db.prepare(`UPDATE agent_routines SET prompt = ?, interval_sec = ?, enabled = ?, allow_downgrade = ?, catch_up_on_unlock = ?, updated_at = ${sqlTs} WHERE id = ?`).run(
        (b.prompt as string) ?? cur.prompt,
        (b.interval_sec as number) ?? cur.interval_sec,
        b.enabled === undefined ? cur.enabled : b.enabled ? 1 : 0,
        b.allow_downgrade === undefined ? cur.allow_downgrade : b.allow_downgrade ? 1 : 0,
        b.catch_up_on_unlock === undefined ? cur.catch_up_on_unlock : b.catch_up_on_unlock ? 1 : 0,
        cur.id,
      )
      return { routine: db.prepare('SELECT * FROM agent_routines WHERE id = ?').get(cur.id) }
    },
  )

  app.delete('/api/agent/routines/:id', async (request, reply) => {
    const { id } = request.params as { id: string }
    const info = db.prepare('DELETE FROM agent_routines WHERE id = ?').run(Number(id))
    if (info.changes === 0) return reply.code(404).send({ error: { message: 'الروتين غير موجود', type: 'not_found', code: 404 } })
    return { ok: true }
  })

  app.post('/api/agent/routines/:id/run', async (request, reply) => {
    const { id } = request.params as { id: string }
    const cur = db.prepare('SELECT * FROM agent_routines WHERE id = ?').get(Number(id)) as RoutineRow | undefined
    if (!cur) return reply.code(404).send({ error: { message: 'الروتين غير موجود', type: 'not_found', code: 404 } })
    const res = await scheduler.runRoutine(cur.id)
    return {
      status: res.status,
      run: db.prepare('SELECT * FROM agent_routine_runs WHERE id = ?').get(res.runId),
      task: res.taskId ? getTask(db, res.taskId) : null,
    }
  })

  app.get('/api/agent/routines/:id/runs', async (request) => {
    const { id } = request.params as { id: string }
    return { runs: scheduler.listRuns(Number(id)) }
  })

  // ---------------------------------------------- automatic model routing
  // (اختيار النماذج أوتوماتيكياً) — the owner's ordered preferences per
  // agent purpose. Saved entries are validated against the registry so a
  // typo cannot silently kill auto-selection.

  app.get('/api/agent/model-prefs', async () => ({
    prefs: getAutoPrefs(db),
    usable: (await pickAutoModel(db, registry, vault, config, 'planner'))
      ? {
          planner: await pickAutoModel(db, registry, vault, config, 'planner'),
          critic: await pickAutoModel(db, registry, vault, config, 'critic'),
        }
      : null,
  }))

  app.put(
    '/api/agent/model-prefs',
    {
      schema: {
        body: {
          type: 'object',
          additionalProperties: false,
          properties: {
            planner: { type: 'array', maxItems: 10, items: { type: 'string', minLength: 3, maxLength: 256 } },
            critic: { type: 'array', maxItems: 10, items: { type: 'string', minLength: 3, maxLength: 256 } },
          },
        },
      },
    },
    async (request, reply) => {
      const b = request.body as Partial<AutoModelPrefs>
      const bad: string[] = []
      for (const m of [...(b.planner ?? []), ...(b.critic ?? [])]) {
        try {
          registry.resolveModel(m)
        } catch {
          bad.push(m)
        }
      }
      if (bad.length > 0) {
        return reply.code(400).send({
          error: { message: `نماذج غير قابلة للحل: ${bad.join(' · ')}`, type: 'invalid_request_error', code: 400 },
        })
      }
      const prefs: AutoModelPrefs = {
        planner: [...new Set(b.planner ?? [])],
        critic: [...new Set(b.critic ?? [])],
      }
      setAutoPrefs(db, prefs)
      return { ok: true, prefs }
    },
  )
}

// ------------------------------------------------------------------ shared

export interface AgentTaskRow {
  id: number
  goal: string
  model: string
  status: string
  source: string
  project_id: string | null
  mode: string
  plan: string | null
  report: string | null
  created_at: string
  updated_at: string
}

export function getTask(db: DB, id: number): AgentTaskRow | undefined {
  return db.prepare('SELECT * FROM agent_tasks WHERE id = ?').get(id) as AgentTaskRow | undefined
}

function safeParse(s: string | null): Record<string, unknown> {
  if (!s) return {}
  try {
    return JSON.parse(s) as Record<string, unknown>
  } catch {
    return {}
  }
}
