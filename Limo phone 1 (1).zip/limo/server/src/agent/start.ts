import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import type { Logger } from '../logger.js'
import type { VectorMemory } from './memory.js'
import { buildModelFn } from './model.js'
import { runAgentTask } from './engine.js'
import { autoModelFn, pickAutoModel } from './autoselect.js'
import { publish } from './bus.js'
import { getProject } from '../projects/store.js'

/**
 * ONE shared agent-task starter — used by BOTH the HTTP route
 * (POST /api/agent/tasks) and the Black Box brain tool `launch_agent_task`
 * (LIMO #14: «اربط كل الأدوات بالنماذج ليصبح وكيلاً فعلاً»).
 *
 * Same validation, same insert, same fire-and-forget engine hand-off, same
 * live model_selected events. The only difference is the honest `source`
 * provenance column ('user' from the UI, 'box' from the chatbot brain).
 */

export interface AgentTaskDeps {
  db: DB
  config: ServerConfig
  registry: ProviderRegistry
  vault: Vault
  log: Logger
  memory: VectorMemory
}

export interface StartTaskInput {
  goal: string
  model: string
  projectId?: string | null
  mode?: 'auto' | 'research' | 'build' | 'creative' | 'super'
  source?: 'user' | 'box'
}

export type StartTaskResult =
  | { ok: true; id: number }
  | { ok: false; code: number; error: string }

export const TASK_MODES = ['auto', 'research', 'build', 'creative', 'super'] as const

export async function startAgentTask(deps: AgentTaskDeps, input: StartTaskInput): Promise<StartTaskResult> {
  const { db, config, registry, vault, log, memory } = deps
  const goal = input.goal.trim()
  const mode = input.mode ?? 'auto'
  if (goal.length < 4) return { ok: false, code: 400, error: 'الموجز قصير جدًا — اكتب الهدف بوضوح' }
  if (!(TASK_MODES as readonly string[]).includes(mode)) return { ok: false, code: 400, error: `النمط يجب أن يكون واحدًا من: ${TASK_MODES.join(' / ')}` }

  // SUPER (الحاسوب الخارق): one brief → planned production line with
  // AUTOMATIC per-purpose model routing — an explicit model is honestly
  // overridden, exactly like Higgsfield's routing layer owns the choice.
  const useAuto = input.model === 'auto' || mode === 'super'
  if (!useAuto) {
    try {
      registry.resolveModel(input.model) // fail fast on unknown provider/model prefix
    } catch (e) {
      return { ok: false, code: 400, error: e instanceof Error ? e.message : 'نموذج غير صالح' }
    }
  } else if (!(await pickAutoModel(db, registry, vault, config, 'planner'))) {
    return {
      ok: false,
      code: 409,
      error: 'لا نماذج قابلة للاستخدام الآن — شغّل Ollama أو أضف مفتاح مزود من الخزنة ثم جمّع الفهرس، أو اختر نموذجًا محددًا',
    }
  }
  // a bound workspace must exist (404, never a silent no-op)
  if (input.projectId && !getProject(db, input.projectId)) {
    return { ok: false, code: 404, error: 'مساحة المشروع غير موجودة' }
  }
  const effectiveModel = useAuto ? 'auto' : input.model
  const info = db
    .prepare("INSERT INTO agent_tasks (goal, model, status, source, project_id, mode) VALUES (?, ?, 'queued', ?, ?, ?)")
    .run(goal, effectiveModel, input.source ?? 'user', input.projectId ?? null, mode)
  const id = Number(info.lastInsertRowid)

  // fire-and-forget: the SSE stream + GET /tasks/:id are the live views
  if (useAuto) {
    // every routing decision is recorded live (agent_events + the bus)
    const recordChoice = (purpose: string, choice: { model: string; reason: string }) => {
      const event = { kind: 'model_selected' as const, ts: new Date().toISOString(), data: { purpose, model: choice.model, reason: choice.reason } }
      db.prepare('INSERT INTO agent_events (task_id, kind, data) VALUES (?, ?, ?)').run(id, event.kind, JSON.stringify(event.data))
      publish(id, event)
    }
    const modelFnFor = autoModelFn({
      db,
      config,
      registry,
      vault,
      build: (m) => buildModelFn({ db, config, registry, vault, log, model: m, source: 'agent' }),
      onChoice: (purpose, choice) => recordChoice(purpose, choice),
    })
    void runAgentTask({ db, config, registry, vault, log, memory, modelFnFor }, id).catch((e) => {
      log.error('agent task crashed', { id, err: e instanceof Error ? e.message : String(e) })
      db.prepare('UPDATE agent_tasks SET status = ? WHERE id = ?').run('failed', id)
    })
  } else {
    const modelFn = buildModelFn({ db, config, registry, vault, log, model: effectiveModel, source: 'agent' })
    void runAgentTask({ db, config, registry, vault, log, memory, modelFn }, id).catch((e) => {
      log.error('agent task crashed', { id, err: e instanceof Error ? e.message : String(e) })
      db.prepare('UPDATE agent_tasks SET status = ? WHERE id = ?').run('failed', id)
    })
  }
  return { ok: true, id }
}
