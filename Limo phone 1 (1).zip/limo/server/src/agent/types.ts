import type { ChatMessage } from '../providers/types.js'
import type { AgentRole, TaskMode } from './roles.js'
export type { AgentRole, TaskMode } from './roles.js'

/**
 * Agent engine types (PLAN.md §6 stage 3 · LIMO v3 HYPERBRAIN).
 *
 * The loop is planner → executor → critic with bounded recovery, a
 * deterministic evidence-based report, human approvals for dangerous
 * categories, and a full append-only event timeline. v3 adds the
 * multi-agent director: every step carries a specialized agent ROLE with a
 * real tool allowlist, and a task may bind to a sandboxed project workspace.
 */

export type TaskStatus =
  | 'queued'
  | 'planning'
  | 'running'
  | 'awaiting_approval'
  | 'completed'
  | 'failed'
  | 'cancelled'

export type StepStatus = 'pending' | 'running' | 'done' | 'failed' | 'skipped'

/** The mandatory human-approval categories (owner-specified list). */
export type RiskCategory =
  | 'payment' // دفع
  | 'deletion' // حذف
  | 'send' // إرسال
  | 'settings_change' // تغيير إعدادات
  | 'software_install' // تثبيت برامج
  | 'secret_share' // مشاركة أسرار

export const RISK_CATEGORY_AR: Record<RiskCategory, string> = {
  payment: 'دفع مالي',
  deletion: 'حذف بيانات',
  send: 'إرسال للخارج',
  settings_change: 'تغيير إعدادات',
  software_install: 'تشغيل/تثبيت برامج',
  secret_share: 'مشاركة أسرار',
}

/** One planned step, exactly as the planner model returned it (after validation). */
export interface PlanStep {
  idx: number
  title: string
  tool: string
  args: Record<string, unknown>
  acceptance: string
  /** LIMO v3: the specialized agent that owns this step (validated + enforced). */
  role: AgentRole
}

/** Tool contract. `risk !== null` ⇒ an approval gate opens before execution. */
export interface ToolContext {
  taskId: number | null
  db: import('../db/database.js').DB
  config: import('../config.js').ServerConfig
  log: import('../logger.js').Logger
  /** the shared vector/user memory — tools like memory_search need it */
  memory: import('./memory.js').VectorMemory
  /** LIMO v3: the sandboxed project workspace when the task is bound to one */
  projectId: string | null
  /** LIMO #18: the task's own model function — self_start_change hands it to
   * the Reality Forge engineer so the forge uses the SAME model stack as the
   * task (the documented engine-bypasses-gateway gap, no third stack). */
  modelFn?: import('./types.js').ModelFn
  /** LIMO #18: the task's model id — recorded on forge changes for an honest
   * audit trail of who wrote the patch. */
  model?: string | null
  /** LIMO #19: present when the engine can build forge deps for the pinned
   * engineering model (registry + vault) — self_start_change then honors the
   * owner's pin exactly like the REST and box paths do. */
  registry?: import('../providers/registry.js').ProviderRegistry
  vault?: import('../vault/vault.js').Vault
}

export interface ToolResult {
  ok: boolean
  data?: unknown
  error?: string
  /** Evidence digests the critic and the report quote verbatim. */
  evidence: string
}

export interface Tool {
  name: string
  description: string
  /** Short arg spec shown to the planner: { "url": "string" } */
  args: Record<string, string>
  risk: RiskCategory | null
  /** Human-readable summary of what WILL run — shown on the approval card. */
  summarize(args: Record<string, unknown>): string
  run(args: Record<string, unknown>, ctx: ToolContext): Promise<ToolResult>
}

export type AgentEventKind =
  | 'task_started'
  | 'plan_ready'
  | 'step_started'
  | 'tool_call'
  | 'tool_result'
  | 'approval_required'
  | 'approval_decided'
  | 'step_done'
  | 'step_failed'
  | 'step_skipped'
  | 'recovery_retry'
  | 'model_selected'
  | 'task_completed'
  | 'task_failed'
  | 'task_cancelled'

export interface AgentEvent {
  kind: AgentEventKind
  ts: string
  data: Record<string, unknown>
}

/** How the engine talks to a model. Injectable so tests stay deterministic (محاكى). */
export interface ModelCallOpts {
  maxTokens?: number
  temperature?: number
  /** LIMO #22/#23 — live token tap (SSE box stream). Called with every raw
   *  delta AS IT ARRIVES; on a transient RETRY the stream restarts, so the
   *  consumer sees the discarded attempt too (real activity, never hidden). */
  onDelta?: (chunk: string) => void
  /** Cooperative abort: thrown-into by the caller mid-stream (client gone). */
  shouldStop?: () => boolean
}

export type ModelFn = (messages: ChatMessage[], opts?: ModelCallOpts) => Promise<string>

export interface ApprovalRow {
  id: number
  task_id: number | null
  category: string
  summary: string
  payload: string
  status: 'pending' | 'approved' | 'rejected' | 'expired'
  created_at: string
  decided_at: string | null
  decided_by: string | null
}

export interface RoutineRow {
  id: number
  name: string
  prompt: string
  model: string
  interval_sec: number
  enabled: number
  allow_downgrade: number
  catch_up_on_unlock: number
  pending_catchup: number
  last_run_at: string | null
  next_run_at: string
  created_at: string
  updated_at: string
}

export type RoutineRunStatus = 'ok' | 'skipped_vault_locked' | 'degraded_vault_locked' | 'error'

export interface RoutineRunRow {
  id: number
  routine_id: number
  ts: string
  status: RoutineRunStatus
  detail: string | null
  task_id: number | null
}
