import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import type { Logger } from '../logger.js'
import type { ChatMessage } from '../providers/types.js'
import { publish } from './bus.js'
import { createApproval, decideApproval, expireApproval, getApproval } from './approvals.js'
import { ShortTermMemory, type VectorMemory } from './memory.js'
import { extractJson } from './model.js'
import { SYSTEM_PROMPT_BASE, PLANNER_ADDENDUM, CRITIC_ADDENDUM, RECOVERY_ADDENDUM, toolCatalogPrompt, rolesCatalogPrompt } from './systemPrompt.js'
import { skillsCatalogPrompt } from '../skills/agentlink.js'
import { toolByName, toolCatalog } from './tools.js'
import { AGENT_ROLES, isAgentRole, MODE_HINTS, roleForTool, type AgentRole, type TaskMode } from './roles.js'
import type { AutoPurpose } from './autoselect.js'
import type { AgentEvent, AgentEventKind, ModelFn, PlanStep, ToolResult } from './types'

/**
 * The agent engine — HYPERBRAIN v3 (LIMO PHASE 3).
 *
 * planner → executor → critic with bounded recovery, now as a multi-agent
 * director: every step is owned by a specialized agent (real tool allowlist,
 * role addendum injected into the planner AND the critic), the task may run
 * in a strategy mode (auto / research / build / creative) and may be bound to
 * a sandboxed project workspace (project_* tools are jailed inside it).
 *
 * Honesty rules baked into the loop (owner-specified):
 *  - the FINAL REPORT is assembled deterministically from recorded evidence
 *    (never free-typed by the model), so a success claim always maps to a
 *    stored step result the owner can open.
 *  - a failing step is retried at most twice, then reported as failed.
 *  - risky tools pause the task behind a human approval; rejection/timeout
 *    SKIPS the action — never executes it silently.
 *  - a tool outside its role's allowlist is deterministically REASSIGNED to a
 *    role that permits it (never executed with broader permissions silently).
 *  - project tools without a bound project fail honestly — never pretend.
 *  - everything lands in agent_events (append-only) and agent_actions.
 */

export interface AgentEngineDeps {
  db: DB
  config: ServerConfig
  registry: ProviderRegistry
  vault: Vault
  log: Logger
  memory: VectorMemory
  /** classic single-model mode — required unless modelFnFor is provided */
  modelFn?: ModelFn
  /**
   * Automatic model selection (اختيار النماذج أوتوماتيكياً): when present,
   * every purpose (planner / critic / recovery) resolves its OWN model at
   * call time. Absent → the classic single-model behaviour via modelFn.
   */
  modelFnFor?: (purpose: AutoPurpose) => ModelFn
  /** how long to wait for a human decision before expiring (default 5 min) */
  approvalTimeoutMs?: number
  /** max attempts per step (default 3: initial + 2 recoveries) */
  maxStepAttempts?: number
}

interface PlannedStepRaw {
  title?: unknown
  tool?: unknown
  args?: unknown
  acceptance?: unknown
  role?: unknown
}

interface AgentTaskRow {
  id: number
  goal: string
  model: string
  status: string
  source: string
  project_id: string | null
  mode: string
}

const isTaskMode = (v: string): v is TaskMode => v === 'auto' || v === 'research' || v === 'build' || v === 'creative' || v === 'super'

export async function runAgentTask(deps: AgentEngineDeps, taskId: number): Promise<void> {
  const { db, log } = deps
  const task = db.prepare('SELECT * FROM agent_tasks WHERE id = ?').get(taskId) as AgentTaskRow | undefined
  if (!task) return
  const mode: TaskMode = isTaskMode(task.mode) ? task.mode : 'auto'
  // the SUPER mode budget: a longer production line (Higgsfield-style brief →
  // plan → routed execution → delivery) needs more steps than the classic 8
  const maxSteps = mode === 'super' ? 12 : 8
  const fnFor: (purpose: AutoPurpose) => ModelFn =
    deps.modelFnFor ??
    (() => {
      if (!deps.modelFn) throw new Error('لا نموذج مضبوط لهذه المهمة')
      return deps.modelFn
    })
  const projectId = task.project_id
  // the catalog the planner sees: project tools ONLY when a workspace is bound
  const catalogForTask = () =>
    projectId
      ? toolCatalog()
      : toolCatalog().filter((t) => !t.name.startsWith('project_'))

  const emit = (kind: AgentEventKind, data: Record<string, unknown>) => {
    const event: AgentEvent = { kind, ts: new Date().toISOString(), data }
    db.prepare('INSERT INTO agent_events (task_id, kind, data) VALUES (?, ?, ?)').run(taskId, kind, JSON.stringify(data))
    publish(taskId, event)
  }
  const setStatus = (status: string) => {
    db.prepare('UPDATE agent_tasks SET status = ?, updated_at = ? WHERE id = ?').run(status, new Date().toISOString(), taskId)
  }
  const isCancelled = () =>
    (db.prepare('SELECT status FROM agent_tasks WHERE id = ?').get(taskId) as { status: string } | undefined)?.status === 'cancelled'

  const startedAt = Date.now()
  setStatus('planning')
  emit('task_started', { goal: task.goal, model: task.model, source: task.source })

  // ---- context: semantic recall over the owner's memory + past episodes
  const recalled = deps.memory.search(task.goal, 4)
  const memoryBlock = recalled.length
    ? recalled.map((r) => `- «${r.title}»: ${r.content.slice(0, 200)}`).join('\n')
    : '(لا ذكريات ذات صلة)'

  const shortTerm = new ShortTermMemory()
  const modeHint = MODE_HINTS[mode]
  const projectBlock = projectId
    ? `# مساحة المشروع\nهذه المهمة مرتبطة بمساحة مشروع معزولة. أدوات project_* تعمل داخلها فقط، وكل مخرجات البناء تُكتب ملفات فعلية هناك.`
    : ''
  // ALLIMNI ↔ HYPERBRAIN (LIMO #11): installed capabilities reach the agent
  // as a bounded catalog; content is read on demand via skill_read (data only)
  const skillsBlock = skillsCatalogPrompt(deps.db)
  const plannerMessages = (): ChatMessage[] => [
    {
      role: 'system',
      content: [
        SYSTEM_PROMPT_BASE,
        PLANNER_ADDENDUM,
        ...(modeHint ? [modeHint] : []),
        ...(projectBlock ? [projectBlock] : []),
        ...(skillsBlock ? [skillsBlock] : []),
        rolesCatalogPrompt(Object.values(AGENT_ROLES).map((r) => ({ id: r.id, labelAr: r.labelAr, description: r.description, tools: r.tools }))),
        toolCatalogPrompt(catalogForTask()),
      ].join('\n\n'),
    },
    {
      role: 'user',
      content: `المهمة: ${task.goal}\n\n# ذاكرة ذات صلة\n${memoryBlock}\n\n# ما جرى حتى الآن\n${shortTerm.render()}\n\nأعد الخطة الآن (JSON فقط).`,
    },
  ]

  // ---- 1) planner — LIMO #25: the planner is FIRST a classifier. A plain
  // message (greeting/thanks/general question) is answered conversationally
  // (no steps, no tools, no fake «task completed» production line); only a
  // real task gets the plan→execute→critic pipeline.
  let steps: PlanStep[] = []
  try {
    const raw = await fnFor('planner')(plannerMessages(), { temperature: 0.2, maxTokens: mode === 'super' ? 2400 : 1200 })
    const cls = classifyPlannerOutput(raw, projectId === null, maxSteps)
    if (cls.kind === 'chat') {
      finalize(deps, taskId, { verdict: 'completed', chatReply: cls.reply, startedAt })
      setStatus('completed')
      emit('task_completed', { kind: 'chat', reply: cls.reply, durationMs: Date.now() - startedAt })
      return
    }
    steps = cls.steps
    if (steps.length === 0) throw new Error('خطة فارغة أو بلا خطوات صالحة')
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    setStatus('failed')
    emit('task_failed', { reason: `فشل التخطيط: ${msg}` })
    finalize(deps, taskId, { verdict: 'failed', failureReason: `فشل التخطيط: ${msg}` })
    return
  }
  db.prepare('UPDATE agent_tasks SET plan = ? WHERE id = ?').run(JSON.stringify(steps), taskId)
  emit('plan_ready', {
    steps: steps.map((s) => ({ idx: s.idx, title: s.title, tool: s.tool, role: s.role, risk: toolByName(s.tool)?.risk ?? null })),
  })

  // persist steps
  const stepIds: number[] = []
  for (const s of steps) {
    const info = db
      .prepare('INSERT INTO agent_steps (task_id, idx, title, tool, args, acceptance, role) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(taskId, s.idx, s.title, s.tool, JSON.stringify(s.args), s.acceptance, s.role)
    stepIds.push(Number(info.lastInsertRowid))
  }

  setStatus('running')
  const approvalsUsed: Array<{ id: number; category: string; decision: string }> = []
  const memoryWrites: string[] = []

  // ---- 2) executor + critic, per step
  for (let i = 0; i < steps.length; i++) {
    if (isCancelled()) {
      setStatus('cancelled')
      emit('task_cancelled', { at: `خطوة ${i + 1}` })
      finalize(deps, taskId, { verdict: 'cancelled', steps, stepIds, approvalsUsed, memoryWrites, startedAt })
      return
    }
    const step = steps[i]!
    const stepId = stepIds[i]!
    const tool = toolByName(step.tool)!
    const roleDef = AGENT_ROLES[step.role]
    db.prepare('UPDATE agent_steps SET status = ? WHERE id = ?').run('running', stepId)
    emit('step_started', { idx: step.idx, title: step.title, tool: step.tool, role: step.role })

    let current: PlanStep = step
    let result: ToolResult | null = null
    let attempts = 0
    let skipReason: string | null = null

    while (attempts < (deps.maxStepAttempts ?? 3)) {
      attempts++
      db.prepare('UPDATE agent_steps SET attempts = ? WHERE id = ?').run(attempts, stepId)

      // ---- approval gate for risky tools
      if (tool.risk) {
        const approval = createApproval(deps.db, {
          taskId,
          category: tool.risk,
          summary: tool.summarize(current.args),
          payload: { tool: tool.name, args: current.args },
        })
        setStatus('awaiting_approval')
        emit('approval_required', { approvalId: approval.id, idx: step.idx, category: tool.risk, summary: approval.summary })
        const decision = await waitForDecision(deps, approval.id)
        const row = getApproval(deps.db, approval.id)!
        approvalsUsed.push({ id: approval.id, category: row.category, decision: row.status })
        emit('approval_decided', { approvalId: approval.id, decision: row.status })
        setStatus('running')
        if (decision !== 'approved') {
          skipReason = decision === 'rejected' ? 'رفض المالك الإجراء' : 'انتهت مهلة الموافقة دون قرار'
          break
        }
      }

      // ---- execute (real tool, recorded action)
      emit('tool_call', { idx: step.idx, tool: tool.name, args: scrub(current.args) })
      db.prepare('INSERT INTO agent_actions (task_id, tool, args, ok, result, risk, approval_id) VALUES (?, ?, ?, 0, NULL, ?, NULL)')
        .run(taskId, tool.name, JSON.stringify(scrub(current.args)), tool.risk)
      const actionId = Number((db.prepare('SELECT last_insert_rowid() AS id').get() as { id: number }).id)
      try {
        result = await tool.run(current.args, {
          taskId,
          db: deps.db,
          config: deps.config,
          log: deps.log,
          memory: deps.memory,
          projectId,
          modelFn: fnFor('planner'), // LIMO #18: the task's own model for self-tools
          model: task.model, // honest audit: which model wrote the forge patch
          registry: deps.registry, // LIMO #19: so self_start_change honors the engineering pin
          vault: deps.vault,
        })
      } catch (e) {
        result = { ok: false, error: e instanceof Error ? e.message : String(e), evidence: `استثناء: ${e instanceof Error ? e.message : String(e)}` }
      }
      db.prepare('UPDATE agent_actions SET ok = ?, result = ? WHERE id = ?').run(result.ok ? 1 : 0, JSON.stringify(result.data ?? result.error ?? null), actionId)
      emit('tool_result', { idx: step.idx, tool: tool.name, ok: result.ok, evidence: result.evidence })

      if (result.ok) {
        // ---- critic (honesty gate: no step passes without checked evidence)
        const verdict = await criticVerdict(deps, fnFor('critic'), task.goal, current, result, roleDef.addendum)
        db.prepare('UPDATE agent_steps SET critic = ? WHERE id = ?').run(JSON.stringify(verdict), stepId)
        if (verdict.pass) break
        result = { ok: false, error: `رفض الناقد: ${verdict.reason}`, evidence: result.evidence }
      }

      // ---- bounded recovery: ask the planner for a corrected single step
      if (attempts < (deps.maxStepAttempts ?? 3)) {
        emit('recovery_retry', { idx: step.idx, attempt: attempts + 1, reason: result.error ?? 'لم يتحقق شرط القبول' })
        const fixed = await planRecovery(deps, fnFor('recovery'), task.goal, current, result, projectId === null)
        if (fixed) {
          current = { ...current, tool: fixed.tool, args: fixed.args, title: fixed.title, acceptance: fixed.acceptance, role: fixed.role }
          db.prepare('UPDATE agent_steps SET tool = ?, args = ?, title = ?, role = ? WHERE id = ?').run(fixed.tool, JSON.stringify(scrub(fixed.args)), fixed.title, fixed.role, stepId)
        }
      }
    }

    // ---- record the step outcome
    if (skipReason) {
      db.prepare('UPDATE agent_steps SET status = ?, result = ? WHERE id = ?').run('skipped', JSON.stringify({ skipped: skipReason }), stepId)
      emit('step_skipped', { idx: step.idx, reason: skipReason })
      shortTerm.push(`خطوة ${step.idx} «${step.title}»`, `تخطيت — ${skipReason}`)
    } else if (result?.ok) {
      db.prepare('UPDATE agent_steps SET status = ?, result = ? WHERE id = ?').run('done', JSON.stringify(result.data ?? null), stepId)
      emit('step_done', { idx: step.idx, evidence: result.evidence })
      shortTerm.push(`خطوة ${step.idx} «${step.title}»`, result.evidence)
      if (step.tool === 'memory_write') memoryWrites.push(String(step.args.title ?? ''))
    } else {
      db.prepare('UPDATE agent_steps SET status = ?, result = ? WHERE id = ?').run('failed', JSON.stringify({ error: result?.error ?? 'فشل غير معروف' }), stepId)
      emit('step_failed', { idx: step.idx, error: result?.error ?? 'فشل غير معروف' })
      shortTerm.push(`خطوة ${step.idx} «${step.title}»`, `فشلت — ${result?.error ?? 'غير معروف'}`)
    }
  }

  // ---- 3) deterministic, evidence-based report (no model free-typing)
  const rows = db.prepare('SELECT * FROM agent_steps WHERE task_id = ? ORDER BY idx').all(taskId) as Array<{
    idx: number
    title: string
    tool: string | null
    status: string
    attempts: number
    result: string | null
    critic: string | null
  }>
  const doneCount = rows.filter((r) => r.status === 'done').length
  const skipped = rows.filter((r) => r.status === 'skipped').length
  const failed = rows.filter((r) => r.status === 'failed').length
  const verdict = failed === 0 && doneCount > 0 ? 'completed' : doneCount > 0 ? 'completed_with_failures' : 'failed'

  finalize(deps, taskId, { verdict, steps, stepIds, approvalsUsed, memoryWrites, startedAt })

  if (verdict === 'completed') {
    setStatus('completed')
    emit('task_completed', { verdict, done: doneCount, skipped, failed, durationMs: Date.now() - startedAt })
    // episode memory: what the agent did (recallable in later tasks)
    deps.memory.upsert({
      kind: 'episode',
      title: `مهمة #${taskId}: ${task.goal.slice(0, 120)}`,
      content: rows.map((r) => `${r.status === 'done' ? '✓' : r.status === 'skipped' ? '–' : '✗'} ${r.title} (${r.tool})`).join(' · '),
      source: `task:${taskId}`,
    })
  } else {
    setStatus('failed')
    emit('task_failed', { verdict, done: doneCount, skipped, failed, durationMs: Date.now() - startedAt })
  }
}

// ------------------------------------------------------------------ helpers

/** Remove obviously secret-looking values from anything persisted/emitted. */
function scrub(args: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(args)) {
    if (/key|token|secret|password|authorization/i.test(k)) out[k] = '«محجوب»'
    else if (typeof v === 'string' && v.length > 500) out[k] = `${v.slice(0, 500)}…`
    else out[k] = v
  }
  return out
}

/** LIMO #25 — the planner output has two honest shapes: a conversational reply
 *  ({"mode":"chat","reply"}) or a plan ({"steps":[...]}). Anything else falls
 *  back to the strict plan validation (which returns [] on garbage — the caller
 *  then fails the planning honestly, exactly as before). */
export function classifyPlannerOutput(
  raw: string,
  noProject: boolean,
  maxSteps = 8,
): { kind: 'chat'; reply: string } | { kind: 'task'; steps: PlanStep[] } {
  const parsed = extractJson<{ mode?: unknown; reply?: unknown; steps?: PlannedStepRaw[] }>(raw)
  if (parsed?.mode === 'chat' && typeof parsed.reply === 'string' && parsed.reply.trim().length > 0) {
    return { kind: 'chat', reply: parsed.reply.trim().slice(0, 4000) }
  }
  return { kind: 'task', steps: validatePlan(raw, noProject, maxSteps) }
}

function validatePlan(raw: string, noProject: boolean, maxSteps = 8): PlanStep[] {
  const parsed = extractJson<{ steps?: PlannedStepRaw[] }>(raw)
  if (!parsed?.steps || !Array.isArray(parsed.steps)) return []
  const out: PlanStep[] = []
  for (const s of parsed.steps.slice(0, maxSteps)) {
    if (typeof s.tool !== 'string') continue
    const tool = toolByName(s.tool)
    if (!tool) continue
    if (noProject && s.tool.startsWith('project_')) continue // no workspace bound — never offer
    if (typeof s.title !== 'string' || s.title.length === 0) continue
    const args = (s.args && typeof s.args === 'object' ? s.args : {}) as Record<string, unknown>
    const acceptance = typeof s.acceptance === 'string' && s.acceptance ? s.acceptance : 'تنجح الأداة بلا خطأ'
    // v3: the step's owning agent — validated, then the allowlist is ENFORCED
    // deterministically (a tool outside the role moves the step to a role that
    // permits it; it is never executed with broader permissions silently).
    const claimedRole: AgentRole = isAgentRole(s.role) ? s.role : 'orchestrator'
    const role = roleForTool(claimedRole, s.tool)
    out.push({ idx: out.length + 1, title: s.title.slice(0, 300), tool: s.tool, args, acceptance: acceptance.slice(0, 500), role })
  }
  return out
}

async function criticVerdict(
  deps: AgentEngineDeps,
  fn: ModelFn,
  goal: string,
  step: PlanStep,
  result: ToolResult,
  roleAddendum?: string,
): Promise<{ pass: boolean; reason: string; evidence?: string }> {
  try {
    const raw = await fn(
      [
        { role: 'system', content: [SYSTEM_PROMPT_BASE, CRITIC_ADDENDUM, ...(roleAddendum ? [roleAddendum] : [])].join('\n\n') },
        {
          role: 'user',
          content: `المهمة الكلية: ${goal}\n\nالخطوة: ${step.title} (أداة: ${step.tool} · وكيل: ${step.role})\nشرط القبول: ${step.acceptance}\n\nنتيجة الأداة (بيانات خام):\n${JSON.stringify(result.data ?? result.error).slice(0, 3000)}\n\nالدليل المقتطع: ${result.evidence}\n\nأعد حكمك الآن (JSON فقط).`,
        },
      ],
      { temperature: 0, maxTokens: 400 },
    )
    const v = extractJson<{ pass?: unknown; reason?: unknown; evidence?: unknown }>(raw)
    if (v && typeof v.pass === 'boolean') {
      return { pass: v.pass, reason: typeof v.reason === 'string' ? v.reason.slice(0, 500) : v.pass ? 'حقق شرط القبول' : 'سبب غير مذكور', evidence: typeof v.evidence === 'string' ? v.evidence.slice(0, 300) : undefined }
    }
  } catch {
    /* critic call failed — fall through to the deterministic check below */
  }
  // Deterministic fallback critic: the recorded evidence is the verdict.
  return { pass: result.ok, reason: result.ok ? 'نجحت الأداة وسُجّل دليلها' : result.error ?? 'فشلت الأداة', evidence: result.evidence }
}

async function planRecovery(deps: AgentEngineDeps, fn: ModelFn, goal: string, failed: PlanStep, result: ToolResult, noProject: boolean): Promise<PlanStep | null> {
  try {
    const raw = await fn(
      [
        {
          role: 'system',
          content: `${SYSTEM_PROMPT_BASE}\n\n${RECOVERY_ADDENDUM}\n\n${skillsCatalogPrompt(deps.db) || ''}\n\n${rolesCatalogPrompt(Object.values(AGENT_ROLES).map((r) => ({ id: r.id, labelAr: r.labelAr, description: r.description, tools: r.tools })))}\n\n${toolCatalogPrompt(noProject ? toolCatalog().filter((t) => !t.name.startsWith('project_')) : toolCatalog())}`,
        },
        {
          role: 'user',
          content: `المهمة الكلية: ${goal}\n\nالخطوة الفاشلة: ${JSON.stringify({ title: failed.title, tool: failed.tool, args: failed.args, acceptance: failed.acceptance, role: failed.role })}\nسبب الفشل: ${result.error ?? 'لم يتحقق شرط القبول'}\nالدليل: ${result.evidence}\n\nأعد الخطوة المصحّحة (JSON فقط).`,
        },
      ],
      { temperature: 0.2, maxTokens: 500 },
    )
    const parsed = extractJson<PlannedStepRaw>(raw)
    if (parsed && typeof parsed.tool === 'string' && toolByName(parsed.tool) && !(noProject && parsed.tool.startsWith('project_'))) {
      const claimedRole: AgentRole = isAgentRole(parsed.role) ? parsed.role : failed.role
      return {
        idx: failed.idx,
        title: typeof parsed.title === 'string' && parsed.title ? parsed.title.slice(0, 300) : failed.title,
        tool: parsed.tool,
        args: (parsed.args && typeof parsed.args === 'object' ? parsed.args : {}) as Record<string, unknown>,
        acceptance: typeof parsed.acceptance === 'string' && parsed.acceptance ? parsed.acceptance.slice(0, 500) : failed.acceptance,
        role: roleForTool(claimedRole, parsed.tool),
      }
    }
  } catch {
    /* no recovery plan — the bounded attempts counter handles it */
  }
  return null
}

function waitForDecision(deps: AgentEngineDeps, approvalId: number): Promise<'approved' | 'rejected' | 'timeout'> {
  const timeoutMs = deps.approvalTimeoutMs ?? 300_000
  const deadline = Date.now() + timeoutMs
  return new Promise((resolve) => {
    const timer = setInterval(() => {
      const row = getApproval(deps.db, approvalId)
      if (!row) {
        clearInterval(timer)
        resolve('rejected') // vanished (task deleted) — never execute
        return
      }
      if (row.status === 'approved' || row.status === 'rejected') {
        clearInterval(timer)
        resolve(row.status)
        return
      }
      if (Date.now() >= deadline) {
        clearInterval(timer)
        expireApproval(deps.db, approvalId)
        resolve('timeout')
      }
    }, 400)
    timer.unref?.()
  })
}

/** The honest one-line summary — the step counts are ALWAYS present. */
function reportSummary(
  verdict: 'completed' | 'completed_with_failures' | 'failed' | 'cancelled',
  rows: Array<{ status: string }>,
  failureReason?: string,
): string {
  const done = rows.filter((r) => r.status === 'done').length
  const failed = rows.filter((r) => r.status === 'failed').length
  const skipped = rows.filter((r) => r.status === 'skipped').length
  const counts = `الخطوات: ${done} نجحت · ${failed} فشلت · ${skipped} تخطيت (من أصل ${rows.length})`
  if (verdict === 'completed') return `اكتملت المهمة: كل الخطوات (${rows.length}) نجحت بأدلة مسجّلة.`
  if (verdict === 'cancelled') return `أُلغيت المهمة بأمر المالك. ${counts}`
  if (failureReason) return `${failureReason} ${counts}`
  return `لم تكتمل المهمة. ${counts}`
}

/** Assemble the deterministic report and store it on the task row. */
function finalize(
  deps: AgentEngineDeps,
  taskId: number,
  info: {
    verdict: 'completed' | 'completed_with_failures' | 'failed' | 'cancelled'
    failureReason?: string
    /** LIMO #25 — conversational reply: the report IS the reply (kind: chat) */
    chatReply?: string
    steps?: PlanStep[]
    stepIds?: number[]
    approvalsUsed?: Array<{ id: number; category: string; decision: string }>
    memoryWrites?: string[]
    startedAt?: number
  },
): void {
  const rows = deps.db.prepare('SELECT * FROM agent_steps WHERE task_id = ? ORDER BY idx').all(taskId) as Array<{
    idx: number
    title: string
    tool: string | null
    status: string
    attempts: number
    result: string | null
    critic: string | null
  }>
  const report = {
    verdict: info.verdict,
    ...(info.chatReply ? { kind: 'chat' as const, reply: info.chatReply } : {}),
    ...(info.failureReason ? { failureReason: info.failureReason } : {}),
    summary: info.chatReply ?? reportSummary(info.verdict, rows, info.failureReason),
    steps: rows.map((r) => ({
      idx: r.idx,
      title: r.title,
      tool: r.tool,
      status: r.status,
      attempts: r.attempts,
      evidence: r.result ? String(r.result).slice(0, 400) : null,
      critic: r.critic ? (JSON.parse(r.critic) as { pass: boolean; reason: string }).reason : null,
    })),
    approvals: info.approvalsUsed ?? [],
    memoryWrites: info.memoryWrites ?? [],
    durationMs: info.startedAt ? Date.now() - info.startedAt : null,
    finishedAt: new Date().toISOString(),
  }
  deps.db.prepare('UPDATE agent_tasks SET report = ?, updated_at = ? WHERE id = ?').run(
    JSON.stringify(report),
    new Date().toISOString(),
    taskId,
  )
}
