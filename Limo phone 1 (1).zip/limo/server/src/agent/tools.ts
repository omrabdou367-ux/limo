import { execFile } from 'node:child_process'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { promisify } from 'node:util'
import { recordEgress, updateEgress } from '../db/egress.js'
import { listProjectFiles, readProjectFile, writeProjectFile } from '../projects/store.js'
import { listSkillFiles, readSkillFile } from '../skills/install.js'
import { readSourceFile, searchSource } from '../box/universal.js'
import { createChange, startChange, readAutonomyLevel, changeForChat, resolveForgeModel, forgeDepsFor } from '../forge/orchestrator.js'
import type { Tool, ToolResult } from './types'

/**
 * The built-in tool catalog (PLAN.md §6 stage 3 · LIMO v3 project tools).
 *
 * Real tools only — no fake results. Every external request an agent makes is
 * egress-logged. Risky categories (send / software_install / deletion) open
 * the human-approval gate BEFORE anything runs.
 *
 * Project tools (LIMO v3) are jailed inside the task's bound project workspace
 * (ctx.projectId) — when a task has no project bound they fail honestly with
 * an explicit message instead of pretending to work.
 */

const execFileAsync = promisify(execFile)

const ok = (data: unknown, evidence: string): ToolResult => ({ ok: true, data, evidence })
const fail = (error: string): ToolResult => ({ ok: false, error, evidence: `خطأ: ${error}` })

// ------------------------------------------------------------------ helpers

/** Safe arithmetic (shunting-yard) — no eval, no Function constructor. */
export function safeCalc(expression: string): number {
  const tokens: Array<string | number> = []
  let i = 0
  const isNum = (c: string) => /[0-9.]/.test(c)
  while (i < expression.length) {
    const c = expression[i]!
    if (c === ' ') {
      i++
      continue
    }
    if (isNum(c)) {
      let j = i
      while (j < expression.length && isNum(expression[j]!)) j++
      const n = Number(expression.slice(i, j))
      if (!Number.isFinite(n)) throw new Error(`رقم غير صالح: ${expression.slice(i, j)}`)
      tokens.push(n)
      i = j
      continue
    }
    if ('+-*/%^()'.includes(c)) {
      // unary minus/plus → fold into the number
      if ((c === '-' || c === '+') && (tokens.length === 0 || tokens[tokens.length - 1] === '(')) {
        let j = i + 1
        while (j < expression.length && expression[j] === ' ') j++
        if (j < expression.length && isNum(expression[j]!)) {
          let k = j
          while (k < expression.length && isNum(expression[k]!)) k++
          const n = Number(expression.slice(j, k))
          tokens.push(c === '-' ? -n : n)
          i = k
          continue
        }
      }
      tokens.push(c)
      i++
      continue
    }
    throw new Error(`محرف غير مسموح في الحساب: «${c}»`)
  }
  const prec: Record<string, number> = { '+': 1, '-': 1, '*': 2, '/': 2, '%': 2, '^': 3 }
  const out: Array<string | number> = []
  const ops: string[] = []
  for (const t of tokens) {
    if (typeof t === 'number') out.push(t)
    else if (t === '(') ops.push(t)
    else if (t === ')') {
      while (ops.length && ops[ops.length - 1] !== '(') out.push(ops.pop()!)
      if (ops.pop() !== '(') throw new Error('أقواس غير متوازنة')
    } else {
      while (ops.length && ops[ops.length - 1] !== '(' && prec[ops[ops.length - 1]!]! >= prec[t]! && t !== '^') {
        out.push(ops.pop()!)
      }
      ops.push(t)
    }
  }
  while (ops.length) {
    const op = ops.pop()!
    if (op === '(') throw new Error('أقواس غير متوازنة')
    out.push(op)
  }
  const st: number[] = []
  for (const t of out) {
    if (typeof t === 'number') st.push(t)
    else {
      const b = st.pop()
      const a = st.pop()
      if (a === undefined || b === undefined) throw new Error('تعبير ناقص')
      st.push(t === '+' ? a + b : t === '-' ? a - b : t === '*' ? a * b : t === '/' ? a / b : t === '%' ? a % b : a ** b)
    }
  }
  if (st.length !== 1 || !Number.isFinite(st[0]!)) throw new Error('تعبير غير صالح')
  return st[0]!
}

const asString = (v: unknown, maxLen = 4096): string => (typeof v === 'string' ? v.slice(0, maxLen) : String(v))

/** Shared HTTP fetch for tools: timeout, size cap, egress row, honest errors. */
async function toolFetch(
  ctx: Parameters<Tool['run']>[1],
  url: string,
  init: { method: 'GET' | 'POST'; body?: string; contentType?: string },
): Promise<{ status: number; text: string }> {
  let parsed: URL
  try {
    parsed = new URL(url)
  } catch {
    throw new Error('عنوان غير صالح')
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') throw new Error('يسمح بـ http/https فقط')
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 10_000)
  const egressId = recordEgress(ctx.db, {
    source: 'agent',
    provider: parsed.hostname,
    model: null,
    payload: init.body ?? url,
    config: ctx.config,
  })
  try {
    const res = await fetch(url, {
      method: init.method,
      signal: controller.signal,
      headers: init.body ? { 'content-type': init.contentType ?? 'application/json' } : undefined,
      body: init.body,
      redirect: 'follow',
    })
    const text = (await res.text()).slice(0, 64 * 1024) // hard cap — tool data, not a dump
    updateEgress(ctx.db, egressId, res.ok, res.ok ? null : `HTTP ${res.status}`)
    return { status: res.status, text }
  } catch (e) {
    updateEgress(ctx.db, egressId, false, 'provider_unreachable')
    throw e instanceof Error ? e : new Error(String(e))
  } finally {
    clearTimeout(timer)
  }
}

// -------------------------------------------------------------------- tools

export const builtinTools: Tool[] = [
  {
    name: 'get_time',
    description: 'يعيد الوقت الحالي على جهاز المالك (ISO + Unix + المنطقة الزمنية).',
    args: {},
    risk: null,
    summarize: () => 'قراءة الوقت الحالي من جهاز المالك',
    async run(): Promise<ToolResult> {
      const now = new Date()
      return ok(
        { iso: now.toISOString(), unix: Math.floor(now.getTime() / 1000), tz: Intl.DateTimeFormat().resolvedOptions().timeZone },
        `الآن ${now.toISOString()} (${Intl.DateTimeFormat().resolvedOptions().timeZone})`,
      )
    },
  },
  {
    name: 'calc',
    description: 'حاسبة تعبيرات حسابية آمنة: أرقام و + - * / % ^ وأقواس فقط.',
    args: { expression: 'string — مثل "2^10 / 4"' },
    risk: null,
    summarize: (a) => `حساب التعبير: ${asString(a.expression, 120)}`,
    async run(args): Promise<ToolResult> {
      try {
        const value = safeCalc(asString(args.expression, 512))
        return ok({ value }, `${asString(args.expression, 120)} = ${value}`)
      } catch (e) {
        return fail(e instanceof Error ? e.message : String(e))
      }
    },
  },
  {
    name: 'memory_search',
    description: 'بحث دلالي (متجهي) في ذاكرة المالك وملاحظاته وحلقات المهام السابقة.',
    args: { query: 'string', k: 'number (اختياري، افتراضي 5)' },
    risk: null,
    summarize: (a) => `بحث في الذاكرة عن: «${asString(a.query, 120)}»`,
    async run(args, ctx): Promise<ToolResult> {
      const memory = ctx.memory
      const k = typeof args.k === 'number' && args.k > 0 ? Math.min(Math.floor(args.k), 20) : 5
      const hits = memory.search(asString(args.query, 1024), k)
      return ok(
        { hits: hits.map((h) => ({ id: h.id, kind: h.kind, title: h.title, content: h.content, distance: Number(h.distance.toFixed(4)) })) },
        hits.length ? `${hits.length} نتيجة، أقربها «${hits[0]!.title}»` : 'لا نتائج في الذاكرة',
      )
    },
  },
  {
    name: 'memory_write',
    description: 'يكتب ملاحظة في ذاكرة المالك (قابلة للتعديل والحذف من الواجهة لاحقًا).',
    args: { title: 'string', content: 'string' },
    risk: null,
    summarize: (a) => `كتابة ملاحظة بعنوان «${asString(a.title, 120)}» في ذاكرة المالك`,
    async run(args, ctx): Promise<ToolResult> {
      const id = ctx.memory.upsert({ kind: 'note', title: asString(args.title, 200), content: asString(args.content, 8000), source: ctx.taskId ? `task:${ctx.taskId}` : 'agent' })
      return ok({ id }, `كُتبت الملاحظة «${asString(args.title, 120)}» (id=${id})`)
    },
  },
  {
    name: 'http_get',
    description: 'يجلب محتوى عنوان http/https (نص أو JSON، بحد 64KB و10 ثوانٍ). يُسجَّل في سجل الخارج.',
    args: { url: 'string' },
    risk: null,
    summarize: (a) => `جلب GET للعنوان: ${asString(a.url, 160)}`,
    async run(args, ctx): Promise<ToolResult> {
      try {
        const res = await toolFetch(ctx, asString(args.url, 2048), { method: 'GET' })
        if (res.status >= 400) return fail(`HTTP ${res.status}`)
        return ok({ status: res.status, body: res.text }, `HTTP ${res.status} — أول 120 محرفًا: ${res.text.slice(0, 120)}`)
      } catch (e) {
        return fail(e instanceof Error ? e.message : String(e))
      }
    },
  },
  {
    name: 'send_webhook',
    description: 'يرسل POST ببيانات JSON إلى عنوان خارجي. خطر (إرسال للخارج) — يتطلب موافقة المالك.',
    args: { url: 'string', body: 'object (JSON)' },
    risk: 'send',
    summarize: (a) => `إرسال POST إلى ${asString(a.url, 160)} بحمولة JSON`,
    async run(args, ctx): Promise<ToolResult> {
      try {
        const body = JSON.stringify(args.body ?? {})
        const res = await toolFetch(ctx, asString(args.url, 2048), { method: 'POST', body })
        return ok({ status: res.status, body: res.text.slice(0, 512) }, `HTTP ${res.status} — ${res.text.slice(0, 120)}`)
      } catch (e) {
        return fail(e instanceof Error ? e.message : String(e))
      }
    },
  },
  {
    name: 'shell_exec',
    description: 'يشغّل أمر node أو python3 معزولًا في مجلد مؤقت (10 ثوانٍ، مخرجات محدودة). خطر (تشغيل برامج) — يتطلب موافقة المالك.',
    args: { command: 'string — مثل "node -e \\"console.log(1+1)\\""' },
    risk: 'software_install',
    summarize: (a) => `تشغيل أمر معزول: ${asString(a.command, 160)}`,
    async run(args, ctx): Promise<ToolResult> {
      const raw = asString(args.command, 2000).trim()
      const bin = raw.split(/\s+/)[0] ?? ''
      if (!['node', 'python3'].includes(bin)) {
        return fail(`الأمر «${bin}» خارج قائمة السماح (node / python3 فقط)`)
      }
      const cwd = mkdtempSync(join(tmpdir(), 'omnara-agent-'))
      try {
        const { stdout, stderr } = await execFileAsync(bin, raw.slice(bin.length).trim() ? raw.slice(bin.length).trim().split(/\s+/) : [], {
          cwd,
          timeout: 10_000,
          maxBuffer: 64 * 1024,
          env: { PATH: process.env.PATH ?? '/usr/bin:/bin', HOME: cwd, LANG: 'C.UTF-8' },
        })
        const out = `${stdout}${stderr ? `\n[stderr] ${stderr}` : ''}`.slice(0, 2000)
        return ok({ bin, out }, out ? `المخرجات: ${out.slice(0, 120)}` : 'انتهى بلا مخرجات (رمز خروج 0)')
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e)
        return fail(msg.slice(0, 500))
      } finally {
        rmSync(cwd, { recursive: true, force: true })
      }
    },
  },
  {
    name: 'project_list_files',
    description: 'يسرد ملفات مساحة المشروع المعزولة المرتبطة بالمهمة (حتى 1000 مدخل).',
    args: {},
    risk: null,
    summarize: () => 'سرد ملفات مساحة المشروع',
    async run(_args, ctx): Promise<ToolResult> {
      if (!ctx.projectId) return fail('لا توجد مساحة مشروع مرتبطة بهذه المهمة')
      const files = listProjectFiles(ctx.config, ctx.projectId)
      return ok(
        { files },
        files.length ? `${files.length} مدخل، أولها «${files[0]!.path}»` : 'مساحة المشروع فارغة',
      )
    },
  },
  {
    name: 'project_read_file',
    description: 'يقرأ ملفًا نصيًا من مساحة المشروع المعزولة (حتى 256KB).',
    args: { path: 'string — مسار نسبي داخل المشروع' },
    risk: null,
    summarize: (a) => `قراءة الملف «${asString(a.path, 160)}» من مساحة المشروع`,
    async run(args, ctx): Promise<ToolResult> {
      if (!ctx.projectId) return fail('لا توجد مساحة مشروع مرتبطة بهذه المهمة')
      const file = readProjectFile(ctx.config, ctx.projectId, asString(args.path, 512))
      if (!file) return fail(`تعذّر قراءة «${asString(args.path, 160)}» (غير موجود، أو يتجاوز 256KB، أو خارج الحدود)`)
      return ok({ path: file.path, size: file.size, content: file.content.slice(0, 32 * 1024) }, `قُرئ «${file.path}» (${file.size} بايت)`) // keep tool output bounded
    },
  },
  {
    name: 'project_write_file',
    description: 'يكتب ملفًا نصيًا في مساحة المشروع المعزولة (حتى 256KB للملف الواحد). يُنشئ المجلدات الوسيطة.',
    args: { path: 'string — مسار نسبي داخل المشروع', content: 'string — المحتوى الكامل للملف' },
    risk: null,
    summarize: (a) => `كتابة الملف «${asString(a.path, 160)}» في مساحة المشروع (${String(a.content ?? '').length} محرف)`,
    async run(args, ctx): Promise<ToolResult> {
      if (!ctx.projectId) return fail('لا توجد مساحة مشروع مرتبطة بهذه المهمة')
      try {
        const written = writeProjectFile(ctx.config, ctx.projectId, asString(args.path, 512), asString(args.content, 256 * 1024))
        return ok({ path: written.path, bytes: written.bytes }, `كُتب «${written.path}» (${written.bytes} بايت)`)
      } catch (e) {
        return fail(e instanceof Error ? e.message : String(e))
      }
    },
  },
  {
    name: 'memory_delete',
    description: 'يحذف ملاحظة من ذاكرة المالك (بمعرّفها، أو كل الملاحظات بـ all:true). خطر (حذف) — يتطلب موافقة المالك.',
    args: { id: 'number', all: 'boolean (اختياري)' },
    risk: 'deletion',
    summarize: (a) => (a.all === true ? 'حذف كل ملاحظات ذاكرة المالك' : `حذف الملاحظة رقم ${String(a.id)}`),
    async run(args, ctx): Promise<ToolResult> {
      if (args.all === true) {
        const rows = ctx.memory.listUser()
        let n = 0
        for (const r of rows) if (ctx.memory.deleteUser(r.id)) n++
        return ok({ deleted: n }, `حُذفت ${n} ملاحظة`)
      }
      const id = Number(args.id)
      if (!Number.isInteger(id) || id <= 0) return fail('id غير صالح')
      const done = ctx.memory.deleteUser(id)
      return done ? ok({ deleted: 1 }, `حُذفت الملاحظة ${id}`) : fail(`لا توجد ملاحظة برقم ${id}`)
    },
  },
  {
    // ALLIMNI ↔ HYPERBRAIN (LIMO #11): bounded, jailed, READ-ONLY access to
    // installed skills. Only ACTIVE skills are readable — disabling a skill
    // in the management center removes it from the agent's reach immediately.
    name: 'skill_read',
    description: 'يقرأ ملفًا من مهارة مثبتة في مكتبة علّمني (الافتراضي SKILL.md) — قراءة فقط، بلا تنفيذ لأي أوامر داخلها.',
    args: { slug: 'string — معرّف المهارة من قسم «قدرات مثبتة»', path: 'string (اختياري، افتراضي SKILL.md)' },
    risk: null,
    summarize: (a) => `قراءة ${a.path ? String(a.path) : 'SKILL.md'} من المهارة «${String(a.slug)}»`,
    async run(args, ctx): Promise<ToolResult> {
      const slug = asString(args.slug, 64).toLowerCase()
      if (!/^[a-z0-9][a-z0-9-]{0,63}$/.test(slug)) return fail('slug غير صالح')
      const row = ctx.db
        .prepare("SELECT slug, name, status FROM skills WHERE slug = ?")
        .get(slug) as { slug: string; name: string; status: string } | undefined
      if (!row) return fail(`لا مهارة بهذا المعرّف (${slug}) — استخدم قسم «قدرات مثبتة» في موجّهك`)
      if (row.status !== 'active') return fail(`المهارة «${row.name}» معطّلة حاليًا — فعّلها من مركز إدارة علّمني`)
      const path = args.path ? asString(args.path, 256) : 'SKILL.md'
      const files = listSkillFiles(ctx.config, slug)
      if (files.length === 0) return fail('ملفات المهارة غير موجودة على القرص')
      const file = readSkillFile(ctx.config, slug, path)
      if (!file) {
        return ok(
          { available: files.slice(0, 40).map((f) => f.path) },
          `الملف «${path}» غير موجود — المتاح: ${files.slice(0, 10).map((f) => f.path).join(' · ')}`,
        )
      }
      return ok({ path: file.path, content: file.content.slice(0, 48 * 1024) }, `قُرئ «${file.path}» (${file.content.length} محرفًا) من «${row.name}»`)
    },
  },

  // ------------------------------------------- SELF-REALM (LIMO #18)
  // The agent reads its own source through the SAME jailed, secret-denied
  // inspectors the box uses, and STARTS self-modification through the SAME
  // Reality Forge pipeline the owner drives — never a parallel write path.
  {
    name: 'self_read_file',
    description: 'الصدَفة الذاتية (قراءة): يقرأ ملفًا من كود ليمو نفسه — نصي فقط بحد حجم، ممنوع الأسرار والبناء والتبعيات وخارج جذر المستودع.',
    args: { path: 'string — مسار نسبي مثل "server/src/agent/tools.ts"' },
    risk: null,
    summarize: (a) => `قراءة ملف من كود ليمو: ${asString(a.path, 160)}`,
    async run(args, ctx): Promise<ToolResult> {
      const res = readSourceFile(ctx.config, asString(args.path, 512))
      if (!res.ok) return fail(res.error)
      const content = res.content.slice(0, 32 * 1024)
      return ok(
        { path: res.path, bytes: res.bytes, lines: res.lines, truncated: content.length < res.content.length, content },
        `قُرئ «${res.path}» من كود ليمو (${res.bytes} بايت)`,
      )
    },
  },
  {
    name: 'self_search_code',
    description: 'الصدَفة الذاتية (بحث): بحث حقيقي في شيفرة ليمو نفسها (واجهة + خادم، حدود صارمة: 900 ملف و40 تطابقًا، الأسرار مستثناة) — لأثر التعديل الذاتي وتتبع الاعتماديات.',
    args: { query: 'string — كلمة أو نمط بحث' },
    risk: null,
    summarize: (a) => `بحث في كود ليمو عن: ${asString(a.query, 120)}`,
    async run(args, ctx): Promise<ToolResult> {
      const res = searchSource(ctx.config, asString(args.query, 256))
      if (!res.ok) return fail(res.error)
      return ok(
        { scanned: res.scanned, capped: res.capped, matches: res.matches },
        res.matches.length
          ? `${res.matches.length} تطابقًا في ${res.scanned} ملفًا — أولها «${res.matches[0]!.path}:${res.matches[0]!.line}»`
          : `لا تطابقات في ${res.scanned} ملفًا`,
      )
    },
  },
  {
    name: 'self_start_change',
    description:
      'الصدَفة الذاتية (كتابة عبر المسبكة): يبدأ تعديلًا حقيقيًا لكود ليمو نفسه عبر Reality Forge — فحص، خطة ورقعة بنموذج المهمة نفسه، فرع git معزول، اختبارات، مراجعة أمنية، ثم بوابة موافقة المالك. لا كتابة مباشرة أبدًا.',
    args: { request: 'string — وصف دقيق للتعديل المطلوب في كود ليمو (بعد فحصه بـ self_read_file/self_search_code)' },
    risk: null, // the forge pipeline carries its own owner gate + L4 policy
    summarize: (a) => `بدء تعديل ذاتي عبر Reality Forge: ${asString(a.request, 140)}`,
    async run(args, ctx): Promise<ToolResult> {
      if (!ctx.config.forgeRepoRoot)
        return fail('Reality Forge معطّل — لا مستودع git تحت هذا التشغيل (FORGE_REPO_ROOT)؛ التعديل الذاتي متاح على الجوال بعد git init')
      const request = asString(args.request, 4000).trim()
      if (request.length < 8) return fail('اوصف التعديل المطلوب بثمانية أحرف على الأقل')
      const level = readAutonomyLevel(ctx.db)
      // LIMO #19: the owner's engineering pin wins when this ctx can build
      // forge deps for it; otherwise the task's own model stack is used and
      // recorded — the row always names the model that ACTUALLY engineers.
      const canPin = Boolean(ctx.registry && ctx.vault)
      const model = canPin ? resolveForgeModel(ctx.db, ctx.model ?? null) : (ctx.model ?? null)
      const id = createChange(ctx.db, request, model, level)
      const deps = canPin
        ? forgeDepsFor({ db: ctx.db, config: ctx.config, registry: ctx.registry, vault: ctx.vault, log: ctx.log }, model)
        : { db: ctx.db, config: ctx.config, log: ctx.log, modelFn: ctx.modelFn ?? null, model: ctx.model ?? null }
      startChange(deps, id, ctx.log)
      return ok(
        { id, status: 'analyzing', autonomyLevel: level, model },
        `انطلق التغيير الذاتي #${id} بمستوى L${level} — تابعه بـ self_change_status؛ التطبيق النهائي خلف بوابة المالك`,
      )
    },
  },
  {
    name: 'self_change_status',
    description: 'الصدَفة الذاتية (حالة): يقرأ حالة تغيير تعديل ذاتي برقمه — الخطة، الملفات، مقتطف الفرق، نتيجة الاختبارات، المراجعة الأمنية، وسجل الأحداث.',
    args: { id: 'number — رقم التغيير من self_start_change' },
    risk: null,
    summarize: (a) => `حالة التغيير الذاتي رقم ${String(a.id)}`,
    async run(args, ctx): Promise<ToolResult> {
      const id = Number(args.id)
      if (!Number.isInteger(id) || id <= 0) return fail('معرّف التغيير مطلوب (رقم)')
      const res = changeForChat(ctx.db, id)
      if (!res.ok) return fail(res.error)
      const c = res.change
      return ok(
        c,
        `التغيير #${c.id}: ${c.status} (L${c.level})${c.security.verdict ? ` · أمن: ${c.security.verdict}` : ''}${c.test.code !== null ? ` · اختبارات: ${c.test.code === 0 ? 'نجحت' : `فشلت (${c.test.code})`}` : ''}`,
      )
    },
  },
]

export function toolByName(name: string): Tool | undefined {
  return builtinTools.find((t) => t.name === name)
}

/** The catalog shown to the planner (name / description / args / risk). */
export function toolCatalog(): Array<{ name: string; description: string; args: Record<string, string>; risk: string | null }> {
  return builtinTools.map((t) => ({ name: t.name, description: t.description, args: t.args, risk: t.risk }))
}
