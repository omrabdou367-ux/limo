import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import type { Logger } from '../logger.js'
import { buildModelFn } from './model.js'
import { runAgentTask, type AgentEngineDeps } from './engine.js'
import type { RoutineRow, RoutineRunRow, RoutineRunStatus } from './types.js'

/**
 * Scheduled routines with the vault lock policy (PLAN.md §7.2 + owner
 * directive v2.2 #5):
 *
 *  - `allow_downgrade` defaults to FALSE. When the vault is LOCKED and the
 *    routine's model needs a key:
 *      · allow_downgrade = 0 → the run is recorded `skipped_vault_locked`
 *        (visible in the UI — never a fake success).
 *      · allow_downgrade = 1 → the run degrades to the first keyless
 *        provider (local Ollama & friends) and is recorded
 *        `degraded_vault_locked` with the model actually used.
 *  - `catch_up_on_unlock` → skipped one-shots re-run once the vault is
 *    unwrapped. In open mode (LIMO #8) that is at every boot — index.ts
 *    calls catchUpOnUnlock() right after the vault self-unwraps.
 */

export interface RoutineDeps {
  db: DB
  config: ServerConfig
  registry: ProviderRegistry
  vault: Vault
  log: Logger
  /** engine deps factory (modelFn is built per-run for the chosen model) */
  engineDeps: Omit<AgentEngineDeps, 'modelFn'>
}

export class RoutineScheduler {
  private timer: NodeJS.Timeout | null = null

  constructor(private readonly deps: RoutineDeps) {}

  start(tickMs = 20_000): () => void {
    this.timer = setInterval(() => void this.tick(), tickMs)
    this.timer.unref?.()
    return () => this.stop()
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer)
    this.timer = null
  }

  /** Run every due routine now. Idempotent; safe to call manually in tests. */
  async tick(now = new Date()): Promise<void> {
    const due = this.deps.db
      .prepare('SELECT * FROM agent_routines WHERE enabled = 1 AND next_run_at <= ?')
      .all(now.toISOString().slice(0, 19).replace('T', ' ')) as RoutineRow[]
    // next_run_at is stored ISO-ish; compare defensively in JS too
    for (const r of due) {
      if (new Date(r.next_run_at).getTime() <= now.getTime() + 1000) await this.runRoutine(r.id)
    }
  }

  /** The vault policy + one agent task run. Returns the recorded run status. */
  async runRoutine(routineId: number): Promise<{ status: RoutineRunStatus; runId: number; taskId: number | null; detail: string | null }> {
    const db = this.deps.db
    const r = db.prepare('SELECT * FROM agent_routines WHERE id = ?').get(routineId) as RoutineRow | undefined
    if (!r) return { status: 'error', runId: 0, taskId: null, detail: 'الروتين غير موجود' }

    const bump = (status: RoutineRunStatus, detail: string | null, taskId: number | null): number => {
      const info = db
        .prepare('INSERT INTO agent_routine_runs (routine_id, status, detail, task_id) VALUES (?, ?, ?, ?)')
        .run(routineId, status, detail, taskId)
      const nowIso = new Date().toISOString()
      db.prepare('UPDATE agent_routines SET last_run_at = ?, next_run_at = ?, pending_catchup = 0, updated_at = ? WHERE id = ?').run(
        nowIso,
        new Date(Date.now() + r.interval_sec * 1000).toISOString(),
        nowIso,
        routineId,
      )
      return Number(info.lastInsertRowid)
    }

    // ---- vault lock policy (§7.2 / v2.2 #5)
    let model = r.model
    let degraded = false
    try {
      const resolved = this.deps.registry.resolveModel(r.model)
      const adapter = this.deps.registry.get(resolved.providerId)
      if (adapter?.needsKey && !this.deps.vault.isUnlocked) {
        if (!r.allow_downgrade) {
          const runId = bump('skipped_vault_locked', 'الخزنة مقفلة وallow_downgrade معطّل (الافتراضي)', null)
          if (r.catch_up_on_unlock) {
            db.prepare('UPDATE agent_routines SET pending_catchup = 1 WHERE id = ?').run(routineId)
          }
          this.deps.log.info('routine skipped — vault locked', { routine: r.name })
          return { status: 'skipped_vault_locked', runId, taskId: null, detail: 'الخزنة مقفلة وallow_downgrade معطّل' }
        }
        const fallback = await this.findKeylessModel()
        if (!fallback) {
          const runId = bump('skipped_vault_locked', 'الخزنة مقفلة ولا يوجد مزود بلا مفاتيح متاح للخفض', null)
          if (r.catch_up_on_unlock) db.prepare('UPDATE agent_routines SET pending_catchup = 1 WHERE id = ?').run(routineId)
          return { status: 'skipped_vault_locked', runId, taskId: null, detail: 'لا مزود بلا مفاتيح متاح' }
        }
        model = fallback
        degraded = true
      }
    } catch (e) {
      const runId = bump('error', `تعذر تحليل النموذج: ${e instanceof Error ? e.message : String(e)}`, null)
      return { status: 'error', runId, taskId: null, detail: 'تعذر تحليل النموذج' }
    }

    // ---- create + run one agent task
    const info = db
      .prepare("INSERT INTO agent_tasks (goal, model, status, source) VALUES (?, ?, 'queued', ?)")
      .run(r.prompt, model, `routine:${routineId}`)
    const taskId = Number(info.lastInsertRowid)
    const modelFn = buildModelFn({ ...this.deps, model, source: 'agent' })
    try {
      await runAgentTask({ ...this.deps.engineDeps, modelFn }, taskId)
    } catch (e) {
      this.deps.log.warn('routine task threw', { routine: r.name, err: e instanceof Error ? e.message : String(e) })
    }
    const task = db.prepare('SELECT status FROM agent_tasks WHERE id = ?').get(taskId) as { status: string } | undefined
    // the vault-policy outcome comes first: a degraded run is reported as
    // degraded even when the downgraded task itself completed (honest label)
    const status: RoutineRunStatus = degraded ? 'degraded_vault_locked' : task?.status === 'completed' ? 'ok' : 'error'
    const runId = bump(
      status,
      degraded
        ? `خُفِّض إلى ${model} (الخزنة مقفلة وallow_downgrade مفعّل) — حالة المهمة: ${task?.status ?? 'مجهولة'}`
        : `النموذج: ${model} — حالة المهمة: ${task?.status ?? 'مجهولة'}`,
      taskId,
    )
    return { status, runId, taskId, detail: degraded ? `خُفِّض إلى ${model}` : null }
  }

  /** First model of the first keyless (local) provider — the §7.2 downgrade. */
  private async findKeylessModel(): Promise<string | null> {
    for (const adapter of this.deps.registry.list()) {
      if (adapter.needsKey) continue
      try {
        const models = await adapter.listModels()
        if (models.length > 0) return `${adapter.id}/${models[0]!.id}`
      } catch {
        /* provider unreachable — try the next */
      }
    }
    return null
  }

  /** §7.2 catch-up: run pending catch-up routines once, right after unlock. */
  async catchUpOnUnlock(): Promise<number> {
    const rows = this.deps.db
      .prepare('SELECT id FROM agent_routines WHERE enabled = 1 AND pending_catchup = 1')
      .all() as Array<{ id: number }>
    for (const r of rows) await this.runRoutine(r.id)
    return rows.length
  }

  listRuns(routineId: number, limit = 20): RoutineRunRow[] {
    return this.deps.db
      .prepare('SELECT * FROM agent_routine_runs WHERE routine_id = ? ORDER BY id DESC LIMIT ?')
      .all(routineId, limit) as RoutineRunRow[]
  }
}
