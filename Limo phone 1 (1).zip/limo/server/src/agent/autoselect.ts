import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { ProviderRegistry } from '../providers/registry.js'
import type { Vault } from '../vault/vault.js'
import type { ModelFn } from './types.js'
import { getSettingJson, setSettingJson } from '../db/settings.js'
import { usableModels } from '../box/brain.js'

/**
 * Automatic model selection (owner directive 2026-11-01: «وضف لوضع الوكيل
 * ميزة اختيار النماذج أوتوماتيكيا») — the LIMO take on the routing layer
 * behind agentic "supercomputer" products: every agent purpose resolves its
 * OWN model from what is actually usable right now, with a recorded reason.
 *
 * Honesty rules:
 *  - candidates are ONLY models the system can truly call (usable models);
 *  - the owner's saved preferences win, when their models are usable;
 *  - otherwise deterministic, explainable heuristics over catalog metadata
 *    (context window for the planner, free models for the critic, diversity
 *    when both exist) — never a claimed "quality ranking" we cannot verify;
 *  - every choice is reported with its reason and lands in agent_events.
 */

export type AutoPurpose = 'planner' | 'critic' | 'recovery'

export interface ModelChoice {
  model: string
  reason: string
}

export interface AutoModelPrefs {
  /** ordered preferred models for the planner step */
  planner?: string[]
  /** ordered preferred models for the critic gate */
  critic?: string[]
}

export const AUTO_PREFS_KEY = 'auto_model_prefs'

export function getAutoPrefs(db: DB): AutoModelPrefs {
  const raw = getSettingJson<AutoModelPrefs>(db, AUTO_PREFS_KEY)
  return {
    planner: Array.isArray(raw?.planner) ? raw.planner.filter((m) => typeof m === 'string') : [],
    critic: Array.isArray(raw?.critic) ? raw.critic.filter((m) => typeof m === 'string') : [],
  }
}

export function setAutoPrefs(db: DB, prefs: AutoModelPrefs): void {
  setSettingJson(db, AUTO_PREFS_KEY, prefs)
}

/**
 * Pick the model for one purpose. Returns null when NOTHING is usable —
 * callers must fail honestly, never silently fall back to a dead model.
 */
export async function pickAutoModel(
  db: DB,
  registry: ProviderRegistry,
  vault: Vault,
  config: ServerConfig,
  purpose: AutoPurpose,
): Promise<ModelChoice | null> {
  const usable = await usableModels(db, registry, vault, config)
  if (usable.length === 0) return null
  const byId = new Map(usable.map((m) => [m.id, m] as const))
  const prefs = getAutoPrefs(db)

  // 1) owner preferences — first usable entry wins
  const prefList: string[] = purpose === 'critic' ? (prefs.critic ?? []) : (prefs.planner ?? [])
  for (const p of prefList) {
    if (byId.has(p)) return { model: p, reason: 'تفضيل المالك المحفوظ' }
  }

  // 2) deterministic heuristics over real catalog metadata
  if (purpose === 'critic') {
    const free = usable.find((m) => m.free)
    if (free) return { model: free.id, reason: 'نموذج مجاني من الفهرس — مناسب لبوابة الناقد' }
    if (usable.length > 1) {
      const second = usable[1]!
      return { model: second.id, reason: 'تنويع عن نموذج المخطط لتقليل التحيز' }
    }
    return { model: usable[0]!.id, reason: 'النموذج الوحيد المتاح' }
  }

  // planner / recovery: largest declared context window, ties → first
  let best: UsableModelLike | null = null
  for (const m of usable) {
    if (!best) {
      best = m
      continue
    }
    if ((m.contextLength ?? 0) > (best.contextLength ?? 0)) best = m
  }
  if (best && (best.contextLength ?? 0) > 0) {
    return { model: best.id, reason: `أكبر نافذة سياق معلنة في الفهرس (${best.contextLength})` }
  }
  return { model: usable[0]!.id, reason: 'أول نموذج متاح (لا بيانات سياق في الفهرس)' }
}

export interface AutoModelDeps {
  db: DB
  config: ServerConfig
  registry: ProviderRegistry
  vault: Vault
  build: (model: string) => ModelFn
  /** called once per resolved choice — routes record it in agent_events */
  onChoice?: (purpose: AutoPurpose, choice: ModelChoice) => void
}

interface UsableModelLike {
  id: string
  contextLength: number | null
}

/**
 * A purpose-aware ModelFn: resolves the model at CALL time (so a vault
 * unlock or a preferences change between steps is honored) and reports every
 * choice with its reason. Falls back to the single-purpose choice when a
 * purpose has nothing usable — the caller surfaces the honest error.
 */
export function autoModelFn(deps: AutoModelDeps): (purpose: AutoPurpose) => ModelFn {
  const cache = new Map<AutoPurpose, ModelFn>()
  return (purpose: AutoPurpose): ModelFn => {
    const memo = cache.get(purpose)
    if (memo) return memo
    const fn: ModelFn = async (messages, opts) => {
      const choice = await pickAutoModel(deps.db, deps.registry, deps.vault, deps.config, purpose)
      if (!choice) {
        throw new Error('لا نماذج قابلة للاستخدام — شغّل Ollama أو أضف مفتاح مزود من الخزنة ثم جمّع الفهرس')
      }
      deps.onChoice?.(purpose, choice)
      return deps.build(choice.model)(messages, opts)
    }
    cache.set(purpose, fn)
    return fn
  }
}
