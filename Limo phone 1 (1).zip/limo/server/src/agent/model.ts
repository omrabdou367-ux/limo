import type { ServerConfig } from '../config.js'
import type { DB } from '../db/database.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import { keyAliasFor } from '../providers/registry.js'
import { ProviderError, type ChatMessage, type ProviderErrorKind } from '../providers/types.js'
import { recordUsage } from '../db/usage.js'
import { recordEgress, updateEgress } from '../db/egress.js'
import type { Logger } from '../logger.js'
import type { ModelCallOpts, ModelFn } from './types.js'

/**
 * buildModelFn — how the agent engine talks to a model.
 *
 * It reuses the SAME adapter path as the /v1 gateway (no parallel stack):
 * resolve the prefixed model id, honor the vault lock policy, aggregate the
 * adapter's stream into one string, record usage AND an egress-log row
 * (source 'agent') with the payload fingerprint — no content, ever.
 *
 * Tests inject their own ModelFn instead (deterministic محاكى mode).
 */

/**
 * LIMO #22 — transient provider failures worth a bounded retry. OpenRouter's
 * free tier (and any mobile NAT) regularly returns one-off 429/5xx/network
 * drops; a single transient error must NOT kill a whole box turn or task.
 * Everything else (bad key, locked vault, unknown model, open breaker) fails
 * honestly on the first attempt — retrying those is a lie with extra steps.
 */
const RETRYABLE_KINDS = new Set<ProviderErrorKind>(['rate_limited', 'provider_unreachable', 'provider_error'])
const MAX_MODEL_ATTEMPTS = 3
const RETRY_CAP_MS = 8_000

function retryDelayMs(e: ProviderError, attempt: number): number {
  if (e.retryAfterSec && e.retryAfterSec > 0) return Math.min(e.retryAfterSec * 1000, RETRY_CAP_MS)
  return Math.min(800 * 2 ** (attempt - 1), RETRY_CAP_MS)
}

export function buildModelFn(deps: {
  db: DB
  config: ServerConfig
  registry: ProviderRegistry
  vault: Vault
  log: Logger
  model: string
  source?: 'agent' | 'forge' | 'workflow' | 'box'
}): ModelFn {
  const { db, config, registry, vault, log, model } = deps
  const source = deps.source ?? 'agent'

  return async (messages: ChatMessage[], opts?: ModelCallOpts): Promise<string> => {
    const resolved = registry.resolveModel(model) // throws ProviderError on unknown provider
    const adapter = registry.get(resolved.providerId)!

    if (adapter.needsKey) {
      if (!vault.isUnlocked) {
        throw new ProviderError('vault_locked', 'الخزنة مقفلة بعد إعادة التشغيل — افتحها من الواجهة ثم أعد المحاولة', 409)
      }
      if (!vault.hasSecret(keyAliasFor(resolved.providerId))) {
        throw new ProviderError('missing_key', `${resolved.providerId}: لا يوجد مفتاح مضبوط — أضفه من لوحة الخزنة`, 409)
      }
    }

    // one real outbound call per attempt, each with its own honest egress/usage rows
    const attemptOnce = async (): Promise<string> => {
      if (opts?.shouldStop?.()) throw new ProviderError('provider_error', 'aborted_before_call', 499)
      const payload = JSON.stringify({ model: resolved.modelId, messages, temperature: opts?.temperature ?? null, max_tokens: opts?.maxTokens ?? null })
      const egressId = recordEgress(db, { source, provider: resolved.providerId, model, payload, config })
      const started = Date.now()
      let content = ''
      try {
        const controller = new AbortController()
        const events = adapter.streamChat({
          modelId: resolved.modelId,
          messages,
          temperature: opts?.temperature,
          maxTokens: opts?.maxTokens,
          signal: controller.signal,
        })
        for await (const evt of events) {
          if (evt.type === 'delta') {
            content += evt.content
            opts?.onDelta?.(evt.content)
            if (opts?.shouldStop?.()) throw new ProviderError('provider_error', 'client_aborted', 499)
          }
        }
        controller.abort()
        updateEgress(db, egressId, true)
        recordUsage(db, { provider: resolved.providerId, model, ok: true, durationMs: Date.now() - started })
        return content
      } catch (e) {
        const pe = e instanceof ProviderError ? e : new ProviderError('provider_error', e instanceof Error ? e.message : String(e))
        updateEgress(db, egressId, false, pe.kind)
        recordUsage(db, { provider: resolved.providerId, model, ok: false, durationMs: Date.now() - started, errorKind: pe.kind })
        log.warn(`${source}: model call failed`, { model, kind: pe.kind })
        throw pe
      }
    }

    let lastError: ProviderError = new ProviderError('provider_error', 'unreachable')
    for (let attempt = 1; attempt <= MAX_MODEL_ATTEMPTS; attempt++) {
      try {
        return await attemptOnce()
      } catch (e) {
        lastError = e instanceof ProviderError ? e : new ProviderError('provider_error', e instanceof Error ? e.message : String(e))
        // a cooperative client abort NEVER retries — the owner asked to stop
        if (opts?.shouldStop?.() || lastError.message === 'client_aborted' || lastError.message === 'aborted_before_call') throw lastError
        if (attempt >= MAX_MODEL_ATTEMPTS || !RETRYABLE_KINDS.has(lastError.kind)) throw lastError
        const waitMs = retryDelayMs(lastError, attempt)
        log.warn(`${source}: transient ${lastError.kind} — retry ${attempt + 1}/${MAX_MODEL_ATTEMPTS} in ${waitMs}ms`, { model })
        await new Promise((r) => setTimeout(r, waitMs))
      }
    }
    throw lastError // unreachable, but TS demands it
  }
}

/**
 * Parse the first balanced JSON object out of a model reply (models add
 * prose despite the prompt; the engine never trusts formatting blindly).
 */
export function extractJson<T>(text: string): T | null {
  const start = text.indexOf('{')
  if (start < 0) return null
  let depth = 0
  let inStr = false
  let esc = false
  for (let i = start; i < text.length; i++) {
    const c = text[i]!
    if (inStr) {
      if (esc) esc = false
      else if (c === '\\') esc = true
      else if (c === '"') inStr = false
      continue
    }
    if (c === '"') inStr = true
    else if (c === '{') depth++
    else if (c === '}') {
      depth--
      if (depth === 0) {
        try {
          return JSON.parse(text.slice(start, i + 1)) as T
        } catch {
          return null
        }
      }
    }
  }
  return null
}
