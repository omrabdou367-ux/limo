import type { DB } from '../db/database.js'
import type { ApprovalRow, RiskCategory } from './types'

/**
 * The human-approval gate for dangerous agent actions (owner-specified
 * mandatory list). An approval is CREATED before anything runs, the task
 * drops to `awaiting_approval`, and only an explicit decision unblocks it.
 * Timeouts expire — a dangerous action is never executed by default.
 */

export function createApproval(
  db: DB,
  e: { taskId: number | null; category: RiskCategory; summary: string; payload: unknown },
): ApprovalRow {
  const info = db
    .prepare('INSERT INTO agent_approvals (task_id, category, summary, payload) VALUES (?, ?, ?, ?)')
    .run(e.taskId, e.category, e.summary, JSON.stringify(e.payload))
  return getApproval(db, Number(info.lastInsertRowid))!
}

export function getApproval(db: DB, id: number): ApprovalRow | undefined {
  return db.prepare('SELECT * FROM agent_approvals WHERE id = ?').get(id) as ApprovalRow | undefined
}

export function listApprovals(db: DB, status?: 'pending' | 'approved' | 'rejected' | 'expired'): ApprovalRow[] {
  if (status) {
    return db.prepare('SELECT * FROM agent_approvals WHERE status = ? ORDER BY id DESC LIMIT 100').all(status) as ApprovalRow[]
  }
  return db.prepare('SELECT * FROM agent_approvals ORDER BY id DESC LIMIT 100').all() as ApprovalRow[]
}

export type ApprovalDecision = 'approved' | 'rejected'

/** Decide a PENDING approval. Any other state is refused (append-only decisions). */
export function decideApproval(db: DB, id: number, decision: ApprovalDecision, decidedBy = 'owner'): ApprovalRow | { error: string } {
  const cur = getApproval(db, id)
  if (!cur) return { error: 'not_found' }
  if (cur.status !== 'pending') return { error: 'already_decided' }
  db.prepare('UPDATE agent_approvals SET status = ?, decided_at = ?, decided_by = ? WHERE id = ?').run(
    decision,
    new Date().toISOString(),
    decidedBy,
    id,
  )
  return getApproval(db, id)!
}

/** Expire stale pending approvals (called by the engine when it gives up waiting). */
export function expireApproval(db: DB, id: number): void {
  db.prepare("UPDATE agent_approvals SET status = 'expired', decided_at = ? WHERE id = ? AND status = 'pending'").run(
    new Date().toISOString(),
    id,
  )
}
