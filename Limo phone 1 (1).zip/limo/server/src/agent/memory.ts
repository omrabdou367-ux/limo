import { createRequire } from 'node:module'
import type { DB } from '../db/database.js'

/**
 * The agent memory (PLAN.md §6 stage 3) — three parts:
 *
 *  1. ShortTermMemory — the compact rolling trace of what the engine has
 *     already done this task (deterministic digest folding, no model calls).
 *  2. VectorMemory   — semantic recall over episodes + user notes, backed by
 *     sqlite-vec (vec0 virtual table, KNN). If the extension cannot load on
 *     the host, it falls back to exact-same-math JS cosine similarity and
 *     says so via `mode` — never silently pretends.
 *  3. user memory CRUD — kind='note' rows the owner can list / edit / delete
 *     from the UI at any time (exportable as plain JSON via the API).
 *
 * Embeddings: a deterministic local hashing embedder (256-dim, L2-normalized,
 * Arabic + Latin tokenization). No data leaves the machine to embed — the
 * egress log stays quiet unless an owner plugs a remote embedding provider.
 */

export const EMBED_DIM = 256

/** Deterministic local embedder: hashed bag-of-tokens, tf-weighted, L2-normalized. */
export function localEmbed(text: string): Float32Array {
  const vec = new Float32Array(EMBED_DIM)
  const tokens = text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s._/-]+/gu, ' ')
    .split(/[\s._/-]+/)
    .filter((t) => t.length > 1)
  const counts = new Map<string, number>()
  for (const t of tokens) counts.set(t, (counts.get(t) ?? 0) + 1)
  for (const [token, count] of counts) {
    let h = 0x811c9dc5
    for (let i = 0; i < token.length; i++) {
      h ^= token.charCodeAt(i)
      h = Math.imul(h, 0x01000193) >>> 0
    }
    const idx = h % EMBED_DIM
    const sign = (h >>> 31) === 1 ? -1 : 1
    vec[idx] = (vec[idx] ?? 0) + sign * (1 + Math.log(count))
  }
  let norm = 0
  for (let i = 0; i < EMBED_DIM; i++) norm += vec[i]! * vec[i]!
  norm = Math.sqrt(norm) || 1
  for (let i = 0; i < EMBED_DIM; i++) vec[i] = vec[i]! / norm
  return vec
}

const f32buf = (v: Float32Array): Buffer => Buffer.from(v.buffer, v.byteOffset, v.byteLength)

// ---------------------------------------------------------------- short term

/**
 * Compact short-term memory: the last `window` entries stay verbatim; older
 * ones fold into one-line digests (deterministic — never a fabricated summary).
 */
export class ShortTermMemory {
  private entries: Array<{ label: string; digest: string }> = []
  private folded: string[] = []
  constructor(private readonly window = 8) {}

  push(label: string, digest: string): void {
    this.entries.push({ label, digest: digest.replace(/\s+/g, ' ').slice(0, 160) })
    if (this.entries.length > this.window) {
      const dropped = this.entries.shift()!
      this.folded.push(`${dropped.label}: ${dropped.digest.slice(0, 80)}`)
    }
  }

  /** Rendered context for the planner/recovery prompts. */
  render(): string {
    if (this.entries.length === 0 && this.folded.length === 0) return '(لا سابق — هذه بداية المهمة)'
    const head = this.folded.length ? `# ملخص مضغوط لما سبق\n${this.folded.map((f) => `- ${f}`).join('\n')}\n` : ''
    const tail = this.entries.length
      ? `# آخر ما جرى (بالترتيب)\n${this.entries.map((e) => `- ${e.label}: ${e.digest}`).join('\n')}`
      : ''
    return head + tail
  }

  get size(): number {
    return this.folded.length + this.entries.length
  }
}

// ------------------------------------------------------------------- vector

export interface MemoryHit {
  id: number
  kind: string
  title: string
  content: string
  source: string | null
  distance: number
}

export interface UserMemoryRow {
  id: number
  kind: string
  title: string
  content: string
  source: string | null
  created_at: string
  updated_at: string
}

export class VectorMemory {
  readonly mode: 'sqlite-vec' | 'js-cosine'
  private readonly vecTable = 'agent_vec_embeddings'

  constructor(
    private readonly db: DB,
    private readonly embed: (text: string) => Float32Array = localEmbed,
  ) {
    let mode: 'sqlite-vec' | 'js-cosine' = 'js-cosine'
    try {
      // sqlite-vec is a runtime dependency; if the loadable isn't available on
      // this host we degrade to JS cosine and say so via `mode`.
      const nodeRequire = createRequire(import.meta.url)
      const sqliteVec = nodeRequire('sqlite-vec') as { load(db: unknown): void }
      sqliteVec.load(db)
      db.exec(`CREATE VIRTUAL TABLE IF NOT EXISTS ${this.vecTable} USING vec0(embedding float[${EMBED_DIM}])`)
      mode = 'sqlite-vec'
    } catch {
      mode = 'js-cosine'
    }
    this.mode = mode
  }

  /** Insert (or replace) a memory and its embedding. Returns the memory id. */
  upsert(e: { kind: 'note' | 'episode'; title: string; content: string; source?: string | null; id?: number }): number {
    const vec = f32buf(this.embed(`${e.title}\n${e.content}`))
    if (e.id !== undefined) {
      db_run(this.db, 'UPDATE agent_memories SET title = ?, content = ?, source = ?, updated_at = ? WHERE id = ?', [
        e.title,
        e.content,
        e.source ?? null,
        new Date().toISOString(),
        e.id,
      ])
      if (this.mode === 'sqlite-vec') {
        db_run(this.db, `DELETE FROM ${this.vecTable} WHERE rowid = ?`, [e.id])
        // vec0 (v0.1.9) rejects a plain bound ? for its integer primary key —
        // CAST(? AS INTEGER) binds correctly.
        db_run(this.db, `INSERT INTO ${this.vecTable} (rowid, embedding) VALUES (CAST(? AS INTEGER), ?)`, [e.id, vec])
      }
      return e.id
    }
    const info = db_run(
      this.db,
      "INSERT INTO agent_memories (kind, title, content, source) VALUES (?, ?, ?, ?)",
      [e.kind, e.title, e.content, e.source ?? null],
    )
    const id = Number(info.lastInsertRowid)
    if (this.mode === 'sqlite-vec') {
      db_run(this.db, `INSERT INTO ${this.vecTable} (rowid, embedding) VALUES (CAST(? AS INTEGER), ?)`, [id, vec])
    }
    return id
  }

  remove(id: number): boolean {
    if (this.mode === 'sqlite-vec') db_run(this.db, `DELETE FROM ${this.vecTable} WHERE rowid = ?`, [id])
    const info = db_run(this.db, 'DELETE FROM agent_memories WHERE id = ?', [id])
    return info.changes > 0
  }

  search(query: string, k = 5): MemoryHit[] {
    const q = this.embed(query)
    if (this.mode === 'sqlite-vec') {
      return this.db
        .prepare(
          `SELECT m.id, m.kind, m.title, m.content, m.source, v.distance AS distance
           FROM ${this.vecTable} v JOIN agent_memories m ON m.id = v.rowid
           WHERE v.embedding MATCH ? AND k = ?
           ORDER BY v.distance`,
        )
        .all(f32buf(q), k) as MemoryHit[]
    }
    // JS cosine fallback — same math, honest scale (personal memory counts)
    const rows = this.db.prepare('SELECT id, kind, title, content, source FROM agent_memories').all() as Array<Omit<MemoryHit, 'distance'>>
    const scored = rows.map((r) => {
      const v = this.embed(`${r.title}\n${r.content}`)
      let dot = 0
      for (let i = 0; i < EMBED_DIM; i++) dot += v[i]! * q[i]!
      return { ...r, distance: 1 - dot } // cosine distance
    })
    scored.sort((a, b) => a.distance - b.distance)
    return scored.slice(0, k)
  }

  // ------------------------------------------------------------ user memory

  listUser(): UserMemoryRow[] {
    return this.db
      .prepare("SELECT * FROM agent_memories WHERE kind = 'note' ORDER BY id DESC")
      .all() as UserMemoryRow[]
  }

  getUser(id: number): UserMemoryRow | undefined {
    return this.db.prepare("SELECT * FROM agent_memories WHERE id = ? AND kind = 'note'").get(id) as
      | UserMemoryRow
      | undefined
  }

  updateUser(id: number, patch: { title?: string; content?: string }): UserMemoryRow | undefined {
    const cur = this.getUser(id)
    if (!cur) return undefined
    this.upsert({ kind: 'note', title: patch.title ?? cur.title, content: patch.content ?? cur.content, source: cur.source, id })
    return this.getUser(id)
  }

  deleteUser(id: number): boolean {
    const cur = this.getUser(id)
    if (!cur) return false
    return this.remove(id)
  }
}

/** small helper so `require` stays in one place and run-info typing is shared */
function db_run(db: DB, sql: string, params: unknown[] = []): { changes: number; lastInsertRowid: number | bigint } {
  return db.prepare(sql).run(...params)
}
