import { randomBytes } from 'node:crypto'
import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import { keyAliasFor } from '../providers/registry.js'
import type { Logger } from '../logger.js'
import type { ChatMessage } from '../providers/types.js'
import type { ModelFn } from '../agent/types.js'
import { extractJson } from '../agent/model.js'
import { getProfile, applyProfilePatch, ACCENT_IDS, THEME_MODES, type AppProfile } from './profile.js'
import { listCatalogModels } from '../db/catalog.js'
import { createApiKey } from '../db/api_keys.js'
import { API_KEY_PREFIX, hashApiKey } from '../auth/guard.js'
import { currentMap, createChange, startChange, readAutonomyLevel, readEngineeringModel, resolveForgeModel, forgeDepsFor, changeForChat, decideChange, rollbackChange, cancelChange, listChanges } from '../forge/orchestrator.js'
import { listProposals, persistProposals, proposeFromMap } from '../forge/evolution.js'
import { AUTONOMY_LEVELS } from '../forge/types.js'
import { discoverSkills } from '../skills/discovery.js'
import { startSkillImport } from '../skills/pipeline.js'
import { startAgentTask } from '../agent/start.js'
import type { VectorMemory } from '../agent/memory.js'
import { createProject, listProjects, writeProjectFile } from '../projects/store.js'
import { inspectFrontend, readSourceFile, searchSource } from './universal.js'

/**
 * The Black Box BRAIN (توجيه المالك 2026-11-01) — the box is a REAL chatbot:
 * an actual model conversation with REAL tools that modify LIMO itself
 * (rename, tagline, language, default model, autonomy level, access links,
 * theme + accent colors, new features = skills through the ALLIMNI pipeline)
 * and read the live system state (Forge status, changes, models).
 *
 * Honesty invariants (same family as the rest of LIMO):
 *  - a tool call is executed ONLY when the model emits a JSON object whose
 *    "tool" matches a real registered tool — otherwise the text is a reply.
 *  - every executed tool lands in the append-only box_modifications audit
 *    (or is read-only) and in the message's actions list the UI shows.
 *  - model/provider failures surface as honest errors, never fake replies.
 *  - the box NEVER invents capabilities: the tool list IS its whole power.
 *  - "adding a new feature" is REAL and bounded: it installs a skill — a
 *    capability HYPERBRAIN genuinely gains — through the same ALLIMNI
 *    inspection + owner-approval + risk-gate pipeline as the UI (the box can
 *    REQUEST, only the owner APPROVES; it never writes code into the app).
 */

export interface BoxDeps {
  db: DB
  config: ServerConfig
  registry: ProviderRegistry
  vault: Vault
  log: Logger
  modelFn: ModelFn
  model: string
  /** shared vector memory — the same instance the agent engine uses */
  memory?: VectorMemory
}

export interface BoxAction {
  tool: string
  args: Record<string, unknown>
  ok: boolean
  result: unknown
}

export interface BoxChatResult {
  reply: string
  actions: BoxAction[]
  profile: AppProfile
  /** LIMO #23 — true only when the owner pressed STOP mid-turn; a stopped
   *  turn persists NO box reply (a half-thought is never sold as an answer). */
  stopped?: boolean
}

// ------------------------------------------------------------- usable models

export interface UsableModel {
  /** prefixed id: provider/model */
  id: string
  provider: string
  free: boolean
  contextLength: number | null
}

/**
 * Models the system can actually call RIGHT NOW: the provider adapter exists
 * and either needs no key (Ollama / custom endpoints) or its key is in the
 * unlocked vault. Model ids come from the daily catalog aggregate PLUS the
 * registry's live cached list — so a fresh install (empty catalog) still sees
 * its local Ollama models, and an unreachable provider keeps its stale rows.
 */
export async function usableModels(db: DB, registry: ProviderRegistry, vault: Vault, config: ServerConfig): Promise<UsableModel[]> {
  const out: UsableModel[] = []
  const seen = new Set<string>()
  const catalogRows = listCatalogModels(db)
  for (const adapter of registry.list()) {
    const usable = !adapter.needsKey || (vault.isUnlocked && vault.hasSecret(keyAliasFor(adapter.id)))
    if (!usable) continue
    for (const r of catalogRows) {
      if (r.provider !== adapter.id) continue
      const id = `${r.provider}/${r.model_id}`
      if (!seen.has(id)) {
        seen.add(id)
        out.push({ id, provider: r.provider, free: r.free === 1, contextLength: r.context_length })
      }
    }
    try {
      const live = await registry.listModels(adapter.id, config, db)
      for (const m of live) {
        const id = `${adapter.id}/${m.id}`
        if (!seen.has(id)) {
          seen.add(id)
          out.push({ id, provider: adapter.id, free: m.free === true, contextLength: m.contextLength ?? null })
        }
      }
    } catch {
      /* provider unreachable right now — its catalog rows (if any) stand */
    }
  }
  return out
}

// ------------------------------------------------------------------ autonomy

// NOTE: same key as routes/forge.ts (the single writer invariant holds — this
// module only runs inside authenticated box routes, i.e. owner decisions).
const AUTONOMY_KEY = 'forge_autonomy_level'

function getAutonomy(db: DB): number {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(AUTONOMY_KEY) as { value: string } | undefined
  const n = row ? Number(row.value) : 0
  return Number.isInteger(n) && n >= 0 && n <= 4 ? n : 0
}

function setAutonomy(db: DB, level: number): void {
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(AUTONOMY_KEY, String(level))
}

// ---------------------------------------------------------------- the tools

interface BoxTool {
  name: string
  /** mutated = lands in the audit trail; read-only tools do not */
  mutates: boolean
  description: string
  argsHint: string
  run(ctx: BoxDeps & { origin: string }, args: Record<string, unknown>): Promise<{ ok: boolean; error?: string; data?: unknown }>
}

export const TOOLS: BoxTool[] = [
  {
    name: 'get_system_status',
    mutates: false,
    description: 'قراءة الحالة الحية الكاملة: هوية التطبيق، حالة الخزنة والمزودين، مستوى الاستقلالية، حالة محرك Reality Forge، وآخر التغييرات.',
    argsHint: '{}',
    run: async (ctx) => ({
      ok: true,
      data: {
        profile: getProfile(ctx.db),
        vault: ctx.vault.isUnlocked ? 'unlocked' : 'locked',
        providers: ctx.registry.list().map((a) => ({ id: a.id, needsKey: a.needsKey })),
        usableModels: (await usableModels(ctx.db, ctx.registry, ctx.vault, ctx.config)).length,
        autonomyLevel: getAutonomy(ctx.db),
        forge: { repo: ctx.config.forgeRepoRoot ? ctx.config.forgeRepoRoot.split('/').pop() ?? null : null },
        sourceReads: { enabled: !!ctx.config.sourceRoot, note: 'قراءة/بحث/تصفح المصدر تعمل حتى بلا مستودع git (التعديل يتطلب git)' },
        link: ctx.origin,
      },
    }),
  },
  {
    name: 'set_app_name',
    mutates: true,
    description: 'تغيير اسم التطبيق (ينعكس فورًا في الواجهة). بين حرفين و40 حرفًا.',
    argsHint: '{"name": "الاسم الجديد"}',
    run: async (ctx, args) => {
      const res = applyProfilePatch(ctx.db, { name: args.name })
      if (!res.ok) return res
      return { ok: true, data: { name: getProfile(ctx.db).name, note: 'انعكس الاسم في الواجهة', link: ctx.origin } }
    },
  },
  {
    name: 'set_tagline',
    mutates: true,
    description: 'تغيير شعار التطبيق (السطر التعريفي القصير). بين حرفين و80 حرفًا.',
    argsHint: '{"tagline": "الشعار الجديد"}',
    run: async (ctx, args) => {
      const res = applyProfilePatch(ctx.db, { tagline: args.tagline })
      if (!res.ok) return res
      return { ok: true, data: { tagline: getProfile(ctx.db).tagline } }
    },
  },
  {
    name: 'set_language',
    mutates: true,
    description: 'ضبط لغة الواجهة الافتراضية للزوار الجدد.',
    argsHint: '{"lang": "ar"} أو {"lang": "en"}',
    run: async (ctx, args) => {
      const res = applyProfilePatch(ctx.db, { language: (args.lang ?? args.language) as string })
      if (!res.ok) return res
      return { ok: true, data: { language: getProfile(ctx.db).language } }
    },
  },
  {
    name: 'set_default_model',
    mutates: true,
    description: 'ضبط النموذج الافتراضي للتطبيق (يستخدمه الصندوق الأسود كافتراضي). الصيغة provider/model.',
    argsHint: '{"model": "groq/llama-3.3-70b-versatile"}',
    run: async (ctx, args) => {
      const model = typeof args.model === 'string' ? args.model.trim() : ''
      try {
        ctx.registry.resolveModel(model) // fail fast on unknown provider/model
      } catch {
        return { ok: false, error: `نموذج غير معروف: ${model}` }
      }
      const res = applyProfilePatch(ctx.db, { defaultModel: model })
      if (!res.ok) return res
      return { ok: true, data: { defaultModel: model } }
    },
  },
  {
    name: 'set_autonomy_level',
    mutates: true,
    description: 'ضبط مستوى استقلالية Reality Forge (قرار مالك): 0=تحليل فقط … 4=تطبيق منخفض الخطر بعد السياسة.',
    argsHint: '{"level": 2}',
    run: async (ctx, args) => {
      const level = Number(args.level)
      if (!Number.isInteger(level) || level < 0 || level > 4) return { ok: false, error: 'المستوى يجب أن يكون عددًا صحيحًا من 0 إلى 4' }
      setAutonomy(ctx.db, level)
      return { ok: true, data: { level, label: AUTONOMY_LEVELS[level]?.ar ?? `L${level}` } }
    },
  },
  {
    name: 'list_models',
    mutates: false,
    description: 'قائمة النماذج القابلة للاستخدام فعلًا الآن (مزود متاح + مفتاح موجود أو لا يحتاج مفتاحًا).',
    argsHint: '{}',
    run: async (ctx) => ({
      ok: true,
      data: (await usableModels(ctx.db, ctx.registry, ctx.vault, ctx.config)).map((m) => ({ id: m.id, free: m.free, contextLength: m.contextLength })),
    }),
  },
  {
    name: 'create_access_link',
    mutates: true,
    description: 'إنشاء رابط وصول جديد لل تطبيق: مفتاح API جديد (يظهر مرة واحدة) مع عنوان التطبيق — للبرمجة عبر بوابة متوافقة مع OpenAI.',
    argsHint: '{"name": "جهازي"}',
    run: async (ctx, args) => {
      const name = typeof args.name === 'string' && args.name.trim() ? args.name.trim().slice(0, 64) : `box-${new Date().toISOString().slice(0, 10)}`
      const raw = `${API_KEY_PREFIX}${randomBytes(24).toString('hex')}`
      const row = createApiKey(ctx.db, name, raw.slice(0, 12), hashApiKey(raw))
      return { ok: true, data: { id: row.id, name, link: ctx.origin, apiBase: `${ctx.origin}/v1`, key: raw, note: 'احفظ المفتاح الآن — لن يظهر مجددًا' } }
    },
  },
  {
    name: 'set_theme_mode',
    mutates: true,
    description: 'ضبط ثيم الواجهة الذي يثبّته المالك: system (كل جهاز يتبع إعداده) أو light أو dark — ينعكس فورًا.',
    argsHint: '{"mode": "dark"}',
    run: async (ctx, args) => {
      const res = applyProfilePatch(ctx.db, { themeMode: args.mode ?? args.theme })
      if (!res.ok) return res
      return { ok: true, data: { themeMode: getProfile(ctx.db).themeMode, note: 'انعكس الثيم في الواجهة فورًا' } }
    },
  },
  {
    name: 'set_accent',
    mutates: true,
    description: `تغيير لون التمييز للواجهة كلها (يتّسع للأزرار والروابط والتركيز). الألوان المتاحة: ${ACCENT_IDS.join(' / ')} — mono هو الأحادي الافتراضي.`,
    argsHint: '{"accent": "forest"}',
    run: async (ctx, args) => {
      const res = applyProfilePatch(ctx.db, { accent: args.accent ?? args.color })
      if (!res.ok) return res
      return { ok: true, data: { accent: getProfile(ctx.db).accent, note: 'انعكس اللون في الواجهة فورًا' } }
    },
  },
  {
    name: 'search_skills',
    mutates: false,
    description: 'البحث عن مهارات جديدة (قدرات حقيقية للوكيل) في فهرس skills.sh العام — نفس المصدر الذي يستخدمه الـCLI الرسمي.',
    argsHint: '{"query": "react"}',
    run: async (ctx, args) => {
      const q = typeof (args.query ?? args.q) === 'string' ? String(args.query ?? args.q).trim() : ''
      if (q.length < 1) return { ok: false, error: 'اكتب كلمة بحث' }
      const r = await discoverSkills(ctx.db, q, { limit: 8 })
      return {
        ok: true,
        data: {
          originalQuery: r.originalQuery,
          effectiveQuery: r.effectiveQuery,
          providers: r.providers.map((p) => ({ provider: p.provider, unavailable: p.unavailable, reason: p.reason ?? null, count: p.skills.length })),
          skills: r.skills.slice(0, 12).map((s) => ({ id: s.id, source: s.source, name: s.name, installs: s.installs, sourceUrl: s.sourceUrl })),
        },
      }
    },
  },
  {
    name: 'list_installed_skills',
    mutates: false,
    description: 'قائمة المهارات المثبتة فعلًا (قدرات ليمو الحالية) وحالتها.',
    argsHint: '{}',
    run: async (ctx) => ({
      ok: true,
      data: {
        skills: (ctx.db.prepare('SELECT slug, name, status, risk_level FROM skills ORDER BY installed_at DESC LIMIT 30').all() as Array<{ slug: string; name: string; status: string; risk_level: string | null }>).map((s) => ({ slug: s.slug, name: s.name, status: s.status, risk: s.risk_level })),
      },
    }),
  },
  {
    name: 'request_skill_install',
    mutates: true,
    description: 'إضافة ميزة حقيقية للوكيل: يبدأ تثبيت مهارة من مستودع GitHub عبر فحص عَلِّمني الأمني الكامل. المالك يوافق لاحقًا في شاشة عَلِّمني — HIGH/CRITICAL ممنوعة حتى مع الموافقة. الصيغة owner/repo.',
    argsHint: '{"source": "owner/repo", "skillId": "skill-name"}',
    run: async (ctx, args) => {
      const source = typeof args.source === 'string' ? args.source.trim() : ''
      const skillId = typeof args.skillId === 'string' ? args.skillId.trim() : undefined
      if (!source) return { ok: false, error: 'حدد المصدر بصيغة owner/repo' }
      const started = await startSkillImport(ctx.db, { source, skillId })
      if (started.kind === 'not_supported') {
        return { ok: false, error: started.reason }
      }
      if (started.kind === 'inspection_failed') {
        // LIMO #20: when the repo is multi-skill, name the available skill ids so
        // the next attempt carries skillId instead of repeating the same failure.
        const roots = started.report.skillRoots.filter((r) => r.name || r.dir).map((r) => r.name ?? r.dir)
        const hint = roots.length > 1 ? ` المستودع متعدد المهارات — أعد المحاولة بتمرير skillId لأحدها: ${roots.slice(0, 8).join(' · ')}` : ''
        return { ok: false, error: `مانعات الفحص: ${started.blockers.join(' · ')}${hint}`, data: { importId: started.importId, status: 'rejected', availableSkills: roots.length > 1 ? roots.slice(0, 8) : undefined } }
      }
      return {
        ok: true,
        data: {
          importId: started.importId,
          status: 'awaiting_approval',
          skill: started.report.frontmatter?.name ?? skillId ?? source,
          risk: started.security.riskLevel,
          compatibility: started.compatibility.state,
          note: 'بانتظار قرار المالك في شاشة عَلِّمني ← الاستيراد — لا تثبيت بلا موافقة صريحة',
        },
      }
    },
  },
  // -------------------------------------------------------------- deployment
  // LIMO DEPLOYMENT COMMAND CENTER (#20, directive §11–12): real Vercel
  // deploys through the owner's vault-held token. PREVIEW + reads live here;
  // PRODUCTION promote/rollback are the OWNER's buttons in the System Map and
  // are deliberately NOT exposed to the model (§12 + #12 doctrine).

  {
    name: 'deploy_state',
    mutates: false,
    description: 'حالة مركز النشر: هل رمز Vercel مُخزَّن في الخزنة (بدون كشفه)؟ ما المشروع؟ ما آخر النشرات الحقيقية من واجهة Vercel الرسمية؟',
    argsHint: '{}',
    run: async (ctx) => {
      const token = ctx.vault.getSecret('vercel')
      const row = ctx.db.prepare('SELECT value FROM settings WHERE key = ?').get('vercel_project') as { value: string } | undefined
      const project = (row?.value ?? '').trim() || 'limo-agent'
      if (!token) return { ok: true, data: { configured: false, project, note: 'اطلب من المالك لصق رمز Vercel في شاشة خريطة النظام — لا تقبل رمزًا في الدردشة أبدًا' } }
      const { vercelUser, vercelEnsureProject, vercelDeployments } = await import('../deploy/vercel.js')
      try {
        const user = await vercelUser(token)
        const ensured = await vercelEnsureProject(token, project)
        const rows = await vercelDeployments(token, ensured.id, 5)
        return { ok: true, data: { configured: true, account: user.username, project: ensured.name, deployments: rows } }
      } catch (e) {
        return { ok: false, error: e instanceof Error ? e.message.slice(0, 200) : 'خطأ Vercel' }
      }
    },
  },
  {
    name: 'deploy_preview',
    mutates: true,
    description: 'انشر نسخة المعاينة الحقيقية على Vercel: يرفع بناء الواجهة الثابت الفعلي (ملفات out/ كما هي) كمعاينة، ويسجل النشرة في الدفتر. يتطلب رمزًا مخزَّنًا وبناءً موجودًا. النشر للإنتاج قرار المالك وحده من خريطة النظام — لا يمكنك فعله من هنا.',
    argsHint: '{}',
    run: async (ctx) => {
      const token = ctx.vault.getSecret('vercel')
      if (!token) return { ok: false, error: 'لا يوجد رمز Vercel في الخزنة — المالك يضيفه من شاشة خريطة النظام' }
      if (!ctx.config.webDist) return { ok: false, error: 'لا يوجد WEB_DIST مضبوط — لا بناء ثابت للرفع' }
      const { vercelUser, vercelEnsureProject, vercelDeployFiles } = await import('../deploy/vercel.js')
      const { collectArtifact } = await import('../deploy/artifact.js')
      try {
        const user = await vercelUser(token)
        const row = ctx.db.prepare('SELECT value FROM settings WHERE key = ?').get('vercel_project') as { value: string } | undefined
        const project = (row?.value ?? '').trim() || 'limo-agent'
        const ensured = await vercelEnsureProject(token, project)
        const artifact = collectArtifact(ctx.config.webDist)
        const ref = await vercelDeployFiles({ token, projectName: ensured.name, files: artifact.files, target: 'preview' })
        ctx.db.prepare(
          'INSERT INTO deployments (deployment_id, project, url, target, state, file_count, total_bytes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        ).run(ref.id, ensured.name, ref.url, 'preview', ref.readyState, artifact.fileCount, artifact.totalBytes, new Date().toISOString())
        return {
          ok: true,
          data: {
            deploymentId: ref.id,
            readyState: ref.readyState,
            url: ref.url,
            uploadedFiles: artifact.fileCount,
            uploadedKB: Math.round(artifact.totalBytes / 1024),
            account: user.username,
            note: 'استعلم deploy_status حتى تصبح READY — لا تعلن نجاحًا قبل إجابة Vercel',
          },
        }
      } catch (e) {
        return { ok: false, error: e instanceof Error ? e.message.slice(0, 240) : 'خطأ غير متوقع' }
      }
    },
  },
  {
    name: 'deploy_status',
    mutates: false,
    description: 'الحالة الحقيقية لنشرة Vercel من الواجهة الرسمية: readyState كما أجابت Vercel — لا تخمين ولا افتراض نجاح.',
    argsHint: '{"id": "dpl_xxx"}',
    run: async (ctx, args) => {
      const token = ctx.vault.getSecret('vercel')
      if (!token) return { ok: false, error: 'لا يوجد رمز Vercel في الخزنة' }
      let id = typeof args.id === 'string' ? args.id.trim() : ''
      if (!id) {
        const last = ctx.db.prepare("SELECT deployment_id FROM deployments WHERE target = 'preview' ORDER BY id DESC LIMIT 1").get() as { deployment_id: string } | undefined
        if (!last) return { ok: false, error: 'لا نشرة سابقة — مرّر id أو انشر أولًا' }
        id = last.deployment_id
      }
      const { vercelDeployment } = await import('../deploy/vercel.js')
      try {
        const state = await vercelDeployment(token, id)
        ctx.db.prepare('UPDATE deployments SET state = ?, url = COALESCE(?, url), updated_at = ? WHERE deployment_id = ?').run(
          state.readyState, state.url, new Date().toISOString(), id,
        )
        return { ok: true, data: state }
      } catch (e) {
        return { ok: false, error: e instanceof Error ? e.message.slice(0, 200) : 'خطأ Vercel' }
      }
    },
  },
  {
    name: 'deploy_logs',
    mutates: false,
    description: 'سجل البناء الحقيقي لنشرة من حدث Vercel الرسمي — لما يفشل شيء اقرأ الفشل كما هو ولا تختلق رسالة نجاح.',
    argsHint: '{"id": "dpl_xxx", "lines": 40}',
    run: async (ctx, args) => {
      const token = ctx.vault.getSecret('vercel')
      if (!token) return { ok: false, error: 'لا يوجد رمز Vercel في الخزنة' }
      const id = typeof args.id === 'string' ? args.id.trim() : ''
      if (!id) return { ok: false, error: 'مرّر id النشرة (deploy_status يعيده)' }
      const { vercelDeploymentLogs } = await import('../deploy/vercel.js')
      try {
        const lines = await vercelDeploymentLogs(token, id, 120)
        const n = typeof args.lines === 'number' && args.lines > 0 ? Math.min(args.lines, 120) : 40
        return { ok: true, data: { deploymentId: id, returned: lines.slice(0, n) } }
      } catch (e) {
        return { ok: false, error: e instanceof Error ? e.message.slice(0, 200) : 'خطأ Vercel' }
      }
    },
  },
  {
    name: 'deploy_verify',
    mutates: false,
    description: 'تحقق حقيقي من محتوى نشرة READY: يجلب العنوان ويصنّف ما أجاب فعلًا — واجهة LIMO، أم جدار حماية Vercel، أم شيء آخر. لا إعلان نجاح قبل هذا الفحص.',
    argsHint: '{"id": "dpl_xxx"}',
    run: async (ctx, args) => {
      const token = ctx.vault.getSecret('vercel')
      if (!token) return { ok: false, error: 'لا يوجد رمز Vercel في الخزنة' }
      const id = typeof args.id === 'string' ? args.id.trim() : ''
      if (!id) return { ok: false, error: 'مرّر id النشرة' }
      const { vercelDeployment } = await import('../deploy/vercel.js')
      try {
        const state = await vercelDeployment(token, id)
        if (state.readyState !== 'READY') return { ok: false, error: `النشرة ليست READY (${state.readyState}) — لا يُفحص ما لم يجهز` }
        if (!state.url) return { ok: false, error: 'Vercel لم يعِد عنوانًا' }
        const full = `https://${state.url}`
        const res = await fetch(full, { headers: { 'user-agent': 'limo-deployment-verify/1.0' }, signal: AbortSignal.timeout(20_000) })
        const body = (await res.text()).slice(0, 200_000)
        const served = /Protected by Vercel Authentication/i.test(body) ? 'vercel-wall' : /<div id="root">|limo/i.test(body) ? 'limo-ui' : 'other'
        return { ok: true, data: { url: full, httpStatus: res.status, bytes: body.length, served } }
      } catch (e) {
        return { ok: false, error: e instanceof Error ? e.message.slice(0, 200) : 'فشل الجلب' }
      }
    },
  },
  {
    name: 'launch_agent_task',
    mutates: true,
    description: 'القدرة العالمية: أطلق مهمة وكيل HYPERBRAIN حقيقية متعددة الخطوات لأي طلب هندسي أكبر من أدواتك المباشرة (بحث/بناء/تحليل/إبداع/الحاسوب الخارق). النموذج الافتراضي auto — التوجيه التلقائي يختار لكل غرض. المهمة تعمل في الخلفية وتراقبها بـ get_agent_task.',
    argsHint: '{"goal": "هدف المهمة", "mode": "auto|research|build|creative|super", "model": "auto", "projectId": null}',
    run: async (ctx, args) => {
      if (!ctx.memory) return { ok: false, error: 'خدمة الذاكرة غير مهيأة لهذه الجلسة — لا إطلاق مهام بصدق' }
      const started = await startAgentTask(
        { db: ctx.db, config: ctx.config, registry: ctx.registry, vault: ctx.vault, log: ctx.log, memory: ctx.memory },
        {
          goal: typeof args.goal === 'string' ? args.goal : '',
          model: typeof args.model === 'string' && args.model.trim() ? args.model.trim() : 'auto',
          mode: (typeof args.mode === 'string' ? args.mode : 'auto') as 'auto' | 'research' | 'build' | 'creative' | 'super',
          projectId: typeof args.projectId === 'string' ? args.projectId : null,
          source: 'box',
        },
      )
      if (!started.ok) return { ok: false, error: started.error }
      return { ok: true, data: { taskId: started.id, status: 'queued', note: 'المهمة تعمل فعليًا في محرك الوكيل الآن — راقبها بـ get_agent_task أو في مساحة الوكيل' } }
    },
  },
  {
    name: 'get_agent_task',
    mutates: false,
    description: 'قراءة حالة حية لمهمة وكيل: الحالة، الخطوات، آخر الأحداث (من قاعدة البيانات الحقيقية).',
    argsHint: '{"id": 12}',
    run: async (ctx, args) => {
      const id = Number(args.id)
      if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'حدد رقم المهمة (عدد صحيح)' }
      const task = ctx.db.prepare('SELECT id, goal, model, mode, status, source, created_at FROM agent_tasks WHERE id = ?').get(id) as Record<string, unknown> | undefined
      if (!task) return { ok: false, error: `لا توجد مهمة برقم ${id}` }
      const steps = ctx.db.prepare('SELECT idx, title, role, status, tool FROM agent_steps WHERE task_id = ? ORDER BY idx').all(id)
      const events = (ctx.db.prepare('SELECT kind, data, ts FROM agent_events WHERE task_id = ? ORDER BY id DESC LIMIT 8').all(id) as Array<{ kind: string; data: string | null; ts: string }>).map((e) => ({ kind: e.kind, ts: e.ts, data: e.data ? JSON.parse(e.data) : null }))
      return { ok: true, data: { task, steps, recentEvents: events } }
    },
  },
  {
    name: 'list_recent_tasks',
    mutates: false,
    description: 'آخر 8 مهام وكيل بحالتها ومصدرها (user = من الواجهة، box = من هذا الصندوق).',
    argsHint: '{}',
    run: async (ctx) => ({
      ok: true,
      data: {
        tasks: ctx.db.prepare('SELECT id, goal, model, mode, status, source, created_at FROM agent_tasks ORDER BY id DESC LIMIT 8').all(),
      },
    }),
  },
  {
    name: 'list_projects',
    mutates: false,
    description: 'مساحات المشاريع الحقيقية (مساحات العمل المعزولة للوكيل).',
    argsHint: '{}',
    run: async (ctx) => ({
      ok: true,
      data: {
        projects: listProjects(ctx.db).slice(0, 12).map((p) => ({ id: p.id, name: p.name, kind: p.kind, status: p.status })),
      },
    }),
  },
  {
    name: 'create_project',
    mutates: true,
    description: 'إنشاء مساحة مشروع معزولة حقيقية (web_app/notes) تعمل فيها مهام الوكيل — تُنشأ فعليًا على القرص وفي القاعدة.',
    argsHint: '{"name": "اسم المشروع", "kind": "web_app", "description": "وصف"}',
    run: async (ctx, args) => {
      const name = typeof args.name === 'string' ? args.name.trim() : ''
      if (name.length < 2) return { ok: false, error: 'اسم المشروع قصير جدًا' }
      const kind = typeof args.kind === 'string' && args.kind ? args.kind : 'web_app'
      const project = createProject(ctx.db, ctx.config, { name, kind, description: typeof args.description === 'string' ? args.description : undefined })
      return { ok: true, data: { id: project.id, name: project.name, kind: project.kind } }
    },
  },
  {
    name: 'write_project_file',
    mutates: true,
    description: 'كتابة/تحديث ملف حقيقي داخل مساحة مشروع معزولة (ليس كود ليمو نفسه — لتعديل كود ليمو مسار Reality Forge بموافقة المالك).',
    argsHint: '{"projectId": "abc123", "path": "index.html", "content": "<h1>…</h1>"}',
    run: async (ctx, args) => {
      const projectId = typeof args.projectId === 'string' ? args.projectId : ''
      const path = typeof args.path === 'string' ? args.path.trim() : ''
      const content = typeof args.content === 'string' ? args.content : ''
      if (!projectId || !path) return { ok: false, error: 'حدد projectId ومسار الملف' }
      if (!content) return { ok: false, error: 'المحتوى فارغ — ارفض الكتابة الفارغة' }
      const written = writeProjectFile(ctx.config, projectId, path, content)
      return { ok: true, data: written }
    },
  },
  {
    name: 'memory_write',
    mutates: true,
    description: 'حفظ ملاحظة/خلاصة في ذاكرة ليمو المتجهة (الذاكرة نفسها التي يستخدمها الوكيل).',
    argsHint: '{"title": "عنوان", "content": "النص"}',
    run: async (ctx, args) => {
      if (!ctx.memory) return { ok: false, error: 'خدمة الذاكرة غير مهيأة — لا حفظ بصدق' }
      const title = typeof args.title === 'string' ? args.title.trim().slice(0, 120) : ''
      const content = typeof args.content === 'string' ? args.content.trim() : ''
      if (title.length < 2 || content.length < 2) return { ok: false, error: 'العنوان والمحتوى مطلوبان (حرفان على الأقل)' }
      const id = ctx.memory.upsert({ kind: 'note', title, content, source: `box:${ctx.model}` })
      return { ok: true, data: { memoryId: id, title } }
    },
  },
  {
    name: 'memory_search',
    mutates: false,
    description: 'بحث دلالي في ذاكرة ليمو الحقيقية.',
    argsHint: '{"query": "ما أبحث عنه"}',
    run: async (ctx, args) => {
      if (!ctx.memory) return { ok: false, error: 'خدمة الذاكرة غير مهيأة — لا بحث بصدق' }
      const q = typeof (args.query ?? args.q) === 'string' ? String(args.query ?? args.q).trim() : ''
      if (q.length < 2) return { ok: false, error: 'اكتب كلمة بحث من حرفين على الأقل' }
      const hits = ctx.memory.search(q, 5)
      return { ok: true, data: { hits: hits.map((h) => ({ id: h.id, title: h.title, kind: h.kind, distance: Math.round(h.distance * 100) / 100 })) } }
    },
  },
  {
    name: 'inspect_frontend',
    mutates: false,
    description: 'أشعة الواجهة (SITE ARCHITECT — قراءة): جرد حقيقي لتطبيق الويب الفعلي — طبقاته، ملفاته، مناطق التنقل من lib/nav.ts، ورموز التصميم من نظام tokens — لا اختراع معماري.',
    argsHint: '{}',
    run: async (ctx) => {
      const inv = inspectFrontend(ctx.config)
      return { ok: true, data: inv }
    },
  },
  {
    name: 'read_source_file',
    mutates: false,
    description: 'قراءة ملف مصدر حقيقي من المستودع (نصي فقط، بحد حجم، ممنوع: الأسرار/البناء/التبعيات/خارج الجذر). للتفسير والاقتراح — التعديل يمرّ بـ Reality Forge وموافقة المالك.',
    argsHint: '{"path": "apps/web/src/lib/nav.ts"}',
    run: async (ctx, args) => {
      const res = readSourceFile(ctx.config, typeof args.path === 'string' ? args.path : '')
      if (!res.ok) return { ok: false, error: res.error }
      const content = res.content.length > 12000 ? `${res.content.slice(0, 12000)}\n… (مقتطع عند 12K للحفاظ على سياق المحادثة — الحجم الكامل ${res.bytes} بايت)` : res.content
      return { ok: true, data: { path: res.path, bytes: res.bytes, lines: res.lines, truncated: res.truncated || content.length < res.content.length, content } }
    },
  },
  {
    name: 'search_source',
    mutates: false,
    description: 'بحث حقيقي في شيفرة الواجهة والخادم (حدود صارمة: 900 ملف، 40 تطابقًا، الأسرار مستثناة) — لأثر التعديل وتتبع الاعتماديات.',
    argsHint: '{"query": "نمط البحث"}',
    run: async (ctx, args) => {
      const res = searchSource(ctx.config, typeof (args.query ?? args.q) === 'string' ? String(args.query ?? args.q) : '')
      if (!res.ok) return { ok: false, error: res.error }
      return { ok: true, data: res }
    },
  },
  {
    name: 'forge_overview',
    mutates: false,
    description: 'قراءة سجل تغييرات Reality Forge: آخر 10 تغييرات بحالتها ومستواها.',
    argsHint: '{}',
    run: async (ctx) => ({
      ok: true,
      data: {
        enabled: !!ctx.config.forgeRepoRoot,
        autonomyLevel: getAutonomy(ctx.db),
        changes: ctx.db
          .prepare('SELECT id, request, status, level, created_at FROM forge_changes ORDER BY id DESC LIMIT 10')
          .all(),
      },
    }),
  },
  {
    name: 'forge_scan',
    mutates: true,
    description: 'فحص حتمي لخريطة المعمارية يولّد اقتراحات تطوير حقيقية (لا ينفّذ شيئًا — الاقتراحات بيانات).',
    argsHint: '{}',
    run: async (ctx) => {
      if (!ctx.config.forgeRepoRoot) return { ok: false, error: 'Reality Forge معطّل — اضبط FORGE_REPO_ROOT' }
      const map = currentMap({ db: ctx.db, config: ctx.config, registry: ctx.registry, vault: ctx.vault, log: ctx.log, modelFn: null, model: null })
      if (!map) return { ok: false, error: 'Reality Forge معطّل — لم يُعثر على مستودع git' }
      const drafts = proposeFromMap(map)
      const n = persistProposals(ctx.db, drafts)
      return { ok: true, data: { generated: n, proposals: listProposals(ctx.db, 'proposed').slice(0, 10) } }
    },
  },
  {
    // LIMO #18 «الصدَفة الذاتية»: the box STARTS a real self-modification by
    // driving the SAME Reality Forge pipeline the owner drives from the Forge
    // screen — isolated worktree, allowlisted tests, static security review,
    // then the owner gate. The box never writes source directly.
    name: 'forge_create',
    mutates: true,
    description:
      'الصدَفة الذاتية: تبدأ تعديلًا حقيقيًا لكود ليمو نفسه من طلب المالك — يمر إلزاميًا عبر خط أنابيب Reality Forge (فحص ← خطة ورقعة ← فرع git معزول ← اختبارات ← مراجعة أمنية ← بوابة موافقة المالك). لا يُطبَّق شيء دون قرار المالك أو سياسة L4.',
    argsHint: '{"request": "وصف دقيق للتعديل المطلوب في كود ليمو"}',
    run: async (ctx, args) => {
      if (!ctx.config.forgeRepoRoot)
        return { ok: false, error: 'Reality Forge معطّل — لا مستودع git (على الجوال: pkg install git ثم git init داخل مجلد ليمو وأول commit)' }
      const request = typeof args.request === 'string' ? args.request.trim() : ''
      if (request.length < 8) return { ok: false, error: 'اوصف التعديل المطلوب بثمانية أحرف على الأقل' }
      const level = readAutonomyLevel(ctx.db)
      // LIMO #19: the owner-pinned engineering model wins — the change row
      // records the model that will ACTUALLY plan/engineer it (honest provenance)
      const model = resolveForgeModel(ctx.db, ctx.model)
      const id = createChange(ctx.db, request, model, level)
      // no pin override ⇒ reuse the conversation-proven modelFn as-is (#18:
      // the chat route already gated needsKey/vault before us); a pin that
      // differs must build its own deps — and the vault gate applies honestly
      const pinOverrode = model !== ctx.model
      startChange(
        !pinOverrode && ctx.modelFn
          ? { db: ctx.db, config: ctx.config, registry: ctx.registry, vault: ctx.vault, log: ctx.log, modelFn: ctx.modelFn, model: ctx.model }
          : forgeDepsFor({ db: ctx.db, config: ctx.config, registry: ctx.registry, vault: ctx.vault, log: ctx.log }, model),
        id,
        ctx.log,
      )
      return {
        ok: true,
        data: {
          id,
          status: 'analyzing',
          autonomyLevel: level,
          note:
            'انطلق خط الأنابيب الحقيقي. تابِع بـ forge_change_status حتى تصل «awaiting_approval»، ثم اعرض الخلاصة على المالك وقراره بكلمة «طبّق» أو «ارفض» ينفّذه forge_decide. التطبيق بقرار المالك فقط (أو سياسة L4).',
        },
      }
    },
  },
  {
    name: 'forge_change_status',
    mutates: false,
    description: 'قراءة حالة تغيير Reality Forge برقمه: الخطة، الملفات المتأثرة، مقتطف الفرق، نتيجة الاختبارات، المراجعة الأمنية، وسجل الأحداث — بلا مبالغة أو تجميل.',
    argsHint: '{"id": 5}',
    run: async (ctx, args) => {
      const id = Number(args.id)
      if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'معرّف التغيير مطلوب (رقم)' }
      const res = changeForChat(ctx.db, id)
      if (!res.ok) return { ok: false, error: res.error }
      return { ok: true, data: res.change }
    },
  },
  {
    name: 'forge_decide',
    mutates: true,
    description:
      'قرار المالك على تغيير وصل بوابة الموافقة أو وصل حالة «applied»: decision=«apply» للدمج، «reject» للرفض، «rollback» للتراجع عن تغيير مطبَّق (revert جديد، السجل يبقى)، «cancel» لإلغاء تغيير غير منتهٍ فيقف عند حده ولا يُستأنف. كلام المالك هنا هو البوابة البشرية نفسها.',
    argsHint: '{"id": 5, "decision": "apply"}',
    run: async (ctx, args) => {
      if (!ctx.config.forgeRepoRoot) return { ok: false, error: 'Reality Forge معطّل — لا مستودع git' }
      const id = Number(args.id)
      const decision = String(args.decision ?? '')
      if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'معرّف التغيير مطلوب (رقم)' }
      if (!['apply', 'reject', 'rollback', 'cancel'].includes(decision)) return { ok: false, error: 'القرار يجب أن يكون apply أو reject أو rollback أو cancel' }
      const deps = forgeDepsFor({ db: ctx.db, config: ctx.config, registry: ctx.registry, vault: ctx.vault, log: ctx.log }, null)
      const row = decision === 'rollback' ? await rollbackChange(deps, id) : decision === 'cancel' ? await cancelChange(deps, id) : await decideChange(deps, id, decision as 'apply' | 'reject')
      if (!('status' in row)) {
        const ar: Record<string, string> = {
          not_found: 'التغيير غير موجود',
          not_awaiting_approval: 'التغيير ليس في انتظار موافقة الآن — افحص حالته بـ forge_change_status',
          not_applied: 'لا تراجع إلا عن تغيير مطبَّق فعليًا',
          already_finished: 'التغيير منتهٍ بالفعل — لا إلغاء بعد الانتهاء',
          forge_disabled: 'Reality Forge معطّل',
          no_branch: 'لا يوجد فرع صندوق لهذا التغيير',
        }
        return { ok: false, error: ar[row.error] ?? row.error }
      }
      const view = changeForChat(ctx.db, id)
      return { ok: true, data: { decision, change: view.ok ? view.change : { id, status: row.status } } }
    },
  },
  {
    // LIMO #19 (directive §14) — CHANGE MEMORY: the owner's engineering
    // history is queryable from the chat: «ماذا غيّرت أمس؟», «أظهر كل ما مسّ
    // الواجهة», «ما الذي فشل؟» — answered from the real rows, never guessed.
    name: 'forge_history',
    mutates: false,
    description:
      'ذاكرة التغييرات (محرك التنفيذ المباشر): استعلم سجل تعديلات Reality Forge الحقيقية — بماذا طُلب ومتى وبأي حالة ونموذج والتزام. يدعم التصفية: status (مثل applied/failed/rejected/cancelled/awaiting_approval)، q (بحث نصي في الطلب)، since (تاريخ ISO مثل 2026-11-01)، limit.',
    argsHint: '{"q": "الواجهة", "status": "applied", "since": "2026-11-01", "limit": 10}',
    run: async (ctx, args) => {
      const opt = (v: unknown): string | undefined => (typeof v === 'string' && v.trim() ? v.trim() : undefined)
      const limit = Number(args.limit)
      const rows = listChanges(ctx.db, {
        status: opt(args.status),
        q: opt(args.q),
        since: opt(args.since),
        limit: Number.isFinite(limit) && limit > 0 ? limit : 15,
      })
      return {
        ok: true,
        data: {
          count: rows.length,
          changes: rows.map((r) => ({
            id: r.id,
            request: r.request.slice(0, 120),
            status: r.status,
            level: r.level,
            model: r.model,
            commit: r.commit_id,
            error: r.error ? r.error.slice(0, 160) : null,
            updatedAt: r.updated_at,
          })),
          note: 'هذا هو السجل الحقيقي من قاعدة البيانات — لا شيء مُتخيَّل. استئناف غير المنتهي بـ forge_resume، والتراجع عن المطبَّق بـ forge_decide بـ rollback.',
        },
      }
    },
  },
  {
    // LIMO #19 (directive §7/§14) — task recovery: continue the last
    // unfinished engineering task from where it honestly stopped.
    name: 'forge_resume',
    mutates: true,
    description:
      'استئناف تغيير Reality Forge غير المنتهي من حيث توقف («أكمل آخر مهمة هندسية غير المنتهية»). يرفض المنتهي (applied/rejected/rolled_back/cancelled/failed) بصدق — تابِع النتيجة بـ forge_change_status.',
    argsHint: '{"id": 7}',
    run: async (ctx, args) => {
      if (!ctx.config.forgeRepoRoot) return { ok: false, error: 'Reality Forge معطّل — لا مستودع git' }
      const id = Number(args.id)
      if (!Number.isInteger(id) || id <= 0) return { ok: false, error: 'معرّف التغيير مطلوب (رقم)' }
      const change = changeForChat(ctx.db, id)
      if (!change.ok) return { ok: false, error: change.error }
      if (['applied', 'rejected', 'rolled_back', 'cancelled', 'failed'].includes(change.change.status))
        return { ok: false, error: `التغيير #${id} منتهٍ (${change.change.status}) — لا استئناف بعد الانتهاء` }
      startChange(
        forgeDepsFor({ db: ctx.db, config: ctx.config, registry: ctx.registry, vault: ctx.vault, log: ctx.log }, resolveForgeModel(ctx.db, change.change.model)),
        id,
        ctx.log,
      )
      return {
        ok: true,
        data: { id, status: change.change.status, note: 'استُؤنف الخط من حيث توقف — تابِع بـ forge_change_status حتى بوابة الموافقة' },
      }
    },
  },
]

const toolByName = (name: string): BoxTool | undefined => TOOLS.find((t) => t.name === name)

function toolsPrompt(): string {
  return TOOLS.map((t) => `- ${t.name}: ${t.description}\n  الوسائط: ${t.argsHint}`).join('\n')
}

// ------------------------------------------------------------ the chat loop

const HISTORY_TAIL = 14
const MAX_TOOL_ROUNDS = 5

async function systemPrompt(ctx: BoxDeps & { origin: string }): Promise<string> {
  const profile = getProfile(ctx.db)
  const models = await usableModels(ctx.db, ctx.registry, ctx.vault, ctx.config)
  const skillCount = (ctx.db.prepare('SELECT COUNT(*) AS n FROM skills').get() as { n: number }).n
  return `أنت «الصندوق الأسود» — قلب نظام ${profile.name}: ليس شات بوت مساعدًا صغيرًا بل **وكيل هندسي عالمي** يملكه المالك المحلي وحده.
أي طلب يطرحه المالك — صغيرًا كان أو ضخمًا — تلبيه: إما مباشرة بأدواتك، أو بإطلاق مهمة وكيل HYPERBRAIN كاملة عبر launch_agent_task.
تحدّث بلغة المالك (عربي غالبًا)، بأسلوب موجز صادق، وتنفّذ عبر أدواتك الحقيقية.

# هوية النظام الحالية
- الاسم: ${profile.name}
- الشعار: ${profile.tagline}
- اللغة الافتراضية: ${profile.language}
- النموذج الافتراضي: ${profile.defaultModel ?? 'غير مضبوط'}
- الثيم المثبّت: ${profile.themeMode} · لون التمييز: ${profile.accent}
- المهارات المثبتة (قدرات الوكيل): ${skillCount}
- مستوى استقلالية Reality Forge: L${getAutonomy(ctx.db)}
- نموذج الذكاء الهندسي للمسبكة: ${readEngineeringModel(ctx.db) ?? 'نموذج المحادثة نفسه (لم يُثبّت المالك نموذجاً هندسياً خاصاً)'}
- رابط التطبيق: ${ctx.origin}

# النماذج القابلة للاستخدام الآن (${models.length})
${models.length ? models.slice(0, 30).map((m) => `- ${m.id}${m.free ? ' (مجاني)' : ''}`).join('\n') : '- لا نماذج متاحة (المزودون يحتاجون مفاتيح أو غير مشغلين)'}

# أدواتك — كلها موصولة بالنماذج والنظام الحقيقي، وهذا كل ما تستطيعه
${toolsPrompt()}

# قواعد الوكيل العالمي (كيف تقرر)
1. طلب صغير ومحدود (تغيير اسم/لون/ثيم/سؤال حالة/بحث/قراءة ملف/حفظ ملاحظة) → نفّذه مباشرة بأداتك.
2. طلب هندسي أكبر (تحليل معماري عميق، بناء ميزة متعددة الخطوات، بحث شامل، إبداع) → أطلقه كمحطة عمل:
   launch_agent_task بنمط مناسب (research للتحليل، build للبناء، creative للإبداع، super لخط الإنتاج الكامل)
   وبنموذج auto، ثم تابع نتيجتها بـ get_agent_task وأبلغ المالك. لا ترفض طلبًا لأنه كبير — هذا الوكيل الحقيقي.
3. طلب تعديل كود ليمو نفسه (الصدَفة الذاتية) → افحص المصدر أولًا (inspect_frontend/read_source_file/search_source — تعمل بلا git أيضًا) لترسيخ الملفات والخطة،
   ثم أنشئ التغيير الحقيقي بـ forge_create — سيمر إلزاميًا عبر Reality Forge: فرع git معزول، اختبارات، مراجعة أمنية، ثم بوابة موافقة المالك.
   تابع الحالة بـ forge_change_status؛ عند «awaiting_approval» اعرض الخلاصة (الخطة/الفرق/الاختبارات/الأمن) وقل بوضوح إن القرار للمالك.
   موافقة المالك كلاميًا («طبّق» / «ارفض») تنفّذها بـ forge_decide، وبعد التطبيق يمكن «ارجع/تراجع» عبر forge_decide بـ rollback.
   أنت لا تكتب كود التطبيق مباشرة أبدًا — كل تعديل حقيقي يمر عبر خط أنابيب Forge الموثّق، وتقول ذلك صراحة.
4. «إضافة ميزات» تعني: مهارات عبر ALLIMNI (بحث ثم طلب تثبيت بموافقة المالك وبوابة HIGH/CRITICAL)،
   أو مشروع + مهمة وكيل تبنيه في مساحة معزولة. لا تدّعِ غير ذلك.

# بروتوكول استدعاء الأداة
إذا احتاج طلب المالك أداة، أرسل كائن JSON واحدًا فقط بالشكل:
{"tool": "اسم_الأداة", "args": { ... }}
بلا أي نص آخر. ستنفَّذ الأداة وتعود لك نتيجتها الحقيقية، ثم تُكمل المحادثة.
إذا احتاج طلب المالك أكثر من أداة، اطلبها واحدة واحدة (ردًا برد).
لا تُغلف JSON بأقواس كود ولا تشرحه.

# قواعد صارمة
- نفّذ التعديل فقط عبر أداته المخصصة؛ لا تقل «تم» قبل أن تنجح الأداة فعلًا.
- لا تختلق إعدادات أو نماذج أو ألوان أو مسارات ملفات أو مزايا غير موجودة في أدواتك.
- عند طلب لون أو ثيم خارج القوائم المتاحة، اعرض المتاح بدل الرفض الجاف.
- إذا فشلت أداة، اذكر سبب الفشل كما هو دون تجميل — ولا تكرّر استدعاء أداة فشلت بالسبب نفسه؛ أخبر المالك بالسبب وما البديل.
- للمعلومات الحية (حالة/سجل/نماذج/مهارات/مهام/مشاريع/ذاكرة/مصدر) استخدم أدوات القراءة بدلًا من التخمين.
- ميّز في ردودك بين: حقيقة مثبتة من أداة، استنتاج، ومعلومة غير معروفة.
- لا تكشف مفاتيح أو أسرارًا مخزنة؛ مفتاح الوصول الجديد يظهر من أداة إنشائه فقط.
- طلب خارج قدرتك كليًا؟ قله بصراحة واقترح أقرب أداة حقيقية.
- كن رفيقًا محادثة حقيقيًا: رحّب، تجاوب، اسأل عند الغموض، واختم بأفضل خطوة تالية — وليس ردود آلات جافة.`
}

export interface BoxHistoryRow {
  role: 'user' | 'box'
  content: string
}

/** Load the conversation tail from the durable log (box_messages). */
export function loadHistory(db: DB): BoxHistoryRow[] {
  const rows = db.prepare('SELECT role, content FROM box_messages ORDER BY id DESC LIMIT ?').all(HISTORY_TAIL) as Array<{ role: string; content: string }>
  return rows
    .reverse()
    .filter((r) => r.role === 'user' || r.role === 'box')
    .map((r) => ({ role: r.role as 'user' | 'box', content: r.content }))
}

export function persistBoxMessage(db: DB, role: 'user' | 'box', content: string, actions: BoxAction[] | null, model: string | null): void {
  db.prepare('INSERT INTO box_messages (role, content, actions, model) VALUES (?, ?, ?, ?)').run(
    role,
    content,
    actions && actions.length ? JSON.stringify(actions) : null,
    model,
  )
}

function recordModification(db: DB, tool: string, args: Record<string, unknown>, ok: boolean, result: unknown, model: string): void {
  db.prepare('INSERT INTO box_modifications (tool, args, ok, result, model) VALUES (?, ?, ?, ?, ?)').run(
    tool,
    JSON.stringify(args),
    ok ? 1 : 0,
    JSON.stringify(result).slice(0, 4000),
    model,
  )
}

/**
 * One owner turn: LLM loop with tools, honest errors, durable persistence.
 * Throws ProviderError-ish Errors on model failures — the route surfaces them.
 * LIMO #23 — optional live tap: onDelta forwards RAW model tokens as they
 * arrive (real thinking, retries included), onAction fires per executed tool,
 * shouldStop() is polled mid-stream (owner pressed stop) — on stop the loop
 * ends WITHOUT a persisted reply: a half-thought is never sold as an answer.
 */
export interface BoxStreamTap {
  onDelta: (chunk: string) => void
  onAction: (action: BoxAction) => void
  shouldStop: () => boolean
}

export async function runBoxChat(deps: BoxDeps, history: BoxHistoryRow[], message: string, origin: string, tap?: BoxStreamTap): Promise<BoxChatResult> {
  const ctx = { ...deps, origin }
  const messages: ChatMessage[] = [
    { role: 'system', content: await systemPrompt(ctx) },
    ...history.map((h) => ({ role: h.role === 'user' ? ('user' as const) : ('assistant' as const), content: h.content })),
    { role: 'user', content: message },
  ]

  const actions: BoxAction[] = []
  let reply = ''
  for (let round = 0; round < MAX_TOOL_ROUNDS; round++) {
    if (tap?.shouldStop()) return { reply: '', actions, profile: getProfile(deps.db), stopped: true }
    const raw = await deps.modelFn(messages, {
      temperature: 0.3,
      maxTokens: 900,
      onDelta: tap?.onDelta,
      shouldStop: tap?.shouldStop,
    })
    const call = extractJson<{ tool?: unknown; args?: unknown }>(raw)

    if (call && typeof call.tool === 'string' && toolByName(call.tool)) {
      const tool = toolByName(call.tool)!
      const args = (call.args && typeof call.args === 'object' ? call.args : {}) as Record<string, unknown>
      let outcome: { ok: boolean; error?: string; data?: unknown }
      try {
        outcome = await tool.run(ctx, args)
      } catch (e) {
        outcome = { ok: false, error: e instanceof Error ? e.message : String(e) }
      }
      actions.push({ tool: tool.name, args, ok: outcome.ok, result: outcome.ok ? (outcome.data ?? null) : (outcome.error ?? 'فشل غير معروف') })
      tap?.onAction(actions[actions.length - 1]!)
      if (tool.mutates) recordModification(deps.db, tool.name, args, outcome.ok, outcome.ok ? outcome.data : outcome.error, deps.model)
      // feed the REAL outcome back to the model
      messages.push({ role: 'assistant', content: raw })
      messages.push({ role: 'user', content: `نتيجة أداة ${tool.name} (حقيقية):\n${JSON.stringify(outcome.ok ? { ok: true, data: outcome.data } : { ok: false, error: outcome.error })}\n\nأكمل الآن: أبلغ المالك بالنتيجة بصياغتك، أو اطلب الأداة التالية إن لزم.` })
      continue
    }

    // no tool call → this IS the final reply
    reply = raw.trim()
    break
  }

  // exhausted rounds without a final word → summarize honestly from evidence
  if (!reply) {
    reply = actions.length
      ? `نفّذت ${actions.length} إجراءً ولم يصلني رد ختامي من النموذج. الإجراءات المسجلة أعلاه حقيقية — تحقق منها أو أعد الصياغة.`
      : 'لم يصلني رد صالح من النموذج — أعد المحاولة.'
  }

  return { reply, actions, profile: getProfile(deps.db) }
}

// ------------------------------------------------- deterministic self-mod rail
// LIMO #21 — «اريده ان يعدل نفسه بنفسه»: on the owner's phone a live model
// literally REFUSED the self-modification request («لا أستطيع. إطلاقاً»)
// instead of calling forge_create — a rule-3 prompt can never guarantee the
// model's willingness. The #12 doctrine is therefore extended to
// self-modification: the owner's engineering imperative is DETECTED here and
// the box route executes the real pipeline WITHOUT a model turn. Imperative-
// only and question-proof: a question about self-modification still goes to
// the brain (which explains the pipeline), only a command STARTS it.

const SELF_MOD_RE = new RegExp(
  [
    // Arabic imperatives + object (self / own code / the system)
    '(عدّل|عدل|غيّر|غير|طوّر|طور|حسّن|حسن|هندس|برمج|اشطب)\\s+(نفسك|نفسِك|كودك|كود\\s+ليمو|كود\\s+التطبيق|نظامك|النظام\\s+نفسه|النظام\\s+ذاته|النظام)',
    // English imperatives
    '(modify|change|improve|update|edit|refactor)\\s+(yourself|your\\s+own\\s+code|your\\s+code|the\\s+system|limo)',
    'self[- ]?modif',
  ].join('|'),
  'i',
)

/** questions are EXPLAINED, never executed — even if they contain the verbs */
const QUESTION_RE = /^\s*(هل\b|من\b|ما\b|ماذا|كيف|لماذا|أين|اين|متى|أي\b|اي\b|يمكنك|تستطيع|can\s|could\s|what\s|how\s|why\s|where\s|is\s|are\s|do\s|does\s|should\s)/i

/** True when the owner's words are an imperative to modify LIMO itself. */
export function detectSelfModification(message: string): boolean {
  const s = (message ?? '').trim()
  if (s.length < 8) return false
  if (QUESTION_RE.test(s)) return false
  return SELF_MOD_RE.test(s)
}
