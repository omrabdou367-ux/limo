import type { DB } from '../db/database.js'
import { getSetting, setSetting } from '../db/settings.js'

/**
 * The LIMO profile — the identity fields the owner may change through the
 * Black Box chatbot (توجيه المالك 2026-11-01: «حتى تغيير الاسم الخ…»،
 * و2026-11-01: «الألوان والاسم وحتى ميزات جديدة»).
 *
 * Everything is a real settings row (persisted, survives restarts) with
 * strict validation — the box never writes anything it cannot read back.
 */

/**
 * The owner-selectable accent palette — each id maps to a WCAG-checked
 * light/dark (signal, signal-text, accent-contrast) triple on the web side
 * (apps/web/src/lib/appearance.ts — the two lists MUST stay in sync).
 * 'mono' = the stock monochrome ink/paper identity (no override).
 */
export const ACCENT_IDS = ['mono', 'forest', 'indigo', 'crimson', 'ocean', 'violet'] as const
export type AccentId = (typeof ACCENT_IDS)[number]
export const THEME_MODES = ['system', 'light', 'dark'] as const
export type ThemeMode = (typeof THEME_MODES)[number]

export interface AppProfile {
  name: string
  tagline: string
  /** interface default language: 'ar' | 'en' */
  language: 'ar' | 'en'
  /** default model id (provider/model) — validated against the registry */
  defaultModel: string | null
  /** owner-pinned theme; 'system' = every device follows its own toggle */
  themeMode: ThemeMode
  /** accent palette id — the single color the whole UI tints with */
  accent: AccentId
}

export const PROFILE_DEFAULTS: AppProfile = {
  name: 'LIMO AGENT',
  tagline: 'اكتشف. تسلّح. تطوّر.',
  language: 'ar',
  defaultModel: null,
  themeMode: 'system',
  accent: 'mono',
}

const KEY_NAME = 'app_name'
const KEY_TAGLINE = 'app_tagline'
const KEY_LANG = 'default_lang'
const KEY_MODEL = 'default_model'
const KEY_THEME = 'default_theme'
const KEY_ACCENT = 'accent'

const clean = (v: unknown, min: number, max: number): string | null => {
  if (typeof v !== 'string') return null
  const t = v.trim().replace(/\s+/g, ' ')
  if (t.length < min || t.length > max) return null
  return t
}

export function getProfile(db: DB): AppProfile {
  const name = clean(getSetting(db, KEY_NAME), 2, 40)
  const tagline = clean(getSetting(db, KEY_TAGLINE), 2, 80)
  const language = getSetting(db, KEY_LANG) === 'en' ? 'en' : 'ar'
  const defaultModel = getSetting(db, KEY_MODEL) ?? null
  const themeMode = (THEME_MODES as readonly string[]).includes(getSetting(db, KEY_THEME) ?? '')
    ? (getSetting(db, KEY_THEME) as ThemeMode)
    : PROFILE_DEFAULTS.themeMode
  const accentRaw = getSetting(db, KEY_ACCENT) ?? ''
  const accent = ((ACCENT_IDS as readonly string[]).includes(accentRaw) ? accentRaw : PROFILE_DEFAULTS.accent) as AccentId
  return {
    name: name ?? PROFILE_DEFAULTS.name,
    tagline: tagline ?? PROFILE_DEFAULTS.tagline,
    language,
    defaultModel,
    themeMode,
    accent,
  }
}

export interface ProfilePatch {
  name?: unknown
  tagline?: unknown
  language?: unknown
  defaultModel?: unknown
  themeMode?: unknown
  accent?: unknown
}

/** Validated writes only — returns { ok, error } with an Arabic reason. */
export function applyProfilePatch(db: DB, patch: ProfilePatch): { ok: boolean; error?: string } {
  if (patch.name !== undefined) {
    const v = clean(patch.name, 2, 40)
    if (!v) return { ok: false, error: 'الاسم يجب أن يكون بين حرفين و40 حرفًا' }
    setSetting(db, KEY_NAME, v)
  }
  if (patch.tagline !== undefined) {
    const v = clean(patch.tagline, 2, 80)
    if (!v) return { ok: false, error: 'الشعار يجب أن يكون بين حرفين و80 حرفًا' }
    setSetting(db, KEY_TAGLINE, v)
  }
  if (patch.language !== undefined) {
    if (patch.language !== 'ar' && patch.language !== 'en') return { ok: false, error: 'اللغة يجب أن تكون ar أو en' }
    setSetting(db, KEY_LANG, patch.language)
  }
  if (patch.defaultModel !== undefined) {
    // null clears the default; a string must pass caller-side registry
    // validation BEFORE reaching here (this module stays registry-free)
    if (patch.defaultModel === null) {
      setSetting(db, KEY_MODEL, '')
    } else if (typeof patch.defaultModel === 'string' && patch.defaultModel.includes('/')) {
      setSetting(db, KEY_MODEL, patch.defaultModel.trim())
    } else {
      return { ok: false, error: 'معرّف النموذج غير صالح (الصيغة: provider/model)' }
    }
  }
  if (patch.themeMode !== undefined) {
    if (!(THEME_MODES as readonly string[]).includes(String(patch.themeMode))) {
      return { ok: false, error: `الثيم يجب أن يكون واحدًا من: ${THEME_MODES.join(' / ')}` }
    }
    setSetting(db, KEY_THEME, String(patch.themeMode))
  }
  if (patch.accent !== undefined) {
    if (!(ACCENT_IDS as readonly string[]).includes(String(patch.accent))) {
      return { ok: false, error: `اللون يجب أن يكون واحدًا من: ${ACCENT_IDS.join(' / ')}` }
    }
    setSetting(db, KEY_ACCENT, String(patch.accent))
  }
  return { ok: true }
}
