import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs'
import { extname, join, relative, resolve, sep } from 'node:path'
import type { ServerConfig } from '../config.js'

/**
 * The universal Black Box X-RAY (LIMO #14) — READ-ONLY engineering inspection
 * over the REAL repository, powering the SITE ARCHITECT phase 1 inside the box
 * brain:
 *
 *  - inspectFrontend(): the actual apps/web/src tree (counts by layer, the
 *    real nav areas from lib/nav.ts, the real token list from the design
 *    system) — no invented architecture.
 *  - readSourceFile(): path-jailed, text-only, size-capped, secret-denied.
 *  - searchSource(): bounded literal/regex scan with hard caps.
 *
 * WRITES to app source are NOT here by design: source modifications stay
 * behind the Reality Forge approval pipeline (proposals, isolated branch,
 * tests, owner approval, rollback). The box can look, explain, propose —
 * and change identity/theme through the profile tools; it never edits code
 * directly. That boundary is stated in the brain's system prompt too.
 */

const DENIED_NAMES = new Set(['node_modules', '.git', '.next', 'dist', 'out', 'data', '.vercel', 'coverage'])
const SECRET_PATTERNS = [/\.env/i, /\.key$/, /secret/i, /credential/i, /\.pem$/, /vault/i, /password/i]
const TEXT_EXTS = new Set([
  '.ts', '.tsx', '.js', '.mjs', '.cjs', '.css', '.scss', '.json', '.md', '.mdx', '.html', '.svg',
  '.yml', '.yaml', '.toml', '.sh', '.sql', '.txt', '.rs', '.py', '.prisma', '.gitignore', '.lock',
])
const MAX_FILE_BYTES = 48 * 1024
const SCAN_MAX_FILES = 900
const SCAN_MAX_MATCHES = 40
const TREE_MAX_ENTRIES = 220

export interface FrontendInventory {
  available: boolean
  reason?: string
  root?: string
  layers?: Array<{ dir: string; files: number; subdirs: string[] }>
  totalFiles?: number
  navAreas?: Array<{ id: string; ar?: string; en?: string }>
  tokens?: string[]
  entry?: { appRouter: string[]; hasI18n: boolean; hasTokens: boolean }
}

function isTextFile(p: string): boolean {
  const ext = extname(p).toLowerCase()
  if (ext === '') return true // dotfiles like Dockerfile/.gitignore
  return TEXT_EXTS.has(ext)
}

function denied(rel: string): boolean {
  const parts = rel.split(sep)
  if (parts.some((p) => DENIED_NAMES.has(p))) return true
  if (SECRET_PATTERNS.some((re) => re.test(rel))) return true
  return false
}

function countTree(root: string, rel: string, budget: { files: number }): { files: number; subdirs: string[] } {
  const abs = join(root, rel)
  let files = 0
  const subdirs: string[] = []
  let entries: string[] = []
  try {
    entries = readdirSync(abs)
  } catch {
    return { files: 0, subdirs: [] }
  }
  for (const e of entries) {
    if (budget.files >= TREE_MAX_ENTRIES) break
    if (e === '.git' || e === 'node_modules' || e === '.next') continue
    const childRel = rel ? `${rel}${sep}${e}` : e
    let st
    try {
      st = statSync(join(root, childRel))
    } catch {
      continue
    }
    if (st.isDirectory()) {
      subdirs.push(e)
      const sub = countTree(root, childRel, budget)
      files += sub.files
    } else if (isTextFile(childRel)) {
      files += 1
      budget.files += 1
    }
  }
  return { files, subdirs }
}

/** The REAL web-app inventory under <repoRoot>/apps/web/src. */
export function inspectFrontend(config: ServerConfig): FrontendInventory {
  const root = config.sourceRoot
  if (!root) return { available: false, reason: 'جذر المصدر غير مضبوط — الفحص البنيوي غير متاح بصدق' }
  const webSrc = join(root, 'apps', 'web', 'src')
  if (!existsSync(webSrc)) return { available: false, reason: `لا يوجد apps/web/src تحت ${root}` }

  const budget = { files: 0 }
  const layers = ['app', 'components', 'lib', 'hooks'].map((dir) => {
    const { files, subdirs } = existsSync(join(webSrc, dir)) ? countTree(webSrc, dir, budget) : { files: 0, subdirs: [] }
    return { dir, files, subdirs }
  })
  const totalFiles = layers.reduce((a, l) => a + l.files, 0)

  // real nav areas from lib/nav.ts (id: '...' lines) — the actual sidebar source
  const navAreas: Array<{ id: string; ar?: string; en?: string }> = []
  const navPath = join(webSrc, 'lib', 'nav.ts')
  if (existsSync(navPath)) {
    try {
      const src = readFileSync(navPath, 'utf8')
      for (const m of src.matchAll(/id:\s*'([a-z_]+)'/g)) navAreas.push({ id: m[1]! })
      for (const m of src.matchAll(/'([a-z_]+)':\s*'([^']+)',/g)) {
        const hit = navAreas.find((n) => n.id === m[1])
        if (hit) hit.ar = m[2]
      }
    } catch {
      /* nav read failed — the counts above are still real */
    }
  }

  // real design tokens from the tokens package (the single source of truth)
  const tokens: string[] = []
  const tokensPath = join(root, 'packages', 'tokens', 'css', 'variables.css')
  if (existsSync(tokensPath)) {
    try {
      const css = readFileSync(tokensPath, 'utf8')
      for (const m of css.matchAll(/(--omn-[a-z0-9-]+):/g)) tokens.push(m[1]!)
    } catch {
      /* ignore */
    }
  }

  const appRouter = existsSync(join(webSrc, 'app'))
    ? readdirSync(join(webSrc, 'app')).filter((f) => !f.startsWith('.')).slice(0, 20)
    : []

  return {
    available: true,
    root: relative(root, webSrc) || 'apps/web/src',
    layers,
    totalFiles,
    navAreas,
    tokens: tokens.slice(0, 60),
    entry: {
      appRouter,
      hasI18n: existsSync(join(webSrc, 'lib', 'i18n.tsx')),
      hasTokens: tokens.length > 0,
    },
  }
}

/** Jail a user-supplied relative path inside the READ root; null = rejected.
 *  LIMO #22: reads are jailed by sourceRoot (git root OR bare package root);
 *  the secret/build/data denial list below is unchanged and still applies. */
function jailed(config: ServerConfig, rel: string): string | null {
  const root = config.sourceRoot
  if (!root) return null
  const abs = resolve(root, rel)
  const rootWithSep = root.endsWith(sep) ? root : `${root}${sep}`
  if (!abs.startsWith(rootWithSep)) return null // ../ escape or absolute path
  if (denied(relative(root, abs))) return null
  return abs
}

export type SourceRead =
  | { ok: true; path: string; bytes: number; lines: number; content: string; truncated: boolean }
  | { ok: false; error: string }

// ------------------------------------------------------------- files browser
// LIMO #21 — «الملفات»: the owner (and the Krea-parity Files area) browses the
// REAL repository the agent reads and Reality Forge modifies. Same jail, same
// secret denial, hard caps — a browser is a read surface, never a bypass.

const LIST_MAX_ENTRIES = 400

export interface DirFileInfo {
  name: string
  bytes: number
}

export type DirListing =
  | { ok: true; path: string; dirs: string[]; files: DirFileInfo[]; capped: boolean }
  | { ok: false; error: string }

/** List ONE real directory of the repo — jailed, secret-denied, bounded. */
export function listDir(config: ServerConfig, rel: string): DirListing {
  const root = config.sourceRoot
  if (!root) return { ok: false, error: 'جذر المصدر غير مضبوط — تصفح الملفات غير متاح بصدق' }
  const clean = (typeof rel === 'string' ? rel : '').trim().replace(/\\/g, '/').replace(/\/+/g, '/')
  if (clean.startsWith('/') || clean.split('/').includes('..')) {
    return { ok: false, error: 'مسار مرفوض: مطلق أو يحاول الخروج من المستودع' }
  }
  // jailed() deliberately rejects the root itself (every path it accepts is
  // strictly BELOW root) — the empty rel IS the root, so it is handled here
  // directly; every non-empty path still goes through the same jail.
  const abs = clean === '' ? root : jailed(config, clean)
  if (!abs) return { ok: false, error: 'مسار مرفوض: خارج المستودع أو ضمن الملفات المحمية (أسرار/بناء/تبعيات)' }
  let st
  try {
    st = statSync(abs)
  } catch {
    return { ok: false, error: `المجلد غير موجود: ${clean || '.'}` }
  }
  if (!st.isDirectory()) return { ok: false, error: `ليس مجلدًا: ${clean}` }
  let entries: string[]
  try {
    entries = readdirSync(abs)
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e) }
  }
  const dirs: string[] = []
  const files: DirFileInfo[] = []
  let capped = false
  for (const e of entries.sort()) {
    if (dirs.length + files.length >= LIST_MAX_ENTRIES) {
      capped = true
      break
    }
    const childRel = clean ? `${clean}/${e}` : e
    if (denied(childRel)) continue // node_modules/.git/…/secrets — invisible here too
    let cs
    try {
      cs = statSync(join(abs, e))
    } catch {
      continue
    }
    if (cs.isDirectory()) dirs.push(e)
    else if (cs.isFile() && isTextFile(childRel)) files.push({ name: e, bytes: cs.size })
  }
  return { ok: true, path: clean, dirs, files, capped }
}

/** Read ONE real source file from the repo — jailed, text-only, size-capped. */
export function readSourceFile(config: ServerConfig, rel: string): SourceRead {
  const root = config.sourceRoot
  if (!root) return { ok: false, error: 'جذر المصدر غير مضبوط — قراءة المصدر غير متاحة بصدق' }
  if (typeof rel !== 'string' || !rel.trim()) return { ok: false, error: 'حدد مسار ملف داخل المستودع' }
  const abs = jailed(config, rel.trim())
  if (!abs) return { ok: false, error: 'مسار مرفوض: خارج المستودع أو ضمن الملفات المحمية (أسرار/بناء/تبعيات)' }
  if (!existsSync(abs) || !statSync(abs).isFile()) return { ok: false, error: `الملف غير موجود: ${rel.trim()}` }
  if (!isTextFile(abs)) return { ok: false, error: 'الملف ثنائي أو غير نصي — القراءة متاحة للنصوص فقط' }
  const st = statSync(abs)
  if (st.size > MAX_FILE_BYTES) return { ok: false, error: `الملف أكبر من الحد (${Math.round(MAX_FILE_BYTES / 1024)}KB) — اقرأه على أجزاء عبر المصدر` }
  try {
    const buf = readFileSync(abs)
    if (buf.includes(0)) return { ok: false, error: 'الملف ثنائي (يحوي NUL) — رفض القراءة' }
    const content = buf.toString('utf8')
    return {
      ok: true,
      path: relative(root, abs).split(sep).join('/'),
      bytes: st.size,
      lines: content.split('\n').length,
      content,
      truncated: false,
    }
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e) }
  }
}

export interface SourceHit {
  path: string
  line: number
  snippet: string
}

export type SourceSearch =
  | { ok: true; query: string; scanned: number; matches: SourceHit[]; capped: boolean }
  | { ok: false; error: string }

/** Bounded search over the repo's text files — real, capped, secret-denied. */
export function searchSource(config: ServerConfig, query: string): SourceSearch {
  const root = config.sourceRoot
  if (!root) return { ok: false, error: 'جذر المصدر غير مضبوط — البحث غير متاح بصدق' }
  if (typeof query !== 'string' || query.trim().length < 2) return { ok: false, error: 'اكتب كلمة بحث من حرفين على الأقل' }
  let matcher: RegExp
  try {
    matcher = new RegExp(query.trim(), 'i')
  } catch {
    matcher = new RegExp(query.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i')
  }
  const webSrc = join(root, 'apps', 'web', 'src')
  const serverSrc = join(root, 'server', 'src')
  const hits: SourceHit[] = []
  let scanned = 0
  let capped = false

  const walk = (dir: string): void => {
    if (capped || hits.length >= SCAN_MAX_MATCHES || scanned >= SCAN_MAX_FILES) {
      capped = capped || hits.length >= SCAN_MAX_MATCHES || scanned >= SCAN_MAX_FILES
      return
    }
    let entries: string[] = []
    try {
      entries = readdirSync(dir)
    } catch {
      return
    }
    for (const e of entries) {
      if (capped) return
      if (e === '.git' || e === 'node_modules' || e === '.next') continue
      const abs = join(dir, e)
      let st
      try {
        st = statSync(abs)
      } catch {
        continue
      }
      if (st.isDirectory()) {
        if (!denied(relative(root, abs))) walk(abs)
        continue
      }
      const rel = relative(root, abs).split(sep).join('/')
      if (denied(rel) || !isTextFile(abs) || st.size > 256 * 1024) continue
      scanned += 1
      if (scanned > SCAN_MAX_FILES) {
        capped = true
        return
      }
      let content: string
      try {
        content = readFileSync(abs, 'utf8')
      } catch {
        continue
      }
      const lines = content.split('\n')
      for (let i = 0; i < lines.length; i++) {
        if (matcher.test(lines[i]!)) {
          hits.push({ path: rel, line: i + 1, snippet: lines[i]!.trim().slice(0, 160) })
          if (hits.length >= SCAN_MAX_MATCHES) {
            capped = true
            return
          }
          break // one hit per file keeps the report broad
        }
      }
    }
  }

  walk(webSrc)
  walk(serverSrc)
  return { ok: true, query: query.trim(), scanned, matches: hits, capped }
}
