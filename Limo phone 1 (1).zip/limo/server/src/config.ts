/** Omnara server configuration — env-driven, all defaults safe for local dev. */
import { existsSync, readFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'

export interface ServerConfig {
  host: string
  port: number
  dataDir: string
  sessionTtlHours: number
  corsOrigins: string[]
  ollamaBaseUrl: string
  openrouterBaseUrl: string
  groqBaseUrl: string
  modelsCacheTtlMs: number
  simpleFallback: string[]
  webDist: string | null
  enforceOrigin: boolean
  logLevel: 'trace' | 'debug' | 'info' | 'warn' | 'error'
  /** Catalog: hours between daily aggregations (PLAN §8.1.1). */
  catalogRefreshHours: number
  /** Catalog: per-source fetch timeout. */
  catalogTimeoutMs: number
  /** Reality Forge: the git repository Omnara may modify (itself).
   *  FORGE_REPO_ROOT wins; otherwise probed by walking up from cwd; null = disabled.
   *  WRITE tools REQUIRE this git root (isolation branches + rollback). */
  forgeRepoRoot: string | null
  /** LIMO #22 — READ-ONLY source root (inspect/read/search/files browser).
   *  The phone package IS the source even without `git init`, so reads fall
   *  back to the package root (a dir holding server/src); writes never do. */
  sourceRoot: string | null
  /** Forge: guarded command installing deps inside a fresh sandbox worktree. */
  forgeInstallCommand: string
  /** Forge: guarded + time-boxed test command run inside the worktree (L3+).
   *  A stricter gate can be set via env, e.g. `bun run --cwd server test`. */
  forgeTestCommand: string
  /** LIMO #19 DIRECT ACTION validation chain: guarded lint step (L3+).
   *  Empty string = the step is skipped with an honest 'skipped' record. */
  forgeLintCommand: string
  /** LIMO #19 DIRECT ACTION validation chain: guarded production-build step
   *  (L3+). Empty = skipped. The first failing step stops the whole line. */
  forgeBuildCommand: string
}

/** Tiny .env loader — zero deps, only KEY=VALUE lines, no interpolation. */
export function loadDotEnv(path: string): Record<string, string> {
  if (!existsSync(path)) return {}
  const out: Record<string, string> = {}
  for (const raw of readFileSync(path, 'utf8').split('\n')) {
    const line = raw.trim()
    if (!line || line.startsWith('#')) continue
    const eq = line.indexOf('=')
    if (eq <= 0) continue
    const key = line.slice(0, eq).trim()
    let val = line.slice(eq + 1).trim()
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1)
    }
    out[key] = val
  }
  return out
}

const num = (v: string | undefined, d: number): number => {
  const n = Number(v)
  return Number.isFinite(n) && n > 0 ? n : d
}

const list = (v: string | undefined, d: string[]): string[] =>
  v === undefined || v.trim() === '' ? d : v.split(',').map((s) => s.trim()).filter(Boolean)

/** Reality Forge probe: the nearest ancestor of `from` that is a git repo
 *  (has .git). Omnara modifying ITSELF means the repo containing this server. */
function probeRepoRoot(from: string): string | null {
  let dir = resolve(from)
  for (let i = 0; i < 6; i++) {
    if (existsSync(join(dir, '.git'))) return dir
    const parent = dirname(dir)
    if (parent === dir) return null
    dir = parent
  }
  return null
}

/** LIMO #22 read-root probe: the nearest ancestor of `from` that IS the LIMO
 *  package (server/src exists). The phone runs `cd ~/limo/server` with NO git
 *  repo — reads of the agent's own source must still work there, honestly and
 *  jailed; only writes (Reality Forge) demand the real git root. */
function probePackageRoot(from: string): string | null {
  let dir = resolve(from)
  for (let i = 0; i < 6; i++) {
    if (existsSync(join(dir, 'server', 'src'))) return dir
    const parent = dirname(dir)
    if (parent === dir) return null
    dir = parent
  }
  return null
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): ServerConfig {
  return {
    host: env.HOST ?? '127.0.0.1',
    port: num(env.PORT, 8787),
    dataDir: resolve(env.DATA_DIR ?? './data'),
    sessionTtlHours: num(env.SESSION_TTL_HOURS, 14 * 24),
    // v2.2 #4 — explicit CORS allowlist: local dev + EVERY Tauri v2 origin
    // (macOS/Linux tauri://, Windows https://tauri.localhost, Linux webkitgtk
    // http://tauri.localhost) + capacitor for the future Android shell.
    // Unknown origins are rejected (origin callback returns false).
    corsOrigins: list(env.CORS_ORIGINS, [
      'http://localhost:3000',
      'http://127.0.0.1:3000',
      'tauri://localhost',
      'https://tauri.localhost',
      'http://tauri.localhost',
      'capacitor://localhost',
      'http://localhost',
    ]),
    ollamaBaseUrl: (env.OLLAMA_BASE_URL ?? 'http://127.0.0.1:11434').replace(/\/+$/, ''),
    openrouterBaseUrl: (env.OPENROUTER_BASE_URL ?? 'https://openrouter.ai/api/v1').replace(/\/+$/, ''),
    groqBaseUrl: (env.GROQ_BASE_URL ?? 'https://api.groq.com/openai/v1').replace(/\/+$/, ''),
    modelsCacheTtlMs: num(env.MODELS_CACHE_TTL_MS, 10 * 60 * 1000),
    simpleFallback: list(env.SIMPLE_FALLBACK, []),
    catalogRefreshHours: num(env.CATALOG_REFRESH_HOURS, 24),
    catalogTimeoutMs: num(env.CATALOG_TIMEOUT_MS, 10_000),
    webDist: env.WEB_DIST ? resolve(env.WEB_DIST) : null,
    enforceOrigin: env.ENFORCE_ORIGIN === 'true',
    logLevel: (env.LOG_LEVEL as ServerConfig['logLevel']) ?? 'info',
    forgeRepoRoot: env.FORGE_REPO_ROOT ? resolve(env.FORGE_REPO_ROOT) : probeRepoRoot(process.cwd()),
    // LIMO #22: reads work from the git root OR the bare package; env wins.
    sourceRoot: env.SOURCE_ROOT
      ? resolve(env.SOURCE_ROOT)
      : (env.FORGE_REPO_ROOT ? resolve(env.FORGE_REPO_ROOT) : (probeRepoRoot(process.cwd()) ?? probePackageRoot(process.cwd()))),
    // single guarded command (no shell chaining) — see sandbox.guardedRun
    forgeInstallCommand: env.FORGE_INSTALL_COMMAND ?? 'bun install',
    forgeTestCommand: env.FORGE_TEST_COMMAND ?? `bun run typecheck`,
    // LIMO #19: the DIRECT ACTION validation chain — lint and build are
    // opt-in (empty = skipped honestly); install+tests keep their defaults
    forgeLintCommand: env.FORGE_LINT_COMMAND ?? '',
    forgeBuildCommand: env.FORGE_BUILD_COMMAND ?? '',
  }
}
