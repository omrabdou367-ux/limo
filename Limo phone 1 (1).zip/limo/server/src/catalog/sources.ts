import type { ServerConfig } from '../config.js'
import type { DB } from '../db/database.js'
import type { Vault } from '../vault/vault.js'
import type { FetchLike } from '../providers/types.js'
import { keyAliasFor, type ProviderRegistry } from '../providers/registry.js'
import { listCustomProviders, type CustomProvider } from '../db/custom_providers.js'

/**
 * Catalog sources (PLAN.md §8.1.1) — every source is fetched independently;
 * one failing source never blocks the others, and its stale rows are kept.
 *
 * Legitimacy filter (§7): only OFFICIAL endpoints are queried — the provider's
 * own documented /models (or /api/tags for Ollama). Nothing is scraped.
 */

export interface CatalogEntry {
  provider: string
  modelId: string
  ownedBy?: string | null
  free?: boolean
  contextLength?: number | null
  pricingPrompt?: string | null // $ per 1M prompt tokens, as declared by the provider
  pricingCompletion?: string | null
}

export interface SourceSpec {
  /** Stable source id recorded per row, e.g. 'openrouter:/models'. */
  source: string
  /** Provider whose rows this source replaces. */
  provider: string
  /** Honest reason the source was skipped entirely (no network attempt). */
  skipReason?: string
  fetch(signal: AbortSignal): Promise<CatalogEntry[]>
}

export interface SourceDeps {
  config: ServerConfig
  db: DB
  vault: Vault
  registry: ProviderRegistry
  fetchImpl?: FetchLike
}

const doFetch: FetchLike = (u, i) => fetch(u, i)

/** $/token (OpenRouter style) → "$/1M tokens" string, trimmed of noise. */
function perMillion(perToken: string | undefined): string | null {
  if (perToken === undefined) return null
  const v = Number(perToken)
  if (!Number.isFinite(v)) return null
  const m = v * 1_000_000
  if (m === 0) return '0'
  return String(Number(m.toPrecision(4)))
}

/** OpenRouter — the models listing is PUBLIC (no key); free = declared $0 pricing. */
function openrouterSource(deps: SourceDeps): SourceSpec {
  return {
    source: 'openrouter:/models',
    provider: 'openrouter',
    fetch: async (signal) => {
      const res = await (deps.fetchImpl ?? doFetch)(`${deps.config.openrouterBaseUrl}/models`, { signal })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const body = (await res.json()) as {
        data?: Array<{
          id: string
          context_length?: number
          pricing?: { prompt?: string; completion?: string }
        }>
      }
      return (body.data ?? []).map((m) => ({
        provider: 'openrouter',
        modelId: m.id,
        ownedBy: 'openrouter',
        free: m.pricing?.prompt === '0',
        contextLength: m.context_length ?? null,
        pricingPrompt: perMillion(m.pricing?.prompt),
        pricingCompletion: perMillion(m.pricing?.completion),
      }))
    },
  }
}

/** Groq — official list; needs the owner's BYOK key, so it is skipped (honestly) without one. */
function groqSource(deps: SourceDeps): SourceSpec {
  const hasKey = deps.vault.hasSecret(keyAliasFor('groq'))
  const spec: SourceSpec = {
    source: 'groq:/models',
    provider: 'groq',
    fetch: async (signal) => {
      const key = deps.vault.getSecret(keyAliasFor('groq'))
      if (!key) throw new Error('مفتاح Groq غير متاح (الخزنة مقفلة)')
      const res = await (deps.fetchImpl ?? doFetch)(`${deps.config.groqBaseUrl}/models`, {
        headers: { authorization: `Bearer ${key}` },
        signal,
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const body = (await res.json()) as {
        data?: Array<{ id: string; owned_by?: string; context_window?: number }>
      }
      // Groq does not declare per-model pricing in this endpoint — no free flag.
      return (body.data ?? []).map((m) => ({
        provider: 'groq',
        modelId: m.id,
        ownedBy: m.owned_by ?? 'groq',
        free: false,
        contextLength: m.context_window ?? null,
      }))
    },
  }
  if (!hasKey) spec.skipReason = 'لا يوجد مفتاح Groq في الخزنة — المصدر يُتخطى بصدق'
  return spec
}

/** Ollama — local /api/tags; free by nature (runs on the owner's machine). */
function ollamaSource(deps: SourceDeps): SourceSpec {
  return {
    source: 'ollama:/api/tags',
    provider: 'ollama',
    fetch: async (signal) => {
      const res = await (deps.fetchImpl ?? doFetch)(`${deps.config.ollamaBaseUrl}/api/tags`, { signal })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const body = (await res.json()) as { models?: Array<{ name: string }> }
      return (body.models ?? []).map((m) => ({
        provider: 'ollama',
        modelId: m.name,
        ownedBy: 'ollama',
        free: true,
      }))
    },
  }
}

/** A user-added OpenAI-compatible endpoint — official /models of that endpoint. */
function customSource(deps: SourceDeps, row: CustomProvider): SourceSpec {
  const alias = keyAliasFor(row.id)
  const hasKey = !row.needsKey || deps.vault.hasSecret(alias)
  const spec: SourceSpec = {
    source: `custom:${row.id}:/models`,
    provider: row.id,
    fetch: async (signal) => {
      const headers: Record<string, string> = {}
      if (row.needsKey) {
        const key = deps.vault.getSecret(alias)
        if (!key) throw new Error(`مفتاح ${row.id} غير متاح (الخزنة مقفلة)`)
        headers.authorization = `Bearer ${key}`
      }
      const res = await (deps.fetchImpl ?? doFetch)(`${row.baseUrl.replace(/\/+$/, '')}/models`, {
        headers,
        signal,
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const body = (await res.json()) as {
        data?: Array<{ id: string; owned_by?: string; context_length?: number }>
      }
      return (body.data ?? []).map((m) => ({
        provider: row.id,
        modelId: m.id,
        ownedBy: m.owned_by ?? row.id,
        free: false, // unknown unless the provider declares it — we never guess
        contextLength: m.context_length ?? null,
      }))
    },
  }
  if (!hasKey) spec.skipReason = `لا يوجد مفتاح ${row.id} في الخزنة — المصدر يُتخطى بصدق`
  return spec
}

/** Build every source for one aggregation round. */
export function buildSources(deps: SourceDeps): SourceSpec[] {
  const sources: SourceSpec[] = [openrouterSource(deps), groqSource(deps), ollamaSource(deps)]
  for (const row of listCustomProviders(deps.db)) {
    if (row.enabled) sources.push(customSource(deps, row))
  }
  return sources
}
