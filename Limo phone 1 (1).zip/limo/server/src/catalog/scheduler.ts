import type { ServerConfig } from '../config.js'
import type { DB } from '../db/database.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import type { Logger } from '../logger.js'
import { isStale, refreshCatalog, type AggregateDeps } from './aggregate.js'

/**
 * Daily catalog scheduler (PLAN.md §8.1.1). Started by src/index.ts only —
 * never inside buildApp, so tests stay side-effect free. On boot it refreshes
 * immediately IF the stored snapshot is older than the interval, then repeats
 * on the interval. Returns a stop() for graceful shutdown.
 */
export function startCatalogScheduler(deps: {
  db: DB
  config: ServerConfig
  vault: Vault
  registry: ProviderRegistry
  log: Logger
}): () => void {
  const intervalMs = Math.max(1, deps.config.catalogRefreshHours) * 3_600_000
  const run = (reason: 'boot-stale' | 'interval') => {
    refreshCatalog(deps as AggregateDeps)
      .then((r) => deps.log.info('catalog: scheduled refresh done', { reason, models: r.models }))
      .catch((e) => deps.log.warn('catalog: scheduled refresh crashed', { reason, error: e instanceof Error ? e.message : String(e) }))
  }

  if (isStale({ db: deps.db, config: deps.config })) run('boot-stale')

  const timer = setInterval(() => run('interval'), intervalMs)
  timer.unref?.()
  return () => clearInterval(timer)
}
