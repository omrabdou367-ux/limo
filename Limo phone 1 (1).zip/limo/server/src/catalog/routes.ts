import type { FastifyInstance } from 'fastify'
import type { ServerConfig } from '../config.js'
import type { DB } from '../db/database.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import type { Logger } from '../logger.js'
import { getRefreshState, listCatalogModels } from '../db/catalog.js'
import { isStale, refreshCatalog } from './aggregate.js'

/**
 * Catalog routes — the daily live index, with the honest summary the usage
 * board renders verbatim (skips, errors, timestamps). Refresh is explicit:
 * the user always sees when data was actually last verified.
 */
export function registerCatalogRoutes(
  app: FastifyInstance,
  ctx: { db: DB; config: ServerConfig; vault: Vault; registry: ProviderRegistry; log: Logger },
): void {
  const { db, config } = ctx

  app.get('/api/catalog', async () => {
    const state = getRefreshState(db)
    const models = listCatalogModels(db)
    const byProvider = new Map<string, { models: number; free: number; discoveredAt: string }>()
    for (const m of models) {
      const cur = byProvider.get(m.provider) ?? { models: 0, free: 0, discoveredAt: m.discovered_at }
      cur.models++
      if (m.free === 1) cur.free++
      if (m.discovered_at > cur.discoveredAt) cur.discoveredAt = m.discovered_at
      byProvider.set(m.provider, cur)
    }
    return {
      refreshedAt: state.at,
      ok: state.ok,
      stale: isStale({ db, config }),
      models: state.models,
      freeModels: state.freeModels,
      durationMs: state.durationMs,
      errors: state.errors,
      providers: [...byProvider.entries()]
        .map(([provider, v]) => ({ provider, ...v }))
        .sort((a, b) => a.provider.localeCompare(b.provider)),
      // full row list for the UI's searchable table (id is the prefixed form)
      data: models.map((m) => ({
        id: `${m.provider}/${m.model_id}`,
        provider: m.provider,
        modelId: m.model_id,
        ownedBy: m.owned_by,
        free: m.free === 1,
        contextLength: m.context_length,
        pricingPrompt: m.pricing_prompt,
        pricingCompletion: m.pricing_completion,
        discoveredAt: m.discovered_at,
      })),
    }
  })

  app.post('/api/catalog/refresh', async () => {
    const summary = await refreshCatalog(ctx)
    return summary
  })
}
