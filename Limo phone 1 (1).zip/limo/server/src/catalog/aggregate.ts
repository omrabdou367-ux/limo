import type { ServerConfig } from '../config.js'
import type { DB } from '../db/database.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import type { FetchLike } from '../providers/types.js'
import type { Logger } from '../logger.js'
import {
  catalogByProvider,
  getRefreshState,
  listCatalogModels,
  replaceSourceModels,
  setRefreshState,
  type CatalogRefreshState,
} from '../db/catalog.js'
import { buildSources, type SourceDeps } from './sources.js'
import { recordEgress, updateEgress } from '../db/egress.js'

/**
 * One aggregation round: fetch every source independently (timeout each),
 * replace the rows of every source that succeeded, keep the stale rows of
 * every source that failed, and write an honest summary the UI can show
 * verbatim — including per-source skips and errors.
 */

export interface RefreshSummary extends CatalogRefreshState {
  providers: Array<{ provider: string; models: number; free: number; discoveredAt: string | null }>
  skipped: Array<{ source: string; reason: string }>
}

export interface AggregateDeps {
  db: DB
  config: ServerConfig
  vault: Vault
  registry: ProviderRegistry
  log: Logger
  fetchImpl?: FetchLike
}

export async function refreshCatalog(deps: AggregateDeps): Promise<RefreshSummary> {
  const { db, log } = deps
  const started = Date.now()
  const sourceDeps: SourceDeps = {
    config: deps.config,
    db: deps.db,
    vault: deps.vault,
    registry: deps.registry,
    fetchImpl: deps.fetchImpl,
  }
  const sources = buildSources(sourceDeps)
  const errors: Array<{ source: string; error: string }> = []
  const skipped: Array<{ source: string; reason: string }> = []
  const discoveredAt = new Date().toISOString()
  let okCount = 0

  for (const src of sources) {
    if (src.skipReason) {
      skipped.push({ source: src.source, reason: src.skipReason })
      continue
    }
    // v2.2 #7 «ما غادر الجهاز»: catalog fetches are outbound requests too
    const egressId = recordEgress(db, {
      source: 'catalog',
      provider: src.provider,
      model: null,
      payload: src.source,
      config: deps.config,
    })
    try {
      const entries = await src.fetch(AbortSignal.timeout(deps.config.catalogTimeoutMs))
      updateEgress(db, egressId, true)
      const tx = db.transaction(() => {
        replaceSourceModels(
          db,
          src.provider,
          entries.map((e) => ({
            provider: e.provider,
            modelId: e.modelId,
            ownedBy: e.ownedBy ?? null,
            free: e.free ?? false,
            contextLength: e.contextLength ?? null,
            pricingPrompt: e.pricingPrompt ?? null,
            pricingCompletion: e.pricingCompletion ?? null,
            source: src.source,
            discoveredAt,
          })),
        )
      })
      tx()
      okCount++
      log.info('catalog: source refreshed', { source: src.source, models: entries.length })
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e)
      updateEgress(db, egressId, false, 'provider_unreachable')
      errors.push({ source: src.source, error: msg })
      log.warn('catalog: source failed (stale rows kept)', { source: src.source, error: msg })
    }
  }

  const models = listCatalogModels(db)
  const state: CatalogRefreshState = {
    at: discoveredAt,
    ok: errors.length === 0,
    models: models.length,
    freeModels: models.filter((m) => m.free === 1).length,
    durationMs: Date.now() - started,
    errors,
  }
  setRefreshState(db, state)

  return {
    ...state,
    providers: catalogByProvider(db).map((p) => ({
      provider: p.provider,
      models: p.models,
      free: p.free ?? 0,
      discoveredAt: p.discoveredAt,
    })),
    skipped,
  }
}

/** True when the last refresh is older than the configured interval. */
export function isStale(deps: { db: DB; config: ServerConfig }): boolean {
  const state = getRefreshState(deps.db)
  if (!state.at) return true
  return Date.now() - Date.parse(state.at) > deps.config.catalogRefreshHours * 3_600_000
}
