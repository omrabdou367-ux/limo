import { loadDotEnv } from './config.js'
import { buildApp } from './app.js'
import { startCatalogScheduler } from './catalog/scheduler.js'

// .env next to the server package (optional, zero-dep parse)
Object.assign(process.env, loadDotEnv(new URL('../.env', import.meta.url).pathname))

async function main(): Promise<void> {
  const { app, deps } = buildApp()
  const { config, log } = deps

  await app.listen({ host: config.host, port: config.port })
  log.info('LIMO server up — open mode (no password)', {
    url: `http://${config.host}:${config.port}`,
    data: config.dataDir,
    vault: deps.vault.isUnlocked ? 'unlocked (machine key)' : 'locked (legacy — migrate)',
    catalog: `every ${config.catalogRefreshHours}h`,
  })

  // open mode: the vault self-unwrapped at boot, so routines catch up now
  if (deps.vault.isUnlocked) {
    void deps.routineScheduler.catchUpOnUnlock().catch(() => undefined)
  }

  // daily live catalog (PLAN §8.1.1) — refreshes on boot only if stale
  const stopCatalog = startCatalogScheduler(deps)

  // phase 3: scheduled routines — the scheduler ticks here (not inside
  // buildApp) so tests never leak intervals; skipped one-shots caught up
  // right above (the vault self-unwrapped at boot).
  const stopRoutines = deps.routineScheduler.start()

  const shutdown = async (signal: string) => {
    log.info(`shutting down (${signal}) — locking vault`)
    stopCatalog()
    stopRoutines()
    try {
      await app.close()
    } finally {
      process.exit(0)
    }
  }
  process.on('SIGINT', () => void shutdown('SIGINT'))
  process.on('SIGTERM', () => void shutdown('SIGTERM'))
}

main().catch((e) => {
  console.error('[omnara] fatal:', e)
  process.exit(1)
})
