/**
 * Central, secret-scrubbing logger.
 *
 * PLAN.md §7: no key may ever reach a log line. Every message string passes
 * through scrub(); structured objects are serialized then scrubbed. Fastify
 * itself never logs request bodies, and we never log secret fields.
 */

const SECRET_PATTERNS: RegExp[] = [
  /sk-[A-Za-z0-9_-]{6,}/g, // OpenAI-style
  /sk-or-[A-Za-z0-9_-]{6,}/g, // OpenRouter
  /gsk_[A-Za-z0-9]{6,}/g, // Groq
  /omn_live_[A-Za-z0-9]{6,}/g, // Omnara API keys
  /Bearer\s+[A-Za-z0-9._-]{6,}/gi, // headers pasted into messages
  /(api[_-]?key|passphrase|password|token|secret)"?\s*[:=]\s*"?[^",\s}]{4,}/gi,
]

export function scrub(text: string): string {
  let out = text
  for (const re of SECRET_PATTERNS) out = out.replace(re, (m) => `${m.slice(0, 6)}••••••`)
  return out
}

function scrubValue(v: unknown, depth = 0): string {
  if (depth > 4) return '[deep]'
  if (typeof v === 'string') return scrub(v)
  if (v === undefined || v === null || typeof v !== 'object') return String(v)
  if (v instanceof Error) return scrub(`${v.name}: ${v.message}`)
  try {
    return scrub(JSON.stringify(v, (_k, val) => (typeof val === 'string' ? scrub(val) : val)))
  } catch {
    return '[unserializable]'
  }
}

const LEVELS = { trace: 10, debug: 20, info: 30, warn: 40, error: 50 } as const
export type LogLevel = keyof typeof LEVELS

export interface Logger {
  level: LogLevel
  trace(msg: string, ...rest: unknown[]): void
  debug(msg: string, ...rest: unknown[]): void
  info(msg: string, ...rest: unknown[]): void
  warn(msg: string, ...rest: unknown[]): void
  error(msg: string, ...rest: unknown[]): void
  child(prefix: string): Logger
}

export function createLogger(level: LogLevel = 'info'): Logger {
  const emit = (lvl: LogLevel, prefix: string, msg: string, rest: unknown[]) => {
    if (LEVELS[lvl] < LEVELS[level]) return
    const line = `[omnara${prefix}] ${scrub(msg)}${rest.length ? ` ${rest.map((r) => scrubValue(r)).join(' ')}` : ''}`
    if (lvl === 'error') console.error(line)
    else if (lvl === 'warn') console.warn(line)
    else console.log(line)
  }
  const make = (prefix: string): Logger => ({
    level,
    trace: (m, ...r) => emit('trace', prefix, m, r),
    debug: (m, ...r) => emit('debug', prefix, m, r),
    info: (m, ...r) => emit('info', prefix, m, r),
    warn: (m, ...r) => emit('warn', prefix, m, r),
    error: (m, ...r) => emit('error', prefix, m, r),
    child: (p: string) => make(`${prefix}:${p}`),
  })
  return make('')
}
