import { randomBytes } from 'node:crypto'
import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import type { Logger } from '../logger.js'
import { runAgentTask } from '../agent/engine.js'
import { buildModelFn } from '../agent/model.js'
import { AGENT_ROLES, isAgentRole } from '../agent/roles.js'
import type { VectorMemory } from '../agent/memory.js'
import { getTask } from '../agent/routes.js'

/**
 * Workflow Lab — LIMO PHASE 5: editable ordered prompt chains executed through
 * the REAL agent engine (each step is a full HYPERBRAIN task with its own
 * planner/executor/critic/approval gates). Nothing is simulated: a run is a
 * sequence of agent tasks; the run row records their ids and finishes only
 * when the last task finishes. Failures are recorded honestly ("partial").
 */

export interface WorkflowRouteDeps {
  db: DB
  config: ServerConfig
  registry: ProviderRegistry
  vault: Vault
  log: Logger
  memory: VectorMemory
}

export interface WorkflowStepInput {
  title: string
  prompt: string
  role?: string
}

export interface WorkflowRow {
  id: string
  name: string
  description: string
  steps: string // JSON array
  created_at: string
  updated_at: string
}

export interface WorkflowRunRow {
  id: string
  workflow_id: string
  status: string
  task_ids: string // JSON array
  detail: string | null
  started_at: string
  finished_at: string | null
}

function parseSteps(raw: unknown): WorkflowStepInput[] | null {
  if (!Array.isArray(raw)) return null
  const out: WorkflowStepInput[] = []
  for (const s of raw.slice(0, 12)) {
    if (!s || typeof s !== 'object') return null
    const { title, prompt, role } = s as { title?: unknown; prompt?: unknown; role?: unknown }
    if (typeof title !== 'string' || title.length === 0 || title.length > 200) return null
    if (typeof prompt !== 'string' || prompt.length < 4 || prompt.length > 4000) return null
    if (role !== undefined && (!isAgentRole(role) || role === 'orchestrator')) {
      // roles are planner-assigned inside the engine; a step may only HINT at
      // the specialized agent via its goal text — we accept the field but it
      // must be a real role id (not the catch-all) to mean anything.
      return null
    }
    out.push({ title, prompt, ...(role ? { role } : {}) })
  }
  return out.length > 0 ? out : null
}

export function registerWorkflowRoutes(app: FastifyInstance, deps: WorkflowRouteDeps): void {
  const { db, config, registry, vault, log, memory } = deps

  app.get('/api/workflows', async () => ({ workflows: (db.prepare('SELECT * FROM workflows ORDER BY updated_at DESC').all() as WorkflowRow[]) }))

  app.post(
    '/api/workflows',
    {
      schema: {
        body: {
          type: 'object',
          required: ['name', 'steps'],
          additionalProperties: false,
          properties: {
            name: { type: 'string', minLength: 1, maxLength: 120 },
            description: { type: 'string', maxLength: 2000 },
            steps: {
              type: 'array',
              minItems: 1,
              maxItems: 12,
              items: {
                type: 'object',
                required: ['title', 'prompt'],
                additionalProperties: false,
                properties: {
                  title: { type: 'string', minLength: 1, maxLength: 200 },
                  prompt: { type: 'string', minLength: 4, maxLength: 4000 },
                  role: { type: 'string', enum: Object.keys(AGENT_ROLES) },
                },
              },
            },
          },
        },
      },
    },
    async (request, reply) => {
      const b = request.body as { name: string; description?: string; steps: WorkflowStepInput[] }
      const steps = parseSteps(b.steps)
      if (!steps) return reply.code(400).send({ error: { message: 'خطوات غير صالحة', type: 'invalid_request_error', code: 400 } })
      const id = randomBytes(5).toString('hex')
      const now = new Date().toISOString()
      db.prepare('INSERT INTO workflows (id, name, description, steps, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)').run(
        id,
        b.name,
        b.description ?? '',
        JSON.stringify(steps),
        now,
        now,
      )
      return reply.code(201).send({ workflow: db.prepare('SELECT * FROM workflows WHERE id = ?').get(id) })
    },
  )

  app.get('/api/workflows/:id', async (request, reply) => {
    const { id } = request.params as { id: string }
    const wf = db.prepare('SELECT * FROM workflows WHERE id = ?').get(id) as WorkflowRow | undefined
    if (!wf) return reply.code(404).send({ error: { message: 'سير العمل غير موجود', type: 'not_found', code: 404 } })
    const runs = db.prepare('SELECT * FROM workflow_runs WHERE workflow_id = ? ORDER BY started_at DESC LIMIT 20').all(id) as WorkflowRunRow[]
    return { workflow: wf, runs }
  })

  app.patch(
    '/api/workflows/:id',
    {
      schema: {
        body: {
          type: 'object',
          additionalProperties: false,
          properties: {
            name: { type: 'string', minLength: 1, maxLength: 120 },
            description: { type: 'string', maxLength: 2000 },
            steps: { type: 'array', minItems: 1, maxItems: 12 },
          },
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params as { id: string }
      const cur = db.prepare('SELECT * FROM workflows WHERE id = ?').get(id) as WorkflowRow | undefined
      if (!cur) return reply.code(404).send({ error: { message: 'سير العمل غير موجود', type: 'not_found', code: 404 } })
      const b = request.body as { name?: string; description?: string; steps?: WorkflowStepInput[] }
      let stepsJson = cur.steps
      if (b.steps !== undefined) {
        const steps = parseSteps(b.steps)
        if (!steps) return reply.code(400).send({ error: { message: 'خطوات غير صالحة', type: 'invalid_request_error', code: 400 } })
        stepsJson = JSON.stringify(steps)
      }
      db.prepare('UPDATE workflows SET name = ?, description = ?, steps = ?, updated_at = ? WHERE id = ?').run(
        b.name ?? cur.name,
        b.description ?? cur.description,
        stepsJson,
        new Date().toISOString(),
        id,
      )
      return { workflow: db.prepare('SELECT * FROM workflows WHERE id = ?').get(id) }
    },
  )

  app.delete('/api/workflows/:id', async (request, reply) => {
    const { id } = request.params as { id: string }
    const info = db.prepare('DELETE FROM workflows WHERE id = ?').run(id)
    if (info.changes === 0) return reply.code(404).send({ error: { message: 'سير العمل غير موجود', type: 'not_found', code: 404 } })
    return { ok: true }
  })

  // --------------------------------------------------------------- execution

  app.post(
    '/api/workflows/:id/run',
    {
      schema: {
        body: {
          type: 'object',
          required: ['model'],
          additionalProperties: false,
          properties: {
            model: { type: 'string', minLength: 3, maxLength: 256 },
            projectId: { type: 'string', minLength: 8, maxLength: 12 },
          },
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params as { id: string }
      const { model, projectId } = request.body as { model: string; projectId?: string }
      const wf = db.prepare('SELECT * FROM workflows WHERE id = ?').get(id) as WorkflowRow | undefined
      if (!wf) return reply.code(404).send({ error: { message: 'سير العمل غير موجود', type: 'not_found', code: 404 } })
      try {
        registry.resolveModel(model)
      } catch (e) {
        return reply.code(400).send({ error: { message: e instanceof Error ? e.message : 'نموذج غير صالح', type: 'invalid_request_error', code: 400 } })
      }
      if (projectId && !db.prepare('SELECT id FROM projects WHERE id = ?').get(projectId)) {
        return reply.code(404).send({ error: { message: 'مساحة المشروع غير موجودة', type: 'not_found', code: 404 } })
      }
      const steps = parseSteps(JSON.parse(wf.steps))
      if (!steps) return reply.code(409).send({ error: { message: 'خطوات سير العمل غير صالحة', type: 'invalid_state', code: 409 } })

      const runId = randomBytes(5).toString('hex')
      db.prepare("INSERT INTO workflow_runs (id, workflow_id, status, task_ids, started_at) VALUES (?, ?, 'running', '[]', ?)").run(
        runId,
        id,
        new Date().toISOString(),
      )

      // Sequential execution through the REAL engine. Fire-and-forget: the
      // client follows the run row (GET /api/workflows/:id) and each task's
      // own SSE stream. Honesty: failures mark the run 'partial'/'failed'.
      void (async () => {
        const taskIds: number[] = []
        let failed = 0
        try {
          for (const step of steps) {
            const goal = step.role && isAgentRole(step.role)
              ? `${step.prompt}\n\n(الوكيل المتخصص المقترح لهذه الخطوة: ${AGENT_ROLES[step.role].labelEn} — المخطط يقرر التعيين النهائي)`
              : step.prompt
            const info = db
              .prepare("INSERT INTO agent_tasks (goal, model, status, source, project_id, mode) VALUES (?, ?, 'queued', 'workflow', ?, 'auto')")
              .run(goal, model, projectId ?? null)
            const taskId = Number(info.lastInsertRowid)
            taskIds.push(taskId)
            db.prepare('UPDATE workflow_runs SET task_ids = ? WHERE id = ?').run(JSON.stringify(taskIds), runId)
            const modelFn = buildModelFn({ db, config, registry, vault, log, model, source: 'workflow' })
            await runAgentTask({ db, config, registry, vault, log, memory, modelFn }, taskId)
            const st = getTask(db, taskId)?.status ?? 'failed'
            if (st !== 'completed') failed++
          }
          const status = failed === 0 ? 'completed' : failed === steps.length ? 'failed' : 'partial'
          db.prepare('UPDATE workflow_runs SET status = ?, finished_at = ? WHERE id = ?').run(status, new Date().toISOString(), runId)
        } catch (e) {
          db.prepare('UPDATE workflow_runs SET status = ?, detail = ?, finished_at = ? WHERE id = ?').run(
            'failed',
            e instanceof Error ? e.message.slice(0, 500) : 'خطأ غير معروف',
            new Date().toISOString(),
            runId,
          )
        }
      })()

      return reply.code(202).send({ run: db.prepare('SELECT * FROM workflow_runs WHERE id = ?').get(runId) })
    },
  )

  app.get('/api/workflow-runs/:runId', async (request, reply) => {
    const { runId } = request.params as { runId: string }
    const run = db.prepare('SELECT * FROM workflow_runs WHERE id = ?').get(runId) as WorkflowRunRow | undefined
    if (!run) return reply.code(404).send({ error: { message: 'التشغيلة غير موجودة', type: 'not_found', code: 404 } })
    const taskIds = JSON.parse(run.task_ids) as number[]
    const tasks = taskIds.map((tid) => getTask(db, tid)).filter(Boolean)
    return { run, tasks }
  })
}
