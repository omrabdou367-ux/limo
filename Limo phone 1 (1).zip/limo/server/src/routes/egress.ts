import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import { egressCounts, listEgress } from '../db/egress.js'

/**
 * «ما غادر الجهاز» — the egress screen API (owner directive v2.2 #7).
 * Rows carry provider/model/payload-size/fingerprint only; content is never
 * stored, so it can never leak from this endpoint either.
 */
export function registerEgressRoutes(app: FastifyInstance, ctx: { db: DB }): void {
  app.get('/api/egress', async (request) => {
    const q = request.query as { left?: string; limit?: string; source?: string }
    const leftOnly = q.left === '1' || q.left === 'true'
    const limit = q.limit === undefined ? 100 : Number(q.limit)
    return {
      counts: egressCounts(ctx.db),
      rows: listEgress(ctx.db, {
        leftOnly,
        limit: Number.isFinite(limit) ? limit : 100,
        source: q.source,
      }),
    }
  })
}
