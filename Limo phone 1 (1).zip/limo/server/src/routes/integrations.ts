import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import { keyAliasFor } from '../providers/registry.js'
import { listCatalogModels } from '../db/catalog.js'

/**
 * LIMO #21 — «التكاملات» (the Krea-parity Integrations catalog): what is
 * ACTUALLY connected, MEASURED at request time — the vault (provider keys),
 * the real Vercel deployment center (#20), and the real skills sources. No
 * catalog of services LIMO cannot drive: every row here maps to real code
 * paths, and «connected» means a key in the vault (or a keyless local
 * adapter), never a wish.
 */

export interface IntegrationsRouteDeps {
  db: DB
  config: ServerConfig
  registry: ProviderRegistry
  vault: Vault
}

export interface IntegrationCard {
  id: string
  name: string
  kind: 'intelligence' | 'deploy' | 'source'
  needsKey: boolean
  keyStored: boolean
  connected: boolean
  vaultLocked: boolean
  /** real, measured detail line (Arabic) */
  detail: string
  /** where the UI connects it (a real surface) */
  connectArea: 'integrations' | 'systemmap' | 'vault'
  /** the real permission envelope, stated plainly */
  permissions: string
}

export function registerIntegrationsRoutes(app: FastifyInstance, deps: IntegrationsRouteDeps): void {
  const { db, registry, vault } = deps

  app.get('/api/integrations', async () => {
    // per-provider model counts from the daily catalog aggregate (real rows;
    // live probing stays in the system map — this endpoint stays snappy)
    const counts = new Map<string, number>()
    for (const r of listCatalogModels(db)) counts.set(r.provider, (counts.get(r.provider) ?? 0) + 1)

    const cards: IntegrationCard[] = []

    for (const a of registry.list()) {
      const keyStored = a.needsKey ? vault.hasSecret(keyAliasFor(a.id)) : false
      const connected = !a.needsKey || keyStored
      cards.push({
        id: a.id,
        name: a.label || a.id,
        kind: 'intelligence',
        needsKey: a.needsKey,
        keyStored,
        connected,
        vaultLocked: !vault.isUnlocked,
        detail: connected
          ? a.needsKey
            ? `المفتاح مخزَّن مشفّرًا في الخزنة · ${counts.get(a.id) ?? 0} نموذجًا في فهرس اليوم`
            : `مزود محلي بلا مفتاح · ${counts.get(a.id) ?? 0} نموذجًا في فهرس اليوم`
          : vault.isUnlocked
            ? 'لا مفتاح في الخزنة — الصق مفتاح المزود ليصبح قابلًا للاستخدام فعلًا'
            : 'الخزنة مقفلة (بعد إعادة التشغيل) — افتحها لتقرأ المفاتيح',
        connectArea: 'integrations',
        permissions: a.needsKey
          ? 'المفتاح يخدم نداءات النماذج فقط · AES-256-GCM في الخزنة · لا يُعاد في أي مسار API'
          : 'يعمل محليًا بلا مفتاح ولا صلاحيات سحابية',
      })
    }

    // Vercel — the real deployment command center (#20): token in the vault,
    // project + deployment ledger counts from the REAL rows.
    const vercelStored = vault.hasSecret('vercel')
    const project = ((db.prepare('SELECT value FROM settings WHERE key = ?').get('vercel_project') as { value: string } | undefined)?.value ?? '').trim() || 'limo-agent'
    const deploys = (db.prepare('SELECT COUNT(*) AS n FROM deployments').get() as { n: number }).n
    cards.push({
      id: 'vercel',
      name: 'Vercel',
      kind: 'deploy',
      needsKey: true,
      keyStored: vercelStored,
      connected: vercelStored,
      vaultLocked: !vault.isUnlocked,
      detail: vercelStored
        ? `الرمز مخزَّن مشفّرًا · مشروع «${project}» · ${deploys} نشرة في الدفتر`
        : 'لا رمز Vercel في الخزنة — يُضاف من شاشة خريطة النظام (لا يُقبل في الدردشة)',
      connectArea: 'systemmap',
      permissions:
        'نشر المعاينة عبر الصندوق بأدوات deploy_* · الإنتاج والتراجع زرا المالك فقط من خريطة النظام · الرمز AES-256-GCM ولا يُعاد في أي مسار',
    })

    // GitHub — the real skills source: public read through the official API
    // with the jsDelivr mirror fallback measured in #20. No token, no write.
    const skills = (db.prepare('SELECT COUNT(*) AS n FROM skills').get() as { n: number }).n
    cards.push({
      id: 'github',
      name: 'GitHub',
      kind: 'source',
      needsKey: false,
      keyStored: false,
      connected: true,
      vaultLocked: !vault.isUnlocked,
      detail: `قراءة عامة للمستودعات العامة لتثبيت المهارات (GitHub API + مرآة jsDelivr) · ${skills} مهارة مثبتة`,
      connectArea: 'integrations',
      permissions: 'قراءة فقط · بلا رمز · بلا صلاحيات كتابة على أي مستودع',
    })

    return { generatedAt: new Date().toISOString(), integrations: cards }
  })
}
