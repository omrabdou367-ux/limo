/**
 * LIMO DEPLOYMENT COMMAND CENTER — routes (LIMO #20, directive §11–12).
 *
 * The real pipeline: artifact collected from the ACTUAL static export the
 * server serves → uploaded to the owner's Vercel (official REST, vault-held
 * token) → state read back from the API → recorded in the local ledger.
 *
 * Security doctrine (§12, enforced here in code, not in prose):
 *  - the token NEVER leaves the vault except into the Authorization header;
 *  - no route ever returns the token (state says configured: true/false only);
 *  - PREVIEW is a normal authenticated action; PRODUCTION promote + rollback
 *    are OWNER actions on their own routes and are never exposed to the box
 *    model (destructive owner words never wait for a model turn — #12).
 */
import { randomUUID } from 'node:crypto'
import { existsSync } from 'node:fs'
import type { FastifyInstance, FastifyReply } from 'fastify'
import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Vault } from '../vault/vault.js'
import { ArtifactError, collectArtifact } from '../deploy/artifact.js'
import {
  vercelAssignAlias,
  vercelDeployment,
  vercelDeploymentLogs,
  vercelDeployFiles,
  vercelDeployments,
  vercelEnsureProject,
  vercelPreviewProtection,
  vercelSetPreviewProtection,
  vercelUser,
  VercelError,
} from '../deploy/vercel.js'

export const VERCEL_ALIAS = 'vercel'
export const PROJECT_KEY = 'vercel_project'
const DEFAULT_PROJECT = 'limo-agent'

interface DeployDeps {
  db: DB
  config: ServerConfig
  vault: Vault
}

function projectName(db: DB): string {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(PROJECT_KEY) as { value: string } | undefined
  const v = (row?.value ?? '').trim()
  return /^[a-z0-9_-]{1,52}$/.test(v) ? v : DEFAULT_PROJECT
}

function recordDeployment(db: DB, d: { deploymentId: string; project: string; url: string | null; target: string; state: string; fileCount: number; totalBytes: number }): void {
  db.prepare(
    `INSERT INTO deployments (deployment_id, project, url, target, state, file_count, total_bytes, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(deployment_id) DO UPDATE SET state = excluded.state, url = excluded.url, updated_at = excluded.created_at`,
  ).run(d.deploymentId, d.project, d.url, d.target, d.state, d.fileCount, d.totalBytes, new Date().toISOString())
}

function updateState(db: DB, deploymentId: string, state: string, url: string | null): void {
  db.prepare('UPDATE deployments SET state = ?, url = COALESCE(?, url), updated_at = ? WHERE deployment_id = ?').run(
    state, url, new Date().toISOString(), deploymentId,
  )
}

/** Translate infra errors into honest HTTP replies; never leak the token. */
async function guard(reply: FastifyReply, fn: () => Promise<unknown>): Promise<unknown> {
  try {
    return await fn()
  } catch (e) {
    if (e instanceof VercelError) {
      return reply.code(502).send({ error: { type: 'vercel_error', status: e.status, message: e.message.slice(0, 300) } })
    }
    if (e instanceof ArtifactError) {
      return reply.code(400).send({ error: { type: 'artifact_error', message: e.message } })
    }
    throw e
  }
}

export function registerDeployRoutes(app: FastifyInstance, ctx: DeployDeps): void {
  const { db, config, vault } = ctx

  /** The shared happy path: collect the real artifact and upload it. */
  async function deploy(target: 'preview' | 'production'): Promise<{ statusCode: 202 | 400; body: Record<string, unknown> }> {
    const token = vault.getSecret(VERCEL_ALIAS)
    if (!token) {
      return { statusCode: 400, body: { error: { type: 'no_token', message: 'لا يوجد رمز Vercel في الخزنة — أضِفه أولًا (POST /api/deploy/token)' } } }
    }
    if (!config.webDist || !existsSync(config.webDist)) {
      return { statusCode: 400, body: { error: { type: 'no_artifact', message: 'لا يوجد بناء ثابت للواجهة (WEB_DIST مفقود) — ابنِ الواجهة أولًا' } } }
    }
    const user = await vercelUser(token)
    const ensured = await vercelEnsureProject(token, projectName(db))
    const artifact = collectArtifact(config.webDist)
    const ref = await vercelDeployFiles({ token, projectName: ensured.name, files: artifact.files, target })
    recordDeployment(db, {
      deploymentId: ref.id, project: ensured.name, url: ref.url, target, state: ref.readyState,
      fileCount: artifact.fileCount, totalBytes: artifact.totalBytes,
    })
    return {
      statusCode: 202,
      body: {
        deploymentId: ref.id,
        readyState: ref.readyState,
        url: ref.url,
        target,
        project: ensured.name,
        uploadedFiles: artifact.fileCount,
        uploadedBytes: artifact.totalBytes,
        account: user.username,
      },
    }
  }

  app.get('/api/deploy/state', async (_req, reply) =>
    guard(reply, async () => {
      const token = vault.getSecret(VERCEL_ALIAS)
      const distPresent = Boolean(config.webDist && existsSync(config.webDist))
      const base: Record<string, unknown> = {
        configured: Boolean(token),
        project: projectName(db),
        webDist: distPresent ? config.webDist : null,
      }
      if (!token) return base
      const user = await vercelUser(token)
      base.username = user.username
      const ensured = await vercelEnsureProject(token, projectName(db))
      base.deployments = await vercelDeployments(token, ensured.id, 8)
      base.previewProtection = await vercelPreviewProtection(token, ensured.name)
      base.history = db
        .prepare('SELECT deployment_id, url, target, state, file_count, total_bytes, created_at FROM deployments ORDER BY id DESC LIMIT 8')
        .all()
      return base
    }),
  )

  /** OWNER decision: public previews or the Vercel auth wall. Disclosed in UI. */
  app.post('/api/deploy/protection', async (request, reply) =>
    guard(reply, async () => {
      const body = (request.body ?? {}) as { publicPreviews?: unknown }
      const token = vault.getSecret(VERCEL_ALIAS)
      if (!token) return reply.code(400).send({ error: { type: 'no_token', message: 'لا يوجد رمز Vercel في الخزنة' } })
      const next = body.publicPreviews === true ? null : 'all_except_custom_domains'
      const now = await vercelSetPreviewProtection(token, projectName(db), next)
      return { ok: true, previewProtection: now }
    }),
  )

  /**
   * REAL content verification (TEST D): fetch the deployment URL and classify
   * what actually answered — the LIMO UI, the Vercel auth wall, or something
   * else. The result is what the wire carried, never an assumption.
   */
  app.get('/api/deploy/verify/:id', async (request, reply) =>
    guard(reply, async () => {
      const { id } = request.params as { id: string }
      const token = vault.getSecret(VERCEL_ALIAS)
      if (!token) return reply.code(400).send({ error: { type: 'no_token', message: 'لا يوجد رمز Vercel في الخزنة' } })
      const state = await vercelDeployment(token, id)
      if (!state.url) return reply.code(409).send({ error: { type: 'no_url', message: 'Vercel لم يعِد عنوانًا لهذه النشرة' } })
      const full = `https://${state.url}`
      const ctrl = new AbortController()
      const timer = setTimeout(() => ctrl.abort(), 20_000)
      let status = 0
      let body = ''
      try {
        const res = await fetch(full, { signal: ctrl.signal, headers: { 'user-agent': 'limo-deployment-verify/1.0' } })
        status = res.status
        body = (await res.text()).slice(0, 200_000)
      } finally {
        clearTimeout(timer)
      }
      const served = /Protected by Vercel Authentication/i.test(body)
        ? 'vercel-wall'
        : /<div id="root">|limo/i.test(body)
          ? 'limo-ui'
          : 'other'
      updateState(db, id, state.readyState, state.url)
      return {
        deploymentId: id,
        url: full,
        httpStatus: status,
        bytes: body.length,
        served,
        hasRoot: /<div id="root">/.test(body),
        checkedAt: new Date().toISOString(),
      }
    }),
  )

  app.post('/api/deploy/token', async (request, reply) =>
    guard(reply, async () => {
      const body = (request.body ?? {}) as { token?: unknown }
      const token = typeof body.token === 'string' ? body.token.trim() : ''
      if (token.length < 20) {
        return reply.code(422).send({ error: { type: 'bad_token', message: 'الرمز قصير جدًا — الصقه كما هو من إعدادات Vercel' } })
      }
      const user = await vercelUser(token).catch((e: unknown) => {
        if (e instanceof VercelError && (e.status === 401 || e.status === 403)) return null
        throw e
      })
      if (!user) {
        return reply.code(401).send({ error: { type: 'token_rejected', message: 'رفضت Vercel هذا الرمز (401/403) — لم يُخزَّن شيء' } })
      }
      vault.putSecret(VERCEL_ALIAS, 'vercel', token)
      return { ok: true, username: user.username }
    }),
  )

  app.delete('/api/deploy/token', async () => {
    const removed = vault.removeSecret(VERCEL_ALIAS)
    return { ok: true, removed }
  })

  app.post('/api/deploy/preview', async (_req, reply) =>
    guard(reply, async () => {
      const r = await deploy('preview')
      return reply.code(r.statusCode).send(r.body)
    }),
  )

  app.get('/api/deploy/status/:id', async (request, reply) =>
    guard(reply, async () => {
      const { id } = request.params as { id: string }
      const token = vault.getSecret(VERCEL_ALIAS)
      if (!token) return reply.code(400).send({ error: { type: 'no_token', message: 'لا يوجد رمز Vercel في الخزنة' } })
      const state = await vercelDeployment(token, id)
      updateState(db, id, state.readyState, state.url)
      return state
    }),
  )

  app.get('/api/deploy/logs/:id', async (request, reply) =>
    guard(reply, async () => {
      const { id } = request.params as { id: string }
      const token = vault.getSecret(VERCEL_ALIAS)
      if (!token) return reply.code(400).send({ error: { type: 'no_token', message: 'لا يوجد رمز Vercel في الخزنة' } })
      return { deploymentId: id, lines: await vercelDeploymentLogs(token, id, 120) }
    }),
  )

  app.get('/api/deploy/history', async () => {
    return db
      .prepare('SELECT deployment_id, project, url, target, state, file_count, total_bytes, created_at, updated_at FROM deployments ORDER BY id DESC LIMIT 50')
      .all()
  })

  // ---------------------------------------------------------------- owner-only
  // Production promote + rollback: the OWNER's buttons, never box tools.

  app.post('/api/deploy/promote/:id', async (request, reply) =>
    guard(reply, async () => {
      const { id } = request.params as { id: string }
      const token = vault.getSecret(VERCEL_ALIAS)
      if (!token) return reply.code(400).send({ error: { type: 'no_token', message: 'لا يوجد رمز Vercel في الخزنة' } })
      const state = await vercelDeployment(token, id)
      if (state.readyState !== 'READY') {
        return reply.code(409).send({ error: { type: 'not_ready', message: `النشر ليس READY (حالته ${state.readyState}) — لا ترقية إلا لما جهّزت Vercel فعلًا` } })
      }
      const project = projectName(db)
      const alias = `${project}.vercel.app`
      const res = await vercelAssignAlias(token, id, alias)
      if (!res.assigned) {
        return reply.code(502).send({ error: { type: 'alias_failed', message: `فشل إسناد النطاق: ${res.detail}` } })
      }
      db.prepare('INSERT INTO deployments (deployment_id, project, url, target, state, note, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
        `promote-${randomUUID().slice(0, 8)}`, project, state.url, 'production', 'PROMOTED', `alias ${alias} → ${id}`, new Date().toISOString(),
      )
      return { ok: true, alias, deploymentId: id, url: state.url }
    }),
  )

  app.post('/api/deploy/rollback/:id', async (request, reply) =>
    guard(reply, async () => {
      const { id } = request.params as { id: string }
      const token = vault.getSecret(VERCEL_ALIAS)
      if (!token) return reply.code(400).send({ error: { type: 'no_token', message: 'لا يوجد رمز Vercel في الخزنة' } })
      const state = await vercelDeployment(token, id)
      if (state.readyState !== 'READY') {
        return reply.code(409).send({ error: { type: 'not_ready', message: `النشر ليس READY (حالته ${state.readyState}) — لا استرجاع إلا لما جهّزت Vercel فعلًا` } })
      }
      const project = projectName(db)
      const alias = `${project}.vercel.app`
      const res = await vercelAssignAlias(token, id, alias)
      if (!res.assigned) {
        return reply.code(502).send({ error: { type: 'alias_failed', message: `فشل الاسترجاع: ${res.detail}` } })
      }
      db.prepare('INSERT INTO deployments (deployment_id, project, url, target, state, note, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
        `rollback-${randomUUID().slice(0, 8)}`, project, state.url, 'production', 'ROLLED_BACK', `alias ${alias} → ${id}`, new Date().toISOString(),
      )
      return { ok: true, alias, deploymentId: id, url: state.url }
    }),
  )
}
