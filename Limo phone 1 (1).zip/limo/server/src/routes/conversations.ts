import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import { addMessage, createConversation, deleteConversation, getConversation, listConversations, listMessages, updateConversation } from '../db/conversations.js'
import { recentUsage } from '../db/usage.js'

/** Saved conversations (UI) + usage readback. The /v1 gateway stays pure. */
export function registerConversationRoutes(app: FastifyInstance, ctx: { db: DB }): void {
  const { db } = ctx

  app.get('/api/conversations', async () => listConversations(db))

  app.post(
    '/api/conversations',
    {
      schema: {
        body: {
          type: 'object',
          additionalProperties: false,
          properties: { title: { type: 'string', maxLength: 128 }, model: { type: 'string', maxLength: 256 } },
        },
      },
    },
    async (request) => {
      const body = (request.body ?? {}) as { title?: string; model?: string }
      return createConversation(db, body.title, body.model)
    },
  )

  app.get('/api/conversations/:id', async (request, reply) => {
    const id = numParam(request.params)
    const conv = id === null ? undefined : getConversation(db, id)
    if (!conv) return reply.code(404).send(notFound())
    return { ...conv, messages: listMessages(db, conv.id) }
  })

  app.patch(
    '/api/conversations/:id',
    {
      schema: {
        body: {
          type: 'object',
          additionalProperties: false,
          properties: { title: { type: 'string', maxLength: 128 }, model: { type: 'string', maxLength: 256 } },
        },
      },
    },
    async (request, reply) => {
      const id = numParam(request.params)
      if (id === null || !updateConversation(db, id, request.body as { title?: string; model?: string })) {
        return reply.code(404).send(notFound())
      }
      return getConversation(db, id!)
    },
  )

  app.delete('/api/conversations/:id', async (request, reply) => {
    const id = numParam(request.params)
    if (id === null || !deleteConversation(db, id)) return reply.code(404).send(notFound())
    return { ok: true }
  })

  app.get('/api/conversations/:id/messages', async (request, reply) => {
    const id = numParam(request.params)
    if (id === null || !getConversation(db, id)) return reply.code(404).send(notFound())
    return listMessages(db, id)
  })

  app.post(
    '/api/conversations/:id/messages',
    {
      schema: {
        body: {
          type: 'object',
          required: ['role', 'content'],
          additionalProperties: false,
          properties: {
            role: { type: 'string', enum: ['user', 'assistant', 'system'] },
            content: { type: 'string', minLength: 1, maxLength: 100_000 },
            model: { type: 'string', maxLength: 256 },
          },
        },
      },
    },
    async (request, reply) => {
      const id = numParam(request.params)
      if (id === null || !getConversation(db, id)) return reply.code(404).send(notFound())
      const { role, content, model } = request.body as { role: 'user' | 'assistant' | 'system'; content: string; model?: string }
      return addMessage(db, id, role, content, model ?? null)
    },
  )

  app.get('/api/usage/recent', async (request) => {
    const q = request.query as { limit?: string }
    const limit = Math.min(Math.max(Number(q.limit ?? 50) || 50, 1), 500)
    return recentUsage(db, limit)
  })
}

function numParam(params: unknown): number | null {
  const n = Number((params as { id?: string }).id)
  return Number.isInteger(n) && n > 0 ? n : null
}

function notFound() {
  return { error: { message: 'المحادثة غير موجودة', type: 'not_found', code: 404 } }
}
