/**
 * LIMO COMPUTER PRO — the live system map (decision #17).
 *
 * GET /api/system/map  → product identity + LIVE probes + the audited
 *                        subsystem registry (statuses are audit results,
 *                        clearly dated — never presented as live truth).
 * GET /api/system/engines → honest Blender/Godot/Unreal detection.
 *
 * Everything numeric here is measured at request time from the real DB /
 * registry — no hardcoded counts, no aspirational subsystems.
 */
import { existsSync, readFileSync, statSync } from 'node:fs'
import { join } from 'node:path'
import type { FastifyInstance } from 'fastify'
import type { ServerConfig } from '../config.js'
import type { DB } from '../db/database.js'
import type { ProviderRegistry } from '../providers/registry.js'
import type { Vault } from '../vault/vault.js'
import type { VectorMemory } from '../agent/memory.js'
import { builtinTools } from '../agent/tools.js'
import { TOOLS as BOX_TOOLS, usableModels } from '../box/brain.js'
import { AUDIT_DATE, SUBSYSTEMS, SUBSYSTEM_STATUSES } from '../system/registry.js'
import { detectEngines, platformInfo } from '../system/engines.js'

const pkg = JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf8')) as {
  version: string
}

interface SystemDeps {
  db: DB
  config: ServerConfig
  registry: ProviderRegistry
  vault: Vault
  memory: VectorMemory
}

function count(db: DB, sql: string): number {
  const row = db.prepare(sql).get() as { c: number } | undefined
  return row?.c ?? 0
}

/** The gauntlet writes its result here; absent = honestly "never run here". */
function readLastGauntlet(dataDir: string): { passed: number; total: number; at: string } | null {
  const file = join(dataDir, 'last-gauntlet.json')
  if (!existsSync(file)) return null
  try {
    const raw = JSON.parse(readFileSync(file, 'utf8')) as { passed?: number; total?: number; at?: string }
    if (typeof raw.passed === 'number' && typeof raw.total === 'number' && typeof raw.at === 'string') {
      return { passed: raw.passed, total: raw.total, at: raw.at }
    }
    return null
  } catch {
    return null
  }
}

export function registerSystemRoutes(app: FastifyInstance, ctx: SystemDeps): void {
  const { db, config, registry, vault, memory } = ctx

  app.get('/api/system/engines', async () => ({
    platform: platformInfo(),
    engines: await detectEngines(),
  }))

  // LIMO #21 — «الأدوات والإضافات» (the Krea-parity Plugins tab): the REAL
  // registered inventories, straight from the two registries — nothing here
  // is aspirational; a tool listed is a tool the code actually dispatches.
  app.get('/api/system/tools', async () => ({
    box: {
      surface: 'box',
      count: BOX_TOOLS.length,
      tools: BOX_TOOLS.map((t) => ({ name: t.name, description: t.description, mutates: t.mutates })),
    },
    agent: {
      surface: 'agent',
      count: builtinTools.length,
      tools: builtinTools.map((t) => ({ name: t.name, description: t.description, risk: t.risk ?? null })),
    },
    total: BOX_TOOLS.length + builtinTools.length,
  }))

  app.get('/api/system/map', async () => {
    const usable = await usableModels(db, registry, vault, config)
    const tables = count(db, "SELECT COUNT(*) c FROM sqlite_master WHERE type='table'")
    const dbFile = join(config.dataDir, 'omnara.db')
    const dbBytes = existsSync(dbFile) ? statSync(dbFile).size : 0
    const lastTask = db.prepare(
      "SELECT id, status, created_at FROM agent_tasks ORDER BY id DESC LIMIT 1",
    ).get() as { id: number; status: string; created_at: string } | undefined

    return {
      product: {
        name: 'LIMO COMPUTER PRO',
        base: 'LIMO AGENT',
        version: pkg.version,
        auditDate: AUDIT_DATE,
      },
      live: {
        usableModels: usable.length,
        vaultState: vault.state,
        memoryMode: memory.mode, // 'sqlite-vec' | 'js-cosine' — always honest
        memoryCount: count(db, 'SELECT COUNT(*) c FROM agent_memories'),
        agentTools: builtinTools.length,
        boxTools: BOX_TOOLS.length,
        projects: count(db, 'SELECT COUNT(*) c FROM projects'),
        skillsActive: count(db, "SELECT COUNT(*) c FROM skills WHERE status2 = 'active' OR (status2 IS NULL AND status = 'active')"),
        conversations: count(db, 'SELECT COUNT(*) c FROM conversations'),
        agentTasks: count(db, 'SELECT COUNT(*) c FROM agent_tasks'),
        lastAgentTask: lastTask ?? null,
        dbTables: tables,
        dbBytes,
        gauntlet: readLastGauntlet(config.dataDir),
      },
      platform: platformInfo(),
      subsystems: SUBSYSTEMS,
      statusLegend: SUBSYSTEM_STATUSES,
    }
  })
}
