import { randomBytes } from 'node:crypto'
import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Logger } from '../logger.js'
import { inspectSkill, parseGitHubUrl, type SkillInspectionReport } from '../skills/inspect.js'
import { installSkill, listSkillFiles, readSkillFile, removeSkillDir, fetchHeadCommit } from '../skills/install.js'
import { discoverSkills } from '../skills/discovery.js'
import { assessSecurity, type SecurityAssessment } from '../skills/security.js'
import { assessCompatibility, type CompatibilityAssessment } from '../skills/compatibility.js'
import { recordSkillEvent, skillEvents, lifecycleStatus } from '../skills/registry.js'
import { startSkillImport } from '../skills/pipeline.js'

/**
 * ALLIMNI routes — the Universal Skills Ecosystem (LIMO #11).
 *
 *  discovery (real providers, honest unavailability):
 *    GET  /api/skills/discover?q=&limit=&owner=
 *
 *  import (the 10-step approval workflow, now skills.sh-aware):
 *    POST /api/skills/import        { url }  |  { source, skillId, installs? }
 *    GET  /api/skills/imports        GET /api/skills/imports/:id
 *    POST /api/skills/imports/:id/decision   (HIGH/CRITICAL risk is refused here)
 *
 *  registry + management:
 *    GET    /api/skills            (rows + lifecycle + risk/compat)
 *    GET    /api/skills/:slug      (details + files + events)
 *    PATCH  /api/skills/:slug      (enable/disable, agents)
 *    DELETE /api/skills/:slug      (disk + row, event kept)
 *    POST   /api/skills/:slug/check-update
 *    GET    /api/skills/events     (activity history)
 *
 * No ratings, download counts, or certifications are shown anywhere except
 * what skills.sh itself measured (installs, labelled with fetch time).
 */

export interface SkillRouteDeps {
  db: DB
  config: ServerConfig
  log: Logger
}

export interface SkillImportRow {
  id: string
  url: string
  status: 'inspecting' | 'awaiting_approval' | 'installed' | 'rejected' | 'failed'
  report: string | null
  error: string | null
  requested_at: string
  decided_at: string | null
}

export interface SkillRow {
  id: string
  name: string
  slug: string
  version: string | null
  description: string
  source: string
  source_url: string | null
  repo_owner: string | null
  repo_name: string | null
  commit_hash: string | null
  license: string | null
  status: string
  status2: string | null
  skill_id: string | null
  provider: string
  installs: number | null
  risk_level: string | null
  compatibility: string | null
  security_report: string | null
  agents: string
  last_check: string | null
  update_available: string | null
  manifest: string
  file_count: number
  installed_at: string
}

export interface ImportResponse {
  import: SkillImportRow
  report: SkillInspectionReport
  security: SecurityAssessment
  compatibility: CompatibilityAssessment
}

function rowWithLifecycle(row: SkillRow) {
  return { ...row, lifecycle: lifecycleStatus(row) }
}

export function registerSkillRoutes(app: FastifyInstance, deps: SkillRouteDeps): void {
  const { db, config, log } = deps

  // ------------------------------------------------------------- discovery

  app.get(
    '/api/skills/discover',
    {
      schema: {
        querystring: {
          type: 'object',
          additionalProperties: false,
          properties: {
            q: { type: 'string', minLength: 1, maxLength: 300 },
            limit: { type: 'integer', minimum: 1, maximum: 50 },
            owner: { type: 'string', minLength: 1, maxLength: 100 },
          },
          required: ['q'],
        },
      },
    },
    async (request) => {
      const { q, limit, owner } = request.query as { q: string; limit?: number; owner?: string }
      return discoverSkills(db, q, { limit, owner })
    },
  )

  // ------------------------------------------------------------- the library

  app.get('/api/skills', async () => ({
    skills: (db.prepare('SELECT * FROM skills ORDER BY installed_at DESC').all() as SkillRow[]).map(rowWithLifecycle),
  }))

  app.get('/api/skills/events', async (request) => {
    const slug = String((request.query as { slug?: string }).slug ?? '')
    return { events: skillEvents(db, slug || undefined) }
  })

  app.get('/api/skills/:slug', async (request, reply) => {
    const { slug } = request.params as { slug: string }
    const skill = db.prepare('SELECT * FROM skills WHERE slug = ?').get(slug) as SkillRow | undefined
    if (!skill) return reply.code(404).send({ error: { message: 'المهارة غير موجودة', type: 'not_found', code: 404 } })
    return { skill: rowWithLifecycle(skill), files: listSkillFiles(config, slug), events: skillEvents(db, slug, 50) }
  })

  app.get('/api/skills/:slug/files/content', async (request, reply) => {
    const { slug } = request.params as { slug: string }
    const path = String((request.query as { path?: string }).path ?? '')
    if (!db.prepare('SELECT id FROM skills WHERE slug = ?').get(slug)) {
      return reply.code(404).send({ error: { message: 'المهارة غير موجودة', type: 'not_found', code: 404 } })
    }
    const file = readSkillFile(config, slug, path)
    if (!file) return reply.code(404).send({ error: { message: 'الملف غير موجود أو يتجاوز حد القراءة', type: 'not_found', code: 404 } })
    return { file }
  })

  app.patch(
    '/api/skills/:slug',
    {
      schema: {
        body: {
          type: 'object',
          required: ['status'],
          additionalProperties: false,
          properties: {
            status: { type: 'string', enum: ['active', 'disabled'] },
            agents: { type: 'string', maxLength: 500 },
          },
        },
      },
    },
    async (request, reply) => {
      const { slug } = request.params as { slug: string }
      const { status, agents } = request.body as { status: 'active' | 'disabled'; agents?: string }
      const row = db.prepare('SELECT * FROM skills WHERE slug = ?').get(slug) as SkillRow | undefined
      if (!row) return reply.code(404).send({ error: { message: 'المهارة غير موجودة', type: 'not_found', code: 404 } })
      db.prepare('UPDATE skills SET status = ?, status2 = ?, agents = COALESCE(?, agents) WHERE slug = ?').run(
        status,
        status,
        agents ?? null,
        slug,
      )
      recordSkillEvent(db, slug, status === 'active' ? 'enabled' : 'disabled', agents ? `agents=${agents}` : '')
      return { skill: rowWithLifecycle(db.prepare('SELECT * FROM skills WHERE slug = ?').get(slug) as SkillRow) }
    },
  )

  app.delete('/api/skills/:slug', async (request, reply) => {
    const { slug } = request.params as { slug: string }
    const row = db.prepare('SELECT * FROM skills WHERE slug = ?').get(slug) as SkillRow | undefined
    if (!row) return reply.code(404).send({ error: { message: 'المهارة غير موجودة', type: 'not_found', code: 404 } })
    db.prepare('DELETE FROM skills WHERE slug = ?').run(slug)
    removeSkillDir(config, slug)
    recordSkillEvent(db, slug, 'removed', `كان مثبتًا منذ ${row.installed_at}`)
    return { ok: true }
  })

  // ------------------------------------------------------------- update check

  app.post('/api/skills/:slug/check-update', async (request, reply) => {
    const { slug } = request.params as { slug: string }
    const row = db.prepare('SELECT * FROM skills WHERE slug = ?').get(slug) as SkillRow | undefined
    if (!row) return reply.code(404).send({ error: { message: 'المهارة غير موجودة', type: 'not_found', code: 404 } })
    if (!row.repo_owner || !row.repo_name) {
      return { skill: rowWithLifecycle(row), update: { checked: false, reason: 'المصدر ليس مستودع GitHub' } }
    }
    const head = await fetchHeadCommit(row.repo_owner, row.repo_name, 'main')
    const now = new Date().toISOString()
    if (!head) {
      db.prepare('UPDATE skills SET last_check = ? WHERE slug = ?').run(now, slug)
      recordSkillEvent(db, slug, 'update_check', 'تعذر جلب الالتزام الحالي (حد المعدل أو الشبكة)')
      return { skill: rowWithLifecycle(row), update: { checked: true, headCommit: null, reason: 'تعذر جلب رقم الالتزام الحالي — GitHub API محدود المعدل، أعد المحاولة لاحقًا' } }
    }
    const changed = row.commit_hash !== null && head !== row.commit_hash
    db.prepare('UPDATE skills SET last_check = ?, update_available = ? WHERE slug = ?').run(now, changed ? head : null, slug)
    recordSkillEvent(db, slug, changed ? 'update_available' : 'update_check', changed ? `${row.commit_hash ?? '—'} → ${head}` : `الالتزام لم يتغير (${head.slice(0, 12)})`)
    return {
      skill: rowWithLifecycle(db.prepare('SELECT * FROM skills WHERE slug = ?').get(slug) as SkillRow),
      update: { checked: true, headCommit: head, installedCommit: row.commit_hash, changed },
    }
  })

  // ------------------------------------------------------- import + approve

  app.get('/api/skills/imports', async () => ({
    imports: db.prepare('SELECT id, url, status, error, requested_at, decided_at FROM skill_imports ORDER BY requested_at DESC LIMIT 50').all(),
  }))

  app.get('/api/skills/imports/:id', async (request, reply) => {
    const { id } = request.params as { id: string }
    const row = db.prepare('SELECT * FROM skill_imports WHERE id = ?').get(id) as SkillImportRow | undefined
    if (!row) return reply.code(404).send({ error: { message: 'طلب الاستيراد غير موجود', type: 'not_found', code: 404 } })
    return { import: row }
  })

  app.post(
    '/api/skills/import',
    {
      schema: {
        body: {
          type: 'object',
          additionalProperties: false,
          properties: {
            url: { type: 'string', minLength: 8, maxLength: 512 },
            source: { type: 'string', minLength: 3, maxLength: 200 },
            skillId: { type: 'string', minLength: 1, maxLength: 200 },
            installs: { type: 'integer', minimum: 0 },
          },
          anyOf: [{ required: ['url'] }, { required: ['source'] }],
        },
      },
    },
    async (request, reply) => {
      const body = request.body as { url?: string; source?: string; skillId?: string; installs?: number }

      // the shared import pipeline (same one the Black Box brain tool uses) —
      // real bounded inspection, persisted row, owner decision later
      const started = await startSkillImport(db, body)
      if (started.kind === 'not_supported') {
        return reply.code(422).send({
          error: { message: started.reason, type: 'source_not_supported', code: 422 },
        })
      }
      if (started.kind === 'inspection_failed') {
        return reply.code(422).send({
          error: { message: `مانعات الفحص: ${started.blockers.join(' · ')}`, type: 'inspection_failed', code: 422 },
          import: db.prepare('SELECT * FROM skill_imports WHERE id = ?').get(started.importId) as SkillImportRow,
          report: started.report,
          security: started.security,
          compatibility: started.compatibility,
        } satisfies Partial<ImportResponse> & { error: { message: string; type: string; code: number } })
      }
      return reply.code(202).send({
        import: db.prepare('SELECT * FROM skill_imports WHERE id = ?').get(started.importId) as SkillImportRow,
        report: started.report,
        security: started.security,
        compatibility: started.compatibility,
      } satisfies Partial<ImportResponse>)
    },
  )

  app.post(
    '/api/skills/imports/:id/decision',
    {
      schema: {
        body: {
          type: 'object',
          required: ['decision'],
          additionalProperties: false,
          properties: { decision: { type: 'string', enum: ['approve', 'reject'] } },
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params as { id: string }
      const { decision } = request.body as { decision: 'approve' | 'reject' }
      const row = db.prepare('SELECT * FROM skill_imports WHERE id = ?').get(id) as SkillImportRow | undefined
      if (!row) return reply.code(404).send({ error: { message: 'طلب الاستيراد غير موجود', type: 'not_found', code: 404 } })
      if (row.status !== 'awaiting_approval') {
        return reply.code(409).send({ error: { message: `الطلب في حالة «${row.status}» — لا قرار مطلوبًا`, type: 'invalid_state', code: 409 } })
      }
      const now = new Date().toISOString()
      const payload = JSON.parse(row.report ?? '{}') as { report?: SkillInspectionReport; security?: SecurityAssessment; compatibility?: CompatibilityAssessment; installs?: number | null }
      const report = payload.report
      const security = payload.security

      if (decision === 'reject') {
        db.prepare("UPDATE skill_imports SET status = 'rejected', decided_at = ? WHERE id = ?").run(now, id)
        recordSkillEvent(db, report?.frontmatter?.name ?? row.url, 'rejected', 'قرار المالك: رفض')
        return { import: db.prepare('SELECT * FROM skill_imports WHERE id = ?').get(id) }
      }

      // the risk gate: HIGH/CRITICAL never installs, owner or not (directive §6)
      if (security && security.installBlocked) {
        recordSkillEvent(db, report?.frontmatter?.name ?? row.url, 'permission_denied', `رفض التثبيت تلقائيًا: مستوى الخطر ${security.riskLevel}`)
        return reply.code(409).send({
          error: {
            message: `مستوى الخطر ${security.riskLevel} — التثبيت ممنوع ببوابة الأمان بصرف النظر عن الموافقة؛ راجع النتائج في التقرير`,
            type: 'risk_blocked',
            code: 409,
          },
        })
      }
      if (!report) {
        return reply.code(409).send({ error: { message: 'لا تقرير فحص في الطلب — لا تثبيت بلا فحص', type: 'invalid_state', code: 409 } })
      }

      // approve → install (text-only copy, nothing executed)
      let installed
      try {
        installed = await installSkill(config, report)
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e)
        log.warn('skill install aborted', { id, err: msg })
        db.prepare("UPDATE skill_imports SET status = 'failed', error = ?, decided_at = ? WHERE id = ?").run(msg, now, id)
        recordSkillEvent(db, report.frontmatter?.name ?? row.url, 'rejected', `فشل التثبيت: ${msg}`)
        return reply.code(500).send({ error: { message: msg, type: 'install_failed', code: 500 } })
      }

      const skillId = randomBytes(5).toString('hex')
      const slug = installed.slug
      const replaced = db.prepare('SELECT id, installed_at FROM skills WHERE slug = ?').get(slug) as { id: string; installed_at: string } | undefined
      if (replaced) {
        // same skill re-imported (update path): replace the row (files already refreshed on disk)
        db.prepare('DELETE FROM skills WHERE slug = ?').run(slug)
      }
      db.prepare(
        `INSERT INTO skills (id, name, slug, version, description, source, source_url, repo_owner, repo_name, commit_hash, license,
         status, status2, skill_id, provider, installs, risk_level, compatibility, security_report, agents, manifest, file_count, installed_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', 'active', ?, ?, ?, ?, ?, ?, '*', ?, ?, ?)`,
      ).run(
        skillId,
        report.frontmatter?.name ?? report.target.skillId ?? `${report.repo.owner}/${report.repo.name}`,
        slug,
        report.frontmatter?.version ?? null,
        report.frontmatter?.description ?? '',
        report.target.skillId ? 'skills.sh' : 'allimni',
        row.url,
        report.repo.owner,
        report.repo.name,
        installed.commit,
        report.frontmatter?.license ?? report.repo.license ?? null,
        report.target.skillId ?? null,
        report.target.skillId ? 'skills.sh' : 'github',
        // installs as measured at discovery time — never live-updated (honesty)
        typeof payload.installs === 'number' ? payload.installs : null,
        security?.riskLevel ?? 'UNKNOWN',
        payload.compatibility?.state ?? 'UNKNOWN',
        JSON.stringify({ report, security, compatibility: payload.compatibility }),
        JSON.stringify({ files: installed.files.map((f) => f.path), totalBytes: installed.totalBytes }),
        installed.files.length,
        now,
      )
      db.prepare("UPDATE skill_imports SET status = 'installed', decided_at = ? WHERE id = ?").run(now, id)
      recordSkillEvent(db, slug, 'installed', `${installed.files.length} ملفًا · ${installed.totalBytes} بايت${installed.commit ? ` · ${installed.commit.slice(0, 12)}` : ''}${replaced ? ' (تحديث لمهارة موجودة)' : ''}`)
      return {
        import: db.prepare('SELECT * FROM skill_imports WHERE id = ?').get(id),
        skill: rowWithLifecycle(db.prepare('SELECT * FROM skills WHERE slug = ?').get(slug) as SkillRow),
      }
    },
  )
}
