import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import type { Logger } from '../logger.js'
import {
  cancelChange,
  createChange,
  currentMap,
  decideChange,
  forgeDepsFor,
  getChange,
  listChanges,
  readAutonomyLevel,
  readEngineeringModel,
  resolveForgeModel,
  rollbackChange,
  startChange,
  TERMINAL_STATUSES,
  type ForgeChangeRow,
  type ForgeDeps,
} from '../forge/orchestrator.js'
import { listProposals, persistProposals, proposeFromMap } from '../forge/evolution.js'
import { AUTONOMY_LEVELS, type AutonomyLevel } from '../forge/types.js'
import type { ArchitectureMap } from '../forge/scanner.js'
import { basename } from 'node:path'

/**
 * Reality Forge routes (RF spec §5/§10/§11) — the owner's control surface over
 * the self-modification engine. Everything sits behind the auth guard.
 *
 * Safety invariants (enforced here, not by convention):
 *  - The autonomy level lives in `settings` and is written ONLY by this
 *    authenticated route module. The orchestrator, the model and the proposals
 *    have NO code path to it — the system can never raise its own level.
 *  - Apply / reject / rollback are owner decisions; the change row pins the
 *    level it runs under at creation time.
 *  - Proposals are data: accepting one never starts a change — the owner
 *    files it as a request explicitly.
 */

export interface ForgeRouteDeps {
  db: DB
  config: ServerConfig
  registry: ProviderRegistry
  vault: Vault
  log: Logger
}

const AUTONOMY_KEY = 'forge_autonomy_level'
const ENGINEERING_KEY = 'forge_engineering_model'

// single implementation lives in the forge domain; re-exported for the box
// routes (LIMO #18 — the entry points share one reader, one writer key)
export function getAutonomyLevel(db: DB): AutonomyLevel {
  return readAutonomyLevel(db)
}

function setAutonomyLevel(db: DB, level: AutonomyLevel): void {
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(AUTONOMY_KEY, String(level))
}

/** A trimmed architecture map for the screen (the full map stays in the DB). */
function mapForScreen(map: ArchitectureMap) {
  return {
    root: map.root,
    scannedAt: map.scannedAt,
    layers: map.layers,
    files: map.files.length,
    edges: map.edges.length,
    entryPoints: map.entryPoints,
    moduleBoundaries: map.moduleBoundaries,
    patterns: map.patterns,
    conventions: map.conventions,
    duplication: map.duplication.slice(0, 10),
    debt: map.debt.slice(0, 20),
  }
}

export function registerForgeRoutes(app: FastifyInstance, deps: ForgeRouteDeps): void {
  const { db, config, registry, log } = deps
  const enabled = !!config.forgeRepoRoot

  const requireRepo = (): boolean => enabled

  // ------------------------------------------------- status + autonomy

  app.get('/api/forge/status', async () => ({
    enabled,
    repo: config.forgeRepoRoot ? basename(config.forgeRepoRoot) : null,
    repoRoot: config.forgeRepoRoot,
    level: getAutonomyLevel(db),
    levels: AUTONOMY_LEVELS,
    // LIMO #19: the DIRECT ACTION validation chain, exactly as configured —
    // an empty command is shown as empty (never a fake green step)
    chain: {
      install: config.forgeInstallCommand,
      lint: config.forgeLintCommand,
      tests: config.forgeTestCommand,
      build: config.forgeBuildCommand,
    },
    engineeringModel: readEngineeringModel(db),
  }))

  app.put(
    '/api/forge/autonomy',
    {
      schema: {
        body: {
          type: 'object',
          required: ['level'],
          additionalProperties: false,
          properties: { level: { type: 'integer', minimum: 0, maximum: 4 } },
        },
      },
    },
    async (request, reply) => {
      const { level } = request.body as { level: number }
      setAutonomyLevel(db, level as AutonomyLevel)
      log.info('forge: autonomy level set by owner', { level })
      return { level: getAutonomyLevel(db), levels: AUTONOMY_LEVELS }
    },
  )

  // ------------------------------------------------------------ map

  app.get('/api/forge/map', async (_request, reply) => {
    if (!requireRepo()) return reply.code(503).send({ error: { message: 'Reality Forge معطّل — لم يُعثر على مستودع git (اضبط FORGE_REPO_ROOT)', type: 'forge_disabled', code: 503 } })
    const map = currentMap({ ...deps, modelFn: null, model: null })
    if (!map) return reply.code(503).send({ error: { message: 'Reality Forge معطّل — لم يُعثر على مستودع git (اضبط FORGE_REPO_ROOT)', type: 'forge_disabled', code: 503 } })
    return { map: mapForScreen(map) }
  })

  // -------------------------------------------------------- changes

  app.get('/api/forge/changes', async (request) => {
    // LIMO #19 change memory: filtered + searchable history
    const q = request.query as { status?: string; q?: string; since?: string; limit?: string }
    const limit = Number(q.limit)
    const changes = listChanges(db, {
      status: typeof q.status === 'string' ? q.status.slice(0, 20) : undefined,
      q: typeof q.q === 'string' ? q.q : undefined,
      since: typeof q.since === 'string' ? q.since : undefined,
      limit: Number.isFinite(limit) ? limit : undefined,
    })
    return { changes }
  })

  app.get('/api/forge/changes/:id', async (request, reply) => {
    const { id } = request.params as { id: string }
    const change = getChange(db, Number(id))
    if (!change) return reply.code(404).send({ error: { message: 'التغيير غير موجود', type: 'not_found', code: 404 } })
    const events = db.prepare('SELECT id, ts, actor, kind, data FROM forge_change_events WHERE change_id = ? ORDER BY id').all(change.id)
    return { change, events }
  })

  app.post(
    '/api/forge/changes',
    {
      schema: {
        body: {
          type: 'object',
          required: ['request'],
          additionalProperties: false,
          properties: {
            request: { type: 'string', minLength: 8, maxLength: 4000 },
            model: { type: ['string', 'null'], maxLength: 256 },
            level: { type: 'integer', minimum: 0, maximum: 4 },
          },
        },
      },
    },
    async (request, reply) => {
      if (!requireRepo()) return reply.code(503).send({ error: { message: 'Reality Forge معطّل — لم يُعثر على مستودع git (اضبط FORGE_REPO_ROOT)', type: 'forge_disabled', code: 503 } })
      const b = request.body as { request: string; model?: string | null; level?: number }
      const level = (b.level ?? getAutonomyLevel(db)) as AutonomyLevel
      // LIMO #19: the owner-pinned engineering model wins over the request's
      // conversation model — one resolver for REST, box and agent alike
      const model = resolveForgeModel(db, b.model ?? null)
      if (model) {
        try {
          registry.resolveModel(model) // fail fast on unknown provider/model
        } catch (e) {
          return reply.code(400).send({ error: { message: e instanceof Error ? e.message : 'نموذج غير صالح', type: 'invalid_request_error', code: 400 } })
        }
      }
      // LIMO #18: the shared entry point — identical to the box/agent path
      const id = createChange(db, b.request.trim(), model, level)
      startChange(forgeDepsFor(deps, model), id, log)
      return reply.code(201).send({ change: getChange(db, id) })
    },
  )

  /** Resume a stopped (non-terminal) change — optionally re-pinned to a new level. */
  app.post(
    '/api/forge/changes/:id/resume',
    {
      schema: {
        body: {
          type: 'object',
          additionalProperties: false,
          properties: { level: { type: 'integer', minimum: 0, maximum: 4 } },
        },
      },
    },
    async (request, reply) => {
      if (!requireRepo()) return reply.code(503).send({ error: { message: 'Reality Forge معطّل — لم يُعثر على مستودع git (اضبط FORGE_REPO_ROOT)', type: 'forge_disabled', code: 503 } })
      const { id } = request.params as { id: string }
      const change = getChange(db, Number(id))
      if (!change) return reply.code(404).send({ error: { message: 'التغيير غير موجود', type: 'not_found', code: 404 } })
      if (TERMINAL_STATUSES.includes(change.status)) {
        return reply.code(409).send({ error: { message: 'التغيير منتهٍ بالفعل', type: 'already_finished', code: 409 } })
      }
      const b = request.body as { level?: number }
      if (b.level !== undefined && b.level !== change.level) {
        db.prepare('UPDATE forge_changes SET level = ?, updated_at = ? WHERE id = ?').run(
          b.level,
          new Date().toISOString(),
          change.id,
        )
        db.prepare('INSERT INTO forge_change_events (change_id, actor, kind, data) VALUES (?, ?, ?, ?)').run(
          change.id,
          'owner',
          'level_changed',
          JSON.stringify({ from: change.level, to: b.level }),
        )
      }
      startChange(forgeDepsFor(deps, resolveForgeModel(db, change.model)), change.id, log)
      return { change: getChange(db, change.id) }
    },
  )

  /** The human gate: the owner decision on a change awaiting approval. */
  app.post(
    '/api/forge/changes/:id/decision',
    {
      schema: {
        body: {
          type: 'object',
          required: ['decision'],
          additionalProperties: false,
          properties: { decision: { type: 'string', enum: ['apply', 'reject'] } },
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params as { id: string }
      const { decision } = request.body as { decision: 'apply' | 'reject' }
      const row = await decideChange(forgeDepsFor(deps, resolveForgeModel(db, getChange(db, Number(id))?.model ?? null)), Number(id), decision)
      if (!('status' in row)) {
        const code = row.error === 'not_found' ? 404 : 409
        const messages: Record<string, string> = {
          not_found: 'التغيير غير موجود',
          not_awaiting_approval: 'التغيير ليس في انتظار موافقة',
          no_branch: 'لا يوجد فرع صندوق لهذا التغيير',
          forge_disabled: 'Reality Forge معطّل — لم يُعثر على مستودع git',
        }
        return reply.code(code).send({ error: { message: messages[row.error] ?? row.error, type: row.error, code } })
      }
      return { change: row }
    },
  )

  /** Rollback: a NEW revert commit — history and the audit trail stay intact. */
  app.post('/api/forge/changes/:id/rollback', async (request, reply) => {
    const { id } = request.params as { id: string }
    const row = await rollbackChange(forgeDepsFor(deps, null), Number(id))
    if (!('status' in row)) {
      const code = row.error === 'not_found' ? 404 : 409
      const messages: Record<string, string> = {
        not_found: 'التغيير غير موجود',
        not_applied: 'لا يمكن التراجع إلا عن تغيير مطبَّق',
        forge_disabled: 'Reality Forge معطّل — لم يُعثر على مستودع git',
      }
      return reply.code(code).send({ error: { message: messages[row.error] ?? row.error, type: row.error, code } })
    }
    return { change: row }
  })

  /** LIMO #19 (directive §7): the owner interrupts a running/stopped change.
   *  Terminal rows refuse with 409; a cancelled row can never be resumed. */
  app.post('/api/forge/changes/:id/cancel', async (request, reply) => {
    const { id } = request.params as { id: string }
    const row = await cancelChange(forgeDepsFor(deps, null), Number(id))
    if (!('status' in row)) {
      const code = row.error === 'not_found' ? 404 : 409
      const messages: Record<string, string> = {
        not_found: 'التغيير غير موجود',
        already_finished: 'التغيير منتهٍ بالفعل — لا إلغاء بعد الانتهاء',
      }
      return reply.code(code).send({ error: { message: messages[row.error] ?? row.error, type: row.error, code } })
    }
    return { change: row }
  })

  // ---------------------------------------- engineering intelligence pin
  // LIMO #19 (directive §8): the owner pins the forge's reasoning model —
  // e.g. NVIDIA Nemotron 3 Ultra through the real OpenRouter provider
  // (`openrouter/nvidia/nemotron-3-ultra-550b-a55b`). The pin never bypasses
  // the vault: no key ⇒ no modelFn ⇒ deterministic analysis only.

  app.get('/api/forge/engineering-model', async () => ({ model: readEngineeringModel(db) }))

  app.put(
    '/api/forge/engineering-model',
    {
      schema: {
        body: {
          type: 'object',
          required: ['model'],
          additionalProperties: false,
          properties: { model: { type: ['string', 'null'], maxLength: 256 } },
        },
      },
    },
    async (request, reply) => {
      const { model } = request.body as { model: string | null }
      if (model) {
        try {
          registry.resolveModel(model.trim()) // fail fast on unknown provider/model
        } catch (e) {
          return reply.code(400).send({ error: { message: e instanceof Error ? e.message : 'نموذج غير صالح', type: 'invalid_request_error', code: 400 } })
        }
        db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(ENGINEERING_KEY, model.trim())
        log.info('forge: engineering model pinned by owner', { model: model.trim() })
      } else {
        db.prepare('DELETE FROM settings WHERE key = ?').run(ENGINEERING_KEY)
        log.info('forge: engineering model pin cleared by owner')
      }
      return { model: readEngineeringModel(db) }
    },
  )

  // ------------------------------------------------------ proposals

  app.get('/api/forge/proposals', async (request) => {
    const status = (request.query as { status?: string }).status
    const allowed = ['proposed', 'accepted', 'dismissed']
    const filter = allowed.includes(status ?? '') ? status : undefined
    return { proposals: listProposals(db, filter) }
  })

  /** Regenerate proposals from the CURRENT architecture map — deterministic, no model. */
  app.post('/api/forge/proposals/generate', async (_request, reply) => {
    if (!requireRepo()) return reply.code(503).send({ error: { message: 'Reality Forge معطّل — لم يُعثر على مستودع git (اضبط FORGE_REPO_ROOT)', type: 'forge_disabled', code: 503 } })
    const map = currentMap({ ...deps, modelFn: null, model: null })
    if (!map) return reply.code(503).send({ error: { message: 'Reality Forge معطّل', type: 'forge_disabled', code: 503 } })
    const drafts = proposeFromMap(map)
    const n = persistProposals(db, drafts)
    return { generated: n, proposals: listProposals(db, 'proposed') }
  })

  /** Proposal status only — accepting never starts a change (owner files it). */
  app.post(
    '/api/forge/proposals/:id/status',
    {
      schema: {
        body: {
          type: 'object',
          required: ['status'],
          additionalProperties: false,
          properties: { status: { type: 'string', enum: ['accepted', 'dismissed'] } },
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params as { id: string }
      const { status } = request.body as { status: 'accepted' | 'dismissed' }
      const info = db.prepare('UPDATE forge_proposals SET status = ? WHERE id = ? AND status = ?').run(status, Number(id), 'proposed')
      if (info.changes === 0) {
        return reply.code(409).send({ error: { message: 'المقترح غير موجود أو حُسم من قبل', type: 'already_decided', code: 409 } })
      }
      return { proposal: db.prepare('SELECT * FROM forge_proposals WHERE id = ?').get(Number(id)) }
    },
  )
}

export type { ForgeChangeRow }
