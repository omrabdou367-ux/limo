import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import { keyAliasFor } from '../providers/registry.js'
import { ProviderError, type ChatMessage, type StreamEvent, type Usage } from '../providers/types.js'
import { recordUsage } from '../db/usage.js'
import { recordEgress, updateEgress } from '../db/egress.js'
import type { CircuitBreaker } from '../router/breaker.js'

/**
 * Comparison mode (PLAN.md §8.1.4): one prompt, N models, in PARALLEL, each
 * through the same adapter path as the gateway — with honest per-run metrics:
 * time-to-first-delta, total duration, tokens, tokens/second. Errors are
 * isolated: one failing model never fails the request.
 */

const compareSchema = {
  schema: {
    body: {
      type: 'object',
      required: ['models', 'messages'],
      additionalProperties: false,
      properties: {
        models: { type: 'array', minItems: 2, maxItems: 5, items: { type: 'string', minLength: 3, maxLength: 256 } },
        messages: {
          type: 'array',
          minItems: 1,
          maxItems: 200,
          items: {
            type: 'object',
            required: ['role', 'content'],
            additionalProperties: false,
            properties: {
              role: { type: 'string', enum: ['system', 'user', 'assistant'] },
              content: { type: 'string', minLength: 1, maxLength: 100_000 },
            },
          },
        },
        temperature: { type: 'number', minimum: 0, maximum: 2 },
      },
    },
  },
}

interface CompareResult {
  model: string
  provider: string
  ok: boolean
  content: string
  error: { kind: string; message: string } | null
  skipped: string | null
  metrics: {
    ttfbMs: number | null
    totalMs: number | null
    promptTokens: number | null
    completionTokens: number | null
    tokensPerSec: number | null
  }
}

export function registerCompareRoutes(
  app: FastifyInstance,
  ctx: { db: DB; config: ServerConfig; registry: ProviderRegistry; vault: Vault; breaker: CircuitBreaker },
): void {
  const { db, registry, vault, breaker } = ctx

  app.post('/api/compare', compareSchema, async (request, reply) => {
    const body = request.body as { models: string[]; messages: ChatMessage[]; temperature?: number }
    const models = [...new Set(body.models)]
    if (models.length < 2) {
      return reply.code(400).send({
        error: { message: 'وضع المقارنة يحتاج نموذجين مختلفين على الأقل', type: 'invalid_request_error', code: 400 },
      })
    }

    const results = await Promise.all(
      models.map((model) => runOne(model, body.messages, body.temperature)),
    )
    return { at: new Date().toISOString(), results }
  })

  async function runOne(model: string, messages: ChatMessage[], temperature?: number): Promise<CompareResult> {
    const started = Date.now()
    let providerId: string
    let modelId: string
    try {
      const resolved = registry.resolveModel(model)
      providerId = resolved.providerId
      modelId = resolved.modelId
    } catch (e) {
      const pe = e instanceof ProviderError ? e : new ProviderError('provider_error', String(e))
      return fail(model, '?', pe, started)
    }
    const adapter = registry.get(providerId)!

    // local configuration gates (never counted as provider failures)
    if (adapter.needsKey) {
      if (!vault.isUnlocked || !vault.hasSecret(keyAliasFor(providerId))) {
        const pe = new ProviderError(
          vault.isUnlocked ? 'missing_key' : 'vault_locked',
          vault.isUnlocked
            ? `${providerId}: لا يوجد مفتاح مضبوط — أضفه من لوحة الخزنة`
            : 'الخزنة مقفلة بعد إعادة التشغيل — افتحها من الواجهة ثم أعد المحاولة',
          409,
        )
        recordUsage(db, { provider: providerId, model, ok: false, durationMs: 0, errorKind: pe.kind })
        return fail(model, providerId, pe, started)
      }
    }

    if (!breaker.canAttempt(providerId)) {
      recordUsage(db, { provider: providerId, model, ok: false, durationMs: 0, errorKind: 'breaker_open' })
      return {
        model,
        provider: providerId,
        ok: false,
        content: '',
        error: { kind: 'breaker_open', message: 'قاطع الدارة مفتوح لهذا المزود — صفّره من لوحة التوجيه' },
        skipped: 'breaker_open',
        metrics: { ttfbMs: null, totalMs: null, promptTokens: null, completionTokens: null, tokensPerSec: null },
      }
    }

    const controller = new AbortController()
    let content = ''
    let usage: Usage | undefined
    let ttfbMs: number | null = null
    // v2.2 #7 «ما غادر الجهاز»: comparison-mode runs are egress-logged too
    const egressPayload = JSON.stringify({ model: modelId, messages, temperature: temperature ?? null })
    const egressId = recordEgress(db, { source: 'compare', provider: providerId, model, payload: egressPayload, config: ctx.config })
    try {
      const events: AsyncGenerator<StreamEvent> = adapter.streamChat({
        modelId,
        messages,
        temperature,
        signal: controller.signal,
      })
      for await (const evt of events) {
        if (evt.type === 'delta') {
          if (ttfbMs === null) ttfbMs = Date.now() - started
          content += evt.content
        } else if (evt.type === 'usage') {
          usage = evt.usage
        }
      }
      const totalMs = Date.now() - started
      breaker.recordSuccess(providerId)
      updateEgress(db, egressId, true)
      const completionTokens = usage?.completionTokens ?? null
      recordUsage(db, {
        provider: providerId,
        model,
        ok: true,
        promptTokens: usage?.promptTokens ?? null,
        completionTokens,
        durationMs: totalMs,
      })
      return {
        model,
        provider: providerId,
        ok: true,
        content,
        error: null,
        skipped: null,
        metrics: {
          ttfbMs,
          totalMs,
          promptTokens: usage?.promptTokens ?? null,
          completionTokens,
          tokensPerSec:
            completionTokens === null
              ? null
              : Number(((completionTokens / Math.max(totalMs, 1)) * 1000).toFixed(1)),
        },
      }
    } catch (e) {
      controller.abort()
      const pe = e instanceof ProviderError ? e : new ProviderError('provider_error', e instanceof Error ? e.message : String(e))
      breaker.recordFailure(providerId, pe.message)
      updateEgress(db, egressId, false, pe.kind)
      recordUsage(db, {
        provider: providerId,
        model,
        ok: false,
        durationMs: Date.now() - started,
        errorKind: pe.kind,
      })
      return fail(model, providerId, pe, started, ttfbMs)
    }
  }

  function fail(model: string, provider: string, pe: ProviderError, started: number, ttfbMs: number | null = null): CompareResult {
    void started
    return {
      model,
      provider,
      ok: false,
      content: '',
      error: { kind: pe.kind, message: pe.message },
      skipped: null,
      metrics: { ttfbMs, totalMs: null, promptTokens: null, completionTokens: null, tokensPerSec: null },
    }
  }
}
