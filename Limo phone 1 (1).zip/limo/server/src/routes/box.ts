import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import type { Logger } from '../logger.js'
import { buildModelFn } from '../agent/model.js'
import { pickAutoModel } from '../agent/autoselect.js'
import { applyProfilePatch, getProfile, ACCENT_IDS, THEME_MODES } from '../box/profile.js'
import { loadHistory, persistBoxMessage, runBoxChat, usableModels, detectSelfModification, type BoxAction } from '../box/brain.js'
import { createChange, startChange, readAutonomyLevel, resolveForgeModel, forgeDepsFor, getChange, TERMINAL_STATUSES } from '../forge/orchestrator.js'
import type { VectorMemory } from '../agent/memory.js'
import { getAutonomyLevel } from './forge.js'

/**
 * Black Box chatbot routes (owner directive 2026-11-01: «الصندوق الأسود
 * عبارة عن شات بوت يتيح لك تعديل ليمو كما تشاء حتى تغيير الاسم الخ…»).
 *
 * The conversation is REAL: an actual model (chosen in the new خانة النماذج)
 * with REAL modification tools, a durable chat log, and an append-only audit
 * trail. Read-only state lives next to it so the UI needs no parallel calls.
 * Autonomy reads reuse the forge route's writer (same module family, owner
 * decisions only — the system can never raise its own level).
 */

export interface BoxRouteDeps {
  db: DB
  config: ServerConfig
  registry: ProviderRegistry
  vault: Vault
  log: Logger
  /** shared vector memory — the box brain launches real agent tasks + writes real memories */
  memory: VectorMemory
}

function originOf(request: { headers: Record<string, string | string[] | undefined>; protocol: string; hostname: string }): string {
  const h = request.headers.origin
  if (typeof h === 'string' && h.length > 0) return h
  return `${request.protocol}://${request.hostname}`
}

/**
 * LIMO #21 — the DETERMINISTIC SELF-MODIFICATION RAIL (عقيدة #12 موسّعة).
 *
 * «اريده ان يعدل نفسه بنفسه»: a live model on the owner's phone REFUSED the
 * self-modification imperative instead of calling forge_create. An owner's
 * engineering command must never depend on the model's willingness — so when
 * detectSelfModification() matches, THIS function drives the REAL Reality
 * Forge pipeline with no model turn at all. Everything here is the same
 * machinery the forge_create box tool drives (createChange + startChange),
 * the same audit row, the same owner gate afterwards — only the refusal is
 * removed, never the safety.
 */
function selfModifyTurn(
  deps: { db: DB; config: ServerConfig; registry: ProviderRegistry; vault: Vault; log: Logger },
  request: string,
  model: string,
  autoAction: BoxAction | null,
): { reply: string; actions: BoxAction[]; profile: ReturnType<typeof getProfile> } {
  const { db, config, registry, vault, log } = deps
  persistBoxMessage(db, 'user', request, null, model)
  const finish = (reply: string, actions: BoxAction[]) => {
    persistBoxMessage(db, 'box', reply, actions, model)
    return { reply, actions, profile: getProfile(db) }
  }

  if (!config.forgeRepoRoot) {
    return finish(
      'لا أبدأ تعديلًا ذاتيًا بلا أرض حقيقية: Reality Forge معطّل — لا يوجد مستودع git لكود ليمو. على الجوال: pkg install git ثم git init داخل مجلد ليمو وأول commit، وأعد المحاولة فتشتغل المسبكة فعلًا.',
      [
        ...(autoAction ? [autoAction] : []),
        { tool: 'forge_create', args: { request }, ok: false, result: 'forge_disabled' },
      ],
    )
  }

  // one in-flight self-modification at a time — a second imperative points at
  // the live change instead of piling parallel edits on the same repository
  const terminalSql = TERMINAL_STATUSES.map((s) => `'${s}'`).join(', ')
  const open = db
    .prepare(`SELECT id, status, request FROM forge_changes WHERE status NOT IN (${terminalSql}) ORDER BY id DESC LIMIT 1`)
    .get() as { id: number; status: string; request: string } | undefined
  if (open) {
    const gate = open.status === 'awaiting_approval'
    return finish(
      `هناك تعديل ذاتي مفتوح بالفعل: #${open.id} في حالة «${open.status}» — «${open.request.slice(0, 80)}». خطّ واحد على المستودع، قرّر فيه أولًا: ${gate ? '«طبّق #' + open.id + '» أو «ارفض #' + open.id + '»' : '«تفاصيل #' + open.id + '» لمتابعة التقدم، أو «ألغِ #' + open.id + '»'} — وبعدها أمرك الجديد ينطلق فورًا.`,
      [
        ...(autoAction ? [autoAction] : []),
        { tool: 'forge_create', args: { request }, ok: false, result: { blocked_by: open.id, status: open.status } },
      ],
    )
  }

  const level = readAutonomyLevel(db)
  const forgeModel = resolveForgeModel(db, model)
  const id = createChange(db, request, forgeModel, level)
  startChange(forgeDepsFor({ db, config, registry, vault, log }, forgeModel), id, log)
  const row = getChange(db, id)
  const status = row?.status ?? 'analyzing'
  // the same append-only audit the tool path writes (tool name = forge_create)
  db.prepare('INSERT INTO box_modifications (tool, args, ok, result, model) VALUES (?, ?, 1, ?, ?)').run(
    'forge_create',
    JSON.stringify({ request }),
    JSON.stringify({ id, status, autonomyLevel: level, model: forgeModel, rail: 'owner-imperative' }),
    model,
  )
  const l0 = level === 0
  const reply = [
    `انطلق التعديل الذاتي #${id} من كلمك مباشرة — بلا وسيط ولا رفض: أمر مالك حتمي يُنفَّذ لا يُناقش.`,
    `خط Reality Forge الحقيقي يعمل الآن على كود ليمو نفسه: تحليل ← خطة وورقعة ← فرع git معزول ← اختبارات مسموحة ← مراجعة أمنية ← بوابة قرارك.`,
    `الحالة الحالية: ${status} · نموذج الهندسة: ${forgeModel ?? model} · مستوى الاستقلالية L${level}.`,
    l0
      ? `عند L0 يقف الخط بعد التحليل بصدق — استأنفه بكلمة «استأنف #${id}» أو ارفع المستوى، والتطبيق النهائي بقرارك وحدك.`
      : `عند بلوغ بوابة الموافقة سأعرض الخلاصة (الخطة/الفرق/الاختبارات/الأمن) والتطبيق بقرارك: «طبّق #${id}» أو «ارفض #${id}».`,
    `تابع التقدم بكلمة «تفاصيل #${id}» أو من شاشة الصندوق ← الملف الهندسي، والتراجع بعد التطبيق: «تراجع #${id}».`,
  ].join('\n')
  return finish(
    reply,
    [
      ...(autoAction ? [autoAction] : []),
      { tool: 'forge_create', args: { request }, ok: true, result: { id, status, autonomyLevel: level, model: forgeModel, rail: 'owner-imperative' } },
    ],
  )
}

export function registerBoxRoutes(app: FastifyInstance, deps: BoxRouteDeps): void {
  const { db, config, registry, vault, log, memory } = deps

  // ------------------------------------------------------------- state
  app.get('/api/box/state', async (request) => ({
    profile: getProfile(db),
    autonomy: getAutonomyLevel(db),
    vault: vault.isUnlocked ? 'unlocked' : 'locked',
    usableModels: (await usableModels(db, registry, vault, config)).map((m) => ({ id: m.id, free: m.free, contextLength: m.contextLength })),
    link: originOf(request),
  }))

  // ---------------------------------------------------------- the chat
  app.post(
    '/api/box/chat',
    {
      schema: {
        body: {
          type: 'object',
          required: ['message'],
          additionalProperties: false,
          properties: {
            message: { type: 'string', minLength: 1, maxLength: 4000 },
            model: { type: ['string', 'null'], maxLength: 256 },
          },
        },
      },
    },
    async (request, reply) => {
      const b = request.body as { message: string; model?: string | null }
      let requested = (b.model ?? getProfile(db).defaultModel ?? '').trim()
      // LIMO #21 — Auto: «اختيار النماذج أوتوماتيكياً» on the box surface too.
      // The SAME real routing the agent engine uses (usable models + owner
      // prefs + recorded reason) — never a dead guess, and the resolution is
      // shown as a first-class action so provenance stays honest.
      let autoAction: BoxAction | null = null
      if (requested === 'auto') {
        const pick = await pickAutoModel(db, registry, vault, config, 'planner')
        if (!pick) {
          return reply.code(409).send({
            error: { message: 'auto: لا نموذج قابل للاستخدام الآن — أدخل مفتاح مزود في الخزنة أو شغّل مزودًا محليًا ثم أعد المحاولة', type: 'no_model', code: 409 },
          })
        }
        autoAction = { tool: 'auto_model', args: { requested: 'auto' }, ok: true, result: { model: pick.model, reason: pick.reason } }
        requested = pick.model
      }
      const model = requested
      if (!model) {
        return reply.code(400).send({
          error: { message: 'لا نموذج مضبوط للصندوق — اختر نموذجًا من خانة النماذج أولًا (أو auto للاختيار الآلي)', type: 'no_model', code: 400 },
        })
      }
      try {
        registry.resolveModel(model)
      } catch (e) {
        return reply.code(400).send({ error: { message: e instanceof Error ? e.message : 'نموذج غير صالح', type: 'invalid_request_error', code: 400 } })
      }
      const providerId = model.slice(0, model.indexOf('/'))
      if (registry.get(providerId)?.needsKey && !vault.isUnlocked) {
        return reply.code(409).send({
          error: { message: 'الخزنة مقفلة بعد إعادة التشغيل — افتحها من الواجهة ثم أعد المحاولة', type: 'vault_locked', code: 409 },
        })
      }

      // LIMO #21 — the owner's self-modification imperative NEVER waits for a
      // model turn (a live model refused it on the phone): the deterministic
      // rail starts the REAL forge pipeline directly.
      if (detectSelfModification(b.message)) {
        const out = selfModifyTurn({ db, config, registry, vault, log }, b.message.trim(), model, autoAction)
        return out
      }

      const origin = originOf(request)
      const history = loadHistory(db)
      persistBoxMessage(db, 'user', b.message.trim(), null, null)
      try {
        const modelFn = buildModelFn({ db, config, registry, vault, log, model, source: 'box' })
        const result = await runBoxChat({ db, config, registry, vault, log, memory, modelFn, model }, history, b.message.trim(), origin)
        const actions = autoAction ? [autoAction, ...result.actions] : result.actions
        persistBoxMessage(db, 'box', result.reply, actions, model)
        return { reply: result.reply, actions, profile: result.profile }
      } catch (e) {
        // honest failure — the user turn stays logged, the reply does not fake
        const msg = e instanceof Error ? e.message : String(e)
        log.warn('box: chat failed', { model, err: msg })
        persistBoxMessage(db, 'box', `تعذّر الوصول إلى النموذج: ${msg}`, [], model)
        return reply.code(502).send({ error: { message: `تعذّر الوصول إلى النموذج: ${msg}`, type: 'provider_error', code: 502 } })
      }
    },
  )

  // ------------------------------------------------- the chat (live stream)
  // LIMO #23 — SAME loop, SAME tools, SAME persistence as /api/box/chat —
  // plus an honest live tap: raw model tokens stream as «thinking», each real
  // tool action streams as an action card, the final reply persists exactly
  // like the non-streaming route. STOP is cooperative: the client aborts, the
  // stream notices, the loop ends and persists NO reply (half-thoughts are
  // never sold as answers). Pre-flight failures stay plain JSON errors so the
  // UI can reuse the same handling on both endpoints.
  app.post(
    '/api/box/chat/stream',
    {
      schema: {
        body: {
          type: 'object',
          required: ['message'],
          additionalProperties: false,
          properties: {
            message: { type: 'string', minLength: 1, maxLength: 4000 },
            model: { type: ['string', 'null'], maxLength: 256 },
          },
        },
      },
    },
    async (request, reply) => {
      const b = request.body as { message: string; model?: string | null }
      let requested = (b.model ?? getProfile(db).defaultModel ?? '').trim()
      let autoAction: BoxAction | null = null
      if (requested === 'auto') {
        const pick = await pickAutoModel(db, registry, vault, config, 'planner')
        if (!pick) {
          return reply.code(409).send({
            error: { message: 'auto: لا نموذج قابل للاستخدام الآن — أدخل مفتاح مزود في الخزنة أو شغّل مزودًا محليًا ثم أعد المحاولة', type: 'no_model', code: 409 },
          })
        }
        autoAction = { tool: 'auto_model', args: { requested: 'auto' }, ok: true, result: { model: pick.model, reason: pick.reason } }
        requested = pick.model
      }
      const model = requested
      if (!model) {
        return reply.code(400).send({
          error: { message: 'لا نموذج مضبوط للصندوق — اختر نموذجًا من خانة النماذج أولًا (أو auto للاختيار الآلي)', type: 'no_model', code: 400 },
        })
      }
      try {
        registry.resolveModel(model)
      } catch (e) {
        return reply.code(400).send({ error: { message: e instanceof Error ? e.message : 'نموذج غير صالح', type: 'invalid_request_error', code: 400 } })
      }
      const providerId = model.slice(0, model.indexOf('/'))
      if (registry.get(providerId)?.needsKey && !vault.isUnlocked) {
        return reply.code(409).send({
          error: { message: 'الخزنة مقفلة بعد إعادة التشغيل — افتحها من الواجهة ثم أعد المحاولة', type: 'vault_locked', code: 409 },
        })
      }

      const sse = (event: string, data: unknown): void => {
        reply.raw.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`)
      }

      // the deterministic self-mod rail owns these words (no model turn) —
      // one final event carries the same honest reply + actions as REST.
      if (detectSelfModification(b.message)) {
        reply.hijack()
        reply.raw.writeHead(200, {
          'content-type': 'text/event-stream',
          'cache-control': 'no-cache',
          connection: 'keep-alive',
          'x-accel-buffering': 'no',
        })
        const out = selfModifyTurn({ db, config, registry, vault, log }, b.message.trim(), model, autoAction)
        sse('final', { reply: out.reply, actions: out.actions })
        sse('done', {})
        reply.raw.end()
        return
      }

      const origin = originOf(request)
      const history = loadHistory(db)
      persistBoxMessage(db, 'user', b.message.trim(), null, null)

      reply.hijack()
      reply.raw.writeHead(200, {
        'content-type': 'text/event-stream',
        'cache-control': 'no-cache',
        connection: 'keep-alive',
        'x-accel-buffering': 'no',
      })
      if (autoAction) sse('action', autoAction)

      let clientGone = false
      request.raw.on('close', () => {
        clientGone = true
      })
      let sawFinal = false
      try {
        const modelFn = buildModelFn({ db, config, registry, vault, log, model, source: 'box' })
        const result = await runBoxChat({ db, config, registry, vault, log, memory, modelFn, model }, history, b.message.trim(), origin, {
          onDelta: (chunk) => {
            if (!clientGone) sse('delta', { text: chunk })
          },
          onAction: (action) => {
            if (!clientGone) sse('action', action)
          },
          shouldStop: () => clientGone,
        })
        if (result.stopped) {
          if (!clientGone) sse('stopped', { note: 'أوقفتَ التوليد — ما بثَّ من تفكير حي لم يُحفظ ردًا.' })
        } else {
          sawFinal = true
          persistBoxMessage(db, 'box', result.reply, result.actions, model)
          if (!clientGone) sse('final', { reply: result.reply, actions: result.actions })
        }
        if (!clientGone) sse('done', {})
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e)
        log.warn('box: stream failed', { model, err: msg })
        if (!sawFinal) persistBoxMessage(db, 'box', `تعذّر الوصول إلى النموذج: ${msg}`, [], model)
        if (!clientGone) {
          sse('error', { message: `تعذّر الوصول إلى النموذج: ${msg}` })
          sse('done', {})
        }
      }
      reply.raw.end()
    },
  )

  // ---------------------------------------------------- history + clear
  app.get('/api/box/messages', async () => ({
    messages: db
      .prepare('SELECT id, role, content, actions, model, created_at FROM box_messages ORDER BY id DESC LIMIT 200')
      .all()
      .reverse(),
  }))

  app.delete('/api/box/messages', async () => {
    db.prepare('DELETE FROM box_messages').run()
    return { ok: true }
  })

  // ------------------------------------- conversation search + rewind
  // LIMO #24 — Phase 1 §3A «بحث محادثات + تحرير رسالة + إعادة توليد» over the
  // SAME durable log, no second engine: search is an honest LIKE with escaped
  // wildcards; rewind deletes FROM a user message INCLUSIVE (its reply and
  // everything after die with it) and returns the anchor text so the client
  // re-sends edited/identical text through the EXISTING chat pipeline.
  app.get(
    '/api/box/messages/search',
    {
      schema: {
        querystring: {
          type: 'object',
          required: ['q'],
          additionalProperties: false,
          properties: { q: { type: 'string', minLength: 1, maxLength: 200 } },
        },
      },
    },
    async (request) => {
      const { q } = request.query as { q: string }
      const needle = q.trim()
      if (needle.length === 0) return { results: [] }
      const esc = needle.replace(/[\\%_]/g, (c) => `\\${c}`)
      const results = db
        .prepare(
          `SELECT id, role, content, created_at FROM box_messages
           WHERE content LIKE ? ESCAPE '\\' ORDER BY id DESC LIMIT 50`,
        )
        .all(`%${esc}%`) as Array<{ id: number; role: string; content: string; created_at: string }>
      return { results }
    },
  )

  app.post(
    '/api/box/messages/rewind',
    {
      schema: {
        body: {
          type: 'object',
          required: ['target'],
          additionalProperties: false,
          properties: {
            target: { type: 'string', enum: ['last-user', 'message'] },
            id: { type: 'integer', minimum: 1 },
          },
        },
      },
    },
    async (request, reply) => {
      const b = request.body as { target: 'last-user' | 'message'; id?: number }
      let anchor: { id: number; content: string } | undefined
      if (b.target === 'message') {
        if (!b.id) {
          return reply.code(400).send({
            error: { message: 'تحرير رسالة يتطلب رقم الرسالة (id) — لا أقص من نقطة مجهولة', type: 'invalid_request_error', code: 400 },
          })
        }
        anchor = db.prepare(`SELECT id, content FROM box_messages WHERE id = ? AND role = 'user'`).get(b.id) as
          | { id: number; content: string }
          | undefined
        if (!anchor) {
          return reply.code(404).send({
            error: { message: 'لا رسالة مستخدم بهذا الرقم — التحرير يقصّ من رسالة مستخدم وما بعدها فقط', type: 'not_found', code: 404 },
          })
        }
      } else {
        anchor = db.prepare(`SELECT id, content FROM box_messages WHERE role = 'user' ORDER BY id DESC LIMIT 1`).get() as
          | { id: number; content: string }
          | undefined
        if (!anchor) {
          return reply.code(404).send({
            error: { message: 'لا رسالة مستخدم في السجل لإعادة توليدها — السجل فارغ أو ينتهي بغير رسالتك', type: 'not_found', code: 404 },
          })
        }
      }
      const res = db.prepare('DELETE FROM box_messages WHERE id >= ?').run(anchor.id)
      log.info('box: rewind', { from: anchor.id, deleted: res.changes, target: b.target })
      return { ok: true, deleted: res.changes, text: anchor.content }
    },
  )

  // ----------------------------------------------- modifications audit
  app.get('/api/box/modifications', async () => ({
    modifications: db.prepare('SELECT id, tool, args, ok, result, model, created_at FROM box_modifications ORDER BY id DESC LIMIT 100').all(),
  }))

  // ------------------------------------------------ direct profile write
  // The Settings mirror of the box's identity tools — SAME validations, SAME
  // append-only audit (tool name = the equivalent box tool per field).
  app.put(
    '/api/box/profile',
    {
      schema: {
        body: {
          type: 'object',
          additionalProperties: false,
          properties: {
            name: { type: 'string', minLength: 2, maxLength: 40 },
            tagline: { type: 'string', minLength: 2, maxLength: 80 },
            language: { type: 'string', enum: ['ar', 'en'] },
            defaultModel: { type: ['string', 'null'], maxLength: 256 },
            themeMode: { type: 'string', enum: THEME_MODES },
            accent: { type: 'string', enum: ACCENT_IDS },
          },
        },
      },
    },
    async (request, reply) => {
      const b = request.body as { name?: string; tagline?: string; language?: 'ar' | 'en'; defaultModel?: string | null; themeMode?: string; accent?: string }
      if (b.defaultModel) {
        try {
          registry.resolveModel(b.defaultModel)
        } catch (e) {
          return reply.code(400).send({ error: { message: e instanceof Error ? e.message : 'نموذج غير صالح', type: 'invalid_request_error', code: 400 } })
        }
      }
      const res = applyProfilePatch(db, b)
      if (!res.ok) return reply.code(400).send({ error: { message: res.error ?? 'قيمة غير صالحة', type: 'invalid_request_error', code: 400 } })
      // audit: one row per changed field, tool-named like the box tools
      const toolFor: Record<string, string> = { name: 'set_app_name', tagline: 'set_tagline', language: 'set_language', defaultModel: 'set_default_model', themeMode: 'set_theme_mode', accent: 'set_accent' }
      for (const [field, value] of Object.entries(b)) {
        if (value === undefined) continue
        db.prepare('INSERT INTO box_modifications (tool, args, ok, result, model) VALUES (?, ?, 1, ?, ?)').run(
          toolFor[field] ?? 'set_profile',
          JSON.stringify({ [field]: value }),
          JSON.stringify({ [field]: value }),
          'settings',
        )
      }
      return { profile: getProfile(db) }
    },
  )
}

export type { BoxAction }
