import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import { readFile } from 'node:fs/promises'
import {
  PREVIEW_MIME,
  createProject,
  deleteProject,
  deleteProjectFile,
  getProject,
  listProjectFiles,
  listProjects,
  readProjectFile,
  safeProjectPath,
  updateProject,
  writeProjectFile,
} from '../projects/store.js'

/**
 * Project workspaces — LIMO's isolated build surfaces (HYPERBRAIN "build"
 * mode, App Genesis, Library). Every file operation goes through the store's
 * jail (traversal-proof, size-capped); previews are served with a sandboxing
 * CSP so generated HTML can never touch the app origin.
 */

export interface ProjectRouteDeps {
  db: DB
  config: ServerConfig
}

export function registerProjectRoutes(app: FastifyInstance, deps: ProjectRouteDeps): void {
  const { db, config } = deps

  app.get('/api/projects', async () => ({ projects: listProjects(db) }))

  app.post(
    '/api/projects',
    {
      schema: {
        body: {
          type: 'object',
          required: ['name'],
          additionalProperties: false,
          properties: {
            name: { type: 'string', minLength: 1, maxLength: 120 },
            description: { type: 'string', maxLength: 2000 },
            kind: { type: 'string', enum: ['general', 'web_app', 'creative', 'workflow'] },
          },
        },
      },
    },
    async (request, reply) => {
      const b = request.body as { name: string; description?: string; kind?: string }
      const project = createProject(db, config, { name: b.name, description: b.description, kind: b.kind })
      return reply.code(201).send({ project })
    },
  )

  app.get('/api/projects/:id', async (request, reply) => {
    const { id } = request.params as { id: string }
    const project = getProject(db, id)
    if (!project) return reply.code(404).send({ error: { message: 'المشروع غير موجود', type: 'not_found', code: 404 } })
    return { project, files: listProjectFiles(config, id) }
  })

  app.patch(
    '/api/projects/:id',
    {
      schema: {
        body: {
          type: 'object',
          additionalProperties: false,
          properties: {
            name: { type: 'string', minLength: 1, maxLength: 120 },
            description: { type: 'string', maxLength: 2000 },
            kind: { type: 'string', enum: ['general', 'web_app', 'creative', 'workflow'] },
            status: { type: 'string', enum: ['active', 'archived'] },
          },
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params as { id: string }
      const b = request.body as { name?: string; description?: string; kind?: string; status?: string }
      const project = updateProject(db, id, b)
      if (!project) return reply.code(404).send({ error: { message: 'المشروع غير موجود', type: 'not_found', code: 404 } })
      return { project }
    },
  )

  app.delete('/api/projects/:id', async (request, reply) => {
    const { id } = request.params as { id: string }
    const ok = deleteProject(db, config, id)
    if (!ok) return reply.code(404).send({ error: { message: 'المشروع غير موجود', type: 'not_found', code: 404 } })
    return { ok: true }
  })

  // ------------------------------------------------------------ project files

  app.get('/api/projects/:id/files', async (request, reply) => {
    const { id } = request.params as { id: string }
    if (!getProject(db, id)) return reply.code(404).send({ error: { message: 'المشروع غير موجود', type: 'not_found', code: 404 } })
    return { files: listProjectFiles(config, id) }
  })

  app.get('/api/projects/:id/files/content', async (request, reply) => {
    const { id } = request.params as { id: string }
    const path = String((request.query as { path?: string }).path ?? '')
    if (!getProject(db, id)) return reply.code(404).send({ error: { message: 'المشروع غير موجود', type: 'not_found', code: 404 } })
    const file = readProjectFile(config, id, path)
    if (!file) return reply.code(404).send({ error: { message: 'الملف غير موجود أو يتجاوز حد القراءة (256KB)', type: 'not_found', code: 404 } })
    return { file }
  })

  app.put(
    '/api/projects/:id/files',
    {
      schema: {
        body: {
          type: 'object',
          required: ['path', 'content'],
          additionalProperties: false,
          properties: {
            path: { type: 'string', minLength: 1, maxLength: 512 },
            content: { type: 'string', maxLength: 262144 },
          },
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params as { id: string }
      const { path, content } = request.body as { path: string; content: string }
      if (!getProject(db, id)) return reply.code(404).send({ error: { message: 'المشروع غير موجود', type: 'not_found', code: 404 } })
      try {
        const written = writeProjectFile(config, id, path, content)
        return { file: written }
      } catch (e) {
        return reply.code(400).send({ error: { message: e instanceof Error ? e.message : 'مسار غير صالح', type: 'invalid_request_error', code: 400 } })
      }
    },
  )

  app.delete('/api/projects/:id/files', async (request, reply) => {
    const { id } = request.params as { id: string }
    const path = String((request.query as { path?: string }).path ?? '')
    if (!getProject(db, id)) return reply.code(404).send({ error: { message: 'المشروع غير موجود', type: 'not_found', code: 404 } })
    const ok = deleteProjectFile(config, id, path)
    if (!ok) return reply.code(404).send({ error: { message: 'الملف غير موجود', type: 'not_found', code: 404 } })
    return { ok: true }
  })

  // -------------------------------------------------------- sandboxed preview
  // App Genesis: an HTML/JS/CSS file in a project can be previewed in an
  // iframe. The response carries a hard CSP sandbox: the preview document runs
  // with an opaque origin — it cannot read cookies, storage, or same-origin
  // APIs of LIMO itself.
  app.get('/api/projects/:id/preview/*', async (request, reply) => {
    const { id } = request.params as { id: string; '*': string }
    const rel = (request.params as { '*': string })['*']
    if (!getProject(db, id)) return reply.code(404).send({ error: { message: 'المشروع غير موجود', type: 'not_found', code: 404 } })
    const abs = safeProjectPath(config, id, rel)
    if (!abs) return reply.code(400).send({ error: { message: 'مسار غير صالح', type: 'invalid_request_error', code: 400 } })
    const ext = rel.slice(rel.lastIndexOf('.')).toLowerCase()
    const mime = PREVIEW_MIME[ext]
    if (!mime || mime.startsWith('font/')) {
      return reply.code(415).send({ error: { message: 'نوع الملف غير قابل للمعاينة', type: 'unsupported_media_type', code: 415 } })
    }
    let body: string
    try {
      body = await readFile(abs, 'utf8')
    } catch {
      return reply.code(404).send({ error: { message: 'الملف غير موجود', type: 'not_found', code: 404 } })
    }
    return reply
      .header('content-type', mime)
      .header('content-security-policy', "sandbox allow-scripts allow-forms")
      .header('x-content-type-options', 'nosniff')
      .header('cache-control', 'no-store')
      .send(body)
  })
}
