import type { FastifyInstance } from 'fastify'
import type { ServerConfig } from '../config.js'
import { listDir, readSourceFile } from '../box/universal.js'

/**
 * LIMO #21 — «الملفات» (the Krea-parity Files area): read-only browsing over
 * the REAL repository the agent inspects and Reality Forge modifies. Same
 * jail + secret denial + caps as the box inspectors (box/universal.ts) — a
 * browser is a visibility surface for self-modification, never a bypass.
 */

export interface FilesRouteDeps {
  config: ServerConfig
}

export function registerFilesRoutes(app: FastifyInstance, deps: FilesRouteDeps): void {
  const { config } = deps

  app.get(
    '/api/files',
    {
      schema: {
        querystring: {
          type: 'object',
          properties: { dir: { type: 'string', maxLength: 400 } },
        },
      },
    },
    async (request, reply) => {
      const dir = (request.query as { dir?: string }).dir ?? ''
      const r = listDir(config, dir)
      if (!r.ok) return reply.code(404).send({ error: { message: r.error, type: 'not_found', code: 404 } })
      return r
    },
  )

  app.get(
    '/api/files/content',
    {
      schema: {
        querystring: {
          type: 'object',
          required: ['path'],
          properties: { path: { type: 'string', minLength: 1, maxLength: 400 } },
        },
      },
    },
    async (request, reply) => {
      const path = (request.query as { path?: string }).path ?? ''
      const r = readSourceFile(config, path)
      if (!r.ok) return reply.code(404).send({ error: { message: r.error, type: 'not_found', code: 404 } })
      return { file: { path: r.path, bytes: r.bytes, lines: r.lines, truncated: r.truncated, content: r.content } }
    },
  )
}
