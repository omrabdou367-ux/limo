import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import type { ServerConfig } from '../config.js'
import type { Vault } from '../vault/vault.js'
import type { ProviderRegistry } from '../providers/registry.js'
import { keyAliasFor } from '../providers/registry.js'
import {
  createCustomProvider,
  deleteCustomProvider,
  getCustomProvider,
  isValidCustomId,
  listCustomProviders,
  updateCustomProvider,
} from '../db/custom_providers.js'
import { syncCustomProviders } from '../providers/custom.js'

/**
 * Custom provider CRUD. The adapter is registered into the live registry on
 * every change, so a new endpoint is usable instantly everywhere (models,
 * chat, catalog, router chains). Deleting a provider NEVER deletes its vault
 * secret — the response says so explicitly (non-destructive by design).
 */

const URL_RE = /^https?:\/\/[^\s]+$/i

const createSchema = {
  schema: {
    body: {
      type: 'object',
      required: ['id', 'label', 'baseUrl', 'needsKey'],
      additionalProperties: false,
      properties: {
        id: { type: 'string', minLength: 2, maxLength: 32 },
        label: { type: 'string', minLength: 1, maxLength: 64 },
        baseUrl: { type: 'string', minLength: 8, maxLength: 512 },
        needsKey: { type: 'boolean' },
      },
    },
  },
}

const patchSchema = {
  schema: {
    body: {
      type: 'object',
      additionalProperties: false,
      properties: {
        label: { type: 'string', minLength: 1, maxLength: 64 },
        baseUrl: { type: 'string', minLength: 8, maxLength: 512 },
        needsKey: { type: 'boolean' },
        enabled: { type: 'boolean' },
      },
    },
  },
}

export function registerCustomProviderRoutes(
  app: FastifyInstance,
  ctx: { db: DB; config: ServerConfig; vault: Vault; registry: ProviderRegistry },
): void {
  const { db, vault, registry, config } = ctx

  const withKeyState = () =>
    listCustomProviders(db).map((p) => ({
      ...p,
      hasKey: !p.needsKey || vault.hasSecret(keyAliasFor(p.id)),
    }))

  app.get('/api/providers/custom', async () => ({ providers: withKeyState() }))

  app.post('/api/providers/custom', createSchema, async (request, reply) => {
    const body = request.body as { id: string; label: string; baseUrl: string; needsKey: boolean }
    if (!isValidCustomId(body.id)) {
      return reply.code(400).send({
        error: {
          message: 'معرّف غير صالح: حروف لاتينية صغيرة وأرقام وشرطات، ولا يصح استعمال openrouter/groq/ollama',
          type: 'invalid_provider_id',
          code: 400,
        },
      })
    }
    if (!URL_RE.test(body.baseUrl)) {
      return reply.code(400).send({
        error: { message: 'العنوان يجب أن يبدأ بـ http:// أو https://', type: 'invalid_url', code: 400 },
      })
    }
    if (getCustomProvider(db, body.id)) {
      return reply.code(409).send({
        error: { message: `يوجد مزود مخصص بهذا المعرف أصلًا: ${body.id}`, type: 'provider_exists', code: 409 },
      })
    }
    const provider = createCustomProvider(db, body)
    syncCustomProviders(registry, db, vault)
    return { ok: true, provider, hasKey: !provider.needsKey }
  })

  app.patch('/api/providers/custom/:id', patchSchema, async (request, reply) => {
    const { id } = request.params as { id: string }
    const provider = updateCustomProvider(db, id, request.body as { label?: string; baseUrl?: string; needsKey?: boolean; enabled?: boolean })
    if (!provider) {
      return reply.code(404).send({ error: { message: 'المزود المخصص غير موجود', type: 'not_found', code: 404 } })
    }
    syncCustomProviders(registry, db, vault)
    return { ok: true, provider, hasKey: !provider.needsKey || vault.hasSecret(keyAliasFor(id)) }
  })

  app.delete('/api/providers/custom/:id', async (request, reply) => {
    const { id } = request.params as { id: string }
    const provider = getCustomProvider(db, id)
    if (!provider) {
      return reply.code(404).send({ error: { message: 'المزود المخصص غير موجود', type: 'not_found', code: 404 } })
    }
    const secretKept = vault.hasSecret(keyAliasFor(id))
    deleteCustomProvider(db, id)
    registry.unregister(id) // sync only sees SURVIVING rows — drop the adapter explicitly
    syncCustomProviders(registry, db, vault)
    return { ok: true, secretKept }
  })

  /** Same test path as the vault key test: hit the endpoint's /models. */
  app.post('/api/providers/custom/:id/test', async (request, reply) => {
    const { id } = request.params as { id: string }
    const adapter = registry.get(id)
    if (!adapter) {
      return reply.code(404).send({ error: { message: `مزود غير معروف: ${id}`, type: 'not_found', code: 404 } })
    }
    if (adapter.needsKey && !vault.isUnlocked) {
      return reply.code(409).send({ error: { message: 'الخزنة مقفلة', type: 'vault_locked', code: 409 } })
    }
    try {
      const models = await registry.listModels(id, config, db)
      return { ok: true, provider: id, models: models.length }
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e)
      return reply.code(502).send({ error: { message: msg, type: 'provider_test_failed', code: 502 } })
    }
  })
}
