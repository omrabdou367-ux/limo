import type { FastifyInstance } from 'fastify'
import type { DB } from '../db/database.js'
import { recentErrors, usageByModelSince, usageByProviderSince, usageTotalsSince } from '../db/usage.js'
import { getRefreshState } from '../db/catalog.js'

/**
 * The honest usage board (PLAN.md §8.1.3): local, observed behaviour only —
 * call counts, success/failure, tokens, duration, and "last verified" per
 * provider. We never claim to know a provider's internal quota state.
 */
export function registerUsageRoutes(app: FastifyInstance, ctx: { db: DB }): void {
  const { db } = ctx

  app.get('/api/usage', async (request) => {
    const q = request.query as { days?: string }
    const days = Math.min(Math.max(Number(q.days ?? 7) || 7, 1), 90)
    // rows store strftime('%Y-%m-%dT%H:%M:%fZ','now') — same shape as toISOString()
    const sinceTs = new Date(Date.now() - days * 86_400_000).toISOString()

    return {
      days,
      since: sinceTs,
      totals: usageTotalsSince(db, sinceTs),
      providers: usageByProviderSince(db, sinceTs),
      models: usageByModelSince(db, sinceTs),
      recentErrors: recentErrors(db),
      catalog: getRefreshState(db),
    }
  })
}
