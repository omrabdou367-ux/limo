import { existsSync } from 'node:fs'
import { join } from 'node:path'
import Fastify, { type FastifyInstance } from 'fastify'
import fastifyCookie from '@fastify/cookie'
import fastifyCors from '@fastify/cors'
import fastifyStatic from '@fastify/static'
import { loadConfig, type ServerConfig } from './config.js'
import { openDatabase, type DB } from './db/database.js'
import { authGuard } from './auth/guard.js'
import { registerAuthRoutes } from './auth/routes.js'
import { Vault } from './vault/vault.js'
import { ensureMachineKey } from './vault/machineKey.js'
import { registerVaultRoutes } from './vault/routes.js'
import { buildDefaultRegistry, type ProviderRegistry } from './providers/registry.js'
import { syncCustomProviders } from './providers/custom.js'
import { registerGatewayRoutes } from './gateway/routes.js'
import { registerConversationRoutes } from './routes/conversations.js'
import { registerCustomProviderRoutes } from './routes/custom-providers.js'
import { registerCompareRoutes } from './routes/compare.js'
import { registerUsageRoutes } from './routes/usage.js'
import { registerCatalogRoutes } from './catalog/routes.js'
import { registerEgressRoutes } from './routes/egress.js'
import { CircuitBreaker } from './router/breaker.js'
import { registerRouterRoutes } from './router/routes.js'
import { registerAgentRoutes } from './agent/routes.js'
import { registerForgeRoutes } from './routes/forge.js'
import { registerBoxRoutes } from './routes/box.js'
import { registerProjectRoutes } from './routes/projects.js'
import { registerWorkflowRoutes } from './routes/workflows.js'
import { registerSkillRoutes } from './routes/skills.js'
import { registerSystemRoutes } from './routes/system.js'
import { registerDeployRoutes } from './routes/deploy.js'
import { registerFilesRoutes } from './routes/files.js'
import { registerIntegrationsRoutes } from './routes/integrations.js'
import { RoutineScheduler } from './agent/routines.js'
import { VectorMemory } from './agent/memory.js'
import { registerHealthRoute } from './health.js'
import { createLogger, type Logger } from './logger.js'

export interface AppDeps {
  config: ServerConfig
  db: DB
  vault: Vault
  registry: ProviderRegistry
  breaker: CircuitBreaker
  log: Logger
  /** phase 3: vector/user memory + the routine scheduler (started by index.ts) */
  memory: VectorMemory
  routineScheduler: RoutineScheduler
}

export interface BuildOptions {
  config?: ServerConfig
  /** test injection: custom registry (fake adapters) */
  registry?: ProviderRegistry
  /** test injection: skip static web serving */
  noStatic?: boolean
}

export function buildApp(opts: BuildOptions = {}): { app: FastifyInstance; deps: AppDeps } {
  const config = opts.config ?? loadConfig()
  const log = createLogger(config.logLevel)
  const db = openDatabase(config.dataDir)
  const vault = new Vault(db)
  // Open mode (LIMO decision #8 — password system removed): the vault
  // unwraps itself with the machine key at every boot. A pre-#8 passphrase
  // vault cannot self-unwrap — it stays locked and the one-time migration
  // script (scripts/migrate-vault.ts) converts it, secrets intact.
  const machineSecret = ensureMachineKey(config.dataDir)
  const selfUnwrapped = vault.bootWithMachineSecret(machineSecret)
  if (!selfUnwrapped) {
    log.warn('vault: legacy passphrase vault detected — run: npx tsx scripts/migrate-vault.ts <old-passphrase>')
  }
  const registry = opts.registry ?? buildDefaultRegistry({ config, vault })
  const breaker = new CircuitBreaker()
  // custom providers become first-class adapters in whatever registry is used
  syncCustomProviders(registry, db, vault)

  const app = Fastify({
    logger: false, // we log through the scrubbing logger ourselves
    bodyLimit: 1024 * 1024,
  })

  // phase 3: shared agent services (one vector memory per DB; the routine
  // scheduler is created here but STARTED only by index.ts — tests stay clean)
  const memory = new VectorMemory(db)
  const engineBase = { db, config, registry, vault, log, memory }
  const routineScheduler = new RoutineScheduler({ ...engineBase, engineDeps: engineBase })

  app.addHook('preHandler', async (request, reply) => {
    // The guard covers the API surface (/api/*) and the OpenAI-compatible
    // gateway (/v1/*). Static SPA assets are public — the shell boots and
    // calls /api/health (public) directly: open mode, no login screen.
    const path = request.url.split('?')[0] ?? '/'
    if (!path.startsWith('/api/') && !path.startsWith('/v1/')) return
    const isPublic = (request.routeOptions.config as { public?: boolean } | undefined)?.public === true
    if (!isPublic) await authGuard(request, reply, { db, config })
  })

  void app.register(fastifyCookie)
  void app.register(fastifyCors, {
    origin: (origin, cb) => cb(null, origin !== undefined && config.corsOrigins.includes(origin)),
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  })

  registerHealthRoute(app, { db, config, vault, registry })
  registerAuthRoutes(app, { db })
  registerVaultRoutes(app, { db, config, vault, registry })
  registerConversationRoutes(app, { db })
  registerCustomProviderRoutes(app, { db, config, vault, registry })
  registerCatalogRoutes(app, { db, config, vault, registry, log })
  registerRouterRoutes(app, { db, registry, breaker })
  registerUsageRoutes(app, { db })
  registerCompareRoutes(app, { db, config, registry, vault, breaker })
  registerGatewayRoutes(app, { db, config, registry, vault, log, breaker })
  registerEgressRoutes(app, { db })
  registerAgentRoutes(app, { ...engineBase, scheduler: routineScheduler })
  // Reality Forge — the self-modification engine's control surface (RF spec §5)
  registerForgeRoutes(app, engineBase)
  // The Black Box chatbot — a REAL model conversation that modifies LIMO
  registerBoxRoutes(app, engineBase)
  // LIMO layer 1 — project workspaces, Workflow Lab, ALLIMNI skills
  registerProjectRoutes(app, { db, config })
  registerWorkflowRoutes(app, engineBase)
  registerSkillRoutes(app, { db, config, log })
  // LIMO COMPUTER PRO — the live system map + honest engine detection (#17)
  registerSystemRoutes(app, { db, config, registry, vault, memory })
  // LIMO DEPLOYMENT COMMAND CENTER — real Vercel deploys, vault-held token (#20)
  registerDeployRoutes(app, { db, config, vault })
  // LIMO #21 — «الملفات» (jailed repo browser) + «التكاملات» (measured catalog)
  registerFilesRoutes(app, { config })
  registerIntegrationsRoutes(app, { db, config, registry, vault })

  // serve the exported web build when present (same artifact Tauri embeds).
  // @fastify/static serves index.html at '/' itself when it exists — no
  // explicit GET route (a duplicate would crash Fastify at boot).
  const webDist = config.webDist
  if (!opts.noStatic && webDist && existsSync(join(webDist, 'index.html'))) {
    void app.register(fastifyStatic, { root: webDist, wildcard: false })
    log.info('serving web build', { dir: webDist })
  }

  app.setErrorHandler((error: Error & { statusCode?: number; kind?: string; validation?: unknown[]; retryAfterSec?: number }, request, reply) => {
    const status = error.statusCode ?? 500
    const kind = error.kind
    if (kind) {
      // ProviderError — OpenAI-compatible error object
      return reply.code(status).send({
        error: {
          message: error.message,
          type: kind,
          code: status,
          ...(error.retryAfterSec ? { retry_after: error.retryAfterSec } : {}),
        },
      })
    }
    if (status === 400 && Array.isArray(error.validation)) {
      return reply.code(400).send({
        error: { message: error.message, type: 'invalid_request_error', code: 400 },
      })
    }
    log.error('unhandled error', { url: request.url, status, msg: error.message })
    return reply.code(status).send({
      error: { message: status >= 500 ? 'خطأ داخلي في الخادم' : error.message, type: 'internal_error', code: status },
    })
  })

  app.addHook('onClose', async () => {
    vault.lock() // §7.2: zero the master key on shutdown
    db.close()
  })

  return { app, deps: { config, db, vault, registry, breaker, log, memory, routineScheduler } }
}
