/**
 * LIMO COMPUTER PRO — universal engine adapter, phase 1: HONEST DETECTION
 * (directive §7.4: detect_engine / detect_version / validate_environment).
 *
 * What this module really does: looks for Blender / Godot / Unreal on THIS
 * machine (PATH lookup + documented install roots), parses their version
 * output, and reports what was measured — nothing else. An engine that is not
 * installed is reported `not_installed` with a hint; it is NEVER claimed.
 * Deeper adapter operations (create_project, run_tests, build…) are later
 * phases and are explicitly NOT implemented here.
 *
 * Security: execFile only (no shell), fixed candidate lists, 3s timeouts,
 * stdout/stderr capped, no network, nothing from the output is executed.
 */
import { execFile } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { promisify } from 'node:util'

const exec = promisify(execFile)

const VERSION_TIMEOUT_MS = 3000
const MAX_OUTPUT = 4096

export type EngineId = 'blender' | 'godot' | 'unreal'

export interface EngineProbe {
  id: EngineId
  nameAr: string
  nameEn: string
  /** 'found' only when an executable/install was actually measured on this host */
  status: 'found' | 'not_installed'
  version: string | null
  path: string | null
  /** can it run without a display (CI/phone/remote)? null = unknown/not installed */
  headless: boolean | null
  validation: { ok: boolean; notes: string[] }
  /** honest Arabic hint when missing — how the owner would connect it */
  hintAr: string | null
}

/** Platform facts for the system map — no usernames, no paths, no secrets. */
export function platformInfo() {
  return {
    node: process.version,
    platform: process.platform,
    arch: process.arch,
    termux: typeof process.env.TERMUX_VERSION === 'string' && process.env.TERMUX_VERSION !== '',
    termuxVersion: process.env.TERMUX_VERSION ?? null,
    uptimeSec: Math.floor(process.uptime()),
  }
}

// ---------------------------------------------------------------- parsers
// Pure functions — unit-tested with real fixture strings from each engine.

/** Blender prints `Blender 4.2.1 LTS` on the first line of `blender --version`. */
export function parseBlenderVersion(stdout: string): string | null {
  const m = stdout.match(/Blender\s+(\d+\.\d+(?:\.\d+)?(?:\s+LTS)?)/i)
  return m?.[1] ?? null
}

/** Godot 4 prints `4.2.1.stable.official.99909` from `godot --version`. */
export function parseGodotVersion(stdout: string): string | null {
  const line = stdout.split('\n').map((l) => l.trim()).find(Boolean) ?? ''
  const m = line.match(/^v?(\d+\.\d+(?:\.\d+)?)/)
  return m?.[1] ?? null
}

/** Unreal's Engine/Build/Build.version is XML: <MajorVersion>5</MajorVersion>… */
export function parseUnrealBuildVersion(xml: string): string | null {
  const major = xml.match(/<MajorVersion>(\d+)<\/MajorVersion>/)
  const minor = xml.match(/<MinorVersion>(\d+)<\/MinorVersion>/)
  const patch = xml.match(/<PatchVersion>(\d+)<\/PatchVersion>/)
  if (!major || !minor) return null
  return `${major[1]}.${minor[1]}${patch ? `.${patch[1]}` : ''}`
}

// ------------------------------------------------------------- exec helper
async function tryExec(cmd: string, args: string[]): Promise<string | null> {
  try {
    const { stdout } = await exec(cmd, args, { timeout: VERSION_TIMEOUT_MS, maxBuffer: MAX_OUTPUT })
    return stdout.slice(0, MAX_OUTPUT)
  } catch {
    return null
  }
}

/** PATH lookup without a shell: `which <name>` (Linux/macOS/Termux). */
async function which(name: string): Promise<string | null> {
  const out = await tryExec('which', [name])
  const p = out?.split('\n').map((l) => l.trim()).find(Boolean)
  return p && p.startsWith('/') ? p : null
}

function clamp(v: string): [number, number, number] {
  const parts = v.split('.').map((n) => Number.parseInt(n, 10) || 0)
  return [parts[0] ?? 0, parts[1] ?? 0, parts[2] ?? 0]
}

/** numeric compare of dotted versions: a >= b */
export function versionGte(a: string, b: string): boolean {
  const [a1, a2, a3] = clamp(a)
  const [b1, b2, b3] = clamp(b)
  if (a1 !== b1) return a1 > b1
  if (a2 !== b2) return a2 > b2
  return a3 >= b3
}

// ------------------------------------------------------------- detectors
async function detectBlender(): Promise<EngineProbe> {
  const base: Omit<EngineProbe, 'status' | 'version' | 'path' | 'headless' | 'validation' | 'hintAr'> = {
    id: 'blender', nameAr: 'بلندر — استوديو ثلاثي الأبعاد', nameEn: 'Blender',
  }
  const path = (await which('blender')) ?? (await which('blender-bin'))
  if (!path) {
    return {
      ...base, status: 'not_installed', version: null, path: null, headless: null,
      validation: { ok: false, notes: ['غير مثبّت على هذا الجهاز (بحث PATH فعلي).'] },
      hintAr: 'ثبّت بلندر 4.x (مثال لينكس: من blender.org أو مستودع توزيعتك) ثم أعد الفحص — الكشف تلقائي. على الهاتف: بلندر سطح مكتب لا يعمل داخل Termux، يعمل عبر جهاز موصول لاحقًا.',
    }
  }
  const out = await tryExec(path, ['--version'])
  const version = out ? parseBlenderVersion(out) : null
  const notes: string[] = []
  if (version) notes.push(`النسخة المقاسة: ${version}.`)
  else notes.push('وُجد التنفيذي لكن تعذّر قراءة النسخة — يُبلَّغ كما هو.')
  notes.push('يعمل بلا واجهة عبر ‎-b‎ (سكربتات بايثون/تصدير GLB وFBX وOBJ).')
  return {
    ...base, status: 'found', version, path,
    headless: true,
    validation: { ok: version !== null, notes },
    hintAr: null,
  }
}

async function detectGodot(): Promise<EngineProbe> {
  const base: Omit<EngineProbe, 'status' | 'version' | 'path' | 'headless' | 'validation' | 'hintAr'> = {
    id: 'godot', nameAr: 'جودو — محرك ألعاب خفيف', nameEn: 'Godot',
  }
  let path: string | null = null
  for (const cand of ['godot', 'godot4', 'godot-headless', 'godot4-headless']) {
    path = await which(cand)
    if (path) break
  }
  if (!path) {
    return {
      ...base, status: 'not_installed', version: null, path: null, headless: null,
      validation: { ok: false, notes: ['غير مثبّت على هذا الجهاز (بحث PATH فعلي: godot/godot4/godot-headless).'] },
      hintAr: 'نزّل جودو 4.x من godotengine.org (نسخة واحدة قابلة للتنفيذ) واجعله في PATH ثم أعد الفحص. يدعم ‎--headless‎ لتوليد/اختبار المشاريع من السطر دون شاشة.',
    }
  }
  const out = await tryExec(path, ['--version'])
  const version = out ? parseGodotVersion(out) : null
  const notes: string[] = []
  if (version) notes.push(`النسخة المقاسة: ${version}.`)
  else notes.push('وُجد التنفيذي لكن تعذّر قراءة النسخة — يُبلَّغ كما هو.')
  const headlessOk = version ? versionGte(version, '4.0') : false
  if (version && !headlessOk) notes.push('النسخة أقدم من 4.0: سيناريوهات GDScript 2 غير مضمونة.')
  if (headlessOk) notes.push('يدعم ‎--headless‎ (تشغيل واختبار بلا شاشة).')
  return {
    ...base, status: 'found', version, path,
    headless: version ? headlessOk : null,
    validation: { ok: version !== null && headlessOk, notes },
    hintAr: null,
  }
}

async function detectUnreal(): Promise<EngineProbe> {
  const base: Omit<EngineProbe, 'status' | 'version' | 'path' | 'headless' | 'validation' | 'hintAr'> = {
    id: 'unreal', nameAr: 'أنريل — استوديو AAA', nameEn: 'Unreal Engine',
  }
  // Unreal has no standard PATH binary; probe documented install roots only.
  const roots = [join(homedir(), 'UnrealEngine'), '/opt/UnrealEngine', '/usr/local/UnrealEngine', join(homedir(), 'unreal-engine')]
  const found = roots.find((r) => existsSync(join(r, 'Engine', 'Build', 'Build.version')))
  const pathBin = await which('unreal') // uncommon but honest to check
  const root = found ?? (pathBin ? pathBin : null)
  if (!root) {
    return {
      ...base, status: 'not_installed', version: null, path: null, headless: null,
      validation: { ok: false, notes: ['غير مثبّت (بحث PATH + جُذور التثبيت الموثقة: ~/UnrealEngine و/opt/UnrealEngine).'] },
      hintAr: 'أنريل محرك ثقيل يتطلب جهازًا قويًا ومصدرًا مبنيًا من GitHub (EpicGames/UnrealEngine) — لا يعمل في المتصفح ولا في Termux. عند توفر جهاز موصول ستُدار المهام الثقيلة عليه، والهاتف للمراقبة والموافقات.',
    }
  }
  const buildFile = join(root, 'Engine', 'Build', 'Build.version')
  let version: string | null = null
  try {
    version = parseUnrealBuildVersion(readFileSync(buildFile, 'utf8'))
  } catch {
    version = null
  }
  const notes = [`تثبيت مكتشف في ${root}.`]
  if (version) notes.push(`النسخة من Build.version: ${version}.`)
  else notes.push('تعذّرت قراءة Build.version — يُبلَّغ كما هو.')
  notes.push('التشغيل بلا شاشة عبر BuildGraph/سطر الأوامر فقط — لا محرر كامل في المتصفح.')
  return {
    ...base, status: 'found', version, path: root,
    headless: true, // command-line build automation exists; the EDITOR is not headless — stated in notes
    validation: { ok: version !== null, notes },
    hintAr: null,
  }
}

/** Detect all three engines — measured, honest, no claims. */
export async function detectEngines(): Promise<EngineProbe[]> {
  return Promise.all([detectBlender(), detectGodot(), detectUnreal()])
}
