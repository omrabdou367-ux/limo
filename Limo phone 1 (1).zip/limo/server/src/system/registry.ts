/**
 * LIMO COMPUTER PRO — subsystem registry (decision #17).
 *
 * The honest architecture map: every named subsystem classified from a REAL
 * source audit (2026-11-02) — code paths were opened and read, not inferred
 * from UI labels. Statuses are audit results, refreshed when subsystems change;
 * LIVE numbers (models, memory, tasks…) come from /api/system/map probes and
 * must never be hardcoded here.
 */

export type SubsystemStatus =
  | 'verified' // implemented + covered by tests / live checks
  | 'implemented' // implemented, not verified live in this audit
  | 'partial' // partially implemented (honest gaps documented in note)
  | 'mocked' // UI only / fake — the map must expose these loudly
  | 'broken'
  | 'missing'
  | 'unknown'

export const SUBSYSTEM_STATUSES: SubsystemStatus[] = [
  'verified', 'implemented', 'partial', 'mocked', 'broken', 'missing', 'unknown',
]

export type SubsystemGroup = 'intelligence' | 'knowledge' | 'creation' | 'platform'

export interface SubsystemEntry {
  id: string
  nameAr: string
  nameEn: string
  group: SubsystemGroup
  status: SubsystemStatus
  /** file-level evidence from the audit (displayed LTR) */
  evidence: string
  /** one honest line — what it really is, including limits */
  noteAr: string
}

export const AUDIT_DATE = '2026-11-02'

export const SUBSYSTEMS: SubsystemEntry[] = [
  // ---------------------------------------------------------- intelligence
  {
    id: 'hyperbrain', nameAr: 'هايبربرين — محرك الوكيل', nameEn: 'HYPERBRAIN (agent engine)',
    group: 'intelligence', status: 'verified',
    evidence: 'server/src/agent/{engine,roles,start,systemPrompt,tools}.ts',
    noteAr: 'مخطط ← منفّذ ← ناقد بحدود (8/12 خطوة). الأدوار التسعة قوائم أدوات + إضافات موجّه مع إعادة إسناد حتمية — ليست وكلاء منفصلين متوازين.',
  },
  {
    id: 'critic', nameAr: 'الناقد', nameEn: 'CRITIC',
    group: 'intelligence', status: 'verified',
    evidence: 'server/src/agent/engine.ts (criticVerdict)',
    noteAr: 'استدعاء نموذج منفصل (يفضَّل المجاني بالاختيار التلقائي) بحرارة 0؛ فشله يتراجع حتميًا إلى نجاح=اكتمال الخطوة.',
  },
  {
    id: 'debate', nameAr: 'المناظرة', nameEn: 'DEBATE',
    group: 'intelligence', status: 'missing',
    evidence: 'الأقرب الموجود: server/src/routes/compare.ts',
    noteAr: 'غير موجودة. الموجود: مقارنة 2–5 نماذج بالتوازي جنبًا إلى جنب بلا نقد متبادل أو إجماع — لن تُدّعى مناظرة.',
  },
  {
    id: 'swarm', nameAr: 'السرب / العقل الجماعي', nameEn: 'SWARM / HIVE MIND',
    group: 'intelligence', status: 'partial',
    evidence: 'server/src/box/brain.ts (launch_agent_task) · routes/workflows.ts',
    noteAr: 'الصندوق الأسود يطلق مهام HYPERBRAIN ويتابعها، وسير العمل يسلسلها — لكن حلقة التنفيذ واحدة تسلسلية: لا تفريخ وكلاء فرعيين ولا تنفيذ متوازٍ بعد.',
  },
  {
    id: 'autopilot', nameAr: 'الطيار الآلي', nameEn: 'AUTOPILOT (routines)',
    group: 'intelligence', status: 'verified',
    evidence: 'server/src/agent/routines.ts',
    noteAr: 'مجدول كل 20 ثانية يشغّل المحرك الحقيقي، بسياسات الخزنة الثلاث (تخطٍّ / تنزيل بلا مفتاح / تعويض عند الفتح).',
  },
  {
    id: 'model-intelligence', nameAr: 'ذكاء النماذج', nameEn: 'MODEL INTELLIGENCE',
    group: 'intelligence', status: 'verified',
    evidence: 'server/src/{catalog,router}/ · agent/autoselect.ts',
    noteAr: 'فهرس يومي من مصادر رسمية + ملف توجيه + اختيار تلقائي لكل غرض بسبب موثّق (حدث model_selected).',
  },
  {
    id: 'fallback-matrix', nameAr: 'مصفوفة الاحتياط', nameEn: 'FALLBACK MATRIX',
    group: 'intelligence', status: 'verified',
    evidence: 'server/src/gateway/routes.ts · router/breaker.ts',
    noteAr: 'سلسلة مزودين + قاطع دارة (3 فشل/60ث ← مفتوح 60ث). حدود معلنة: لا إعادة محاولة لنفس المزود، واستدعاءات محرك الوكيل نفسها خارج السلسلة (فجوة موثقة للمرحلة 2).',
  },
  {
    id: 'cost-intelligence', nameAr: 'ذكاء التكلفة', nameEn: 'COST INTELLIGENCE',
    group: 'intelligence', status: 'partial',
    evidence: 'server/src/db/{usage,egress}.ts · routes/usage.ts',
    noteAr: 'قياس حقيقي: استدعاءات/توكنات/مدد لكل مزود ونموذج + سجل خارج ببصمة لا محتوى. الناقص: ميزانية توكن لكل مهمة/وكيل — المرحلة 2.',
  },

  // ------------------------------------------------------------ knowledge
  {
    id: 'memory-matrix', nameAr: 'مصفوفة الذاكرة', nameEn: 'MEMORY MATRIX',
    group: 'knowledge', status: 'verified',
    evidence: 'server/src/agent/memory.ts',
    noteAr: 'ذاكرة متجهية (sqlite-vec أو js-cosine عند غياب الحزمة — معلَن دائمًا) + ذاكرة قصيرة حتمية بطيّ 8 مدخلات + استرجاع أعلى 4 للمخطط.',
  },
  {
    id: 'allimni', nameAr: 'علّمني — منظومة المهارات', nameEn: 'ALLIMNI (skills ecosystem)',
    group: 'knowledge', status: 'verified',
    evidence: 'server/src/skills/ (provider, inspect, security, compatibility, registry, pipeline, agentlink)',
    noteAr: 'اكتشاف حقيقي (نقطة CLI الرسمية العامة + محلي) + فحص 12 خطوة + بوابة خطر تمنع HIGH/CRITICAL حتى على المالك + توافق + سجل دورة حياة.',
  },
  {
    id: 'event-engine', nameAr: 'محرك الأحداث', nameEn: 'EVENT ENGINE',
    group: 'knowledge', status: 'verified',
    evidence: 'server/src/agent/bus.ts · gateway/sse.ts · migrations 0003/0006/0007',
    noteAr: 'أحداث مهمة دائمة + بث SSE + ثلاثة سجلات إضافية فقط (أحداث المهارة، تغييرات Forge، تعديلات الصندوق). لا ناقل عام على مستوى التطبيق.',
  },

  // ------------------------------------------------------------- creation
  {
    id: 'reality-forge', nameAr: 'مِسبكة الواقع', nameEn: 'REALITY FORGE',
    group: 'creation', status: 'verified',
    evidence: 'server/src/forge/ (orchestrator, scanner, sandbox, security) · routes/forge.ts',
    noteAr: 'فحص خريطة حقيقي ← اقتراحات ← L0–L4 ← تطبيق في فرع git عمل ← رجوع بـrevert. أوامر sandbox بقائمة سماح، و9 أصناف ملفات عالية الخطر تتوقف دائمًا عند بوابة المالك.',
  },
  {
    id: 'self-realm', nameAr: 'الصدَفة الذاتية — ليمو يبني ليمو', nameEn: 'SELF-REALM (chat-driven self-modification)',
    group: 'creation', status: 'verified',
    evidence: 'forge/orchestrator.ts (createChange/startChange/changeForChat) · box/brain.ts (forge_create, forge_change_status, forge_decide) · agent/tools.ts (self_read_file, self_search_code, self_start_change, self_change_status)',
    noteAr: 'الصندوق الأسود ومحرك الوكيل يطلقان تعديلات حقيقية على كود ليمو نفسه من الدردشة — عبر نفس خط أنابيب Reality Forge حصريًا (فرع معزول + اختبارات + مراجعة أمنية + بوابة المالك + تراجع revert). لا كتابة مباشرة للمصدر من أي مسار محادثة.',
  },
  {
    id: 'direct-action', nameAr: 'محرك التنفيذ المباشر', nameEn: 'DIRECT ACTION ENGINE',
    group: 'creation', status: 'verified',
    evidence: 'forge/orchestrator.ts (سلسلة التحقق + مخطط v2 + listChanges/cancelChange/forgeDepsFor) · routes/forge.ts (engineering-model + استعلام السجل + الإلغاء) · box/brain.ts (forge_history, forge_resume, قرار cancel) · config.ts (FORGE_LINT_COMMAND/FORGE_BUILD_COMMAND)',
    noteAr: 'فوق مسبكة Reality Forge نفسها لا بمحرك موازٍ: سلسلة تحقق متعددة الخطوات (تثبيت←تنظيف←اختبارات←بناء) كل خطوة مسجلة صادقة وأول فشل يوقف الخط ولا يُطبَّق شيء، مخطط v2 (تعقيد + تبعيات عكسية من رسم الاستيراد + مخاطر انحدار من دين المعمارية)، ذاكرة تغييرات قابلة للاستعلام من الدردشة + إلغاء واستئناف، وتثبيت «نموذج الذكاء الهندسي» (مثل nvidia/nemotron-3-ultra عبر OpenRouter الحقيقي — يتطلب مفتاح الخزنة). حدود معلنة: نشر Vercel مصمم ولم يُنفّذ بعد، والمحرر البصري الحي والمعاينة قبل/بعد مرحلة قادمة.',
  },
  {
    id: 'black-box', nameAr: 'الصندوق الأسود', nameEn: 'BLACK BOX',
    group: 'creation', status: 'verified',
    evidence: 'server/src/box/{brain,universal,profile}.ts · routes/box.ts',
    noteAr: 'محادثة بنموذج حقيقي و36 أداة JSON فعلية (حتى 5 جولات) تعدّل ليمو نفسه وتنشره — ومنها إطلاق التعديل الذاتي عبر المسبكة وذاكرة التغييرات واستئنافها ومركز نشر Vercel (معاينة + قراءة؛ الإنتاج قرار المالك)؛ بلا نموذج: النوايا القرارية الحتمية تعمل والتوليد يُرفض بصدق. سجل محادثة + تدقيق ملحق فقط.',
  },
  {
    id: 'code-realm', nameAr: 'مملكة الكود — مساحات المشاريع', nameEn: 'CODE REALM (project spaces)',
    group: 'creation', status: 'verified',
    evidence: 'server/src/projects/store.ts · routes/projects.ts · agent/tools.ts',
    noteAr: 'ملفات ثابتة (≤256KB) داخل سجن مسار لكل مشروع + معاينة بعزل CSP. حدود معلنة: لا تنفيذ لملفات المشروع على الخادم، لا نشر.',
  },
  {
    id: 'site-architect', nameAr: 'مهندس الموقع', nameEn: 'SITE ARCHITECT',
    group: 'creation', status: 'partial',
    evidence: 'server/src/box/universal.ts (inspect_frontend, read_source_file, search_source)',
    noteAr: 'طبقة قراءة فقط (جرد/قراءة/بحث بسجن وأسرار مستثناة). أي كتابة على مصدر التطبيق تمر حصريًا عبر Reality Forge وبوابته.',
  },
  {
    id: 'workflows', nameAr: 'مختبر سير العمل', nameEn: 'WORKFLOW LAB',
    group: 'creation', status: 'verified',
    evidence: 'server/src/routes/workflows.ts',
    noteAr: 'CRUD + تشغيل سلسلة (≤12 خطوة) عبر محرك HYPERBRAIN الحقيقي بنتائج صادقة (مكتمل/جزئي/فاشل). الفقرات نصية — لا خطوات أوامر.',
  },
  {
    id: 'engine-adapters', nameAr: 'محوّلات المحركات', nameEn: 'ENGINE ADAPTERS (Blender/Godot/Unreal)',
    group: 'creation', status: 'verified',
    evidence: 'server/src/system/engines.ts · routes/system.ts',
    noteAr: 'كشف حقيقي للمحركات من PATH/النظام (detect/version/validate) بلا أي ادعاء تثبيت — أساس استوديو الألعاب؛ العمليات الأعمق تُبنى فوقه مرحليًا.',
  },
  {
    id: 'web-forge', nameAr: 'مِسبكة الويب', nameEn: 'WEB FORGE',
    group: 'creation', status: 'missing',
    evidence: 'الأقرب الموجود: projects (ملفات ثابتة) + site-architect (قراءة)',
    noteAr: 'لا مولّد مواقع كامل بعد: لا معماري صفحات، لا قوالب، لا معاينة فروق حية. تُبنى فوق مساحات المشاريع في مرحلة قادمة — لن تُدّعى قبل ذلك.',
  },
  {
    id: 'game-forge', nameAr: 'مِسبكة الألعاب', nameEn: 'GAME FORGE',
    group: 'creation', status: 'missing',
    evidence: 'بحث المستودع الكامل 2026-11-02: blender/godot/unreal/لعبة = صفر نتائج',
    noteAr: 'لا كود ألعاب في المستودع: لا أنواع، لا توليد عوالم، لا NPC. أول لبنة فعلية = محوّلات المحركات أعلاه؛ الباقي خطة مراحل معلنة لا ادعاء.',
  },

  // ------------------------------------------------------------- platform
  {
    id: 'world-connect', nameAr: 'وصل العالم — التكاملات', nameEn: 'WORLD CONNECT (integrations)',
    group: 'platform', status: 'verified',
    evidence: 'server/src/routes/custom-providers.ts · providers/ollama.ts',
    noteAr: 'مزودو ذكاء اصطناعي فقط: مفاتيح BYOK + نقاط متوافقة مع OpenAI + كشف Ollama المحلي. لا SaaS خارجي ولا webhooks داخلية — أبعادها معلنة بلا تضخيم.',
  },
  {
    id: 'observer', nameAr: 'المراقب', nameEn: 'OBSERVER',
    group: 'platform', status: 'partial',
    evidence: 'server/src/health.ts · db/usage.ts · routes/egress.ts',
    noteAr: 'المقاييس الفعلية موجودة (صحة، استخدام، خارج) لكنها متفرقة على شاشات — لا لوحة مراقبة موحّدة باسم OBSERVER بعد؛ خريطة النظام هذه أول خطوة نحوها.',
  },
  {
    id: 'sentinel', nameAr: 'الحارس — الأمن', nameEn: 'SENTINEL (security)',
    group: 'platform', status: 'verified',
    evidence: 'server/src/vault/ · auth/guard.ts · agent/types.ts (الموافقات) · projects/store.ts (سجن المسار)',
    noteAr: 'خزنة AES-256-GCM بمفتاح آلة + حارس (مفتاح باطل=401) + موافقات المالك الست + سجون مسار + كشف أسرار. حدود: 3 من فئات الموافقات الست مستعملة فعليًا بالأدوات.',
  },
  {
    id: 'deployment-center', nameAr: 'مركز النشر', nameEn: 'DEPLOYMENT COMMAND CENTER (Vercel)',
    group: 'platform', status: 'verified',
    evidence: 'server/src/deploy/{vercel,artifact}.ts · routes/deploy.ts · db/migrations/0008_deploy.sql',
    noteAr: 'نشر حقيقي عبر واجهة Vercel الرسمية برمز المالك المخزَّن مشفرًا في الخزنة: رفع البناء الثابت الفعلي، حالة readyState كما تجيب Vercel، سجل أحداث حقيقي، دفتر نشرات محلي، وترقية/استرجاع الإنتاج بأزرار المالك حصرًا (بلا أدوات نموذج). لم يُخترع عنوان URL قط — كل رابط من إجابة Vercel نفسها.',
  },
  {
    id: 'desktop', nameAr: 'تطبيق سطح المكتب', nameEn: 'DESKTOP (Tauri v2)',
    group: 'platform', status: 'implemented',
    evidence: 'apps/desktop/ (tauri.conf.json, src/lib.rs, ui/)',
    noteAr: 'غلاف Tauri v2 رفيع (مفاتيح سلسلة، إعدادات ترفض الحقول الشبيهة بالمفاتيح، CSP صارم). لم يُجمَّع في بيئة البناء الحالية — لا سلسلة Rust — لذا يُوسم منفذًا لا مُتحققًا منه هنا.',
  },
  {
    id: 'phone', nameAr: 'حزمة الجوال', nameEn: 'PHONE (Termux)',
    group: 'platform', status: 'verified',
    evidence: 'scripts/build_phone_package.py · phone-check.mjs (محاكاة نظيفة كاملة، القرار 16)',
    noteAr: 'عملية Node واحدة على :8787 تخدم الواجهة المصدَّرة + الخادم، مع فحص ذاتي 5 نقاط. حدود معلنة: لا جهاز أندرويد فيزيائي في بيئة البناء — المالك شغّلها فعليًا على هاتفه.',
  },
]
