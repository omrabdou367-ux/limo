/**
 * One-time legacy vault migration (LIMO decision #8 — password system removed).
 *
 * Converts a pre-#8 passphrase-wrapped vault (argon2id KEK) into a
 * machine-key-wrapped vault (scrypt KEK from dataDir/vault.key), keeping the
 * SAME master key so every stored secret survives untouched.
 *
 * Usage (from the server package):
 *   npx tsx scripts/migrate-vault.ts <old-passphrase>
 */
import { resolve } from 'node:path'
import { loadDotEnv } from '../src/config.js'
import { openDatabase } from '../src/db/database.js'
import { deleteSetting } from '../src/db/settings.js'
import { Vault } from '../src/vault/vault.js'
import { ensureMachineKey } from '../src/vault/machineKey.js'

/** Dead settings from the removed password system (LIMO #8). */
function purgeLegacySettings(db: ReturnType<typeof openDatabase>): string[] {
  const purged: string[] = []
  for (const key of ['passphrase_hash', 'session_hmac_key', 'session_epoch']) {
    try {
      deleteSetting(db, key)
      purged.push(key)
    } catch {
      /* ignore */
    }
  }
  return purged
}

async function main(): Promise<void> {
  const passphrase = process.argv[2]
  if (!passphrase) {
    console.error('usage: npx tsx scripts/migrate-vault.ts <old-passphrase>')
    process.exit(1)
  }
  Object.assign(process.env, loadDotEnv(new URL('../.env', import.meta.url).pathname))
  const dataDir = resolve(process.env.DATA_DIR ?? './data')

  const db = openDatabase(dataDir)
  const vault = new Vault(db)
  if (vault.state === 'uninitialized') {
    console.log('vault is uninitialized — nothing to migrate (boot will create it)')
    process.exit(0)
  }
  if (!vault.isLegacy) {
    const purged = purgeLegacySettings(db)
    console.log(`vault is already machine-key wrapped — nothing to do (purged dead settings: ${purged.length})`)
    process.exit(0)
  }

  const machineSecret = ensureMachineKey(dataDir)
  const ok = await vault.migrateLegacyPassphrase(passphrase, machineSecret)
  if (!ok) {
    console.error('migration failed — wrong passphrase (GCM auth failure)')
    process.exit(1)
  }
  const secrets = vault.listSecrets()
  const purged = purgeLegacySettings(db)
  console.log(`migrated ✓ — vault unwrapped with the machine key; ${secrets.length} secret(s) preserved; dead settings purged: ${purged.join(', ') || 'none'}`)
  db.close()
}

main().catch((e) => {
  console.error('[limo] fatal:', e)
  process.exit(1)
})
