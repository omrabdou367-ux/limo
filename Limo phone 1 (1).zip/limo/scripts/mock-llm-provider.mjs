#!/usr/bin/env node
/**
 * mock-llm-provider — a tiny OpenAI-compatible stand-in (LM Studio style)
 * for LOCAL testing of LIMO without real provider keys.
 *
 *   node scripts/mock-llm-provider.mjs          # listens on 127.0.0.1:9911
 *
 * Then add it as a custom provider (Integrations → Custom):
 *   id: mock · baseUrl: http://127.0.0.1:9911/v1 · needsKey: false
 *
 * The brain is a deterministic contextual script (box tools, agent planner,
 * critic) — it stands in for a real model; the ENTIRE LIMO stack around it
 * (gateway adapter, vault policy, egress log, box brain loop, tools, audit,
 * agent engine) is the real production code path.
 *
 * LIMO #15 — LEGENDARY COMPOUND CHAINS: one owner request resolves to a
 * SEQUENCE of tool calls across the brain's real multi-round loop (each real
 * result is fed back before the next call), exactly how a strong model
 * behaves — including result-aware args (the builder chain reads the fresh
 * projectId from the REAL create_project result) and an over-budget chain
 * that exercises the loop's honest 5-round exhaustion path.
 */
import { createServer } from 'node:http'

const PORT = Number(process.env.MOCK_PORT ?? 9911)

const PLAN_TWO = JSON.stringify({
  steps: [
    { title: 'قراءة الوقت الحالي', tool: 'get_time', args: {}, acceptance: 'تعيد الأداة وقتًا ISO صالحًا' },
    { title: 'حفظ ملاحظة بالنتيجة', tool: 'memory_write', args: { title: 'تقرير الحاسوب الخارق', content: 'وقت النظام مسجل' }, acceptance: 'تُنشأ ملاحظة' },
  ],
})
const CRITIC_PASS = JSON.stringify({ pass: true, reason: 'حقق شرط القبول بدليل من النتيجة', evidence: 'ok' })

// LIMO #18 — the scripted FORGE engineer: when the box/agent drives a real
// self-modification, the forge pipeline asks ITS model for a plan + patch.
// This deterministic plan targets hello.txt (the demo/fixture repo layout).
const FORGE_PLAN = JSON.stringify({
  summary: 'إضافة سطر ترحيبي في نهاية hello.txt — التعديل الذاتي الأول من الدردشة',
  steps: [{ title: 'تعديل hello.txt', detail: 'سطر واحد يُضاف في النهاية' }],
  files: ['hello.txt'],
  risks: [],
  patch: ['--- a/hello.txt', '+++ b/hello.txt', '@@ -1 +1,2 @@', ' hello', '+مرحًا من التعديل الذاتي', ''].join('\n'),
})
const NEW_FILE_PLAN = JSON.stringify({
  summary: 'إنشاء ملف self-realm-demo.md في جذر المستودع — عرض بوابة الحماية',
  steps: [{ title: 'ملف جديد', detail: 'ملف واحد يُنشأ' }],
  files: ['self-realm-demo.md'],
  risks: [],
  patch: ['--- /dev/null', '+++ b/self-realm-demo.md', '@@ -0,0 +1,1 @@', '+<!-- لمسة من بوابة الموافقة -->', ''].join('\n'),
})
// LIMO #19 — the DIRECT ACTION planner demo: a change on hello-mod.ts (a
// file with a measured reverse dependency + untested debt) so the planner v2
// fields (complexity / dependencies / regressions) carry REAL data.
const HELLO_MOD_PLAN = JSON.stringify({
  summary: 'إضافة دالة bonus إلى hello-mod.ts — تعديل مباشر بملف له تبعيات مقيسة',
  steps: [{ title: 'تعديل hello-mod.ts', detail: 'سطر تصدير واحد يُضاف في النهاية' }],
  files: ['server/src/hello-mod.ts'],
  risks: [],
  complexity: 'low',
  complexityReason: 'ملفان متأثران وتبعية عكسية واحدة مقيسة من رسم الاستيراد',
  dependencies: [],
  regressions: [],
  patch: [
    '--- a/server/src/hello-mod.ts',
    '+++ b/server/src/hello-mod.ts',
    '@@ -88,3 +88,4 @@',
    ' export const filler87 = 87',
    ' export const filler88 = 88',
    '+export const bonus = 42',
    ' export const filler89 = 89',
    '',
  ].join('\n'),
})

// ------------------------------------------------------------ legendary chains

/** find the request that started the CURRENT box turn (the last plain user
 *  message — stored history box replies are assistant turns, tool results
 *  start with «نتيجة أداة»). */
function originalRequest(messages) {
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i]
    if (m.role === 'user' && !(m.content ?? '').startsWith('نتيجة أداة')) return m.content ?? ''
  }
  return ''
}

/** parse the {ok,data|error} JSON embedded in a real tool-result message. */
function parseToolResult(text) {
  // the JSON sits between the tool header and the «أكمل الآن» footer —
  // capture ONLY the JSON (lookahead), never the footer itself
  const m = text.match(/\{[\s\S]*\}\s*(?=\n\nأكمل الآن)/) ?? text.match(/^نتيجة أداة[^\n]*\n([\s\S]*?)\n\nأكمل الآن/)
  if (!m) return null
  try {
    return JSON.parse(m[1] ?? m[0])
  } catch {
    return null
  }
}

const LEGENDARY_CHAINS = [
  {
    id: 'identity',
    match: (q) => /مهمة أسطورية: هوية كاملة/.test(q),
    steps: [
      { tool: 'set_app_name', args: { name: 'أسطورة' } },
      { tool: 'set_tagline', args: { tagline: 'صُنع ليبني المستحيل.' } },
      { tool: 'set_accent', args: { accent: 'crimson' } },
      { tool: 'create_access_link', args: { name: 'جهاز الأسطورة' } },
    ],
    final:
      'اكتملت المهمة الأسطورية فعليًا: الاسم صار «أسطورة»، الشعار واللون القرمزي انعكسا على الواجهة، ورابط الوصول الجديد مع مفتاحه أمامك الآن — انسخه فلن يظهر مجددًا. كل إجراء موثّق في سجل التدقيق.',
  },
  {
    id: 'engineering',
    match: (q) => /اشعاع هندسي كامل/.test(q),
    steps: [
      { tool: 'inspect_frontend', args: {} },
      { tool: 'read_source_file', args: { path: 'apps/web/src/lib/nav.ts' } },
      { tool: 'search_source', args: { query: 'AgentView' } },
      { tool: 'memory_write', args: { title: 'خلاصة الاشعاع الهندسي', content: 'جرد الواجهة + قراءة ملف التنقل + بحث AgentView — كلها عبر أدوات حقيقية بنتائج موثقة' } },
    ],
    final:
      'الاشعاع الهندسي اكتمل: جردت الواجهة الفعلية، قرأت ملف التنقل من المصدر، بحثت عن AgentView، وحفظت الخلاصة في ذاكرة ليمو الحقيقية — كل خطوة أداتها ونتيجتها أمامك.',
  },
  {
    id: 'builder',
    match: (q) => /ابنِ لي مشروعًا أسطوريًا/.test(q),
    steps: [
      { tool: 'create_project', args: { name: 'مشروع الأسطورة', kind: 'web_app', description: 'مشروع يبنيه الصندوق عبر أدواته الحقيقية' } },
      { tool: 'write_project_file', argsFrom: (prev) => ({ projectId: prev?.data?.id, path: 'index.html', content: '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>مشروع الأسطورة</title></head><body><h1>مشروع الأسطورة — بناه الصندوق الأسود</h1></body></html>' }) },
      { tool: 'launch_agent_task', args: { goal: 'ابنِ صفحة رئيسية كاملة لمشروع الأسطورة بحيث تصف قدراته، ثم حقّق اكتمالها', mode: 'build', model: 'auto', projectId: null } },
    ],
    final:
      'المشروع الأسطوري قائم فعليًا: أنشأت مساحته المعزولة، كتبت ملف index.html حقيقيًا داخلها، وأطلقت مهمة وكيل build تعمل الآن في محرك HYPERBRAIN — تابعها من مساحة الوكيل بأحداثها الحية.',
  },
  {
    // THE CRAZY PROBE — six tools for a five-round budget: the loop must stop
    // honestly and SAY it ran out of rounds (real limit, no fake completion).
    id: 'exhaustion',
    match: (q) => /مجنونة جدًا: ست أدوات/.test(q),
    steps: [
      { tool: 'set_tagline', args: { tagline: 'الأداة الأولى من ست.' } },
      { tool: 'set_accent', args: { accent: 'ocean' } },
      { tool: 'set_theme_mode', args: { mode: 'dark' } },
      { tool: 'memory_write', args: { title: 'سلسلة مجنونة', content: 'أداة رابعة من ست' } },
      { tool: 'create_project', args: { name: 'سلسلة-مجنونة', kind: 'notes' } },
      { tool: 'write_project_file', argsFrom: (prev) => ({ projectId: prev?.data?.id, path: 'note.md', content: 'الأداة السادسة' }) },
    ],
    final: 'لن يصل هذا الرد أبدًا — الميزانية تنفد قبله وهذا هو هدف الاختبار.',
  },
]

function think(messages) {
  const last = messages[messages.length - 1]?.content ?? ''
  if (last.includes('أعد الخطة الآن')) {
    // LIMO #25 — the agent planner classifies first: a plain greeting/question
    // is answered conversationally ({"mode":"chat","reply"}), real work gets
    // the plan. Keyed on the GOAL LINE ONLY (first line «المهمة: ...»).
    const goalLine = last.split('\n')[0] ?? ''
    const goal = goalLine.replace(/^المهمة:\s*/, '')
    // NB: no \b here — Arabic letters are not \w in JS regex, so \b NEVER
    // matches between them; the greeting must be the whole (short) message.
    if (/^\s*(اهلا|أهلا|مرحبا|مرحبًا|هلا|هاي|سلام|السلام عليكم|شكرا|شكرًا|كيف حالك|من أنت|مين أنت|hi|hello)\s*[؟?!.,،]*(\s*(من أنت|مين أنت|كيف حالك|ماذا تفعل|وش تقدر)\s*[؟?!.,،]*)?\s*$/i.test(goal)) {
      return JSON.stringify({
        mode: 'chat',
        reply: 'أهلًا وسهلًا! أنا **ليمو** — وكيلك الهندسي على جهازك.\n\nكيف أخدمك اليوم؟ اكتب لي مهمة مثل «افحص الواجهة» أو اسألني أي سؤال.',
      })
    }
    return PLAN_TWO
  }
  if (last.includes('أعد حكمك الآن') || last.includes('أعد الخطوة المصحّحة')) return CRITIC_PASS
  // the forge engineer's plan request (its prompt ends with «أعد JSON فقط»)
  if (/أعد JSON فقط/.test(last)) {
    if (/hello-mod/.test(last)) return HELLO_MOD_PLAN
    return /self-realm-demo/.test(last) ? NEW_FILE_PLAN : FORGE_PLAN
  }

  // ---- LIMO #18 self-realm: chat-driven self-modification ---------------
  if (last.startsWith('نتيجة أداة forge_create')) {
    const prev = parseToolResult(last)
    if (prev?.ok && prev.data?.id) return JSON.stringify({ tool: 'forge_change_status', args: { id: prev.data.id } })
    return `لم ينطلق التعديل الذاتي — الأداة أعادت خطأ حقيقيًا: ${prev?.error ?? 'غير معروف'}. هذا بصدق: لا تزييف.`
  }
  if (last.startsWith('نتيجة أداة forge_change_status')) {
    const prev = parseToolResult(last)
    if (prev?.ok && prev.data?.status === 'awaiting_approval') {
      const c = prev.data
      const chainTxt = (c.test?.steps ?? []).map((s) => `${s.name}:${s.code === 0 ? '✓' : '✗'}`).join(' · ')
      const lines = [
        `وصل التعديل الذاتي #${c.id} إلى **بوابة موافقتك** — القرار لك الآن:`,
        `• الطلب: ${c.request}`,
        `• الخطة: ${c.planSummary ?? '—'}`,
        `• التعقيد: ${c.complexity ?? '—'}${(c.dependencies ?? []).length ? ` · التبعيات العكسية: ${c.dependencies.join(' · ')}` : ''}`,
        `• الملفات المتأثرة: ${(c.affectedFiles ?? []).join(' · ') || '—'}`,
        `• سلسلة التحقق: ${chainTxt || (c.test?.skipped ? 'متخطّاة بالمستوى' : '—')}`,
        `• المراجعة الأمنية: ${c.security?.verdict ?? '—'}${c.security?.findings ? ` (${c.security.findings} ملاحظة)` : ''}`,
      ]
      if ((c.regressions ?? []).length) lines.push(`• مخاطر الانحدار: ${c.regressions.join(' · ')}`)
      if (c.diff) lines.push(`• الفرق (مقتطف):\n${c.diff.slice(0, 300)}`)
      else lines.push('• لا فرق بعد')
      lines.push(`قل «طبّق التغيير الذاتي رقم ${c.id}» للدمج، أو «ارفض التغيير رقم ${c.id}» للإسقاط — أنا لا أطبق دون كلمتك (أو سياسة L4).`)
      return lines.join('\n')
    }
    if (prev?.ok) return `التعديل الذاتي #${prev.data.id} ما زال في حالة «${prev.data.status}» — خط الأنابيب الحقيقي يعمل (فحص/عزل/اختبارات). اسألني «ما حالة التغيير رقم ${prev.data.id}؟» بعد لحظات.`
    return `تعذّرت قراءة الحالة: ${prev?.error ?? 'سبب غير معروف'}`
  }
  // ---- LIMO #19 DIRECT ACTION: change memory + interruption + resume ----
  if (last.startsWith('نتيجة أداة forge_history')) {
    const prev = parseToolResult(last)
    if (prev?.ok) {
      const rows = prev.data?.changes ?? []
      return [
        `ذاكرة التغييرات الحقيقية من قاعدة البيانات — ${prev.data?.count ?? 0} سجلًا:`,
        ...rows.map((r) => `• #${r.id} «${r.request}» — ${r.status}${r.model ? ` · ${r.model}` : ''}${r.commit ? ` · التزام ${String(r.commit).slice(0, 10)}` : ''} (${String(r.updatedAt ?? '—').slice(0, 10)})`),
        'هذا سجل مقروء من الصفوف الفعلية لا من ذاكرة متخيلة — استئناف غير المنتهي أو التراجع عن المطبَّق بأمرك.',
      ].join('\n')
    }
    return `تعذّر قراءة السجل: ${prev?.error ?? 'غير معروف'}`
  }
  if (last.startsWith('نتيجة أداة forge_resume')) {
    const prev = parseToolResult(last)
    if (prev?.ok) return `استُؤنف التغيير #${prev.data?.id} من حيث توقف فعليًا — سيتابع خط المسبكة. اسألني «ما حالة التغيير رقم ${prev.data.id}؟»`
    return `لا استئناف: ${prev?.error ?? 'غير معروف'} — لا تزييف.`
  }
  if (/سجل تغييرات المسبكة|ماذا غيّرت|سجل التغييرات/.test(last)) {
    return JSON.stringify({ tool: 'forge_history', args: { limit: 10 } })
  }
  {
    const m = last.match(/أكمل (?:آخر )?(?:مهمة|تغيير)(?: هندسي(?:ة)?)?(?: غير المنتهي)?(?: رقم\s*(\d+))?/)
    if (m && /تغيير|مهمة|هندسي/.test(last)) return JSON.stringify({ tool: 'forge_resume', args: m[1] ? { id: Number(m[1]) } : { id: null } })
  }
  {
    const m = last.match(/ألغِ (?:التغيير|المهمة)(?: الذاتي)? رقم\s*(\d+)/)
    if (m) return JSON.stringify({ tool: 'forge_decide', args: { id: Number(m[1]), decision: 'cancel' } })
  }
  if (last.startsWith('نتيجة أداة forge_decide')) {
    const prev = parseToolResult(last)
    if (prev?.ok) {
      const c = prev.data?.change ?? {}
      return `نُفّذ قرارك فعليًا عبر بوابة المسبكة: الحالة الآن «${c.status}»${c.commitId ? ` والالتزام ${String(c.commitId).slice(0, 12)}` : ''}${c.rollbackOf ? ` (تراجع عن ${String(c.rollbackOf).slice(0, 12)})` : ''}. السجل ملحق فقط — يمكن مراجعته من شاشة مِسبكة الواقع.`
    }
    return `لم ينفَّذ القرار: ${prev?.error ?? 'سبب غير معروف'} — لا تزييف.`
  }
  if (/الصدفة الذاتية: عدّل كود ليمو/.test(last)) {
    return JSON.stringify({ tool: 'forge_create', args: { request: 'أضف سطرًا ترحيبيًا جديدًا في نهاية ملف hello.txt في جذر المستودع' } })
  }
  if (/الصدفة الذاتية على المشروع الحقيقي/.test(last)) {
    return JSON.stringify({ tool: 'forge_create', args: { request: 'أنشئ ملف self-realm-demo.md في جذر المستودع يحتوي تعليق HTML' } })
  }
  {
    const m = last.match(/طبّق التغيير الذاتي رقم\s*(\d+)/)
    if (m) return JSON.stringify({ tool: 'forge_decide', args: { id: Number(m[1]), decision: 'apply' } })
  }
  {
    const m = last.match(/(?:ارفض|ارفضه|ارفض التغيير)(?: الذاتي)?(?: رقم\s*(\d+))?/)
    if (m && /تغيير|الذاتي/.test(last)) return JSON.stringify({ tool: 'forge_decide', args: { id: m[1] ? Number(m[1]) : null, decision: 'reject' } })
  }
  {
    const m = last.match(/تراجع عن التغيير الذاتي رقم\s*(\d+)/)
    if (m) return JSON.stringify({ tool: 'forge_decide', args: { id: Number(m[1]), decision: 'rollback' } })
  }
  {
    const m = last.match(/ما حالة التغيير رقم\s*(\d+)/)
    if (m) return JSON.stringify({ tool: 'forge_change_status', args: { id: Number(m[1]) } })
  }

  // ---- legendary compound chains: continue from the REAL tool result ----
  if (last.startsWith('نتيجة أداة')) {
    const chain = LEGENDARY_CHAINS.find((c) => c.match(originalRequest(messages)))
    if (chain) {
      const m = last.match(/^نتيجة أداة\s+([^\s(]+)/)
      const doneTool = m ? m[1] : ''
      const idx = chain.steps.findIndex((s) => s.tool === doneTool)
      if (idx >= 0 && idx + 1 < chain.steps.length) {
        const next = chain.steps[idx + 1]
        const prev = parseToolResult(last)
        const args = next.argsFrom && prev?.ok ? next.argsFrom(prev) : next.args
        return JSON.stringify({ tool: next.tool, args })
      }
      if (idx >= 0 && idx + 1 === chain.steps.length) return chain.final
    }
  }

  // Black Box tool-result rounds → the final reply
  if (last.startsWith('نتيجة أداة create_access_link')) {
    return 'جاهز — أنشأت رابط وصول جديدًا مع مفتاحه. انسخ المفتاح الآن فلن يظهر مرة أخرى، واستخدمه مع البوابة المتوافقة مع OpenAI على /v1.'
  }
  if (last.startsWith('نتيجة أداة')) {
    return 'تم التنفيذ فعليًا عبر أداة حقيقية — سترى الإجراء ومخرجاته أسفل هذا الرد، وينعكس التغيير في الواجهة فورًا.'
  }

  // ---- legendary compound chains: the opening call ----
  const opening = LEGENDARY_CHAINS.find((c) => c.match(last))
  if (opening) return JSON.stringify({ tool: opening.steps[0].tool, args: opening.steps[0].args })

  // Black Box first-round tool calls
  if (/رابط/.test(last)) {
    return JSON.stringify({ tool: 'create_access_link', args: { name: 'جهاز المالك' } })
  }
  // LIMO #13 — appearance + skills
  if (/(لون|أخضر|accent|color)/.test(last)) {
    return JSON.stringify({ tool: 'set_accent', args: { accent: 'forest' } })
  }
  if (/(ثيم|داكن|فاتح|theme)/.test(last)) {
    const mode = /(فاتح|light)/.test(last) ? 'light' : /(النظام|system)/.test(last) ? 'system' : 'dark'
    return JSON.stringify({ tool: 'set_theme_mode', args: { mode } })
  }
  // LIMO #14 — the universal agent tools (any request, all wired to the model)
  if (/الواجهة الأمامية|inspect frontend/.test(last)) {
    return JSON.stringify({ tool: 'inspect_frontend', args: {} })
  }
  if (/أطلق مهمة|launch a(ge)?nt/.test(last)) {
    return JSON.stringify({ tool: 'launch_agent_task', args: { goal: 'مهمة من الصندوق: اقرأ الوقت الحالي وسجّل خلاصة', mode: 'auto', model: 'auto' } })
  }
  if (/اقرأ الملف|اقرأ مصدر/.test(last)) {
    return JSON.stringify({ tool: 'read_source_file', args: { path: 'apps/web/src/lib/nav.ts' } })
  }
  if (/ابحث في المصدر/.test(last)) {
    return JSON.stringify({ tool: 'search_source', args: { query: 'AgentView' } })
  }
  if (/اكتب ملاحظة|احفظ ملاحظة/.test(last)) {
    return JSON.stringify({ tool: 'memory_write', args: { title: 'خلاصة جلسة الصندوق', content: 'فحص الواجهة وإطلاق مهمة وكيل تمّا عبر أدوات حقيقية' } })
  }
  if (/ابحث في الذاكرة/.test(last)) {
    return JSON.stringify({ tool: 'memory_search', args: { query: 'خلاصة جلسة الصندوق' } })
  }
  if (/(مهارة|مهارات|ابحث)/.test(last)) {
    return JSON.stringify({ tool: 'search_skills', args: { query: 'react' } })
  }
  const nameMatch = last.match(/(?:إلى|اسمه|as)\s+([^\n.,!?]+)/)
  if (/(غيّر|غير|سمّ|سم|اجعل|عرف|rename|name)/.test(last) && /(اسم|الاسم|name)/.test(last) && nameMatch) {
    const name = nameMatch[1].trim().slice(0, 40)
    if (name.length >= 2) return JSON.stringify({ tool: 'set_app_name', args: { name } })
  }
  if (/(شعار|tagline)/.test(last)) {
    return JSON.stringify({ tool: 'set_tagline', args: { tagline: 'اصنع. عدّل. تطوّر.' } })
  }
  if (/(حالة|النظام|status)/.test(last)) {
    return JSON.stringify({ tool: 'get_system_status', args: {} })
  }
  if (/(نموذج|model)/.test(last) && /(قائمة|النماذج|المتاحة|list)/.test(last)) {
    return JSON.stringify({ tool: 'list_models', args: {} })
  }

  // honesty probes — impossible / out-of-bounds requests are REFUSED with
  // the real boundary, never faked (mirrors the universal-agent system prompt)
  // LIMO #18: the boundary moved UP a level — direct writes stay forbidden,
  // but a real gated path now exists and is offered honestly.
  if (/عدّل كود|عدل كود الخادم|غيّر الكود المصدري|modify (the )?(server )?code/.test(last)) {
    return 'لا أكتب كود ليمو مباشرة أبدًا — المسار الحقيقي الوحيد هو Reality Forge عبر forge_create: فرع git معزول واختبارات ومراجعة أمنية ثم بوابة موافقتك ومعها التراجع. قل «الصدفة الذاتية: عدّل كود ليمو …» وأوصف التعديل.'
  }
  // LIMO #22 — markdown rendering probe: real models answer with markdown
  // (## / **bold** / lists), so the mock must be able to produce the same
  // shape to verify the chat renders it instead of showing raw glyphs.
  if (/جرّب التنسيق|markdown/.test(last)) {
    return [
      '## نصيحتي: خيار 1 أو 2 — يعملان الآن وبدون تعقيد',
      '',
      '**الأول:** اربط نموذجًا حقيقيًا من `لوحة الخزنة` — الأسهل OpenRouter أو Groq.',
      '',
      '**الثاني:** جرّب بلا أي مفتاح عبر المزود المحلي:',
      '',
      '1. شغّل المزود الوهمي في جلسة ثانية',
      '2. أضفه من *التكاملات* ← مزودون مخصصون',
      '3. اختر `mock/nova-mind` من خانة النماذج',
      '',
      '```',
      'cd ~/limo && node scripts/mock-llm-provider.mjs',
      '```',
      '',
      'ثم افتح الصندوق وتحدث معي طبيعيًا — أنا أرد دائمًا.',
    ].join('\n')
  }
  if (/امسح كل بيانات|احذف كل|wipe (all )?data|delete everything/.test(last)) {
    return 'لا أملك أداة تمسح كل البيانات — وهذا مقصود: لا يوجد مسار تدمير شامل بأوامر المحادثة. أستطيع مسح سجل محادثتنا فقط بطلبك.'
  }

  // plain free chat — an honest non-tool reply
  return 'أفهم طلبك. أنا وكيل هندسي عالمي أعمل بأدوات حقيقية: تعديل الهوية والألوان والثيم، فحص شجرة الواجهة وقراءة المصدر والبحث فيه، إطلاق مهام وكيل HYPERBRAIN لأي طلب كبير، المشاريع والذاكرة والمهارات عبر عَلِّمني، فحص المحرك وروابط الوصول وقوائم النماذج. اطلب أي شيء — الصغير أنفّذه مباشرة والكبير أطلقه كمحطة عمل.'
}

const server = createServer((req, res) => {
  // wrong-key probe (LIMO #15 gauntlet): a REAL provider authenticates
  // INFERENCE, not the public catalog — OpenRouter-style: /models is open,
  // /chat/completions with a bad key answers 401. The stack exercises its
  // honest-failure path end to end exactly like a real cloud key would.
  if (
    req.method === 'POST' &&
    req.url.endsWith('/chat/completions') &&
    req.headers.authorization === 'Bearer wrong-key-test'
  ) {
    res.writeHead(401, { 'content-type': 'application/json' })
    res.end(JSON.stringify({ error: { message: 'Incorrect API key provided: wrong-key-test', type: 'invalid_request_error', code: 'invalid_api_key' } }))
    return
  }
  if (req.method === 'GET' && req.url.endsWith('/models')) {
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end(
      JSON.stringify({
        object: 'list',
        data: [
          { id: 'nova-mind', owned_by: 'mock', context_length: 32768 },
          { id: 'nova-mini', owned_by: 'mock', context_length: 8192 },
        ],
      }),
    )
    return
  }
  if (req.method === 'POST' && req.url.endsWith('/chat/completions')) {
    let body = ''
    req.on('data', (c) => (body += c))
    req.on('end', () => {
      let messages = []
      try {
        messages = JSON.parse(body).messages ?? []
      } catch {
        /* empty body → plain reply */
      }
      const text = think(messages)
      res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache' })
      // LIMO #23: chunk the reply like a real provider (word pieces over time)
      // so the live box stream shows genuine progressive tokens.
      const pieces = text.match(/[\s\S]{1,24}/g) ?? [text]
      let i = 0
      const tick = () => {
        if (i >= pieces.length) {
          res.write('data: [DONE]\n\n')
          res.end()
          return
        }
        res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: pieces[i++] } }] })}\n\n`)
        setTimeout(tick, 60)
      }
      tick()
    })
    return
  }
  res.writeHead(404, { 'content-type': 'application/json' })
  res.end(JSON.stringify({ error: { message: 'not found' } }))
})

server.listen(PORT, '127.0.0.1', () => {
  console.log(`mock llm provider on http://127.0.0.1:${PORT}/v1 (models: nova-mind, nova-mini)`)
})
