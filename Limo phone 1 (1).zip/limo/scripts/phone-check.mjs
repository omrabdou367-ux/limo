#!/usr/bin/env node
/**
 * phone-check — فحص ذاتي بلا أي اعتماديات لمكدس LIMO (مكتوب لأجل Termux/الجوال).
 *
 *   node scripts/phone-check.mjs        # مقابل http://127.0.0.1:8787
 *   LIMO_URL=http://IP:8787 node scripts/phone-check.mjs
 *
 * يفحص الحقيقة لا المظهر: /api/health — الواجهة الثابتة تُقدَّم من نفس المنفذ —
 * /api/box/state (وعدد النماذج القابلة للاستخدم يُصرَّح به كما هو: صفر يعني
 * «اربط نموذجًا» لا رسالة جميلة زائفة). كود الخروج 1 عند أي فشل.
 */
const base = (process.env.LIMO_URL ?? 'http://127.0.0.1:8787').replace(/\/+$/, '')
let fails = 0
const ok = (name, cond, detail = '') => {
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
  if (!cond) fails++
}

const health = await fetch(base + '/api/health').then((r) => r.json()).catch(() => null)
if (!health) {
  console.log(`FAIL  الخادم غير مستجيب على ${base}`)
  console.log('      شغّله أولًا:  cd ~/limo/server && npm run start:web')
  process.exit(1)
}
ok(`الخادم حي — ${health.name} v${health.version}`, health.ok === true)
ok('الوضع المفتوح (بلا تسجيل دخول)', health.auth?.mode === 'open')
ok('الخزنة فُتحت ذاتيًا عند الإقلاع', health.vault?.state === 'unlocked', `state=${health.vault?.state}`)

const page = await fetch(base + '/').catch(() => null)
const html = page ? await page.text() : ''
ok('الواجهة تُقدَّم من نفس المنفذ (حزمة الجوال)', page?.status === 200 && html.length > 2000, `${html.length} بايت`)

const box = await fetch(base + '/api/box/state').then((r) => r.json()).catch(() => null)
ok('الصندوق الأسود يستجيب (/api/box/state)', !!box?.profile)
const models = Array.isArray(box?.usableModels) ? box.usableModels : []
if (models.length > 0) {
  ok('نماذج قابلة للاستخدام', true, models.map((m) => m.id).join(', '))
} else {
  console.log('WARN  لا نماذج قابلة للاستخدام بعد — هذا طبيعي بلا مفتاح وليس خللًا:')
  console.log('      الواجهة ← الصندوق الأسود ← لوحة «اربط نموذجًا حقيقيًا» (مفتاح OpenRouter/Groq أو نقطة محلية)')
}

// LIMO #21 — the visibility surfaces: honest whether the repo is present or not
const files = await fetch(base + '/api/files').then((r) => r.json().then((b) => ({ status: r.status, b })).catch(() => null)).catch(() => null)
if (files?.status === 200 && files.b?.ok) {
  ok('مستعرض الملفات (/api/files) يعمل', true, `${files.b.dirs.length} مجلدًا · ${files.b.files.length} ملفًا`)
} else {
  console.log('WARN  /api/files غير متاح (لا FORGE_REPO_ROOT مضبوط) — يرفض بصدق وليس خللًا')
}
const integ = await fetch(base + '/api/integrations').then((r) => r.json().then((b) => ({ status: r.status, b })).catch(() => null)).catch(() => null)
if (integ?.status === 200 && Array.isArray(integ.b?.integrations)) {
  const connected = integ.b.integrations.filter((c) => c.connected).map((c) => c.id)
  ok('كتالوج التكاملات (/api/integrations) مقاس', true, `${integ.b.integrations.length} تكاملًا · موصول: ${connected.length ? connected.join(', ') : 'لا شيء بعد'}`)
} else {
  console.log('WARN  /api/integrations غير مستجيب — فحص يدوي مطلوب')
}

console.log(fails === 0 ? '\nالكل سليم ✓' : `\n${fails} فشل ✗ — أصلح أعلاه ثم أعد الفحص`)
process.exit(fails === 0 ? 0 : 1)
