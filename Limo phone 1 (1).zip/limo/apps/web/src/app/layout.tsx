import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ACCENTS, ACCENT_STORAGE_KEY } from "@/lib/appearance";

/**
 * LIMO AGENT shell — RTL Arabic-first, full LTR parity.
 * Fonts are self-hosted via @fontsource (imported in globals.css): one family
 * (Readex Pro, Arabic + Latin) + JetBrains Mono for code. The inline script
 * applies the persisted theme AND the owner's accent (LIMO #13) BEFORE first
 * paint — default is dark (the studio at night). The storage key keeps the
 * Omnara-era name so existing installs keep their preference.
 */
// the accent map travels INTO the pre-paint script as data (single source:
// apps/web/src/lib/appearance.ts — mirrored server-side in box/profile.ts)
const ACCENT_MAP_JSON = JSON.stringify(
  Object.fromEntries(ACCENTS.map((a) => [a.id, { light: a.light, dark: a.dark }])),
)
const themeInit = `(function(){try{var t=localStorage.getItem('omnara-theme');if(t!=='light'&&t!=='dark'){t=window.matchMedia('(prefers-color-scheme: light)').matches?'light':'dark';}document.documentElement.classList.toggle('dark',t==='dark');var A=${ACCENT_MAP_JSON};var a=localStorage.getItem('${ACCENT_STORAGE_KEY}');if(a&&A[a]&&a!=='mono'){var v=A[a][t];var r=document.documentElement.style;r.setProperty('--omn-signal',v.signal);r.setProperty('--omn-signal-text',v.signal);r.setProperty('--omn-accent-contrast',v.contrast);}}catch(e){document.documentElement.classList.add('dark');}})();`

export const metadata: Metadata = {
  title: {
    default: "LIMO AGENT — DISCOVER. ARM. EVOLVE.",
    template: "%s · LIMO AGENT",
  },
  description:
    "استوديو ذكاء مستقل: كل نماذج الذكاء الاصطناعي خلف بوابة واحدة، ووكيل مستقل يخطّط وينفّذ ويتحقّق — محليًا، بمفاتيحك، وبموافقة صريحة على كل إجراء خطر.",
  applicationName: "LIMO AGENT",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#0A0A0A" },
    { media: "(prefers-color-scheme: light)", color: "#F7F7F7" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeInit }} />
      </head>
      <body className="antialiased bg-canvas text-body">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
