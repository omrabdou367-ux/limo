'use client'

/**
 * LIMO AGENT shell — a single client route (skill rule: only `/` is visible).
 * Open mode (LIMO decision #8): there is no setup and no login. The shell
 * boots straight into the app; `loading` only covers the health probe.
 */
import { useCallback, useEffect, useState } from 'react'
import { I18nProvider } from '@/lib/i18n'
import { ThemeProvider } from '@/lib/theme'
import { api, type HealthResponse } from '@/lib/api'
import { ChatView } from '@/components/omnara/ChatView'

function Shell() {
  const [ready, setReady] = useState(false)
  const [health, setHealth] = useState<HealthResponse | null>(null)

  const refreshHealth = useCallback(async () => {
    try {
      const h = await api.health()
      setHealth(h)
    } catch {
      setHealth(null)
    } finally {
      setReady(true)
    }
  }, [])

  useEffect(() => {
    void refreshHealth()
  }, [refreshHealth])

  if (!ready) {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center gap-3 bg-canvas text-dim">
        <span className="inline-block h-4 w-2 animate-pulse bg-signal" aria-hidden="true" />
        <p className="font-mono text-xs" dir="ltr">LIMO CORE…</p>
      </div>
    )
  }

  return (
    <ChatView
      health={health}
      onHealth={() => void refreshHealth()}
      onAuthLost={() => void refreshHealth()}
    />
  )
}

export default function Page() {
  return (
    <I18nProvider>
      <ThemeProvider>
        <Shell />
      </ThemeProvider>
    </I18nProvider>
  )
}
