'use client'

/**
 * Light/dark theme — dark (the control room) is the default.
 * localStorage is read through useSyncExternalStore (SSR-safe, no setState
 * in effects); the <html> class itself is applied pre-paint by the inline
 * script in layout.tsx — React only tracks the value for the toggle icon.
 */
import { createContext, useCallback, useContext, useSyncExternalStore } from 'react'
import { reapplyAccent } from '@/lib/appearance'

type Theme = 'light' | 'dark'

const listeners = new Set<() => void>()
const emit = () => listeners.forEach((l) => l())
const subscribe = (cb: () => void) => {
  listeners.add(cb)
  return () => listeners.delete(cb)
}
const clientSnapshot = (): Theme => {
  // MUST mirror the inline pre-paint script in layout.tsx exactly: stored
  // value if valid, otherwise the system preference. (Previously this
  // defaulted to 'dark' while the pre-paint script followed the system —
  // on a light-preference machine the first toggle was a no-op.)
  const stored = window.localStorage.getItem('omnara-theme')
  if (stored === 'light' || stored === 'dark') return stored
  return window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark'
}
const serverSnapshot = (): Theme => 'dark'

const Ctx = createContext<{ theme: Theme; toggle: () => void }>({
  theme: 'dark',
  toggle: () => undefined,
})

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const theme = useSyncExternalStore(subscribe, clientSnapshot, serverSnapshot)

  const toggle = useCallback(() => {
    const next: Theme = clientSnapshot() === 'dark' ? 'light' : 'dark'
    window.localStorage.setItem('omnara-theme', next)
    document.documentElement.classList.toggle('dark', next === 'dark')
    // accent values differ per mode — re-apply after the flip (LIMO #13)
    reapplyAccent()
    emit()
  }, [])

  return <Ctx.Provider value={{ theme, toggle }}>{children}</Ctx.Provider>
}

export function useTheme() {
  return useContext(Ctx)
}
