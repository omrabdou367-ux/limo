'use client'

/**
 * Minimal, deliberate markdown renderer: fenced code blocks + inline `code`
 * + **bold** + links-as-text. No full markdown engine, no HTML injection —
 * everything renders through React elements. Code runs are forced LTR.
 */
import { Fragment, type ReactNode } from 'react'
import { CodeBlock } from '@/components/omnara/CodeBlock'

export function renderMessage(content: string): ReactNode {
  const parts = content.split(/```/)
  return parts.map((part, i) => {
    if (i % 2 === 1) {
      // inside a fence: first line may carry the language tag
      const nl = part.indexOf('\n')
      const lang = nl > 0 ? part.slice(0, nl).trim() : ''
      const code = nl > 0 ? part.slice(nl + 1) : part
      return <CodeBlock key={i} lang={lang} code={code.replace(/\n$/, '')} />
    }
    return <Fragment key={i}>{renderInline(part)}</Fragment>
  })
}

function renderInline(text: string): ReactNode {
  if (!text) return null
  const nodes: ReactNode[] = []
  // tokens: `code` | **bold** — split with capture groups
  const re = /(`[^`\n]+`)|(\*\*[^*\n]+\*\*)/g
  let last = 0
  let m: RegExpExecArray | null
  let key = 0
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) nodes.push(<span key={key++}>{text.slice(last, m.index)}</span>)
    const token = m[0]
    if (token.startsWith('`')) {
      nodes.push(
        <code
          key={key++}
          dir="ltr"
          className="inline-block align-baseline rounded-sm bg-surface px-1.5 py-0.5 font-mono text-[13.5px] text-signal-text border border-line"
        >
          {token.slice(1, -1)}
        </code>,
      )
    } else {
      nodes.push(
        <strong key={key++} className="font-semibold">
          {token.slice(2, -2)}
        </strong>,
      )
    }
    last = m.index + token.length
  }
  if (last < text.length) nodes.push(<span key={key++}>{text.slice(last)}</span>)
  return <span className="whitespace-pre-wrap break-words">{nodes}</span>
}
