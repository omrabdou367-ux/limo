import type { LucideIcon } from 'lucide-react'
import {
  Bot, Boxes, Folder, FolderKanban, Hammer, Home, KeyRound, Layers, Library,
  Palette, Radar, Settings, ShieldCheck, Sparkles, Wrench,
} from 'lucide-react'

// ---------------------------------------------------- cross-area deep links
// LIMO #15 — the Black Box connect-model panel deep-links owners into the
// real flows. A custom event works for already-mounted views, but the target
// area MOUNTS on navigation (after the event fired) — so the tab hint travels
// through this tiny mailbox instead: set before navigating, taken on mount.
let pendingIntegrationsTab: 'providers' | 'custom' | 'apikeys' | null = null

export function setPendingIntegrationsTab(tab: 'providers' | 'custom' | 'apikeys'): void {
  pendingIntegrationsTab = tab
}

export function takePendingIntegrationsTab(): 'providers' | 'custom' | 'apikeys' | null {
  const t = pendingIntegrationsTab
  pendingIntegrationsTab = null
  return t
}

/**
 * LIMO AGENT navigation model — the 14 areas (LIMO PHASE 1).
 *
 * Progressive disclosure: areas are grouped (core intelligence / build /
 * knowledge / system); each area maps to a REAL capability surface — nothing
 * in this list is a dead placeholder.
 */

export type Area =
  | 'home'
  | 'chat'
  | 'workspace'
  | 'studio'
  | 'workshop'
  | 'builder'
  | 'workflow'
  | 'allimni'
  | 'skills'
  | 'files'
  | 'projects'
  | 'library'
  | 'blackbox'
  | 'memory'
  | 'integrations'
  | 'settings'
  | 'systemmap'

export interface AreaDef {
  id: Area
  icon: LucideIcon
  /** i18n key in the dictionary */
  key: string
  group: 'core' | 'build' | 'knowledge' | 'system'
}

/** The 16 navigation areas (+ chat, the conversation surface reached from Home). */
export const AREAS: AreaDef[] = [
  { id: 'home', icon: Home, key: 'navHome', group: 'core' },
  { id: 'workspace', icon: Bot, key: 'navWorkspace', group: 'core' },
  { id: 'studio', icon: Palette, key: 'navStudio', group: 'core' },
  { id: 'workshop', icon: Wrench, key: 'navWorkshop', group: 'build' },
  { id: 'builder', icon: Layers, key: 'navBuilder', group: 'build' },
  { id: 'workflow', icon: Boxes, key: 'navWorkflow', group: 'build' },
  { id: 'projects', icon: FolderKanban, key: 'navProjects', group: 'build' },
  { id: 'library', icon: Library, key: 'navLibrary', group: 'knowledge' },
  { id: 'allimni', icon: Sparkles, key: 'navAllimni', group: 'knowledge' },
  { id: 'skills', icon: Hammer, key: 'navSkills', group: 'knowledge' },
  { id: 'files', icon: Folder, key: 'navFiles', group: 'knowledge' },
  { id: 'blackbox', icon: ShieldCheck, key: 'navBlackbox', group: 'system' },
  { id: 'memory', icon: Library, key: 'navMemory', group: 'system' },
  { id: 'integrations', icon: KeyRound, key: 'navIntegrations', group: 'system' },
  { id: 'systemmap', icon: Radar, key: 'navSystemMap', group: 'system' },
  { id: 'settings', icon: Settings, key: 'navSettings', group: 'system' },
]

export const AREA_GROUPS: Array<{ id: AreaDef['group']; key: string }> = [
  { id: 'core', key: 'navGroupCore' },
  { id: 'build', key: 'navGroupBuild' },
  { id: 'knowledge', key: 'navGroupKnowledge' },
  { id: 'system', key: 'navGroupSystem' },
]

/** Agent task modes (HYPERBRAIN strategy bias) — shared by several screens. */
export const TASK_MODES = ['auto', 'research', 'build', 'creative', 'super'] as const
export type TaskModeId = (typeof TASK_MODES)[number]

/** The specialized HYPERBRAIN agents (labels come from i18n at render time). */
export const AGENT_ROLE_IDS = [
  'orchestrator', 'researcher', 'engineer', 'frontend', 'backend',
  'creative', 'security', 'qa', 'writer',
] as const
