'use client'

/**
 * Live agent-task events over SSE (GET + ReadableStream) — same consumption
 * pattern as the chat stream: replay + live follow until the task ends.
 */
export interface AgentStreamEvent {
  kind: string
  ts: string
  data: Record<string, unknown>
}

export async function streamAgentEvents(
  taskId: number,
  opts: { onEvent: (e: AgentStreamEvent) => void; signal: AbortSignal },
): Promise<void> {
  const res = await fetch(`/api/agent/tasks/${taskId}/events`, {
    credentials: 'same-origin',
    signal: opts.signal,
  })
  if (!res.ok || !res.body) throw new Error(`SSE ${res.status}`)
  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''
  for (;;) {
    const { done, value } = await reader.read()
    if (done) return
    buffer += decoder.decode(value, { stream: true })
    let nl: number
    while ((nl = buffer.indexOf('\n')) >= 0) {
      const line = buffer.slice(0, nl).trimEnd()
      buffer = buffer.slice(nl + 1)
      if (!line.startsWith('data:')) continue
      const data = line.slice(5).trim()
      if (data === '[DONE]') return
      try {
        opts.onEvent(JSON.parse(data) as AgentStreamEvent)
      } catch {
        /* keep-alive noise */
      }
    }
  }
}
