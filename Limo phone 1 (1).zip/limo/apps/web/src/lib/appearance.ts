/**
 * LIMO appearance — the owner-controlled identity colors (LIMO #13).
 *
 * The Black Box (or the Settings mirror) writes TWO real profile fields:
 *  - themeMode: 'system' | 'light' | 'dark' — pinned by the owner; 'system'
 *    means every device keeps following its own toggle/system preference.
 *  - accent: one palette id below. 'mono' is the stock monochrome ink/paper
 *    identity (NO inline override — the tokens stay the single truth).
 *
 * Every non-mono accent replaces exactly three CSS custom properties on
 * <html> (—omn-signal, —omn-signal-text, —omn-accent-contrast), so the whole
 * UI (buttons, links, focus rings, selection, carets, brand marks) tints at
 * once. Values are WCAG-checked pairs: the light value is dark enough for
 * text on paper, the dark value light enough for text on ink.
 *
 * The id list MUST stay in sync with server/src/box/profile.ts (ACCENT_IDS) —
 * the server validates the ids, this file maps them to CSS.
 */

export type AccentId = 'mono' | 'forest' | 'indigo' | 'crimson' | 'ocean' | 'violet'
export type ThemeMode = 'system' | 'light' | 'dark'

export interface AccentDef {
  id: AccentId
  ar: string
  en: string
  /** light-mode: dark accent on the paper canvas + paper text on fills */
  light: { signal: string; contrast: string }
  /** dark-mode: light accent on the ink canvas + ink text on fills */
  dark: { signal: string; contrast: string }
}

export const ACCENTS: AccentDef[] = [
  // mono → no override (tokens keep their ink/paper values)
  { id: 'mono', ar: 'أحادي', en: 'Mono', light: { signal: '#0A0A0A', contrast: '#FAFAFA' }, dark: { signal: '#FAFAFA', contrast: '#0A0A0A' } },
  { id: 'forest', ar: 'أخضر غابة', en: 'Forest', light: { signal: '#14532D', contrast: '#F0FDF4' }, dark: { signal: '#86EFAC', contrast: '#052E16' } },
  { id: 'indigo', ar: 'نيلي', en: 'Indigo', light: { signal: '#312E81', contrast: '#EEF2FF' }, dark: { signal: '#A5B4FC', contrast: '#1E1B4B' } },
  { id: 'crimson', ar: 'قرمزي', en: 'Crimson', light: { signal: '#881337', contrast: '#FFF1F2' }, dark: { signal: '#FDA4AF', contrast: '#4C0519' } },
  { id: 'ocean', ar: 'محيطي', en: 'Ocean', light: { signal: '#0C4A6E', contrast: '#F0F9FF' }, dark: { signal: '#7DD3FC', contrast: '#082F49' } },
  { id: 'violet', ar: 'بنفسجي', en: 'Violet', light: { signal: '#4C1D95', contrast: '#F5F3FF' }, dark: { signal: '#C4B5FD', contrast: '#2E1065' } },
]

export const ACCENT_STORAGE_KEY = 'limo-accent'
export const THEME_STORAGE_KEY = 'omnara-theme'

const accentById = (id: string): AccentDef | undefined => ACCENTS.find((a) => a.id === id)

/** The effective theme the document is showing right now (the .dark class). */
const effectiveTheme = (): 'light' | 'dark' =>
  typeof document !== 'undefined' && document.documentElement.classList.contains('dark') ? 'dark' : 'light'

/**
 * Apply the owner-pinned theme mode. 'system' clears the pin (the device's
 * own pre-paint choice + manual toggle stay in charge); light/dark pin it.
 */
export function applyThemeMode(mode: ThemeMode): void {
  if (typeof window === 'undefined') return
  if (mode === 'system') {
    window.localStorage.removeItem(THEME_STORAGE_KEY)
    const sys = window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark'
    document.documentElement.classList.toggle('dark', sys === 'dark')
  } else {
    window.localStorage.setItem(THEME_STORAGE_KEY, mode)
    document.documentElement.classList.toggle('dark', mode === 'dark')
  }
}

/** Apply one accent id (or the saved one when omitted). */
export function applyAccent(id?: string | null): void {
  if (typeof document === 'undefined') return
  const chosen = id ?? window.localStorage.getItem(ACCENT_STORAGE_KEY) ?? 'mono'
  const def = accentById(chosen)
  if (!def) return
  window.localStorage.setItem(ACCENT_STORAGE_KEY, def.id)
  const root = document.documentElement
  if (def.id === 'mono') {
    root.style.removeProperty('--omn-signal')
    root.style.removeProperty('--omn-signal-text')
    root.style.removeProperty('--omn-accent-contrast')
    return
  }
  const { signal, contrast } = effectiveTheme() === 'dark' ? def.dark : def.light
  root.style.setProperty('--omn-signal', signal)
  // signal-text follows the signal (emphasis marks use the same color family)
  root.style.setProperty('--omn-signal-text', signal)
  root.style.setProperty('--omn-accent-contrast', contrast)
}

/** Re-apply the saved accent after a light/dark flip (values differ per mode). */
export function reapplyAccent(): void {
  if (typeof window === 'undefined') return
  applyAccent(window.localStorage.getItem(ACCENT_STORAGE_KEY))
}

/** One call for the shell: profile fields → live document. */
export function applyAppearance(profile: { themeMode?: ThemeMode; accent?: string }): void {
  if (typeof window === 'undefined') return
  if (profile.themeMode) applyThemeMode(profile.themeMode)
  // unknown accent ids are ignored by applyAccent's map lookup (honest no-op)
  if (profile.accent) applyAccent(profile.accent)
}
