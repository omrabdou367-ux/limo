import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/** Short relative time, bilingual — "قبل 5 د" / "5m ago". */
export function timeAgo(iso: string | null | undefined, lang: "ar" | "en"): string {
  if (!iso) return ""
  const ms = Date.now() - Date.parse(iso)
  if (!Number.isFinite(ms)) return ""
  const ar = lang === "ar"
  const fmt = (v: number, a: string, e: string) => (ar ? `قبل ${v} ${a}` : `${v}${e} ago`)
  const s = Math.round(ms / 1000)
  if (s < 45) return ar ? "الآن" : "just now"
  const m = Math.round(s / 60)
  if (m < 60) return fmt(m, "د", "m")
  const h = Math.round(m / 60)
  if (h < 24) return fmt(h, "س", "h")
  const d = Math.round(h / 24)
  if (d < 30) return fmt(d, "يوم", "d")
  return new Date(iso).toLocaleDateString(ar ? "ar" : "en-GB")
}
