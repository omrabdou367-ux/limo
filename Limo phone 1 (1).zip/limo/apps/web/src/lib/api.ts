'use client'

/**
 * Omnara API client — RELATIVE paths only (skill rule). In dev, Next rewrites
 * proxy /api + /v1 to the Fastify server; in production the exported build is
 * served same-origin by Fastify itself (or by Tauri with an absolute base).
 */

export interface HealthResponse {
  ok: boolean
  name: string
  version: string
  /** Open mode (LIMO #8): no setup/login state exists — mode is always 'open'. */
  auth: { mode: 'open' }
  vault: { state: 'uninitialized' | 'locked' | 'unlocked' }
  providers: Array<{
    id: string
    label: string
    needsKey: boolean
    configured: boolean
    lastError: string | null
  }>
}

export interface SecretInfo {
  alias: string
  provider: string
  hint: string | null
  updatedAt: string
}

export interface ApiKeyInfo {
  id: number
  name: string
  prefix: string
  createdAt: string
  lastUsedAt: string | null
}

export interface ConversationInfo {
  id: number
  title: string
  model: string | null
  createdAt: string
  updatedAt: string
}

export interface MessageInfo {
  id: number
  chatId: number
  role: 'user' | 'assistant' | 'system'
  content: string
  model: string | null
  createdAt: string
}

export interface ModelInfo {
  id: string
  object: 'model'
  owned_by: string
  free?: boolean
}

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly type: string,
    message: string,
  ) {
    super(message)
    this.name = 'ApiError'
  }
}

async function call<T>(method: string, path: string, body?: unknown): Promise<T> {
  let res: Response
  try {
    res = await fetch(path, {
      method,
      headers: body === undefined ? undefined : { 'content-type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
      credentials: 'same-origin',
    })
  } catch {
    throw new ApiError(0, 'network', 'لا يمكن الوصول إلى الخادم')
  }
  if (!res.ok) {
    let type = 'http_error'
    let message = `HTTP ${res.status}`
    try {
      const j = (await res.json()) as { error?: { message?: string; type?: string } }
      if (j.error?.message) message = j.error.message
      if (j.error?.type) type = j.error.type
    } catch {
      /* keep defaults */
    }
    throw new ApiError(res.status, type, message)
  }
  return (await res.json()) as T
}

// ---------------- LIMO COMPUTER PRO — system map types (#17) ----------------
export interface SubsystemEntryDto {
  id: string
  nameAr: string
  nameEn: string
  group: 'intelligence' | 'knowledge' | 'creation' | 'platform'
  status: 'verified' | 'implemented' | 'partial' | 'mocked' | 'broken' | 'missing' | 'unknown'
  evidence: string
  noteAr: string
}

export interface EngineProbeDto {
  id: 'blender' | 'godot' | 'unreal'
  nameAr: string
  nameEn: string
  status: 'found' | 'not_installed'
  version: string | null
  path: string | null
  headless: boolean | null
  validation: { ok: boolean; notes: string[] }
  hintAr: string | null
}

export interface DeployRow {
  id: string
  state: string
  url: string | null
  target: string | null
  createdAt: number | null
}

export interface DeployStateResponse {
  configured: boolean
  project: string
  webDist: string | null
  username?: string
  previewProtection?: string | null
  deployments?: DeployRow[]
  history?: Array<{ deployment_id: string; url: string | null; target: string; state: string; file_count: number | null; total_bytes: number | null; created_at: string }>
  vercelError?: string
}

export interface DeployRefResponse {
  deploymentId: string
  readyState: string
  url: string | null
  target: string
  project: string
  uploadedFiles: number
  uploadedBytes: number
  account: string
}

export interface DeployVerifyResponse {
  deploymentId: string
  url: string
  httpStatus: number
  bytes: number
  served: 'limo-ui' | 'vercel-wall' | 'other'
  hasRoot: boolean
  checkedAt: string
}

export interface DeployStatusResponse {
  id: string
  readyState: string
  url: string | null
  alias: string[]
  target: string | null
  createdAt: number | null
  ready: number | null
}

export interface SystemMapResponse {
  product: { name: string; base: string; version: string; auditDate: string }
  live: {
    usableModels: number
    vaultState: 'uninitialized' | 'locked' | 'unlocked'
    memoryMode: 'sqlite-vec' | 'js-cosine'
    memoryCount: number
    agentTools: number
    boxTools: number
    projects: number
    skillsActive: number
    conversations: number
    agentTasks: number
    lastAgentTask: { id: number; status: string; created_at: string } | null
    dbTables: number
    dbBytes: number
    gauntlet: { passed: number; total: number; at: string } | null
  }
  platform: { node: string; platform: string; arch: string; termux: boolean; termuxVersion: string | null; uptimeSec: number }
  subsystems: SubsystemEntryDto[]
  statusLegend: string[]
}

export interface SystemEnginesResponse {
  platform: SystemMapResponse['platform']
  engines: EngineProbeDto[]
}

// ---------------- LIMO #21 — files browser / integrations catalog / tools ----------------

export interface DirListingInfo {
  ok: true
  path: string
  dirs: string[]
  files: Array<{ name: string; bytes: number }>
  capped: boolean
}

export interface WorkspaceFileInfo {
  path: string
  bytes: number
  lines: number
  truncated: boolean
  content: string
}

export interface IntegrationCardInfo {
  id: string
  name: string
  kind: 'intelligence' | 'deploy' | 'source'
  needsKey: boolean
  keyStored: boolean
  connected: boolean
  vaultLocked: boolean
  detail: string
  connectArea: 'integrations' | 'systemmap' | 'vault'
  permissions: string
}

export interface ToolsInventoryResponse {
  box: { surface: string; count: number; tools: Array<{ name: string; description: string; mutates: boolean }> }
  agent: { surface: string; count: number; tools: Array<{ name: string; description: string; risk: string | null }> }
  total: number
}

export const api = {
  health: () => call<HealthResponse>('GET', '/api/health'),
  authStatus: () => call<{ initialized: boolean; mode: 'open' }>('GET', '/api/auth/status'),
  me: () => call<{ ok: boolean }>('GET', '/api/auth/me'),

  vaultStatus: () => call<{ state: HealthResponse['vault']['state']; legacy?: boolean }>('GET', '/api/vault/status'),
  vaultSecrets: () => call<{ state: string; secrets: SecretInfo[] }>('GET', '/api/vault/secrets'),
  vaultPutSecret: (alias: string, provider: string, value: string) =>
    call<{ ok: boolean; secret: SecretInfo }>('PUT', '/api/vault/secrets', { alias, provider, value }),
  vaultDeleteSecret: (alias: string) => call<{ ok: boolean }>('DELETE', `/api/vault/secrets/${encodeURIComponent(alias)}`),
  vaultTestSecret: (alias: string) => call<{ ok: boolean; models: number }>('POST', `/api/vault/secrets/${encodeURIComponent(alias)}/test`),

  apiKeys: () => call<ApiKeyInfo[]>('GET', '/api/auth/api-keys'),
  createApiKey: (name: string) => call<{ id: number; name: string; prefix: string; key: string }>('POST', '/api/auth/api-keys', { name }),
  deleteApiKey: (id: number) => call<{ ok: boolean }>('DELETE', `/api/auth/api-keys/${id}`),

  conversations: () => call<ConversationInfo[]>('GET', '/api/conversations'),
  createConversation: (model?: string) => call<ConversationInfo>('POST', '/api/conversations', { model }),
  conversation: (id: number) => call<ConversationInfo & { messages: MessageInfo[] }>('GET', `/api/conversations/${id}`),
  deleteConversation: (id: number) => call<{ ok: boolean }>('DELETE', `/api/conversations/${id}`),
  addMessage: (chatId: number, role: MessageInfo['role'], content: string, model?: string) =>
    call<MessageInfo>('POST', `/api/conversations/${chatId}/messages`, { role, content, model }),

  models: () => call<{ object: 'list'; data: ModelInfo[]; omnara: { errors: Array<{ provider: string; error: string }> } }>('GET', '/v1/models'),

  // ---------------- phase 2: catalog / usage / router / compare / custom ----------------

  catalog: () =>
    call<CatalogSummary>('GET', '/api/catalog'),
  catalogRefresh: () => call<CatalogSummary & { skipped: Array<{ source: string; reason: string }> }>('POST', '/api/catalog/refresh'),

  usage: (days = 7) => call<UsageBoard>('GET', `/api/usage?days=${days}`),

  routerState: () => call<RouterState>('GET', '/api/router'),
  saveRouterProfile: (name: string, chain: string[]) =>
    call<{ ok: boolean; profile: RouterProfileInfo }>('PUT', `/api/router/profiles/${encodeURIComponent(name)}`, { chain }),
  deleteRouterProfile: (name: string) => call<{ ok: boolean }>('DELETE', `/api/router/profiles/${encodeURIComponent(name)}`),
  activateRouterProfile: (name: string | null) =>
    call<{ ok: boolean; active: string | null }>('POST', '/api/router/active', name === null ? {} : { name }),
  resetBreaker: (provider: string) => call<{ ok: boolean; provider: string }>('POST', `/api/router/breakers/${encodeURIComponent(provider)}/reset`),

  customProviders: () => call<{ providers: CustomProviderInfo[] }>('GET', '/api/providers/custom'),
  createCustomProvider: (p: { id: string; label: string; baseUrl: string; needsKey: boolean }) =>
    call<{ ok: boolean; provider: CustomProviderInfo }>('POST', '/api/providers/custom', p),
  updateCustomProvider: (id: string, p: { label?: string; baseUrl?: string; needsKey?: boolean; enabled?: boolean }) =>
    call<{ ok: boolean; provider: CustomProviderInfo }>('PATCH', `/api/providers/custom/${encodeURIComponent(id)}`, p),
  deleteCustomProvider: (id: string) => call<{ ok: boolean; secretKept: boolean }>('DELETE', `/api/providers/custom/${encodeURIComponent(id)}`),
  testCustomProvider: (id: string) => call<{ ok: boolean; models: number }>('POST', `/api/providers/custom/${encodeURIComponent(id)}/test`),

  compare: (models: string[], messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }>) =>
    call<{ at: string; results: CompareResultInfo[] }>('POST', '/api/compare', { models, messages }),

  // ---------------- phase 3: agent / memory / routines / egress ----------------
  agentTasks: () => call<{ tasks: AgentTaskInfo[] }>('GET', '/api/agent/tasks'),
  agentTask: (id: number) =>
    call<{ task: AgentTaskInfo; steps: AgentStepInfo[]; events: AgentEventInfo[]; actions: AgentActionInfo[] }>('GET', `/api/agent/tasks/${id}`),
  createAgentTask: (goal: string, model: string, opts?: { projectId?: string; mode?: 'auto' | 'research' | 'build' | 'creative' | 'super' }) =>
    call<{ task: AgentTaskInfo }>('POST', '/api/agent/tasks', { goal, model, ...(opts?.projectId ? { projectId: opts.projectId } : {}), ...(opts?.mode ? { mode: opts.mode } : {}) }),
  cancelAgentTask: (id: number) => call<{ ok: boolean }>('POST', `/api/agent/tasks/${id}/cancel`),

  agentApprovals: (status?: 'pending' | 'approved' | 'rejected' | 'expired') =>
    call<{ approvals: AgentApprovalInfo[] }>('GET', `/api/agent/approvals${status ? `?status=${status}` : ''}`),
  decideApproval: (id: number, decision: 'approve' | 'reject') =>
    call<{ approval: AgentApprovalInfo }>('POST', `/api/agent/approvals/${id}/decision`, { decision }),

  agentMemory: () => call<{ mode: string; notes: UserMemoryInfo[] }>('GET', '/api/agent/memory'),
  createMemory: (title: string, content: string) => call<{ note: UserMemoryInfo }>('POST', '/api/agent/memory', { title, content }),
  updateMemory: (id: number, patch: { title?: string; content?: string }) => call<{ note: UserMemoryInfo }>('PATCH', `/api/agent/memory/${id}`, patch),
  deleteMemory: (id: number) => call<{ ok: boolean }>('DELETE', `/api/agent/memory/${id}`),
  searchMemory: (query: string, k = 5) => call<{ mode: string; hits: Array<UserMemoryInfo & { distance: number }> }>('POST', '/api/agent/memory/search', { query, k }),

  agentRoutines: () => call<{ routines: AgentRoutineInfo[] }>('GET', '/api/agent/routines'),
  createRoutine: (r: { name: string; prompt: string; model: string; interval_sec: number; allow_downgrade?: boolean; catch_up_on_unlock?: boolean }) =>
    call<{ routine: AgentRoutineInfo }>('POST', '/api/agent/routines', r),
  patchRoutine: (id: number, patch: Partial<{ prompt: string; interval_sec: number; enabled: boolean; allow_downgrade: boolean; catch_up_on_unlock: boolean }>) =>
    call<{ routine: AgentRoutineInfo }>('PATCH', `/api/agent/routines/${id}`, patch),
  deleteRoutine: (id: number) => call<{ ok: boolean }>('DELETE', `/api/agent/routines/${id}`),
  runRoutine: (id: number) => call<{ status: string; run: AgentRoutineRunInfo; task: AgentTaskInfo | null }>('POST', `/api/agent/routines/${id}/run`),
  routineRuns: (id: number) => call<{ runs: AgentRoutineRunInfo[] }>('GET', `/api/agent/routines/${id}/runs`),

  egress: (leftOnly = false, limit = 100) => call<EgressBoard>('GET', `/api/egress?limit=${limit}${leftOnly ? '&left=1' : ''}`),

  // ---------------- Reality Forge — the self-modification engine (RF spec) ----------------
  forgeStatus: () => call<ForgeStatusInfo>('GET', '/api/forge/status'),
  forgeSetAutonomy: (level: number) => call<{ level: number }>('PUT', '/api/forge/autonomy', { level }),
  forgeMap: () => call<{ map: ForgeMapInfo }>('GET', '/api/forge/map'),
  forgeChanges: (q?: { status?: string; q?: string; since?: string; limit?: number }) => {
    const params = new URLSearchParams()
    if (q?.status) params.set('status', q.status)
    if (q?.q) params.set('q', q.q)
    if (q?.since) params.set('since', q.since)
    if (q?.limit) params.set('limit', String(q.limit))
    const suffix = params.toString() ? `?${params.toString()}` : ''
    return call<{ changes: ForgeChangeInfo[] }>('GET', `/api/forge/changes${suffix}`)
  },
  forgeChange: (id: number) => call<{ change: ForgeChangeInfo; events: ForgeEventInfo[] }>('GET', `/api/forge/changes/${id}`),
  createForgeChange: (request: string, model?: string | null, level?: number) =>
    call<{ change: ForgeChangeInfo }>('POST', '/api/forge/changes', { request, ...(model ? { model } : {}), ...(level !== undefined ? { level } : {}) }),
  resumeForgeChange: (id: number, level?: number) =>
    call<{ change: ForgeChangeInfo }>('POST', `/api/forge/changes/${id}/resume`, level === undefined ? {} : { level }),
  decideForgeChange: (id: number, decision: 'apply' | 'reject') =>
    call<{ change: ForgeChangeInfo }>('POST', `/api/forge/changes/${id}/decision`, { decision }),
  rollbackForgeChange: (id: number) => call<{ change: ForgeChangeInfo }>('POST', `/api/forge/changes/${id}/rollback`),
  cancelForgeChange: (id: number) => call<{ change: ForgeChangeInfo }>('POST', `/api/forge/changes/${id}/cancel`),
  forgeSetEngineeringModel: (model: string | null) => call<{ model: string | null }>('PUT', '/api/forge/engineering-model', { model }),
  forgeProposals: (status?: string) => call<{ proposals: ForgeProposalInfo[] }>('GET', `/api/forge/proposals${status ? `?status=${status}` : ''}`),
  forgeGenerateProposals: () => call<{ generated: number; proposals: ForgeProposalInfo[] }>('POST', '/api/forge/proposals/generate'),
  forgeProposalStatus: (id: number, status: 'accepted' | 'dismissed') =>
    call<{ proposal: ForgeProposalInfo }>('POST', `/api/forge/proposals/${id}/status`, { status }),

  // ---------------- Black Box chatbot (شات بوت تعديل ليمو) + automatic model routing ----------------
  boxState: () => call<BoxStateInfo>('GET', '/api/box/state'),
  boxChat: (message: string, model?: string | null) =>
    call<{ reply: string; actions: BoxActionInfo[]; profile: BoxProfileInfo }>('POST', '/api/box/chat', { message, model: model ?? null }),
  boxMessages: () => call<{ messages: BoxMessageInfo[] }>('GET', '/api/box/messages'),
  boxClearMessages: () => call<{ ok: boolean }>('DELETE', '/api/box/messages'),
  // LIMO #24 — conversation search + rewind (edit/regenerate primitive)
  boxSearchMessages: (q: string) =>
    call<{ results: Array<{ id: number; role: 'user' | 'box'; content: string; created_at: string }> }>(
      'GET',
      `/api/box/messages/search?q=${encodeURIComponent(q)}`,
    ),
  boxRewind: (body: { target: 'last-user' | 'message'; id?: number }) =>
    call<{ ok: boolean; deleted: number; text: string }>('POST', '/api/box/messages/rewind', body),
  boxModifications: () =>
    call<{ modifications: Array<{ id: number; tool: string; args: string; ok: number; result: string | null; model: string | null; created_at: string }> }>('GET', '/api/box/modifications'),
  boxPutProfile: (patch: { name?: string; tagline?: string; language?: 'ar' | 'en'; defaultModel?: string | null; themeMode?: 'system' | 'light' | 'dark'; accent?: string }) =>
    call<{ profile: BoxProfileInfo }>('PUT', '/api/box/profile', patch),
  modelPrefs: () => call<{ prefs: { planner: string[]; critic: string[] }; usable: { planner: { model: string; reason: string }; critic: { model: string; reason: string } } | null }>('GET', '/api/agent/model-prefs'),

  // ---------------- LIMO COMPUTER PRO — the live system map (#17) ----------------
  systemMap: () => call<SystemMapResponse>('GET', '/api/system/map'),
  systemEngines: () => call<SystemEnginesResponse>('GET', '/api/system/engines'),
  systemTools: () => call<ToolsInventoryResponse>('GET', '/api/system/tools'),
  saveModelPrefs: (prefs: { planner?: string[]; critic?: string[] }) =>
    call<{ ok: boolean; prefs: { planner: string[]; critic: string[] } }>('PUT', '/api/agent/model-prefs', prefs),

  // ---------------- LIMO #21 — «الملفات» + «التكاملات» ----------------
  workspaceFiles: (dir: string) =>
    call<DirListingInfo>('GET', `/api/files?dir=${encodeURIComponent(dir)}`),
  workspaceFileContent: (path: string) =>
    call<{ file: WorkspaceFileInfo }>('GET', `/api/files/content?path=${encodeURIComponent(path)}`),
  integrations: () =>
    call<{ generatedAt: string; integrations: IntegrationCardInfo[] }>('GET', '/api/integrations'),

  // ---------------- LIMO DEPLOYMENT COMMAND CENTER (#20, §11–12) ----------------
  deployState: () => call<DeployStateResponse>('GET', '/api/deploy/state'),
  deploySetToken: (token: string) => call<{ ok: boolean; username: string }>('POST', '/api/deploy/token', { token }),
  deployClearToken: () => call<{ ok: boolean; removed: boolean }>('DELETE', '/api/deploy/token'),
  deployPreview: () => call<DeployRefResponse>('POST', '/api/deploy/preview'),
  deployStatus: (id: string) => call<DeployStatusResponse>('GET', `/api/deploy/status/${encodeURIComponent(id)}`),
  deployVerify: (id: string) => call<DeployVerifyResponse>('GET', `/api/deploy/verify/${encodeURIComponent(id)}`),
  deployProtection: (publicPreviews: boolean) => call<{ ok: boolean; previewProtection: string | null }>('POST', '/api/deploy/protection', { publicPreviews }),
  deployLogs: (id: string) => call<{ deploymentId: string; lines: Array<{ at: string | null; text: string }> }>('GET', `/api/deploy/logs/${encodeURIComponent(id)}`),
  deployPromote: (id: string) => call<{ ok: boolean; alias: string; url: string | null }>('POST', `/api/deploy/promote/${encodeURIComponent(id)}`),
  deployRollback: (id: string) => call<{ ok: boolean; alias: string; url: string | null }>('POST', `/api/deploy/rollback/${encodeURIComponent(id)}`),

  // ---------------- LIMO layer 1: projects / workflows / ALLIMNI skills ----------------
  projects: () => call<{ projects: ProjectInfo[] }>('GET', '/api/projects'),
  createProject: (p: { name: string; description?: string; kind?: 'general' | 'web_app' | 'creative' | 'workflow' }) =>
    call<{ project: ProjectInfo }>('POST', '/api/projects', p),
  project: (id: string) => call<{ project: ProjectInfo; files: ProjectFileInfo[] }>('GET', `/api/projects/${id}`),
  updateProject: (id: string, patch: { name?: string; description?: string; kind?: string; status?: string }) =>
    call<{ project: ProjectInfo }>('PATCH', `/api/projects/${id}`, patch),
  deleteProject: (id: string) => call<{ ok: boolean }>('DELETE', `/api/projects/${id}`),
  projectFiles: (id: string) => call<{ files: ProjectFileInfo[] }>('GET', `/api/projects/${id}/files`),
  projectFileContent: (id: string, path: string) =>
    call<{ file: { path: string; size: number; content: string } }>('GET', `/api/projects/${id}/files/content?path=${encodeURIComponent(path)}`),
  writeProjectFile: (id: string, path: string, content: string) =>
    call<{ file: { path: string; bytes: number } }>('PUT', `/api/projects/${id}/files`, { path, content }),
  deleteProjectFile: (id: string, path: string) => call<{ ok: boolean }>('DELETE', `/api/projects/${id}/files?path=${encodeURIComponent(path)}`),

  workflows: () => call<{ workflows: WorkflowInfo[] }>('GET', '/api/workflows'),
  createWorkflow: (w: { name: string; description?: string; steps: Array<{ title: string; prompt: string; role?: string }> }) =>
    call<{ workflow: WorkflowInfo }>('POST', '/api/workflows', w),
  workflow: (id: string) => call<{ workflow: WorkflowInfo; runs: WorkflowRunInfo[] }>('GET', `/api/workflows/${id}`),
  updateWorkflow: (id: string, patch: { name?: string; description?: string; steps?: Array<{ title: string; prompt: string; role?: string }> }) =>
    call<{ workflow: WorkflowInfo }>('PATCH', `/api/workflows/${id}`, patch),
  deleteWorkflow: (id: string) => call<{ ok: boolean }>('DELETE', `/api/workflows/${id}`),
  runWorkflow: (id: string, model: string, projectId?: string) =>
    call<{ run: WorkflowRunInfo }>('POST', `/api/workflows/${id}/run`, { model, ...(projectId ? { projectId } : {}) }),
  workflowRun: (runId: string) => call<{ run: WorkflowRunInfo; tasks: AgentTaskInfo[] }>('GET', `/api/workflow-runs/${runId}`),

  skills: () => call<{ skills: SkillInfo[] }>('GET', '/api/skills'),
  skill: (slug: string) => call<{ skill: SkillInfo; files: Array<{ path: string; bytes: number }>; events: SkillEventRow[] }>('GET', `/api/skills/${slug}`),
  skillFileContent: (slug: string, path: string) =>
    call<{ file: { path: string; content: string } }>('GET', `/api/skills/${slug}/files/content?path=${encodeURIComponent(path)}`),
  setSkillStatus: (slug: string, status: 'active' | 'disabled') => call<{ skill: SkillInfo }>('PATCH', `/api/skills/${slug}`, { status }),
  deleteSkill: (slug: string) => call<{ ok: boolean }>('DELETE', `/api/skills/${slug}`),
  skillEvents: (slug?: string) => call<{ events: SkillEventRow[] }>('GET', `/api/skills/events${slug ? `?slug=${encodeURIComponent(slug)}` : ''}`),
  checkSkillUpdate: (slug: string) =>
    call<{ skill: SkillInfo; update: { checked: boolean; headCommit?: string | null; installedCommit?: string | null; changed?: boolean; reason?: string } }>('POST', `/api/skills/${slug}/check-update`),
  discoverSkills: (q: string, opts: { limit?: number; owner?: string } = {}) =>
    call<DiscoveryResponse>('GET', `/api/skills/discover?q=${encodeURIComponent(q)}${opts.limit ? `&limit=${opts.limit}` : ''}${opts.owner ? `&owner=${encodeURIComponent(opts.owner)}` : ''}`),
  skillImports: () => call<{ imports: Array<SkillImportInfo & { report?: string | null }> }>('GET', '/api/skills/imports'),
  skillImport: (id: string) => call<{ import: SkillImportInfo & { report: string | null } }>('GET', `/api/skills/imports/${id}`),
  importSkill: (payload: { url: string } | { source: string; skillId?: string; installs?: number }) =>
    call<{ import: SkillImportInfo; report?: SkillInspectionReport; security?: SecurityAssessment; compatibility?: CompatibilityAssessment }>('POST', '/api/skills/import', payload),
  decideSkillImport: (id: string, decision: 'approve' | 'reject') =>
    call<{ import: SkillImportInfo; skill?: SkillInfo }>('POST', `/api/skills/imports/${id}/decision`, { decision }),
}

// ---------------- phase 2 types ----------------

export interface CatalogModel {
  id: string
  provider: string
  modelId: string
  ownedBy: string | null
  free: boolean
  contextLength: number | null
  pricingPrompt: string | null
  pricingCompletion: string | null
  discoveredAt: string
}

export interface CatalogSummary {
  refreshedAt: string | null
  ok: boolean
  stale: boolean
  models: number
  freeModels: number
  durationMs: number
  errors: Array<{ source: string; error: string }>
  providers: Array<{ provider: string; models: number; free: number; discoveredAt: string | null }>
  data: CatalogModel[]
}

export interface UsageBoard {
  days: number
  since: string
  totals: {
    calls: number
    ok: number
    failed: number
    promptTokens: number
    completionTokens: number
    avgMs: number | null
  }
  providers: Array<{
    provider: string
    calls: number
    ok: number
    failed: number
    promptTokens: number
    completionTokens: number
    avgMs: number | null
    lastUsedAt: string | null
    lastOkAt: string | null
    lastError: string | null
  }>
  models: Array<{
    provider: string
    model: string
    calls: number
    ok: number
    failed: number
    tokens: number
    lastUsedAt: string | null
  }>
  recentErrors: Array<{
    ts: string
    provider: string
    model: string
    error_kind: string | null
  }>
  catalog: { at: string | null; ok: boolean; models: number; freeModels: number }
}

export interface RouterProfileInfo {
  name: string
  chain: string[]
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export interface BreakerInfo {
  provider: string
  state: 'closed' | 'open' | 'half-open'
  failures: number
  lastFailureAt: string | null
  openedAt: string | null
  lastError: string | null
}

export interface RouterState {
  profiles: RouterProfileInfo[]
  active: string | null
  breakers: BreakerInfo[]
  semantics: string
}

export interface CustomProviderInfo {
  id: string
  label: string
  baseUrl: string
  needsKey: boolean
  enabled: boolean
  createdAt: string
  updatedAt: string
  hasKey?: boolean
}

export interface CompareResultInfo {
  model: string
  provider: string
  ok: boolean
  content: string
  error: { kind: string; message: string } | null
  skipped: string | null
  metrics: {
    ttfbMs: number | null
    totalMs: number | null
    promptTokens: number | null
    completionTokens: number | null
    tokensPerSec: number | null
  }
}

// ---------------- phase 3 types ----------------

export interface AgentTaskInfo {
  id: number
  goal: string
  model: string
  status: 'queued' | 'planning' | 'running' | 'awaiting_approval' | 'completed' | 'failed' | 'cancelled'
  source: string
  project_id: string | null
  mode: 'auto' | 'research' | 'build' | 'creative' | string
  plan: string | null
  report: string | null
  created_at: string
  updated_at: string
}

// ---------------- Reality Forge types ----------------

export interface ForgeLevelInfo {
  level: number
  ar: string
  what: string
}

export interface ForgeStatusInfo {
  enabled: boolean
  repo: string | null
  repoRoot: string | null
  level: number
  levels: ForgeLevelInfo[]
  /** LIMO #19: the DIRECT ACTION validation chain exactly as configured —
   *  an empty command is an honest empty (the step is skipped, never faked). */
  chain: { install: string; lint: string; tests: string; build: string }
  /** LIMO #19: the owner-pinned engineering intelligence model (null = the
   *  conversation model is used). e.g. openrouter/nvidia/nemotron-3-ultra-550b-a55b */
  engineeringModel: string | null
}

// ---------------- Black Box chatbot types ----------------

export interface BoxProfileInfo {
  name: string
  tagline: string
  language: 'ar' | 'en'
  defaultModel: string | null
  /** owner-pinned theme ('system' = devices keep their own choice) */
  themeMode: 'system' | 'light' | 'dark'
  /** accent palette id — see lib/appearance.ts */
  accent: string
}

export interface BoxStateInfo {
  profile: BoxProfileInfo
  autonomy: number
  vault: 'locked' | 'unlocked'
  usableModels: Array<{ id: string; free: boolean; contextLength: number | null }>
  link: string
}

export interface BoxActionInfo {
  tool: string
  args: Record<string, unknown>
  ok: boolean
  result: unknown
}

export interface BoxMessageInfo {
  id: number
  role: 'user' | 'box'
  content: string
  actions: string | null
  model: string | null
  created_at: string
}

export interface ForgeMapInfo {
  root: string
  scannedAt: string
  layers: Record<string, number>
  files: number
  edges: number
  entryPoints: string[]
  moduleBoundaries: string[]
  patterns: string[]
  conventions: string[]
  duplication: Array<{ a: string; b: string; windows: number; sample: string }>
  debt: Array<{ file: string; kind: string; detail: string }>
}

export type ForgeChangeStatus =
  | 'analyzing'
  | 'planned'
  | 'implementing'
  | 'testing'
  | 'reviewing'
  | 'awaiting_approval'
  | 'applied'
  | 'rejected'
  | 'rolled_back'
  | 'failed'

export interface ForgeChangeInfo {
  id: number
  request: string
  model: string | null
  status: ForgeChangeStatus
  level: number
  plan: string | null
  branch?: string | null
  worktree?: string | null
  diff?: string | null
  test_output?: string | null
  security_review?: string | null
  commit_id?: string | null
  rollback_of?: string | null
  error?: string | null
  created_at: string
  updated_at: string
}

export interface ForgeEventInfo {
  id: number
  ts: string
  actor: string
  kind: string
  data: string
}

export interface ForgeProposalInfo {
  id: number
  title: string
  kind: string
  benefit: string
  risk: string
  components: string
  cost: string
  validation: string
  status: string
  created_at: string
}

export interface AgentStepInfo {
  id: number
  task_id: number
  idx: number
  title: string
  tool: string | null
  args: string | null
  acceptance: string | null
  role: string | null
  status: 'pending' | 'running' | 'done' | 'failed' | 'skipped'
  result: string | null
  critic: string | null
  attempts: number
}

export interface AgentEventInfo {
  id: number
  task_id: number
  ts: string
  kind: string
  data: string | null
}

export interface AgentActionInfo {
  id: number
  task_id: number | null
  ts: string
  tool: string
  args: string
  ok: number
  result: string | null
  risk: string | null
  approval_id: number | null
}

export interface AgentApprovalInfo {
  id: number
  task_id: number | null
  category: 'payment' | 'deletion' | 'send' | 'settings_change' | 'software_install' | 'secret_share'
  summary: string
  payload: string
  status: 'pending' | 'approved' | 'rejected' | 'expired'
  created_at: string
  decided_at: string | null
  decided_by: string | null
}

export interface AgentRoutineInfo {
  id: number
  name: string
  prompt: string
  model: string
  interval_sec: number
  enabled: number
  allow_downgrade: number
  catch_up_on_unlock: number
  pending_catchup: number
  last_run_at: string | null
  next_run_at: string
  created_at: string
  updated_at: string
}

export interface AgentRoutineRunInfo {
  id: number
  routine_id: number
  ts: string
  status: 'ok' | 'skipped_vault_locked' | 'degraded_vault_locked' | 'error'
  detail: string | null
  task_id: number | null
}

export interface UserMemoryInfo {
  id: number
  kind: string
  title: string
  content: string
  source: string | null
  created_at: string
  updated_at: string
}

export interface EgressRowInfo {
  id: number
  ts: string
  source: string
  provider: string
  model: string | null
  payload_bytes: number
  payload_sha256: string
  left_machine: number
  ok: number | null
  error_kind: string | null
}

export interface EgressBoard {
  counts: { total: number; leftMachine: number; local: number; bytesLeft: number }
  rows: EgressRowInfo[]
}

// ---------------- LIMO layer 1 types ----------------

export interface ProjectInfo {
  id: string
  name: string
  description: string
  kind: string
  status: string
  created_at: string
  updated_at: string
}

export interface ProjectFileInfo {
  path: string
  size: number
  dir: boolean
}

export interface WorkflowStepInfo {
  title: string
  prompt: string
  role?: string
}

export interface WorkflowInfo {
  id: string
  name: string
  description: string
  steps: string // JSON
  created_at: string
  updated_at: string
}

export interface WorkflowRunInfo {
  id: string
  workflow_id: string
  status: 'running' | 'completed' | 'partial' | 'failed'
  task_ids: string // JSON
  detail: string | null
  started_at: string
  finished_at: string | null
}

export interface SkillInfo {
  id: string
  name: string
  slug: string
  version: string | null
  description: string
  source: string
  source_url: string | null
  repo_owner: string | null
  repo_name: string | null
  commit_hash: string | null
  license: string | null
  status: string
  status2: string | null
  lifecycle: string
  skill_id: string | null
  provider: string
  installs: number | null
  risk_level: string | null
  compatibility: string | null
  agents: string
  last_check: string | null
  update_available: string | null
  file_count: number
  installed_at: string
}

export interface SkillImportInfo {
  id: string
  url: string
  status: 'inspecting' | 'awaiting_approval' | 'installed' | 'rejected' | 'failed'
  error: string | null
  requested_at: string
  decided_at: string | null
}

export type SkillCheckStatus = 'verified' | 'not_detected' | 'not_tested' | 'failed' | 'unknown'

export interface SkillInspectionReport {
  url: string
  repo: { owner: string; name: string; branch: string; license?: string | null }
  target: { dir: string; skillId: string | null }
  skillRoots: Array<{ dir: string; name: string | null }>
  commit: string | null
  dataSource: 'github-api' | 'jsdelivr'
  checks: Array<{ id: string; label: string; status: SkillCheckStatus; detail: string; evidence?: string[] }>
  blockers: string[]
  warnings: string[]
  coverage: { scanned: number; total: number }
  frontmatter: Record<string, string> | null
  dependencies: Array<{ file: string; deps: number }>
  files: Array<{ path: string; bytes: number }>
  verdict: 'pass' | 'needs_review' | 'fail'
  inspectedAt: string
}

export interface SecurityAssessment {
  riskLevel: 'NONE' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' | 'UNKNOWN'
  dimensions: Array<{ id: string; label: string; provenance: 'external_audit' | 'limo_static' | 'dynamic_sandbox' | 'not_run' | 'unavailable'; status: 'clean' | 'findings' | 'not_run' | 'unavailable'; detail: string }>
  installBlocked: boolean
  assessedAt: string
}

export interface CompatibilityAssessment {
  state: 'COMPATIBLE' | 'PARTIALLY_COMPATIBLE' | 'INCOMPATIBLE' | 'UNKNOWN'
  requirements: Array<{ id: string; label: string; met: boolean; detail: string }>
  capabilitySummary: string
  limitations: string[]
  assessedAt: string
}

export interface DiscoveredSkill {
  id: string
  name: string
  source: string
  sourceUrl: string | null
  installs: number | null
  provider: 'skills.sh' | 'local' | 'github'
  slug?: string
  status?: string
}

export interface DiscoveryResponse {
  originalQuery: string
  effectiveQuery: string
  mappings: Array<{ from: string; to: string }>
  providers: Array<{ provider: string; skills: DiscoveredSkill[]; unavailable: boolean; reason?: string; fetchedAt: string }>
  skills: DiscoveredSkill[]
  discoveredAt: string
}

export interface SkillEventRow {
  id: number
  skill_slug: string
  action: string
  detail: string
  created_at: string
}
