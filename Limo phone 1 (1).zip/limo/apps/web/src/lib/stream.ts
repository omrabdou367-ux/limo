'use client'

/**
 * SSE consumption over fetch (POST + ReadableStream — EventSource can't POST).
 * Talks to the OpenAI-compatible /v1/chat/completions with stream:true.
 */
import type { ModelInfo } from './api'

export interface StreamResult {
  content: string
  finishReason: string | null
  usage?: { promptTokens?: number | null; completionTokens?: number | null }
  error?: { message: string; type: string }
}

export async function streamChat(params: {
  model: string
  messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }>
  signal: AbortSignal
  onDelta: (text: string) => void
}): Promise<StreamResult> {
  const res = await fetch('/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    credentials: 'same-origin',
    body: JSON.stringify({ model: params.model, messages: params.messages, stream: true }),
    signal: params.signal,
  })

  if (!res.ok) {
    let message = `HTTP ${res.status}`
    let type = 'http_error'
    try {
      const j = (await res.json()) as { error?: { message?: string; type?: string } }
      if (j.error?.message) message = j.error.message
      if (j.error?.type) type = j.error.type
    } catch {
      /* defaults */
    }
    return { content: '', finishReason: null, error: { message, type } }
  }
  if (!res.body) return { content: '', finishReason: null, error: { message: 'empty stream', type: 'provider_error' } }

  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''
  let content = ''
  let finishReason: string | null = null
  let usage: StreamResult['usage']

  for (;;) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })
    let nl: number
    while ((nl = buffer.indexOf('\n')) >= 0) {
      const line = buffer.slice(0, nl).trimEnd()
      buffer = buffer.slice(nl + 1)
      if (!line.startsWith('data:')) continue
      const data = line.slice(5).trim()
      if (data === '[DONE]') {
        return { content, finishReason, usage }
      }
      try {
        const evt = JSON.parse(data) as {
          choices?: Array<{ delta?: { content?: string }; finish_reason?: string | null }>
          usage?: { prompt_tokens?: number | null; completion_tokens?: number | null }
          error?: { message?: string; type?: string }
        }
        if (evt.error) {
          return { content, finishReason, error: { message: evt.error.message ?? 'provider error', type: evt.error.type ?? 'provider_error' } }
        }
        const delta = evt.choices?.[0]?.delta?.content
        if (typeof delta === 'string' && delta.length > 0) {
          content += delta
          params.onDelta(delta)
        }
        if (evt.choices?.[0]?.finish_reason) finishReason = evt.choices[0].finish_reason
        if (evt.usage) {
          usage = { promptTokens: evt.usage.prompt_tokens, completionTokens: evt.usage.completion_tokens }
        }
      } catch {
        /* keep-alive noise */
      }
    }
  }
  return { content, finishReason, usage }
}

export type { ModelInfo }
