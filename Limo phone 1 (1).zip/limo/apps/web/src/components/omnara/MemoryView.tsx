'use client'

import { useCallback, useEffect, useState } from 'react'
import { Check, Database, Loader2, Pencil, Plus, Search, Trash2, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useI18n } from '@/lib/i18n'
import { api, ApiError, type UserMemoryInfo } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * The agent memory screen (PLAN.md §6 stage 3): the owner's notes — fully
 * editable and deletable — plus the recorded task episodes, with LOCAL
 * semantic search (sqlite-vec on the server; mode badge is the server's
 * honest report, never a client guess).
 */
export function MemoryView({ onAuthLost }: { onAuthLost: () => void }) {
  const { t } = useI18n()
  const [mode, setMode] = useState('…')
  const [notes, setNotes] = useState<UserMemoryInfo[]>([])
  const [query, setQuery] = useState('')
  const [hits, setHits] = useState<Array<UserMemoryInfo & { distance: number }> | null>(null)
  const [searching, setSearching] = useState(false)
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [editing, setEditing] = useState<number | null>(null)
  const [editTitle, setEditTitle] = useState('')
  const [editContent, setEditContent] = useState('')
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    try {
      const res = await api.agentMemory()
      setMode(res.mode)
      setNotes(res.notes)
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) onAuthLost()
    }
  }, [onAuthLost])

  useEffect(() => {
    void load()
  }, [load])

  const add = async () => {
    if (title.trim().length === 0 || content.trim().length === 0) return
    setBusy(true)
    try {
      await api.createMemory(title.trim(), content.trim())
      setTitle('')
      setContent('')
      await load()
    } finally {
      setBusy(false)
    }
  }

  const saveEdit = async (id: number) => {
    setBusy(true)
    try {
      await api.updateMemory(id, { title: editTitle.trim(), content: editContent.trim() })
      setEditing(null)
      await load()
    } finally {
      setBusy(false)
    }
  }

  const remove = async (id: number) => {
    if (!window.confirm(t.memoryConfirmDelete)) return
    await api.deleteMemory(id).catch(() => undefined)
    await load()
  }

  const search = async () => {
    if (query.trim().length === 0) {
      setHits(null)
      return
    }
    setSearching(true)
    try {
      const res = await api.searchMemory(query.trim(), 8)
      setHits(res.hits)
    } finally {
      setSearching(false)
    }
  }

  return (
    <div className="h-full overflow-y-auto bg-canvas px-4 py-5 sm:px-6">
      <div className="mx-auto flex max-w-3xl flex-col gap-5">
        <section className="rounded-lg border border-line bg-surface p-4">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="font-display text-lg font-bold">{t.memoryTitle}</h2>
            <span className="ms-auto inline-flex items-center gap-1.5 rounded-sm border border-input px-2 py-0.5 font-mono text-[11px] text-dim" dir="ltr">
              <Database size={11} />
              {mode}
            </span>
          </div>
          <p className="mt-1 text-xs leading-relaxed text-dim">{t.memorySub}</p>

          {/* semantic search */}
          <div className="mt-3 flex gap-2">
            <Input value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && void search()} placeholder={t.memorySearchPh} aria-label={t.memorySearchPh} className="h-9 rounded-md border-input bg-canvas text-sm" />
            <Button onClick={() => void search()} disabled={searching} className="h-9 shrink-0 rounded-md bg-signal px-3 text-sm font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0">
              {searching ? <Loader2 size={14} className="animate-spin" /> : <Search size={14} />}
            </Button>
          </div>
          {hits && (
            <ul className="mt-2 flex flex-col gap-1">
              {hits.length === 0 && <li className="text-xs text-dim">∅</li>}
              {hits.map((h) => (
                <li key={h.id} className="flex items-center gap-2 rounded-sm border border-line bg-canvas px-3 py-1.5 text-xs">
                  <span className="font-semibold">{h.title}</span>
                  <span className="font-mono text-[10px] text-dim" dir="ltr">
                    d={h.distance.toFixed(3)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* add note */}
        <section className="rounded-lg border border-line bg-surface p-4">
          <div className="flex flex-col gap-2">
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={t.memoryAddTitle} aria-label={t.memoryAddTitle} className="h-9 rounded-md border-input bg-canvas text-sm" />
            <textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder={t.memoryAddContent} rows={3} dir="auto" aria-label={t.memoryAddContent} className="w-full resize-none rounded-md border border-input bg-canvas px-3 py-2 text-sm leading-relaxed outline-none placeholder:text-dim focus:border-signal-text dark:focus:border-signal" />
            <Button onClick={() => void add()} disabled={busy || title.trim().length === 0 || content.trim().length === 0} className="h-9 w-fit rounded-md bg-signal px-4 text-sm font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0">
              <Plus size={14} />
              {t.memoryAdd}
            </Button>
          </div>
        </section>

        {/* notes list */}
        <section className="rounded-lg border border-line bg-surface p-4">
          {notes.length === 0 ? (
            <p className="text-xs text-dim">{t.memoryNoNotes}</p>
          ) : (
            <ul className="flex flex-col gap-2">
              {notes.map((n) => (
                <li key={n.id} className="rounded-md border border-line bg-canvas p-3">
                  {editing === n.id ? (
                    <div className="flex flex-col gap-2">
                      <Input value={editTitle} onChange={(e) => setEditTitle(e.target.value)} aria-label={t.memoryAddTitle} className="h-8 rounded-sm border-input bg-surface text-sm" />
                      <textarea value={editContent} onChange={(e) => setEditContent(e.target.value)} rows={3} dir="auto" aria-label={t.memoryAddContent} className="w-full resize-none rounded-sm border border-input bg-surface px-3 py-2 text-xs leading-relaxed outline-none focus:border-signal-text dark:focus:border-signal" />
                      <div className="flex gap-2">
                        <Button size="sm" onClick={() => void saveEdit(n.id)} disabled={busy} className="h-7 rounded-sm bg-signal px-3 text-xs font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0">
                          <Check size={12} />
                          {t.save}
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setEditing(null)} className="h-7 rounded-sm border-input bg-surface px-3 text-xs">
                          <X size={12} />
                          {t.cancel}
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-semibold">{n.title}</span>
                        <span className="rounded-sm border border-input px-1.5 py-0.5 text-[10px] text-dim">
                          {n.kind === 'note' ? t.memoryKindNote : t.memoryKindEpisode}
                        </span>
                        <span className="font-mono text-[10px] text-dim" dir="ltr">
                          {n.source ?? '—'} · {n.updated_at.slice(0, 10)}
                        </span>
                        <span className="ms-auto flex gap-1">
                          <button type="button" onClick={() => { setEditing(n.id); setEditTitle(n.title); setEditContent(n.content) }} aria-label={t.memoryEdit} title={t.memoryEdit} className="rounded-sm p-1 text-dim transition-colors hover:bg-surface hover:text-body">
                            <Pencil size={13} />
                          </button>
                          <button type="button" onClick={() => void remove(n.id)} aria-label={t.memoryDelete} title={t.memoryDelete} className="rounded-sm p-1 text-dim transition-colors hover:bg-surface hover:text-fault-text">
                            <Trash2 size={13} />
                          </button>
                        </span>
                      </div>
                      <p className={cn('mt-1.5 whitespace-pre-wrap text-xs leading-relaxed text-dim')}>{n.content}</p>
                    </>
                  )}
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  )
}
