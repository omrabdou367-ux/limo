'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { ArrowDown, ArrowUp, Loader2, Plus, Route, Trash2, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useI18n } from '@/lib/i18n'
import { api, ApiError, type ModelInfo, type RouterProfileInfo, type RouterState } from '@/lib/api'
import { cn, timeAgo } from '@/lib/utils'

/**
 * Routing & fallback (PLAN.md §8.1.2): editable chains (reorder with explicit
 * arrows — no drag-and-drop theatre), one active profile, live breaker states.
 * Chain entries validate server-side against the registry at save time.
 */
export function RouterPanel() {
  const { t, lang } = useI18n()
  const [state, setState] = useState<RouterState | null>(null)
  const [models, setModels] = useState<ModelInfo[]>([])
  /** local edits: profile name -> chain (null = unchanged) */
  const [edits, setEdits] = useState<Record<string, string[]>>({})
  const [pick, setPick] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [newName, setNewName] = useState('')

  const load = useCallback(async () => {
    try {
      const [r, m] = await Promise.all([api.routerState(), api.models()])
      setState(r)
      setModels(m.data)
    } catch {
      /* keep current */
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  const dirty = useCallback(
    (p: RouterProfileInfo): boolean => {
      const e = edits[p.name]
      return e !== undefined && e.join('¦') !== p.chain.join('¦')
    },
    [edits],
  )

  const chainOf = (p: RouterProfileInfo): string[] => edits[p.name] ?? p.chain

  const mutateChain = (name: string, fn: (chain: string[]) => string[]) => {
    setEdits((prev) => {
      const base = prev[name] ?? state?.profiles.find((p) => p.name === name)?.chain ?? []
      return { ...prev, [name]: fn([...base]) }
    })
  }

  const move = (name: string, i: number, dir: -1 | 1) => {
    mutateChain(name, (chain) => {
      const j = i + dir
      if (j < 0 || j >= chain.length) return chain
      ;[chain[i], chain[j]] = [chain[j]!, chain[i]!]
      return chain
    })
  }

  const save = async (name: string) => {
    const chain = edits[name]
    if (!chain) return
    setBusy(name)
    setError(null)
    try {
      await api.saveRouterProfile(name, chain)
      setEdits((e) => {
        const next = { ...e }
        delete next[name]
        return next
      })
      await load()
    } catch (err) {
      setError(err instanceof ApiError ? err.message : String(err))
    } finally {
      setBusy(null)
    }
  }

  const activate = async (name: string | null) => {
    setBusy(name ?? '__deactivate')
    setError(null)
    try {
      await api.activateRouterProfile(name)
      await load()
    } catch (err) {
      setError(err instanceof ApiError ? err.message : String(err))
    } finally {
      setBusy(null)
    }
  }

  const remove = async (name: string) => {
    setBusy(name)
    setError(null)
    try {
      await api.deleteRouterProfile(name)
      await load()
    } catch (err) {
      setError(err instanceof ApiError ? err.message : String(err))
    } finally {
      setBusy(null)
    }
  }

  const create = async () => {
    const name = newName.trim()
    if (!name) return
    setBusy('__create')
    setError(null)
    try {
      await api.saveRouterProfile(name, [])
      setNewName('')
      await load()
    } catch (err) {
      setError(err instanceof ApiError ? err.message : String(err))
    } finally {
      setBusy(null)
    }
  }

  const addModel = (name: string) => {
    const id = pick[name]
    if (!id) return
    mutateChain(name, (chain) => (chain.includes(id) ? chain : [...chain, id]))
    setPick((p) => ({ ...p, [name]: '' }))
  }

  const selectable = useMemo(() => models, [models])

  return (
    <section className="h-full overflow-y-auto" aria-label={t.routerTitle}>
      <div className="mx-auto flex max-w-3xl flex-col gap-6 px-5 py-6">
        <header>
          <h2 className="flex items-center gap-2 font-display text-xl font-bold">
            <Route size={18} className="text-signal-text" />
            {t.routerTitle}
          </h2>
          <p className="mt-1 text-xs leading-relaxed text-dim">{t.routerSemantics}</p>
        </header>

        {error && <p role="alert" className="rounded-sm border border-fault/40 bg-surface px-3 py-2 text-xs text-fault-text">{error}</p>}

        {/* new profile */}
        <div className="flex gap-2">
          <Input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder={t.routerProfileName}
            aria-label={t.routerProfileName}
            dir="ltr"
            className="h-9 max-w-64 rounded-md border-input bg-surface font-mono text-xs"
          />
          <Button
            onClick={() => void create()}
            disabled={busy === '__create' || newName.trim().length < 2}
            className="h-9 rounded-md bg-signal px-3 text-xs font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0"
          >
            {busy === '__create' ? <Loader2 size={12} className="animate-spin" /> : <Plus size={13} />}
            {t.routerCreate}
          </Button>
        </div>

        {/* profiles */}
        {state?.profiles.length === 0 && <p className="text-xs text-dim">{t.routerNoProfiles}</p>}
        {state?.profiles.map((p) => {
          const chain = chainOf(p)
          const isDirty = dirty(p)
          return (
            <article key={p.name} className={cn('rounded-lg border bg-surface p-4', p.isActive ? 'border-signal/60' : 'border-line')}>
              <div className="flex flex-wrap items-center gap-2">
                <span
                  aria-hidden="true"
                  className={cn('size-2 rounded-full', p.isActive ? 'bg-signal' : 'bg-line')}
                />
                <span className="font-mono text-sm" dir="ltr">
                  {p.name}
                </span>
                {p.isActive ? (
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={busy === '__deactivate'}
                    onClick={() => void activate(null)}
                    className="h-7 rounded-sm border-input bg-canvas px-2 text-[11px]"
                  >
                    {t.routerDeactivate}
                  </Button>
                ) : (
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={busy === p.name || chain.length === 0}
                    onClick={() => void activate(p.name)}
                    className="h-7 rounded-sm border-input bg-canvas px-2 text-[11px]"
                  >
                    {t.routerActivate}
                  </Button>
                )}
                <span className="ms-auto flex items-center gap-1">
                  <Button
                    size="sm"
                    onClick={() => void save(p.name)}
                    disabled={!isDirty || busy === p.name}
                    className="h-7 rounded-sm bg-signal px-3 text-[11px] font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0"
                  >
                    {busy === p.name ? <Loader2 size={11} className="animate-spin" /> : null}
                    {t.routerSave}
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => void remove(p.name)}
                    disabled={p.isActive}
                    aria-label={t.routerDelete}
                    title={p.isActive ? undefined : t.routerDelete}
                    className="h-7 rounded-sm px-2 text-dim hover:text-fault-text disabled:opacity-30"
                  >
                    <Trash2 size={13} />
                  </Button>
                </span>
              </div>

              {/* chain */}
              <div className="mt-3 flex flex-col gap-1">
                {chain.length === 0 && <p className="font-mono text-[11px] text-dim">{t.routerChainEmpty}</p>}
                {chain.map((m, i) => (
                  <div key={m} className="flex items-center gap-1.5 rounded-sm border border-line bg-canvas px-2.5 py-1.5">
                    <span className="w-5 shrink-0 font-mono text-[10px] text-dim" dir="ltr">
                      {i + 1}.
                    </span>
                    <span className="min-w-0 flex-1 truncate font-mono text-xs" dir="ltr" title={m}>
                      {m}
                    </span>
                    <button
                      type="button"
                      onClick={() => move(p.name, i, -1)}
                      disabled={i === 0}
                      aria-label="up"
                      className="rounded-sm p-1 text-dim transition-colors hover:text-body disabled:opacity-25"
                    >
                      <ArrowUp size={12} />
                    </button>
                    <button
                      type="button"
                      onClick={() => move(p.name, i, 1)}
                      disabled={i === chain.length - 1}
                      aria-label="down"
                      className="rounded-sm p-1 text-dim transition-colors hover:text-body disabled:opacity-25"
                    >
                      <ArrowDown size={12} />
                    </button>
                    <button
                      type="button"
                      onClick={() => mutateChain(p.name, (c) => c.filter((x) => x !== m))}
                      aria-label={t.remove}
                      className="rounded-sm p-1 text-dim transition-colors hover:text-fault-text"
                    >
                      <X size={12} />
                    </button>
                  </div>
                ))}
              </div>

              {/* add to chain */}
              <div className="mt-2 flex gap-2">
                <Select value={pick[p.name] ?? ''} onValueChange={(v) => setPick((s) => ({ ...s, [p.name]: v }))}>
                  <SelectTrigger className="h-8 min-w-0 flex-1 rounded-sm border-input bg-canvas font-mono text-xs" dir="ltr" aria-label={t.routerAddModel}>
                    <SelectValue placeholder={t.routerAddModel} />
                  </SelectTrigger>
                  <SelectContent className="max-h-72 rounded-md border-line bg-surface">
                    {selectable
                      .filter((m) => !chain.includes(m.id))
                      .map((m) => (
                        <SelectItem key={m.id} value={m.id} className="rounded-sm font-mono text-xs">
                          <span className="flex items-center gap-2">
                            <span className="truncate" dir="ltr">
                              {m.id}
                            </span>
                            {m.free && <span className="text-[10px] text-signal-text">free</span>}
                          </span>
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={!pick[p.name]}
                  onClick={() => addModel(p.name)}
                  className="h-8 shrink-0 rounded-sm border-input bg-canvas px-2 text-[11px]"
                >
                  <Plus size={12} />
                  {t.routerAddModel}
                </Button>
              </div>
            </article>
          )
        })}

        {/* breakers */}
        {state && state.breakers.length > 0 && (
          <div>
            <h3 className="mb-2 font-mono text-xs text-dim" dir="ltr">
              {t.routerBreakers}
            </h3>
            <div className="flex flex-col gap-1.5">
              {state.breakers.map((b) => (
                <div key={b.provider} className="flex flex-wrap items-center gap-3 rounded-sm border border-line px-3 py-2 font-mono text-[11px]" dir="ltr">
                  <span className={cn(b.state === 'open' ? 'text-rust-text' : b.state === 'half-open' ? 'text-signal-text' : 'text-body')}>
                    {b.provider}: {b.state === 'open' ? t.breakerOpen : b.state === 'half-open' ? t.breakerHalfOpen : t.breakerClosed}
                  </span>
                  <span className="text-dim">
                    {b.failures} {t.breakerFailures} · {b.lastFailureAt ? timeAgo(b.lastFailureAt, lang) : ''}
                  </span>
                  {b.lastError && (
                    <span className="max-w-64 truncate text-fault-text" title={b.lastError}>
                      {b.lastError}
                    </span>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={async () => {
                      await api.resetBreaker(b.provider).catch(() => undefined)
                      await load()
                    }}
                    className="ms-auto h-7 rounded-sm border-input bg-canvas px-2 text-[11px]"
                  >
                    {t.breakerReset}
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
        {state && state.breakers.length === 0 && <p className="font-mono text-[11px] text-dim">{t.breakerNone}</p>}
      </div>
    </section>
  )
}
