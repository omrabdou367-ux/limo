'use client'

import { useEffect, useRef, useState } from 'react'
import { ArrowUp, Square } from 'lucide-react'
import { useVoiceInput } from '@/hooks/use-voice-input'
import { useI18n } from '@/lib/i18n'
import { cn } from '@/lib/utils'

/** Auto-growing soft composer — Enter sends, Shift+Enter breaks the line. */
export function Composer({
  disabled,
  streaming,
  onSend,
  onStop,
}: {
  disabled?: boolean
  streaming: boolean
  onSend: (text: string) => void
  onStop: () => void
}) {
  const { t, lang } = useI18n()
  const [value, setValue] = useState('')
  const ref = useRef<HTMLTextAreaElement>(null)
  const { supported: micSupported, listening, start, stop } = useVoiceInput({ lang })

  useEffect(() => {
    const el = ref.current
    if (!el) return
    el.style.height = '0px'
    el.style.height = `${Math.min(el.scrollHeight, 192)}px`
  }, [value])

  const submit = () => {
    const text = value.trim()
    if (!text || disabled || streaming) return
    setValue('')
    onSend(text)
  }

  const roundBtn =
    'flex size-10 shrink-0 items-center justify-center rounded-full transition-colors'

  return (
    <div className="bg-canvas px-4 pb-4 pt-2 sm:px-5 sm:pb-5">
      <div className="mx-auto max-w-3xl">
        <div className="limo-soft flex items-end gap-1.5 p-2 shadow-lg shadow-ink/5 dark:shadow-black/40">
          {/* honest mic — hidden when the browser lacks SpeechRecognition */}
          {micSupported && (
            <button
              type="button"
              onClick={() => {
                if (listening) stop()
                else
                  start({
                    onFinal: (chunk) => {
                      setValue((prev) => `${prev}${prev && !prev.endsWith(' ') ? ' ' : ''}${chunk.trim()} `)
                      ref.current?.focus()
                    },
                  })
              }}
              aria-label={listening ? t.heroMicStop : t.heroMicLabel}
              title={listening ? t.heroMicStop : t.heroMicLabel}
              aria-pressed={listening}
              className={cn(
                roundBtn,
                'mb-0.5 text-dim hover:bg-canvas hover:text-body',
                listening && 'limo-mic-live bg-canvas text-signal-text dark:text-signal',
              )}
            >
              <svg viewBox="0 0 24 24" className="size-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
                <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
                <line x1="12" x2="12" y1="19" y2="22" />
              </svg>
            </button>
          )}
          <textarea
            ref={ref}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                submit()
              }
            }}
            placeholder={t.composerPlaceholder}
            dir="auto"
            rows={1}
            disabled={disabled}
            aria-label={t.composerPlaceholder}
            className="max-h-48 flex-1 resize-none bg-transparent px-2 py-2.5 text-base leading-relaxed outline-none placeholder:text-dim disabled:opacity-50"
          />
          {streaming ? (
            <button
              type="button"
              onClick={onStop}
              aria-label={t.stop}
              title={t.stop}
              className={cn(roundBtn, 'mb-0.5 bg-fault/15 text-fault-text transition-colors hover:bg-fault/25')}
            >
              <Square size={14} fill="currentColor" />
            </button>
          ) : (
            <button
              type="button"
              onClick={submit}
              disabled={disabled || value.trim().length === 0}
              aria-label={t.send}
              title={t.send}
              className={cn(
                roundBtn,
                'mb-0.5 bg-signal text-primary-foreground transition-opacity',
                'border border-ink dark:border-0',
                (disabled || value.trim().length === 0) && 'opacity-40',
              )}
            >
              <ArrowUp size={17} />
            </button>
          )}
        </div>
        <p className="mt-2 hidden text-center font-mono text-[11px] text-dim sm:block" dir="ltr">
          POST /v1/chat/completions · SSE
        </p>
      </div>
    </div>
  )
}
