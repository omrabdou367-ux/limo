'use client'

import { useCallback, useEffect, useState } from 'react'
import { Loader2, Plus, Server, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useI18n } from '@/lib/i18n'
import { api, ApiError, type CustomProviderInfo, type SecretInfo } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * Custom providers tab (PLAN.md §8.1.5) — lives inside the vault panel.
 * Adding an endpoint registers a live adapter instantly; keyed providers
 * take their secret right here through the same write-only vault path
 * (alias '<id>:default', last-4 display only).
 */
export function CustomProvidersSection({
  vaultUnlocked,
  secrets,
  onChanged,
}: {
  vaultUnlocked: boolean
  secrets: SecretInfo[]
  onChanged: () => void
}) {
  const { t } = useI18n()
  const [providers, setProviders] = useState<CustomProviderInfo[]>([])
  const [id, setId] = useState('')
  const [label, setLabel] = useState('')
  const [url, setUrl] = useState('')
  const [needsKey, setNeedsKey] = useState(false)
  const [busy, setBusy] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [keyDrafts, setKeyDrafts] = useState<Record<string, string>>({})
  const [testResult, setTestResult] = useState<Record<string, string>>({})

  const reload = useCallback(async () => {
    try {
      const res = await api.customProviders()
      setProviders(res.providers)
    } catch {
      /* keep current */
    }
  }, [])

  useEffect(() => {
    void reload()
  }, [reload])

  const add = async () => {
    setBusy('__add')
    setError(null)
    try {
      await api.createCustomProvider({ id: id.trim(), label: label.trim() || id.trim(), baseUrl: url.trim(), needsKey })
      setId('')
      setLabel('')
      setUrl('')
      setNeedsKey(false)
      await reload()
      onChanged()
    } catch (err) {
      setError(err instanceof ApiError ? err.message : String(err))
    } finally {
      setBusy(null)
    }
  }

  const remove = async (pid: string) => {
    setBusy(pid)
    setError(null)
    try {
      const res = await api.deleteCustomProvider(pid)
      if (res.secretKept) setError(t.customSecretKept)
      await reload()
      onChanged()
    } catch (err) {
      setError(err instanceof ApiError ? err.message : String(err))
    } finally {
      setBusy(null)
    }
  }

  const test = async (pid: string) => {
    setBusy(pid)
    setTestResult((r) => ({ ...r, [pid]: '' }))
    try {
      const res = await api.testCustomProvider(pid)
      setTestResult((r) => ({ ...r, [pid]: `✓ ${res.models}` }))
    } catch (err) {
      setTestResult((r) => ({ ...r, [pid]: `✗ ${err instanceof ApiError ? err.message : 'error'}` }))
    } finally {
      setBusy(null)
    }
  }

  const saveKey = async (pid: string) => {
    const value = keyDrafts[pid]
    if (!value || value.length < 8) return
    setBusy(pid)
    setError(null)
    try {
      await api.vaultPutSecret(`${pid}:default`, pid, value)
      setKeyDrafts((d) => ({ ...d, [pid]: '' }))
      await reload()
      onChanged()
    } catch (err) {
      setError(err instanceof ApiError ? err.message : String(err))
    } finally {
      setBusy(null)
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <p className="text-xs leading-relaxed text-dim">{t.customHint}</p>

      {error && <p role="alert" className="rounded-sm border border-line bg-canvas px-3 py-2 text-xs text-rust-text">{error}</p>}

      {/* add form */}
      <div className="flex flex-col gap-2 rounded-md border border-line bg-surface p-3">
        <div className="grid grid-cols-2 gap-2">
          <Input value={id} onChange={(e) => setId(e.target.value)} placeholder={t.customId} aria-label={t.customId} dir="ltr" className="h-8 rounded-sm border-input bg-canvas font-mono text-xs" />
          <Input value={label} onChange={(e) => setLabel(e.target.value)} placeholder={t.customLabel} aria-label={t.customLabel} className="h-8 rounded-sm border-input bg-canvas text-xs" />
        </div>
        <div className="flex gap-2">
          <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder={t.customUrl} aria-label={t.customUrl} dir="ltr" className="h-8 min-w-0 flex-1 rounded-sm border-input bg-canvas font-mono text-xs" />
          <Button
            onClick={() => setNeedsKey((v) => !v)}
            variant="outline"
            aria-pressed={needsKey}
            className={cn('h-8 shrink-0 rounded-sm border-input px-2 text-[11px]', needsKey ? 'bg-canvas text-signal-text' : 'bg-canvas text-dim')}
          >
            <Server size={12} />
            {t.customNeedsKey}
          </Button>
          <Button
            onClick={() => void add()}
            disabled={busy === '__add' || id.trim().length < 2 || !/^https?:\/\//.test(url.trim())}
            className="h-8 shrink-0 rounded-sm bg-signal px-3 text-xs font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0"
          >
            {busy === '__add' ? <Loader2 size={12} className="animate-spin" /> : <Plus size={12} />}
            {t.customAdd}
          </Button>
        </div>
      </div>

      {/* list */}
      {providers.length === 0 && <p className="font-mono text-[11px] text-dim">{t.customNone}</p>}
      {providers.map((p) => {
        const alias = `${p.id}:default`
        const secret = secrets.find((s) => s.alias === alias)
        return (
          <div key={p.id} className="rounded-md border border-line bg-surface p-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-sm" dir="ltr">
                {p.id}
              </span>
              <span className="text-xs text-dim">{p.label}</span>
              <span dir="ltr" className="min-w-0 flex-1 truncate font-mono text-[11px] text-dim" title={p.baseUrl}>
                {p.baseUrl}
              </span>
              {p.needsKey && (
                <span className={cn('font-mono text-[11px]', secret ? 'text-signal-text' : 'text-dim')}>
                  {secret ? `${t.keyHint} ····${secret.hint ?? ''}` : t.noKey}
                </span>
              )}
              <Button size="sm" variant="outline" disabled={busy === p.id} onClick={() => void test(p.id)} className="h-7 rounded-sm border-input bg-canvas px-2 text-[11px]">
                {busy === p.id ? <Loader2 size={11} className="animate-spin" /> : null}
                {t.customTest}
              </Button>
              <Button size="sm" variant="ghost" onClick={() => void remove(p.id)} aria-label={t.remove} className="h-7 rounded-sm px-2 text-dim hover:text-fault-text">
                <Trash2 size={13} />
              </Button>
            </div>
            {testResult[p.id] && (
              <p className={cn('mt-2 font-mono text-[11px]', testResult[p.id]?.startsWith('✓') ? 'text-signal-text' : 'text-fault-text')} dir="ltr">
                {testResult[p.id]}
              </p>
            )}
            {p.needsKey && vaultUnlocked && (
              <div className="mt-2.5 flex flex-wrap items-center gap-2">
                <Input
                  type="password"
                  value={keyDrafts[p.id] ?? ''}
                  onChange={(e) => setKeyDrafts((d) => ({ ...d, [p.id]: e.target.value }))}
                  placeholder={t.customKeyHere}
                  aria-label={`${t.customKeyHere} (${p.id})`}
                  dir="ltr"
                  className="h-8 min-w-40 flex-1 rounded-sm border-input bg-canvas font-mono text-xs"
                />
                <Button size="sm" disabled={(keyDrafts[p.id] ?? '').length < 8} onClick={() => void saveKey(p.id)} className="h-8 rounded-sm bg-signal px-3 text-xs font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0">
                  {t.save}
                </Button>
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
