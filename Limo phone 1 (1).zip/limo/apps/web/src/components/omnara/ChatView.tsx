'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Columns3, KeyRound, PanelRight } from 'lucide-react'
import { Sidebar } from './Sidebar'
import { MessageList, type UiMessage } from './MessageList'
import { Composer } from './Composer'
import { ModelPicker } from './ModelPicker'
import { VaultPanel } from './VaultPanel'
import { CompareMode } from './CompareMode'
import { AgentView } from './AgentView'
import { MemoryView } from './MemoryView'
import { ForgeView } from './ForgeView'
import { BlackBoxChat } from '@/components/limo/BlackBoxChat'
import { HeroChat } from '@/components/limo/HeroChat'
import { ProjectsView } from '@/components/limo/ProjectsView'
import { WorkflowsView } from '@/components/limo/WorkflowsView'
import { AllimniView } from '@/components/limo/AllimniView'
import { SkillsView } from '@/components/limo/SkillsView'
import { FilesView } from '@/components/limo/FilesView'
import { LibraryView } from '@/components/limo/LibraryView'
import { BuilderView, StudioView, WorkshopView } from '@/components/limo/Launchers'
import { IntegrationsView, SettingsView } from '@/components/limo/SystemViews'
import { SystemMapView } from '@/components/limo/SystemMapView'
import { useI18n } from '@/lib/i18n'
import { api, ApiError, type BoxProfileInfo, type ConversationInfo, type HealthResponse } from '@/lib/api'
import { applyAppearance, reapplyAccent } from '@/lib/appearance'
import { streamChat } from '@/lib/stream'
import type { Area } from '@/lib/nav'
import { cn } from '@/lib/utils'

/**
 * The LIMO AGENT shell: one client route, 14 navigation areas + the chat
 * surface. The model is shared state across every area (single source of
 * truth); streaming goes through the OpenAI-compatible gateway; every area
 * renders a REAL capability surface (no placeholder screens).
 */
export function ChatView({ health, onHealth, onAuthLost }: {
  health: HealthResponse | null
  onHealth: () => void
  onAuthLost: () => void
}) {
  const { t, lang, setLang } = useI18n()
  const [area, setArea] = useState<Area>('home')
  const [compareOn, setCompareOn] = useState(false)
  const [conversations, setConversations] = useState<ConversationInfo[]>([])
  const [activeId, setActiveId] = useState<number | null>(null)
  const [messages, setMessages] = useState<UiMessage[]>([])
  const [model, setModel] = useState<string | null>(null)
  const [streaming, setStreaming] = useState(false)
  const [streamError, setStreamError] = useState<string | null>(null)
  const [vaultOpen, setVaultOpen] = useState(false)
  const [navOpen, setNavOpen] = useState(false)
  const [vaultState, setVaultState] = useState<'uninitialized' | 'locked' | 'unlocked' | null>(null)
  const [focusTaskId, setFocusTaskId] = useState<number | null>(null)
  const [openProjectId, setOpenProjectId] = useState<string | null>(null)
  const [bbDossier, setBbDossier] = useState(false)
  const [profile, setProfile] = useState<BoxProfileInfo | null>(null)
  const abortRef = useRef<AbortController | null>(null)

  /** the owner-renamable identity (Black Box «غيّر اسم التطبيق…») — one source
   *  of truth for the sidebar brand, the header and the document title. */
  const loadProfile = useCallback(async () => {
    try {
      const s = await api.boxState()
      setProfile(s.profile)
      // the owner's pinned theme + accent (Black Box tools / Settings mirror)
      applyAppearance(s.profile)
    } catch {
      /* profile is optional — the default identity stays */
    }
  }, [])

  // accent is device-local until the profile says otherwise — no flash on SPA mounts
  useEffect(() => {
    reapplyAccent()
  }, [])

  useEffect(() => {
    void loadProfile()
    // the Black Box dispatches this after any successful modification
    const onProfileChanged = () => void loadProfile()
    window.addEventListener('limo:profile-changed', onProfileChanged)
    return () => window.removeEventListener('limo:profile-changed', onProfileChanged)
  }, [loadProfile])

  // LIMO #15 — the Black Box connect-model panel deep-links into the real
  // flows (vault dialog / Integrations area). Same decoupled custom-event
  // pattern as limo:agent-prefill; unknown areas are ignored, never guessed.
  useEffect(() => {
    const onOpenVault = () => setVaultOpen(true)
    const onNavigateArea = (e: Event) => {
      const target = (e as CustomEvent<string>).detail
      const known: Area[] = ['home', 'chat', 'workspace', 'studio', 'workshop', 'builder', 'workflow', 'allimni', 'skills', 'files', 'projects', 'library', 'blackbox', 'memory', 'integrations', 'systemmap', 'settings']
      if (typeof target === 'string' && (known as string[]).includes(target)) {
        setArea(target as Area)
        setNavOpen(false)
      }
    }
    window.addEventListener('limo:open-vault', onOpenVault)
    window.addEventListener('limo:navigate-area', onNavigateArea)
    return () => {
      window.removeEventListener('limo:open-vault', onOpenVault)
      window.removeEventListener('limo:navigate-area', onNavigateArea)
    }
  }, [])

  const brandName = profile?.name ?? 'LIMO AGENT'

  // first visit honors the owner-set default language (no manual choice yet)
  useEffect(() => {
    if (profile && !window.localStorage.getItem('omnara-lang') && (profile.language === 'ar' || profile.language === 'en') && profile.language !== lang) {
      setLang(profile.language)
    }
  }, [profile, lang, setLang])

  useEffect(() => {
    document.title = brandName
  }, [brandName])

  useEffect(() => {
    const saved = window.localStorage.getItem('omnara-model')
    if (saved) setModel(saved)
  }, [])

  const changeModel = (id: string) => {
    setModel(id)
    window.localStorage.setItem('omnara-model', id)
  }

  const refreshVault = useCallback(async () => {
    try {
      const s = await api.vaultStatus()
      setVaultState(s.state)
    } catch {
      /* ignore */
    }
  }, [])

  const loadConversations = useCallback(async () => {
    try {
      setConversations(await api.conversations())
    } catch {
      /* ignore */
    }
  }, [])

  useEffect(() => {
    void loadConversations()
    void refreshVault()
  }, [loadConversations, refreshVault])

  const openConversation = async (id: number) => {
    try {
      const conv = await api.conversation(id)
      setActiveId(conv.id)
      setMessages(conv.messages.filter((m) => m.role !== 'system').map((m) => ({ ...m, role: m.role as 'user' | 'assistant' })))
      if (conv.model) changeModel(conv.model)
      setArea('chat')
    } catch {
      /* ignore */
    }
  }

  const newChat = () => {
    abortRef.current?.abort()
    setActiveId(null)
    setMessages([])
    setStreamError(null)
    setArea('chat')
  }

  const deleteConversation = async (id: number) => {
    await api.deleteConversation(id).catch(() => undefined)
    if (id === activeId) {
      setActiveId(null)
      setMessages([])
    }
    void loadConversations()
  }

  const send = async (text: string) => {
    if (!model) {
      setStreamError(t.homeNeedModel)
      setVaultOpen(true)
      return
    }
    setStreamError(null)
    const userMsg: UiMessage = { id: `u-${Date.now()}`, role: 'user', content: text }
    const assistantMsg: UiMessage = { id: `a-${Date.now()}`, role: 'assistant', content: '', model }
    setMessages((prev) => [...prev, userMsg, assistantMsg])
    setStreaming(true)

    const controller = new AbortController()
    abortRef.current = controller

    try {
      // lazily create the conversation on first message
      let chatId = activeId
      if (chatId === null) {
        const conv = await api.createConversation(model)
        chatId = conv.id
        setActiveId(chatId)
      }
      await api.addMessage(chatId, 'user', text)

      const history = messages.map((m) => ({ role: m.role, content: m.content }))

      const result = await streamChat({
        model,
        messages: [...history, { role: 'user', content: text }],
        signal: controller.signal,
        onDelta: (chunk) => {
          setMessages((prev) =>
            prev.map((m) => (m.id === assistantMsg.id ? { ...m, content: m.content + chunk } : m)),
          )
        },
      })

      if (result.error) {
        setStreamError(result.error.message)
      }
      if (result.content && chatId !== null) {
        await api.addMessage(chatId, 'assistant', result.content, model).catch(() => undefined)
      }
      void loadConversations()
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        onAuthLost()
        return
      }
      setStreamError(err instanceof Error ? err.message : String(err))
    } finally {
      setStreaming(false)
      abortRef.current = null
    }
  }

  const stop = () => {
    abortRef.current?.abort()
    setStreaming(false)
  }

  const vaultLocked = vaultState === 'locked'
  const hasMessages = messages.length > 0 || streaming

  /** dispatch from Home → chat (prefilled) or agent task (then focus it). */
  const openChatWith = (text: string) => {
    setArea('chat')
    void send(text)
  }
  const dispatchAgentTask = (text: string) => {
    setFocusTaskId(null)
    setArea('workspace')
    // the agent view's own composer holds the goal; prefilling happens via a
    // small custom event so we never duplicate engine logic here
    window.dispatchEvent(new CustomEvent('limo:agent-prefill', { detail: text }))
  }
  const openTask = (id: number) => {
    setFocusTaskId(id)
    setArea('workspace')
  }

  const sidebar = (
    <Sidebar
      conversations={conversations}
      activeId={activeId}
      health={health}
      vaultState={vaultState}
      area={area}
      brandName={brandName}
      onArea={(a) => {
        setArea(a)
        setNavOpen(false) // picking an area closes the mobile overlay
      }}
      onNewChat={newChat}
      onSelect={openConversation}
      onDelete={deleteConversation}
      onOpenVault={() => {
        setVaultOpen(true)
        setNavOpen(false)
      }}
      onNavigate={() => setNavOpen(false)}
    />
  )

  return (
    <div className="flex h-dvh overflow-hidden bg-canvas">
      {/* desktop rail */}
      <div className="hidden md:flex">{sidebar}</div>

      {/* mobile overlay navigation */}
      {navOpen && (
        <div className="fixed inset-0 z-50 md:hidden" role="dialog" aria-modal="true">
          <button
            type="button"
            aria-label={t.close}
            onClick={() => setNavOpen(false)}
            className="absolute inset-0 bg-ink/60"
          />
          <div className="absolute inset-y-0 end-0 shadow-2xl">{sidebar}</div>
        </div>
      )}

      <main className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center gap-2 border-b border-line px-4">
          <button
            type="button"
            onClick={() => setNavOpen(true)}
            aria-label={t.chats}
            className="flex size-9 shrink-0 items-center justify-center rounded-md text-dim transition-colors hover:bg-surface hover:text-body md:hidden"
          >
            <PanelRight size={17} />
          </button>
          {area === 'chat' && (
            <>
              <ModelPicker value={model} onChange={changeModel} onNeedVault={() => setVaultOpen(true)} allowAuto />
              <button
                type="button"
                onClick={() => setCompareOn((v) => !v)}
                aria-label={t.compareMode}
                title={t.compareMode}
                aria-pressed={compareOn}
                className={cn(
                  'flex size-9 shrink-0 items-center justify-center rounded-md border transition-colors',
                  compareOn
                    ? 'border-signal-text bg-canvas text-signal-text dark:border-signal dark:text-signal'
                    : 'border-input bg-surface text-dim hover:text-body',
                )}
              >
                <Columns3 size={15} />
              </button>
            </>
          )}
          {vaultLocked && (
            <button
              type="button"
              onClick={() => setVaultOpen(true)}
              className="flex h-9 shrink-0 items-center gap-1.5 rounded-md border border-rust/40 bg-surface px-3 text-xs text-rust-text transition-colors hover:bg-surface/70"
            >
              <KeyRound size={13} />
              <span className="hidden sm:inline">{t.vaultLocked}</span>
            </button>
          )}
          <span className="ms-auto hidden font-mono text-[11px] text-dim sm:inline" dir="ltr">
            {health ? `${brandName} · v${health.version}` : brandName}
          </span>
        </header>

        {area === 'chat' && vaultLocked && (
          <p className="border-b border-line bg-surface px-4 py-1.5 text-center text-xs text-rust-text">
            {t.vaultLockedBanner}
          </p>
        )}

        <div className="min-h-0 flex-1">
          {area === 'home' ? (
            <HeroChat
              health={health}
              model={model}
              onModelChange={changeModel}
              onNeedVault={() => setVaultOpen(true)}
              onSendChat={openChatWith}
              onDispatchAgent={dispatchAgentTask}
              onOpenTask={openTask}
              showRecent
            />
          ) : area === 'chat' ? (
            compareOn ? (
              <CompareMode />
            ) : hasMessages ? (
              <MessageList messages={messages} streaming={streaming} streamingModel={model} />
            ) : (
              /* empty conversation = the same hero composer — everything IS the chatbot */
              <HeroChat
                health={health}
                model={model}
                onModelChange={changeModel}
                onNeedVault={() => setVaultOpen(true)}
                onSendChat={(text) => void send(text)}
                onDispatchAgent={dispatchAgentTask}
                onOpenTask={openTask}
                showRecent={false}
              />
            )
          ) : area === 'workspace' ? (
            <AgentView
              onAuthLost={onAuthLost}
              focusTaskId={focusTaskId}
              model={model}
              onModelChange={changeModel}
              onNeedVault={() => setVaultOpen(true)}
            />
          ) : area === 'studio' ? (
            <StudioView model={model} onOpenTask={openTask} />
          ) : area === 'workshop' ? (
            <WorkshopView model={model} onOpenTask={openTask} />
          ) : area === 'builder' ? (
            <BuilderView model={model} onOpenTask={openTask} />
          ) : area === 'workflow' ? (
            <WorkflowsView model={model} onOpenTask={openTask} onAuthLost={onAuthLost} />
          ) : area === 'projects' ? (
            <ProjectsView focusProjectId={openProjectId} onAuthLost={onAuthLost} />
          ) : area === 'library' ? (
            <LibraryView
              onOpenProject={(id) => {
                setOpenProjectId(id)
                setArea('projects')
              }}
              onAuthLost={onAuthLost}
            />
          ) : area === 'allimni' ? (
            <AllimniView
              onAuthLost={onAuthLost}
              onInstalled={() => undefined}
            />
          ) : area === 'skills' ? (
            <SkillsView onAuthLost={onAuthLost} />
          ) : area === 'files' ? (
            <FilesView onAuthLost={onAuthLost} />
          ) : area === 'blackbox' ? (
            bbDossier ? (
              <ForgeView onAuthLost={onAuthLost} onBackToChat={() => setBbDossier(false)} />
            ) : (
              <BlackBoxChat onOpenDossier={() => setBbDossier(true)} />
            )
          ) : area === 'memory' ? (
            <MemoryView onAuthLost={onAuthLost} />
          ) : area === 'systemmap' ? (
            <SystemMapView onAuthLost={onAuthLost} />
          ) : area === 'integrations' ? (
            <IntegrationsView
              onVaultOpen={() => setVaultOpen(true)}
              vaultUnlocked={vaultState === 'unlocked'}
              onVaultChanged={() => void refreshVault()}
            />
          ) : (
            <SettingsView onBreakerReset={() => void refreshVault()} onVaultOpen={() => setVaultOpen(true)} />
          )}
        </div>

        {area === 'chat' && !compareOn && streamError && hasMessages && (
          <p role="alert" className="border-t border-line bg-surface px-4 py-2 text-center text-xs text-fault-text">
            {streamError}
          </p>
        )}

        {/* the docked composer only appears once a conversation exists —
            the empty chat state IS the hero composer (everything is the chatbot) */}
        {area === 'chat' && !compareOn && hasMessages && (
          <Composer streaming={streaming} onSend={send} onStop={stop} />
        )}
      </main>

      <VaultPanel
        open={vaultOpen}
        onOpenChange={setVaultOpen}
        health={health}
        onVaultChanged={() => {
          void refreshVault()
          onHealth()
        }}
      />
      {/* Library → Projects focus pass-through lives in state (openProjectId) */}
    </div>
  )
}
