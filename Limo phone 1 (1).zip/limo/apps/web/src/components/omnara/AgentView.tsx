'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { AlertTriangle, ArrowUp, Bot, CheckCircle2, CircleDashed, Clock, Hammer, Loader2, Palette, Play, Repeat, Search, Sparkles, Square, XCircle, Zap } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ModelPicker } from './ModelPicker'
import { useI18n } from '@/lib/i18n'
import { api, ApiError, type AgentApprovalInfo, type AgentRoutineInfo, type AgentRoutineRunInfo, type AgentTaskInfo, type AgentStepInfo, type ProjectInfo } from '@/lib/api'
import { MarkdownText } from '@/components/limo/Markdown'
import { streamAgentEvents } from '@/lib/agentStream'
import { cn } from '@/lib/utils'
import type { TaskModeId } from '@/lib/nav'

/**
 * The agent console (PLAN.md §6 stage 3 · LIMO v3 HYPERBRAIN): launch
 * multi-step tasks in a strategy mode, optionally bound to a sandboxed project
 * workspace, watch the planner→executor→critic loop live with the specialized
 * agent per step, decide dangerous actions, and manage the scheduled routines
 * with the vault lock policy. Everything shown here is the server's recorded
 * state — no client-side invention.
 */

const CATEGORY_AR: Record<string, string> = {
  payment: 'دفع مالي',
  deletion: 'حذف بيانات',
  send: 'إرسال للخارج',
  settings_change: 'تغيير إعدادات',
  software_install: 'تشغيل/تثبيت برامج',
  secret_share: 'مشاركة أسرار',
}

/** mode pills — icon + i18n key (the identity of the v5 agent hero) */
const MODES: Array<{ id: TaskModeId; icon: typeof Zap; labelKey: 'modeAuto' | 'modeResearch' | 'modeBuild' | 'modeCreative' | 'modeSuper' }> = [
  { id: 'auto', icon: Sparkles, labelKey: 'modeAuto' },
  { id: 'research', icon: Search, labelKey: 'modeResearch' },
  { id: 'build', icon: Hammer, labelKey: 'modeBuild' },
  { id: 'creative', icon: Palette, labelKey: 'modeCreative' },
  { id: 'super', icon: Zap, labelKey: 'modeSuper' },
]

const ROLE_LABEL_KEYS: Record<string, 'roleOrchestrator' | 'roleResearcher' | 'roleEngineer' | 'roleFrontend' | 'roleBackend' | 'roleCreative' | 'roleSecurity' | 'roleQa' | 'roleWriter'> = {
  orchestrator: 'roleOrchestrator',
  researcher: 'roleResearcher',
  engineer: 'roleEngineer',
  frontend: 'roleFrontend',
  backend: 'roleBackend',
  creative: 'roleCreative',
  security: 'roleSecurity',
  qa: 'roleQa',
  writer: 'roleWriter',
}

const EVENT_ICON: Record<string, React.ReactNode> = {
  task_started: <Play size={13} className="text-dim" />,
  plan_ready: <CircleDashed size={13} className="text-signal-text dark:text-signal" />,
  model_selected: <Sparkles size={13} className="text-signal-text dark:text-signal" />,
  step_started: <Clock size={13} className="text-dim" />,
  tool_call: <Bot size={13} className="text-dim" />,
  tool_result: <Bot size={13} className="text-signal-text dark:text-signal" />,
  approval_required: <AlertTriangle size={13} className="text-rust-text" />,
  approval_decided: <CheckCircle2 size={13} className="text-dim" />,
  step_done: <CheckCircle2 size={13} className="text-signal-text dark:text-signal" />,
  step_failed: <XCircle size={13} className="text-fault-text" />,
  step_skipped: <Square size={13} className="text-dim" />,
  recovery_retry: <Repeat size={13} className="text-rust-text" />,
  task_completed: <CheckCircle2 size={13} className="text-signal-text dark:text-signal" />,
  task_failed: <XCircle size={13} className="text-fault-text" />,
  task_cancelled: <Square size={13} className="text-fault-text" />,
}

const ACTIVE = new Set(['queued', 'planning', 'running', 'awaiting_approval'])

export function AgentView({ onAuthLost, focusTaskId, model: sharedModel, onModelChange, onNeedVault }: { onAuthLost: () => void; focusTaskId?: number | null; model?: string | null; onModelChange?: (id: string) => void; onNeedVault?: () => void }) {
  const { t } = useI18n()
  const [goal, setGoal] = useState('')
  const [model, setModel] = useState<string | null>(null)
  const [mode, setMode] = useState<TaskModeId>('auto')
  const [projectId, setProjectId] = useState<string | null>(null)
  const [projects, setProjects] = useState<ProjectInfo[] | null>(null)
  const [launching, setLaunching] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [tasks, setTasks] = useState<AgentTaskInfo[]>([])
  const [activeId, setActiveId] = useState<number | null>(null)
  const [detail, setDetail] = useState<{ task: AgentTaskInfo; steps: AgentStepInfo[]; events: Array<{ id: number; ts: string; kind: string; data: string | null }> } | null>(null)
  const [approvals, setApprovals] = useState<AgentApprovalInfo[]>([])
  const [routines, setRoutines] = useState<AgentRoutineInfo[]>([])
  const [runsFor, setRunsFor] = useState<number | null>(null)
  const [runs, setRuns] = useState<AgentRoutineRunInfo[]>([])
  const abortRef = useRef<AbortController | null>(null)
  const goalRef = useRef<HTMLTextAreaElement>(null)
  // last-known task status (for the bounded poll below — LIMO #25)
  const statusRef = useRef<string>('queued')

  // time-aware hero greeting — same family as the home hero (one voice)
  const greeting = useMemo(() => {
    const h = new Date().getHours()
    if (h >= 5 && h < 12) return t.heroGreetingMorning
    if (h >= 12 && h < 17) return t.heroGreetingAfternoon
    if (h >= 17 && h < 23) return t.heroGreetingEvening
    return t.heroGreetingNight
  }, [t])

  // auto-grow the hero textarea
  useEffect(() => {
    const el = goalRef.current
    if (!el) return
    el.style.height = '0px'
    el.style.height = `${Math.min(el.scrollHeight, 220)}px`
  }, [goal])

  const guard = useCallback(
    (e: unknown) => {
      if (e instanceof ApiError && e.status === 401) onAuthLost()
      else setError(e instanceof Error ? e.message : String(e))
    },
    [onAuthLost],
  )

  const loadLists = useCallback(async () => {
    try {
      const [a, r] = await Promise.all([api.agentApprovals('pending'), api.agentRoutines()])
      setApprovals(a.approvals)
      setRoutines(r.routines)
    } catch (e) {
      guard(e)
    }
  }, [guard])

  const loadTasks = useCallback(async () => {
    try {
      setTasks((await api.agentTasks()).tasks)
    } catch (e) {
      guard(e)
    }
  }, [guard])

  const loadDetail = useCallback(
    async (id: number) => {
      try {
        const d = await api.agentTask(id)
        setDetail(d)
        statusRef.current = d.task.status
      } catch (e) {
        guard(e)
      }
    },
    [guard],
  )

  useEffect(() => {
    void loadLists()
    void loadTasks()
    void api
      .projects()
      .then((r) => setProjects(r.projects))
      .catch(() => setProjects([]))
  }, [loadLists, loadTasks])

  // other screens (Home / Workshop / Studio / Workflows) can focus a task
  useEffect(() => {
    if (typeof focusTaskId === 'number') setActiveId(focusTaskId)
  }, [focusTaskId])

  // Home dispatches the central prompt to the agent composer via a DOM event
  useEffect(() => {
    const onPrefill = (e: Event) => {
      const detail = (e as CustomEvent<string>).detail
      if (typeof detail === 'string' && detail.length > 0) setGoal(detail)
    }
    window.addEventListener('limo:agent-prefill', onPrefill)
    return () => window.removeEventListener('limo:agent-prefill', onPrefill)
  }, [])

  // shared model from the shell (single source of truth across areas)
  useEffect(() => {
    if (sharedModel) setModel(sharedModel)
  }, [sharedModel])

  // live follow of the selected task: SSE pushes → refetch the recorded state
  useEffect(() => {
    if (activeId === null) return
    void loadDetail(activeId)
    const controller = new AbortController()
    abortRef.current = controller
    let lastFetch = 0
    streamAgentEvents(activeId, {
      signal: controller.signal,
      onEvent: () => {
        const now = Date.now()
        if (now - lastFetch < 400) return // throttle bursts
        lastFetch = now
        void loadDetail(activeId)
        void loadLists()
      },
    }).catch(() => undefined)
    // LIMO #25 — a FAST task (local/mock model) can complete between the POST
    // and the SSE subscription, so every event is missed and the recorded
    // state would freeze mid-flight. A bounded poll while the status is
    // active guarantees the final report lands. Honest: it reads the real
    // recorded state, never invents it.
    let polls = 0
    const poll = setInterval(() => {
      polls++
      if (polls > 120 || (!ACTIVE.has(statusRef.current) && polls > 2)) {
        clearInterval(poll)
        return
      }
      void loadDetail(activeId)
    }, 1000)
    return () => {
      controller.abort()
      abortRef.current = null
      clearInterval(poll)
    }
  }, [activeId, loadDetail, loadLists])

  const launch = async () => {
    setError(null)
    if (goal.trim().length < 4) return setError(t.agentNeedsGoal)
    if (!model) return setError(t.agentNeedsModel)
    setLaunching(true)
    try {
      const { task } = await api.createAgentTask(goal.trim(), model, { mode, ...(projectId ? { projectId } : {}) })
      setGoal('')
      setActiveId(task.id)
      await loadTasks()
    } catch (e) {
      guard(e)
    } finally {
      setLaunching(false)
    }
  }

  const cancel = async () => {
    if (activeId === null) return
    try {
      await api.cancelAgentTask(activeId)
      void loadDetail(activeId)
      void loadTasks()
    } catch (e) {
      guard(e)
    }
  }

  const decide = async (id: number, decision: 'approve' | 'reject') => {
    try {
      await api.decideApproval(id, decision)
      void loadLists()
      if (activeId !== null) void loadDetail(activeId)
    } catch (e) {
      guard(e)
    }
  }

  const runNow = async (id: number) => {
    try {
      await api.runRoutine(id)
      await loadLists()
      setRunsFor(id)
    } catch (e) {
      guard(e)
    }
  }

  useEffect(() => {
    if (runsFor === null) return
    void api
      .routineRuns(runsFor)
      .then((r) => setRuns(r.runs))
      .catch(guard)
  }, [runsFor, guard])

  const task = detail?.task
  // LIMO #25 — a chat-classified task carries {kind:'chat', reply} in its report:
  // the reply is rendered as a real conversational bubble (Markdown), not a
  // task card with step/tool noise.
  const report = task?.report ? (JSON.parse(task.report) as { summary?: string; verdict?: string; kind?: string; reply?: string }) : null
  const chatReply = report?.kind === 'chat' && typeof report.reply === 'string' && report.reply.length > 0 ? report.reply : null

  return (
    <div className="h-full overflow-y-auto bg-canvas px-4 py-5 sm:px-6">
      <div className="mx-auto flex max-w-4xl flex-col gap-5">
        {/* THE AGENT HERO — the chat-first composer (same voice as the home hero):
            greeting + big soft composer + mode pills + model + project + send */}
        <section className="flex flex-col items-center gap-5 pt-2 md:pt-6">
          <div className="limo-rise flex flex-col items-center gap-2 text-center">
            <span className="flex size-12 items-center justify-center rounded-full border border-line bg-surface text-signal-text dark:text-signal">
              <Bot size={21} aria-hidden="true" />
            </span>
            <h1 className="limo-display text-2xl font-bold md:text-3xl">{greeting}</h1>
            <p className="max-w-lg text-xs leading-relaxed text-dim">{t.agentHeroSub}</p>
          </div>

          <div className="limo-rise-2 w-full">
            <div className="limo-soft p-3 shadow-lg shadow-ink/5 dark:shadow-black/40">
              <textarea
                ref={goalRef}
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                placeholder={t.agentGoalPh}
                rows={2}
                dir="auto"
                aria-label={t.agentTitle}
                className="max-h-[220px] w-full resize-none bg-transparent px-3 pb-2 pt-1.5 text-base leading-relaxed outline-none placeholder:text-dim"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault()
                    void launch()
                  }
                }}
              />
              <div className="flex flex-wrap items-center gap-1.5 px-1 pb-0.5 pt-1">
                {/* mode pills — what this dispatch will be */}
                <div className="flex h-9 items-center gap-0.5 rounded-full border border-line bg-canvas p-1" role="group" aria-label={t.modeLabel}>
                  {MODES.map(({ id: m, icon: Icon, labelKey }) => (
                    <button
                      key={m}
                      type="button"
                      aria-pressed={mode === m}
                      title={t[labelKey]}
                      onClick={() => {
                        setMode(m)
                        // SUPER owns the model choice (routing layer) — preselect AUTO
                        if (m === 'super' && model !== 'auto') setModel('auto')
                      }}
                      className={cn(
                        'flex h-7 items-center gap-1.5 rounded-full px-2.5 text-xs transition-colors',
                        mode === m ? 'bg-signal font-semibold text-primary-foreground' : 'text-dim hover:text-body',
                      )}
                    >
                      <Icon size={12} aria-hidden="true" />
                      <span className="hidden sm:inline">{t[labelKey]}</span>
                    </button>
                  ))}
                </div>

                <ModelPicker
                  value={model}
                  onChange={(id) => {
                    // 'auto' is an agent-composer-only concept — it never leaks
                    // into the shared shell model (the chat gateway needs a real id)
                    setModel(id)
                    if (id !== 'auto') onModelChange?.(id)
                  }}
                  onNeedVault={() => onNeedVault?.()}
                  allowAuto
                />

                <label className="flex h-9 min-w-36 items-center gap-2 rounded-full border border-line bg-canvas px-3 text-xs">
                  <span className="shrink-0 text-dim">{t.bindProject}</span>
                  <select
                    value={projectId ?? ''}
                    onChange={(e) => setProjectId(e.target.value || null)}
                    className="min-w-0 flex-1 bg-transparent text-body outline-none"
                  >
                    <option value="">{t.noProject}</option>
                    {(projects ?? []).map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </label>

                {/* circular send */}
                <button
                  type="button"
                  onClick={() => void launch()}
                  disabled={launching}
                  aria-label={t.agentLaunch}
                  title={t.agentLaunch}
                  className={cn(
                    'ms-auto flex size-10 shrink-0 items-center justify-center rounded-full bg-signal text-primary-foreground transition-opacity',
                    'border border-ink dark:border-0',
                    launching && 'opacity-40',
                  )}
                >
                  {launching ? <Loader2 size={16} className="animate-spin" /> : <ArrowUp size={17} />}
                </button>
              </div>
            </div>

            {mode === 'super' && (
              <p className="mt-2.5 rounded-2xl border border-signal-text/30 bg-signal/5 px-4 py-2 text-xs leading-relaxed text-dim">
                <Zap size={11} className="me-1 inline text-signal-text dark:text-signal" aria-hidden="true" />
                {t.modeSuperHint}
              </p>
            )}
            {error && (
              <p role="alert" className="mt-2.5 rounded-2xl border border-fault-text/40 bg-fault/5 px-4 py-2 text-xs text-fault-text">
                {error}
              </p>
            )}
          </div>

          {/* suggestion chips — prefill only, no fake actions */}
          <div className="limo-rise-3 w-full">
            <div className="flex flex-wrap items-center justify-center gap-2">
              {[t.agentChip1, t.agentChip2, t.agentChip3].map((label) => (
                <button
                  key={label}
                  type="button"
                  onClick={() => {
                    setGoal(label)
                    goalRef.current?.focus()
                  }}
                  className="flex h-9 max-w-full items-center gap-2 rounded-full border border-line bg-surface px-4 text-xs text-dim transition-colors hover:border-border-strong hover:bg-canvas hover:text-body"
                >
                  <Sparkles size={12} className="shrink-0" aria-hidden="true" />
                  <span className="truncate">{label}</span>
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* pending approvals */}
        <section className="rounded-lg border border-rust/40 bg-surface p-4">
          <h3 className="flex items-center gap-2 font-display text-base font-bold">
            <AlertTriangle size={15} className="text-rust-text" />
            {t.agentApprovals}
          </h3>
          {approvals.length === 0 ? (
            <p className="mt-2 text-xs text-dim">{t.agentNoApprovals}</p>
          ) : (
            <ul className="mt-3 flex flex-col gap-2">
              {approvals.map((a) => (
                <li key={a.id} className="rounded-2xl border border-input bg-canvas p-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded-sm bg-rust-fill px-2 py-0.5 text-xs font-semibold text-stone">{CATEGORY_AR[a.category] ?? a.category}</span>
                    <span className="font-mono text-[11px] text-dim" dir="ltr">
                      #{a.id}
                    </span>
                    <span className="text-[11px] text-dim">{t.approvalTimeoutNote}</span>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed">{a.summary}</p>
                  <div className="mt-2 flex gap-2">
                    <Button size="sm" onClick={() => void decide(a.id, 'approve')} className="h-8 rounded-sm bg-signal px-3 text-xs font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0">
                      <CheckCircle2 size={13} />
                      {t.approve}
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => void decide(a.id, 'reject')} className="h-8 rounded-sm border-input bg-canvas px-3 text-xs hover:text-fault-text">
                      <XCircle size={13} />
                      {t.reject}
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* live / selected task — rendered AS A CONVERSATION: the owner's brief
            is the user bubble, the agent's production line is the reply */}
        {task && (
          <section className="flex flex-col gap-4">
            {/* the brief — user bubble */}
            <div className="flex justify-end">
              <div className="max-w-[85%] rounded-3xl rounded-ee-lg border border-line bg-surface px-4 py-2.5 text-sm leading-relaxed">
                {task.goal}
              </div>
            </div>

            {/* the agent's reply */}
            <div className="flex items-start gap-3">
              <span className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-full border border-line bg-surface text-signal-text dark:text-signal">
                <Bot size={17} aria-hidden="true" />
              </span>
              <div className="min-w-0 flex-1 rounded-3xl rounded-es-lg border border-line bg-surface p-4">
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className={cn(
                      'rounded-full border px-2.5 py-0.5 font-mono text-[11px]',
                      task.status === 'completed' && 'border-signal-text/50 text-signal-text dark:text-signal',
                      task.status === 'failed' && 'border-fault-text/50 text-fault-text',
                      ACTIVE.has(task.status) && 'border-input text-dim',
                      task.status === 'cancelled' && 'border-input text-dim',
                    )}
                    dir="ltr"
                  >
                    {task.status}
                  </span>
                  <span className="font-mono text-[11px] text-dim" dir="ltr">
                    {task.model}
                  </span>
                  {ACTIVE.has(task.status) && (
                    <Button size="sm" variant="outline" onClick={() => void cancel()} className="ms-auto h-7 rounded-full border-input bg-canvas px-3 text-[11px] hover:text-fault-text">
                      {t.agentCancel}
                    </Button>
                  )}
                </div>

                {chatReply ? (
                  <div className="mt-3 text-sm leading-relaxed">
                    <MarkdownText text={chatReply} />
                  </div>
                ) : (
                  <>
                    {report?.summary && (
                      <p className="mt-3 rounded-2xl border border-line bg-canvas px-3.5 py-2.5 text-sm leading-relaxed">{report.summary}</p>
                    )}

                    {/* the production line */}
                    <ol className="mt-3 flex flex-col gap-1.5">
                      {detail.steps.map((s) => (
                    <li key={s.id} className="flex items-start gap-2 rounded-2xl border border-line bg-canvas px-3 py-2">
                      <span className="mt-0.5 shrink-0">
                        {s.status === 'done' ? <CheckCircle2 size={14} className="text-signal-text dark:text-signal" /> : s.status === 'failed' ? <XCircle size={14} className="text-fault-text" /> : s.status === 'running' ? <Loader2 size={14} className="animate-spin text-dim" /> : <CircleDashed size={14} className="text-dim" />}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm">
                          {s.idx}. {s.title}
                          {s.role && ROLE_LABEL_KEYS[s.role] && (
                            <span className="ms-1.5 rounded-full border border-line px-2 py-0.5 text-[10px] text-dim">{t[ROLE_LABEL_KEYS[s.role]]}</span>
                          )}
                          <span className="ms-2 font-mono text-[10px] text-dim" dir="ltr">
                            {s.tool}
                            {s.attempts > 1 ? ` ×${s.attempts}` : ''}
                          </span>
                        </p>
                        {s.result && (
                          <p className="mt-0.5 truncate font-mono text-[10px] text-dim" dir="ltr" title={s.result}>
                            {s.result}
                          </p>
                        )}
                        {s.critic && (
                          <p className="mt-0.5 text-[11px] text-dim">
                            {t.agentTitle.includes('Agent') ? 'critic' : 'الناقد'}: {(JSON.parse(s.critic) as { reason: string }).reason}
                          </p>
                        )}
                      </div>
                    </li>
                  ))}
                    </ol>

                    <details className="mt-3">
                      <summary className="cursor-pointer font-mono text-[11px] text-dim" dir="ltr">
                        events ({detail.events.length})
                      </summary>
                      <ul className="mt-2 flex max-h-56 flex-col gap-1 overflow-y-auto">
                        {detail.events.map((e) => (
                          <li key={e.id} className="flex items-center gap-2 font-mono text-[10px] text-dim" dir="ltr">
                            {EVENT_ICON[e.kind] ?? <CircleDashed size={12} />}
                            <span>{e.kind}</span>
                            {e.kind === 'model_selected' && e.data && (
                              <span className="truncate text-signal-text dark:text-signal" title={e.data}>
                                {(() => {
                                  try {
                                    const d = JSON.parse(e.data) as { purpose?: string; model?: string }
                                    return `${d.purpose ?? ''} → ${d.model ?? ''}`
                                  } catch {
                                    return ''
                                  }
                                })()}
                              </span>
                            )}
                            <span className="ms-auto shrink-0 text-dim/70">{e.ts.slice(11, 19)}</span>
                          </li>
                        ))}
                      </ul>
                    </details>
                  </>
                )}
              </div>
            </div>
          </section>
        )}

        {/* past tasks */}
        <section className="rounded-lg border border-line bg-surface p-4">
          <h3 className="font-display text-base font-bold">{t.agentTasks}</h3>
          {tasks.length === 0 ? (
            <p className="mt-2 text-xs text-dim">{t.agentNoTasks}</p>
          ) : (
            <ul className="mt-2 flex flex-col gap-1.5">
              {tasks.slice(0, 12).map((tk) => (
                <li key={tk.id}>
                  <button
                    type="button"
                    onClick={() => setActiveId(tk.id)}
                    className={cn(
                      'flex w-full items-center gap-2.5 rounded-2xl border border-transparent px-3 py-2.5 text-start transition-colors hover:border-line hover:bg-canvas',
                      activeId === tk.id && 'border-line bg-canvas',
                    )}
                  >
                    <span className="shrink-0">
                      {tk.status === 'completed' ? <CheckCircle2 size={14} className="text-signal-text dark:text-signal" /> : tk.status === 'failed' ? <XCircle size={14} className="text-fault-text" /> : <CircleDashed size={14} className="text-dim" />}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-sm">{tk.goal}</span>
                    {tk.report?.includes('"kind":"chat"') ? (
                      <span className="shrink-0 rounded-full border border-line px-2 py-0.5 text-[10px] text-dim">محادثة</span>
                    ) : null}
                    <span className="shrink-0 font-mono text-[10px] text-dim" dir="ltr">
                      {tk.model.split('/')[0]} · {tk.status}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* routines */}
        <section className="rounded-lg border border-line bg-surface p-4">
          <h3 className="font-display text-base font-bold">{t.agentRoutinesTitle}</h3>
          <p className="mt-1 text-xs leading-relaxed text-dim">{t.agentRoutinesSub}</p>
          <RoutineForm onCreated={loadLists} onError={guard} defaultModel={model} />
          {routines.length === 0 ? (
            <p className="mt-3 text-xs text-dim">{t.routineNo}</p>
          ) : (
            <ul className="mt-3 flex flex-col gap-2">
              {routines.map((r) => (
                <li key={r.id} className="rounded-md border border-line bg-canvas p-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-sm font-semibold" dir="ltr">
                      {r.name}
                    </span>
                    <span className={cn('rounded-sm border px-1.5 py-0.5 text-[10px]', r.enabled ? 'border-signal-text/50 text-signal-text dark:text-signal' : 'border-input text-dim')}>{r.enabled ? t.routineEnabled : '⏸'}</span>
                    {r.allow_downgrade === 1 && <span className="rounded-sm border border-rust/50 px-1.5 py-0.5 text-[10px] text-rust-text">downgrade</span>}
                    {r.catch_up_on_unlock === 1 && <span className="rounded-sm border border-input px-1.5 py-0.5 text-[10px] text-dim">catch-up</span>}
                  </div>
                  <p className="mt-1.5 text-xs leading-relaxed text-dim">{r.prompt}</p>
                  <p className="mt-1 font-mono text-[10px] text-dim" dir="ltr">
                    {r.model} · every {Math.round(r.interval_sec / 60)}m
                  </p>
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    <Button size="sm" variant="outline" onClick={() => void runNow(r.id)} className="h-7 rounded-sm border-input bg-surface px-2 text-[11px]">
                      <Play size={11} />
                      {t.routineRunNow}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setRunsFor(runsFor === r.id ? null : r.id)} className="h-7 rounded-sm px-2 text-[11px] text-dim hover:text-body">
                      {t.routineRuns}
                    </Button>
                    <span className="ms-auto font-mono text-[10px] text-dim" dir="ltr">
                      {t.routineNext}: {new Date(r.next_run_at).toLocaleTimeString('en-GB')}
                    </span>
                  </div>
                  {runsFor === r.id && (
                    <ul className="mt-2 flex flex-col gap-1 border-t border-line pt-2">
                      {runs.length === 0 && <li className="text-[11px] text-dim">—</li>}
                      {runs.map((run) => (
                        <li key={run.id} className="flex flex-wrap items-center gap-2 text-[11px]">
                          <span
                            className={cn(
                              'rounded-sm border px-1.5 py-0.5',
                              run.status === 'ok' && 'border-signal-text/50 text-signal-text dark:text-signal',
                              run.status === 'skipped_vault_locked' && 'border-rust/50 text-rust-text',
                              run.status === 'degraded_vault_locked' && 'border-rust/50 text-rust-text',
                              run.status === 'error' && 'border-fault-text/50 text-fault-text',
                            )}
                          >
                            {run.status === 'ok' ? t.runOk : run.status === 'skipped_vault_locked' ? t.runSkippedVault : run.status === 'degraded_vault_locked' ? t.runDegraded : t.runError}
                          </span>
                          <span className="text-dim" dir="ltr">
                            {run.ts.slice(11, 19)}
                          </span>
                          {run.detail && <span className="text-dim">{run.detail}</span>}
                        </li>
                      ))}
                    </ul>
                  )}
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  )
}

function RoutineForm({ onCreated, onError, defaultModel }: { onCreated: () => Promise<void>; onError: (e: unknown) => void; defaultModel: string | null }) {
  const { t } = useI18n()
  const [name, setName] = useState('')
  const [prompt, setPrompt] = useState('')
  const [model, setModel] = useState(defaultModel ?? '')
  const [intervalSec, setIntervalSec] = useState(3600)
  const [allowDowngrade, setAllowDowngrade] = useState(false) // v2.2 #5: default OFF
  const [catchUp, setCatchUp] = useState(false)
  const [busy, setBusy] = useState(false)

  const submit = async () => {
    setBusy(true)
    try {
      await api.createRoutine({ name: name.trim(), prompt: prompt.trim(), model, interval_sec: intervalSec, allow_downgrade: allowDowngrade, catch_up_on_unlock: catchUp })
      setName('')
      setPrompt('')
      await onCreated()
    } catch (e) {
      onError(e)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="mt-3 flex flex-col gap-2 rounded-md border border-line bg-canvas p-3">
      <div className="grid gap-2 sm:grid-cols-2">
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={t.routineName} aria-label={t.routineName} dir="ltr" className="h-8 rounded-sm border-input bg-surface font-mono text-xs" />
        <Input value={model} onChange={(e) => setModel(e.target.value)} placeholder={t.routineModel} aria-label={t.routineModel} dir="ltr" className="h-8 rounded-sm border-input bg-surface font-mono text-xs" />
      </div>
      <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder={t.routinePrompt} rows={2} dir="auto" aria-label={t.routinePrompt} className="w-full resize-none rounded-sm border border-input bg-surface px-3 py-2 text-xs leading-relaxed outline-none placeholder:text-dim focus:border-signal-text dark:focus:border-signal" />
      <div className="flex flex-wrap items-center gap-3">
        <label className="flex items-center gap-1.5 text-xs text-dim" dir="ltr">
          {t.routineEvery}
          <Input type="number" min={60} value={intervalSec} onChange={(e) => setIntervalSec(Number(e.target.value) || 3600)} className="h-8 w-24 rounded-sm border-input bg-surface font-mono text-xs" dir="ltr" />
        </label>
        <label className="flex items-center gap-1.5 text-xs text-dim">
          <input type="checkbox" checked={allowDowngrade} onChange={(e) => setAllowDowngrade(e.target.checked)} className="size-3.5 accent-[#E8A63C]" />
          {t.routineAllowDowngrade}
        </label>
        <label className="flex items-center gap-1.5 text-xs text-dim">
          <input type="checkbox" checked={catchUp} onChange={(e) => setCatchUp(e.target.checked)} className="size-3.5 accent-[#E8A63C]" />
          {t.routineCatchUp}
        </label>
        <Button size="sm" disabled={busy || name.trim().length < 2 || prompt.trim().length < 4 || !model} onClick={() => void submit()} className="ms-auto h-8 rounded-sm bg-signal px-3 text-xs font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0">
          {busy ? <Loader2 size={12} className="animate-spin" /> : <Repeat size={12} />}
          {t.routineAdd}
        </Button>
      </div>
    </div>
  )
}
