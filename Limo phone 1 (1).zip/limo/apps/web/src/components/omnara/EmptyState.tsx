'use client'

import { Button } from '@/components/ui/button'
import { Mark } from './Mark'
import { useI18n } from '@/lib/i18n'
import { api, type HealthResponse } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * Empty chat state — REAL provider readiness from /api/health (no fake data):
 * a dot per provider: signal = ready, dim = keyless+unconfigured or needs key,
 * fault = last recorded error.
 */
export function EmptyState({ health, onOpenVault }: { health: HealthResponse | null; onOpenVault: () => void }) {
  const { t } = useI18n()
  const loaded = health !== null
  const unconfigured = (health?.providers ?? []).filter((p) => !p.configured)

  return (
    <div className="flex h-full flex-col items-center justify-center px-6 text-center">
      <Mark className="h-16 w-auto text-dim" />
      <h2 className="mt-8 font-display text-3xl font-bold">{t.emptyTitle}</h2>
      <p className="mt-3 max-w-md text-s text-dim leading-relaxed">{t.emptySub}</p>

      <div className="mt-8 flex flex-wrap items-center justify-center gap-2" aria-label={t.statusProviders}>
        {!loaded && <span className="inline-block h-4 w-2 animate-pulse bg-signal" aria-hidden="true" />}
        {loaded &&
          health?.providers.map((p) => (
            <span
              key={p.id}
              title={p.lastError ?? (p.configured ? t.availableNow : t.requiresKey)}
              className={cn(
                'inline-flex items-center gap-2 rounded-md border border-line bg-surface px-3 py-1.5 text-xs',
                p.lastError ? 'text-fault-text' : p.configured ? 'text-body' : 'text-dim',
              )}
            >
              <span
                aria-hidden="true"
                className={cn(
                  'inline-block size-1.5 rounded-full',
                  p.lastError ? 'bg-fault' : p.configured ? 'bg-signal' : 'bg-dim',
                )}
              />
              <span dir="ltr" className="font-mono">{p.label}</span>
            </span>
          ))}
      </div>

      {loaded && unconfigured.length > 0 && (
        <Button
          variant="outline"
          onClick={onOpenVault}
          className="mt-6 rounded-md border-input bg-surface text-signal-text hover:bg-surface"
        >
          {t.openVault}
        </Button>
      )}
    </div>
  )
}
