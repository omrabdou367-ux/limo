'use client'

import { useEffect, useRef } from 'react'
import { Mark } from './Mark'
import { useI18n } from '@/lib/i18n'
import { renderMessage } from '@/lib/markdown'
import { cn } from '@/lib/utils'

export interface UiMessage {
  id: number | string
  role: 'user' | 'assistant'
  content: string
  model?: string | null
  createdAt?: string
}

/**
 * Chat transcript — soft v4 treatment:
 *  - user entries: soft rounded bubbles (28px) aligned to the inline end
 *  - assistant entries: full-width clean rows with a mono header (model ·
 *    time). Streaming shows the live block cursor.
 */
export function MessageList({ messages, streaming, streamingModel }: {
  messages: UiMessage[]
  streaming: boolean
  streamingModel?: string | null
}) {
  const scrollRef = useRef<HTMLDivElement>(null)
  const pinnedRef = useRef(true)

  useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const onScroll = () => {
      pinnedRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120
    }
    el.addEventListener('scroll', onScroll, { passive: true })
    return () => el.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    const el = scrollRef.current
    if (el && pinnedRef.current) el.scrollTop = el.scrollHeight
  }, [messages, streaming])

  const { t } = useI18n()

  return (
    <div ref={scrollRef} className="h-full overflow-y-auto">
      <div className="mx-auto flex max-w-3xl flex-col gap-5 px-5 py-8">
        {messages.map((m, i) => {
          const isLastAssistant = m.role === 'assistant' && i === messages.length - 1
          if (m.role === 'user') {
            return (
              <div key={m.id} className="flex flex-col items-end">
                <div className="max-w-[78%] rounded-[24px] rounded-ee-lg border border-line bg-surface px-5 py-3.5 text-base leading-relaxed whitespace-pre-wrap break-words">
                  {m.content}
                </div>
                <span className="mt-1.5 font-mono text-xs text-dim">{t.you}</span>
              </div>
            )
          }
          return (
            <article key={m.id} className="ps-1">
              <header className="mb-1.5 flex items-center gap-3 font-mono text-xs text-dim" dir="ltr">
                {m.model && <span className="truncate">{m.model}</span>}
                {m.createdAt && <time>{new Date(m.createdAt).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</time>}
              </header>
              <div className="text-base leading-[1.9]">{renderMessage(m.content)}</div>
            </article>
          )
        })}

        {streaming && (
          <article className="ps-1">
            <header className="mb-1.5 flex items-center gap-3 font-mono text-xs text-dim" dir="ltr">
              {streamingModel && <span className="truncate">{streamingModel}</span>}
              <span className="inline-block h-3.5 w-2 animate-pulse bg-signal" aria-hidden="true" />
            </header>
          </article>
        )}

        {messages.length === 0 && !streaming && (
          <div className="flex flex-col items-center py-16 text-dim">
            <Mark className="h-10 w-auto opacity-60" />
          </div>
        )}
      </div>
    </div>
  )
}
