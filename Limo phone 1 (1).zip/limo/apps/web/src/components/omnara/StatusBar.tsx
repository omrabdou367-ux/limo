'use client'

import { useI18n } from '@/lib/i18n'
import type { HealthResponse } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * Mono status strip — the control-room footer. REAL values only:
 * vault state, configured-provider count, build version.
 * Mixed AR/LAT rides the F1 font stack (mono -> Readex fallback).
 */
export function StatusBar({
  health,
  vaultState,
}: {
  health: HealthResponse | null
  vaultState: 'uninitialized' | 'locked' | 'unlocked' | null
}) {
  const { t } = useI18n()
  const state = vaultState ?? health?.vault.state ?? 'uninitialized'
  const providers = health?.providers ?? []
  const ready = providers.filter((p) => p.configured).length

  return (
    <div className="rounded-md border border-line bg-canvas px-3 py-2 font-mono text-[11px] leading-relaxed text-dim" dir="ltr">
      <div className="flex items-center justify-between gap-2">
        <span className="flex items-center gap-1.5">
          <span
            aria-hidden="true"
            className={cn('inline-block size-1.5 rounded-full', state === 'unlocked' ? 'bg-signal' : state === 'locked' ? 'bg-rust' : 'bg-dim')}
          />
          VAULT: {state === 'unlocked' ? t.vaultUnlocked : state === 'locked' ? t.vaultLocked : t.vaultUninitialized}
        </span>
        <span>
          {ready}/{providers.length} {t.statusProviders}
        </span>
      </div>
      <div className="mt-1 flex items-center justify-between">
        <span>LIMO AGENT v{health?.version ?? '0.1.0'}</span>
        <span className="text-dim/70">LOCAL · $0</span>
      </div>
    </div>
  )
}
