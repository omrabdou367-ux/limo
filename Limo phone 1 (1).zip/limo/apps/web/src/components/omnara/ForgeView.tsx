'use client'

import { useCallback, useEffect, useState } from 'react'
import {
  AlertTriangle, CheckCircle2, CircleDashed, Clock, Code2, Cpu, FileDiff,
  GitBranch, Hammer, History, Lightbulb, Loader2, Map as MapIcon, Play,
  RotateCcw, ShieldCheck, XCircle,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ModelPicker } from './ModelPicker'
import { useI18n } from '@/lib/i18n'
import { api, ApiError, type ForgeChangeInfo, type ForgeEventInfo, type ForgeMapInfo, type ForgeProposalInfo, type ForgeStatusInfo } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * Reality Forge screen (RF spec §12 — vertical slice): the owner's control
 * room over the self-modification engine. Everything rendered is the
 * server's recorded state — the map, the changes, the diffs, the audit
 * trail; the client invents nothing. The autonomy level and every apply /
 * reject / rollback decision are explicit owner actions.
 */

const STATUS_STYLE: Record<string, string> = {
  awaiting_approval: 'border-rust/60 text-rust-text bg-rust/5',
  applied: 'border-signal-text/50 text-signal-text dark:text-signal',
  rolled_back: 'border-signal-text/40 text-signal-text dark:text-signal',
  failed: 'border-fault-text/50 text-fault-text',
  rejected: 'border-input text-dim',
  cancelled: 'border-line text-dim bg-canvas',
}
const ACTIVE_STATUS = new Set(['analyzing', 'planned', 'implementing', 'testing', 'reviewing'])

const STATUS_AR: Record<string, string> = {
  analyzing: 'يفحص', planned: 'مخطط', implementing: 'ينفّذ في الصندوق', testing: 'يختبر',
  reviewing: 'مراجعة أمنية', awaiting_approval: 'ينتظر موافقتك', applied: 'مطبَّق',
  rejected: 'مرفوض', rolled_back: 'مُستَرجَع', failed: 'فشل', cancelled: 'ملغى',
}
const COMPLEXITY_AR: Record<string, string> = { low: 'منخفض', medium: 'متوسط', high: 'عالٍ' }
const CHAIN_STEP_AR: Record<string, string> = { install: 'تثبيت', lint: 'تنظيف', tests: 'اختبارات', build: 'بناء' }
const ACTOR_AR: Record<string, string> = {
  master: 'المراقب', architect: 'المعماري', engineer: 'المهندس', qa: 'فاحص الجودة',
  security: 'المراجع الأمني', owner: 'المالك', system: 'النظام',
}
const DEBT_AR: Record<string, string> = { todo: 'TODO', long: 'ملف طويل', untested: 'بلا اختبار' }
const KIND_AR: Record<string, string> = { debt: 'دين', duplication: 'تكرار', tests: 'اختبارات', architecture: 'هيكلة' }

function safeParse<T>(s: string | null | undefined, fallback: T): T {
  if (!s) return fallback
  try {
    return JSON.parse(s) as T
  } catch {
    return fallback
  }
}

export function ForgeView({ onAuthLost, onBackToChat }: { onAuthLost: () => void; onBackToChat?: () => void }) {
  const { t, lang } = useI18n()
  const [status, setStatus] = useState<ForgeStatusInfo | null>(null)
  const [levelDraft, setLevelDraft] = useState<number | null>(null)
  const [levelBusy, setLevelBusy] = useState(false)
  const [request, setRequest] = useState('')
  const [model, setModel] = useState<string | null>(null)
  const [launching, setLaunching] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [changes, setChanges] = useState<ForgeChangeInfo[]>([])
  const [activeId, setActiveId] = useState<number | null>(null)
  const [detail, setDetail] = useState<{ change: ForgeChangeInfo; events: ForgeEventInfo[] } | null>(null)
  const [map, setMap] = useState<ForgeMapInfo | null>(null)
  const [proposals, setProposals] = useState<ForgeProposalInfo[]>([])
  const [genBusy, setGenBusy] = useState(false)
  const [prefill, setPrefill] = useState('')
  const [engDraft, setEngDraft] = useState('')
  const [engBusy, setEngBusy] = useState(false)
  const [engSaved, setEngSaved] = useState<string | null>(null)

  const guard = useCallback(
    (e: unknown) => {
      if (e instanceof ApiError && e.status === 401) onAuthLost()
      else setError(e instanceof Error ? e.message : String(e))
    },
    [onAuthLost],
  )

  const loadAll = useCallback(async () => {
    try {
      const [s, c] = await Promise.all([api.forgeStatus(), api.forgeChanges()])
      setStatus(s)
      setLevelDraft(s.level)
      setChanges(c.changes)
      if (s.enabled) {
        api.forgeMap().then((m) => setMap(m.map)).catch(() => undefined)
        api.forgeProposals('proposed').then((p) => setProposals(p.proposals)).catch(() => undefined)
      }
    } catch (e) {
      guard(e)
    }
  }, [guard])

  const loadDetail = useCallback(
    async (id: number) => {
      try {
        setDetail(await api.forgeChange(id))
      } catch (e) {
        guard(e)
      }
    },
    [guard],
  )

  useEffect(() => {
    void loadAll()
  }, [loadAll])

  // live follow of the selected change while it is mid-flight
  useEffect(() => {
    if (activeId === null) return
    void loadDetail(activeId)
    const change = detail?.change
    if (change && !ACTIVE_STATUS.has(change.status)) return
    const timer = setInterval(() => {
      void loadDetail(activeId)
      void api.forgeChanges().then((c) => setChanges(c.changes)).catch(() => undefined)
    }, 1500)
    return () => clearInterval(timer)
  }, [activeId, loadDetail, detail?.change?.status])

  useEffect(() => {
    if (prefill) {
      setRequest(prefill)
      setPrefill('')
    }
  }, [prefill])

  const saveLevel = async () => {
    if (levelDraft === null || levelDraft === status?.level) return
    setLevelBusy(true)
    try {
      const res = await api.forgeSetAutonomy(levelDraft)
      setStatus((s) => (s ? { ...s, level: res.level } : s))
      setError(null)
    } catch (e) {
      guard(e)
    } finally {
      setLevelBusy(false)
    }
  }

  const launch = async () => {
    setError(null)
    if (request.trim().length < 8) return setError(t.forgeNeedsRequest)
    setLaunching(true)
    try {
      const { change } = await api.createForgeChange(request.trim(), model ?? undefined)
      setRequest('')
      setActiveId(change.id)
      await api.forgeChanges().then((c) => setChanges(c.changes)).catch(() => undefined)
      void loadDetail(change.id)
    } catch (e) {
      guard(e)
    } finally {
      setLaunching(false)
    }
  }

  const decide = async (id: number, decision: 'apply' | 'reject') => {
    try {
      await api.decideForgeChange(id, decision)
      await loadDetail(id)
      const c = await api.forgeChanges()
      setChanges(c.changes)
    } catch (e) {
      guard(e)
    }
  }

  const rollback = async (id: number) => {
    try {
      await api.rollbackForgeChange(id)
      await loadDetail(id)
      const c = await api.forgeChanges()
      setChanges(c.changes)
    } catch (e) {
      guard(e)
    }
  }

  const resume = async (id: number) => {
    try {
      await api.resumeForgeChange(id)
      await loadDetail(id)
    } catch (e) {
      guard(e)
    }
  }

  // LIMO #19: the owner's interruption — a non-terminal change stops at its
  // phase boundary and can never be resurrected by an in-flight phase.
  const cancel = async (id: number) => {
    try {
      await api.cancelForgeChange(id)
      await loadDetail(id)
      const c = await api.forgeChanges()
      setChanges(c.changes)
    } catch (e) {
      guard(e)
    }
  }

  // LIMO #19: pin/clear the engineering intelligence model (directive §8)
  const saveEngModel = async (model: string | null) => {
    setEngBusy(true)
    try {
      const res = await api.forgeSetEngineeringModel(model)
      setStatus((s) => (s ? { ...s, engineeringModel: res.model } : s))
      setEngSaved(res.model)
      setEngDraft('')
      setError(null)
    } catch (e) {
      guard(e)
    } finally {
      setEngBusy(false)
    }
  }

  const generate = async () => {
    setGenBusy(true)
    try {
      const res = await api.forgeGenerateProposals()
      setProposals(res.proposals)
    } catch (e) {
      guard(e)
    } finally {
      setGenBusy(false)
    }
  }

  const proposalStatus = async (id: number, s: 'accepted' | 'dismissed') => {
    try {
      await api.forgeProposalStatus(id, s)
      setProposals((cur) => cur.filter((p) => p.id !== id))
    } catch (e) {
      guard(e)
    }
  }

  const change = detail?.change
  const plan = safeParse<{
    summary?: string
    steps?: Array<{ title: string; detail: string }>
    files?: string[]
    risks?: string[]
    complexity?: string
    complexityReason?: string
    dependencies?: string[]
    regressions?: string[]
  }>(change?.plan, {})
  const tests = safeParse<{
    code?: number | null
    durationMs?: number
    skipped?: boolean
    note?: string
    failedStep?: string | null
    steps?: Array<{ name: string; command: string; code: number; durationMs: number; tail: string }>
    stdout?: string
    stderr?: string
  }>(change?.test_output, {})
  const review = safeParse<{ verdict?: string; findings?: Array<{ severity: string; rule: string; file: string; note: string }>; highRiskTouched?: Array<{ file: string; ar: string }> }>(change?.security_review, {})

  return (
    <div className="h-full overflow-y-auto bg-canvas px-4 py-5 sm:px-6">
      <div className="mx-auto flex max-w-4xl flex-col gap-5">
        {/* header + autonomy */}
        <section className="rounded-lg border border-line bg-surface p-4">
          <h2 className="flex items-center gap-2 font-display text-lg font-bold">
            <Hammer size={17} className="text-signal-text dark:text-signal" />
            {t.forgeTitle}
            {onBackToChat && (
              <Button
                size="sm"
                variant="outline"
                onClick={onBackToChat}
                className="ms-auto h-8 rounded-full border-line px-3 text-xs text-dim hover:text-body"
              >
                {lang === 'ar' ? 'العودة للمحادثة' : 'Back to chat'}
              </Button>
            )}
          </h2>
          <p className="mt-1 text-xs leading-relaxed text-dim">{t.forgeSub}</p>

          {!status ? (
            <p className="mt-3 flex items-center gap-2 text-xs text-dim">
              <Loader2 size={13} className="animate-spin" /> …
            </p>
          ) : !status.enabled ? (
            <p role="alert" className="mt-3 rounded-sm border border-rust/40 bg-canvas px-3 py-2 text-xs leading-relaxed text-rust-text">
              <AlertTriangle size={13} className="me-1 inline align-[-2px]" />
              {t.forgeDisabled}
            </p>
          ) : (
            <>
              <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 font-mono text-[11px] text-dim" dir="ltr">
                <span className="flex items-center gap-1"><GitBranch size={12} /> {status.repoRoot}</span>
                <span className="flex items-center gap-1" title={t.forgeChainSub}>
                  <Cpu size={12} /> chain: {(['install', 'lint', 'tests', 'build'] as const)
                    .map((k) => `${k}: ${status.chain[k] || '—'}`)
                    .join(' → ')}
                </span>
              </div>
              <div className="mt-3 rounded-md border border-input bg-canvas p-3">
                <p className="text-xs font-semibold">{t.forgeAutonomy} <span className="text-dim">— {t.forgeAutonomySub}</span></p>
                <div className="mt-2 flex flex-col gap-2">
                  {status.levels.map((l) => (
                    <label key={l.level} className={cn('flex cursor-pointer items-start gap-2 rounded-sm border px-2.5 py-1.5 transition-colors', levelDraft === l.level ? 'border-signal-text/60 bg-surface' : 'border-line hover:bg-surface')}>
                      <input
                        type="radio"
                        name="forge-level"
                        checked={levelDraft === l.level}
                        onChange={() => setLevelDraft(l.level)}
                        className="mt-0.5 size-3.5 accent-signal"
                      />
                      <span className="min-w-0">
                        <span className="block text-xs font-semibold" dir="auto">{l.ar}</span>
                        <span className="block text-[11px] leading-relaxed text-dim" dir="auto">{l.what}</span>
                      </span>
                    </label>
                  ))}
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <Button size="sm" disabled={levelBusy || levelDraft === status.level} onClick={() => void saveLevel()} className="h-8 rounded-sm bg-signal px-3 text-xs font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0">
                    {levelBusy ? <Loader2 size={12} className="animate-spin" /> : <ShieldCheck size={12} />}
                    {t.forgeLevelSave}
                  </Button>
                  {levelDraft === status.level && status.level > 0 && <span className="text-[11px] text-dim">L{status.level}</span>}
                </div>
              </div>

              {/* LIMO #19 — engineering intelligence pin (directive §8) */}
              <div className="mt-3 rounded-md border border-input bg-canvas p-3">
                <p className="text-xs font-semibold">{t.forgeEngModel} <span className="text-dim">— {t.forgeEngModelSub}</span></p>
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <input
                    value={engDraft}
                    onChange={(e) => setEngDraft(e.target.value)}
                    placeholder="openrouter/nvidia/nemotron-3-ultra-550b-a55b"
                    dir="ltr"
                    aria-label={t.forgeEngModel}
                    className="h-8 min-w-0 flex-1 rounded-sm border border-input bg-surface px-2.5 font-mono text-[11px] outline-none placeholder:text-dim focus:border-signal-text dark:focus:border-signal"
                  />
                  <Button size="sm" disabled={engBusy || engDraft.trim().length < 3} onClick={() => void saveEngModel(engDraft.trim())} className="h-8 rounded-sm bg-signal px-3 text-xs font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0">
                    {engBusy ? <Loader2 size={12} className="animate-spin" /> : <Cpu size={12} />}
                    {t.forgeEngModelSave}
                  </Button>
                  {status.engineeringModel && (
                    <Button size="sm" variant="outline" disabled={engBusy} onClick={() => void saveEngModel(null)} className="h-8 rounded-sm border-line bg-canvas px-3 text-xs text-dim hover:text-fault-text">
                      {t.forgeEngModelClear}
                    </Button>
                  )}
                </div>
                <p className="mt-2 font-mono text-[11px] text-dim" dir="ltr">
                  {status.engineeringModel ?? '(conversation model — no pin)'}
                </p>
              </div>
            </>
          )}
        </section>

        {status?.enabled && (
          <>
            {/* new change */}
            <section className="rounded-lg border border-line bg-surface p-4">
              <h3 className="font-display text-base font-bold">{t.forgeNewChange}</h3>
              <textarea
                value={request}
                onChange={(e) => setRequest(e.target.value)}
                placeholder={t.forgeRequestPh}
                rows={2}
                dir="auto"
                aria-label={t.forgeNewChange}
                className="mt-3 w-full resize-none rounded-md border border-input bg-canvas px-3 py-2 text-sm leading-relaxed outline-none transition-colors placeholder:text-dim focus:border-signal-text dark:focus:border-signal"
              />
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <ModelPicker value={model} onChange={setModel} onNeedVault={() => undefined} />
                <Button onClick={() => void launch()} disabled={launching} className="h-9 rounded-md bg-signal px-4 text-sm font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0">
                  {launching ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} />}
                  {t.forgeLaunch}
                </Button>
                <span className="text-[11px] text-dim">{t.forgeOptionalModel}</span>
              </div>
              {error && (
                <p role="alert" className="mt-2 rounded-sm border border-line bg-canvas px-3 py-2 text-xs text-fault-text">
                  {error}
                </p>
              )}
            </section>

            {/* selected change — the time machine */}
            {change && (
              <section className="rounded-lg border border-line bg-surface p-4">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="font-display text-base font-bold">{t.forgeDetail}</h3>
                  <span className={cn('rounded-sm border px-2 py-0.5 font-mono text-[11px]', STATUS_STYLE[change.status] ?? 'border-input text-dim')}>
                    #{change.id} · {STATUS_AR[change.status] ?? change.status}
                  </span>
                  <span className="rounded-sm border border-input px-1.5 py-0.5 font-mono text-[10px] text-dim" dir="ltr">L{change.level}</span>
                  {ACTIVE_STATUS.has(change.status) && <Loader2 size={13} className="animate-spin text-dim" />}
                  <span className="ms-auto flex gap-2">
                    {change.status === 'awaiting_approval' && (
                      <>
                        <Button size="sm" onClick={() => void decide(change.id, 'apply')} className="h-8 rounded-sm bg-signal px-3 text-xs font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0">
                          <CheckCircle2 size={13} /> {t.forgeApply}
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => void decide(change.id, 'reject')} className="h-8 rounded-sm border-input bg-canvas px-3 text-xs hover:text-fault-text">
                          <XCircle size={13} /> {t.forgeReject}
                        </Button>
                      </>
                    )}
                    {change.status === 'applied' && (
                      <Button size="sm" variant="outline" onClick={() => void rollback(change.id)} className="h-8 rounded-sm border-input bg-canvas px-3 text-xs hover:text-rust-text">
                        <RotateCcw size={13} /> {t.forgeRollback}
                      </Button>
                    )}
                    {ACTIVE_STATUS.has(change.status) && change.status !== 'awaiting_approval' && (
                      <>
                        <Button size="sm" variant="outline" onClick={() => void resume(change.id)} className="h-8 rounded-sm border-input bg-canvas px-3 text-xs">
                          <RotateCcw size={13} /> {t.forgeResume}
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => void cancel(change.id)} className="h-8 rounded-sm border-input bg-canvas px-3 text-xs text-dim hover:text-fault-text">
                          <XCircle size={13} /> {t.forgeCancel}
                        </Button>
                      </>
                    )}
                  </span>
                </div>
                <p className="mt-2 text-sm leading-relaxed">{change.request}</p>
                {change.error && (
                  <p className="mt-2 rounded-sm border border-fault-text/40 bg-canvas px-3 py-2 text-xs leading-relaxed text-fault-text" dir="auto">{change.error}</p>
                )}

                {/* plan */}
                {plan.summary && (
                  <div className="mt-3 rounded-md border border-line bg-canvas p-3">
                    <p className="flex items-center gap-1.5 text-xs font-semibold"><CircleDashed size={13} /> {t.forgePlan}</p>
                    <p className="mt-1.5 text-xs leading-relaxed">{plan.summary}</p>
                    {plan.steps && plan.steps.length > 0 && (
                      <ol className="mt-2 flex flex-col gap-1">
                        {plan.steps.map((s, i) => (
                          <li key={i} className="text-[11px] leading-relaxed">
                            <span className="font-semibold">{i + 1}. {s.title}</span>
                            <span className="text-dim"> — {s.detail}</span>
                          </li>
                        ))}
                      </ol>
                    )}
                    {plan.files && plan.files.length > 0 && (
                      <p className="mt-2 font-mono text-[10px] text-dim break-all" dir="ltr">{plan.files.join(' · ')}</p>
                    )}
                    {/* LIMO #19 planner v2 — complexity, dependents, regressions */}
                    <div className="mt-2 flex flex-wrap items-center gap-1.5">
                      {plan.complexity && (
                        <span className={cn('rounded-sm border px-1.5 py-0.5 font-mono text-[10px]', plan.complexity === 'high' ? 'border-rust/60 text-rust-text' : plan.complexity === 'medium' ? 'border-input text-dim' : 'border-signal-text/40 text-signal-text dark:text-signal')}>
                          {t.forgeComplexity}: {COMPLEXITY_AR[plan.complexity] ?? plan.complexity}
                        </span>
                      )}
                      {plan.complexityReason && <span className="text-[10px] text-dim" dir="auto">{plan.complexityReason}</span>}
                    </div>
                    {plan.dependencies && plan.dependencies.length > 0 && (
                      <p className="mt-1.5 text-[10px] leading-relaxed text-dim"><span className="font-semibold">{t.forgeDeps}:</span> <span className="font-mono" dir="ltr">{plan.dependencies.join(' · ')}</span></p>
                    )}
                    {plan.regressions && plan.regressions.length > 0 && (
                      <div className="mt-1.5">
                        <p className="text-[10px] font-semibold text-rust-text">{t.forgeRegressions}:</p>
                        <ul className="mt-0.5 flex flex-col gap-0.5">
                          {plan.regressions.map((r, i) => (
                            <li key={i} className="text-[10px] leading-relaxed text-dim" dir="auto">· {r}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}

                {/* tests + security side by side */}
                <div className="mt-3 grid gap-3 md:grid-cols-2">
                  <div className="rounded-md border border-line bg-canvas p-3">
                    <p className="flex items-center gap-1.5 text-xs font-semibold"><Clock size={13} /> {t.forgeTests}</p>
                    {change.test_output ? (
                      tests.skipped ? (
                        <p className="mt-1.5 text-[11px] leading-relaxed text-dim">{tests.note ?? '—'}</p>
                      ) : tests.steps && tests.steps.length > 0 ? (
                        <div className="mt-1.5 flex flex-col gap-1">
                          <span className={cn('font-mono', tests.code === 0 ? 'text-signal-text dark:text-signal' : 'text-fault-text')} dir="ltr">
                            exit {tests.code ?? '—'} · {tests.durationMs ?? 0}ms{tests.failedStep ? ` · ${tests.failedStep} ✗` : ''}
                          </span>
                          <ul className="flex flex-col gap-1">
                            {tests.steps.map((s, i) => (
                              <li key={i} className="flex items-center gap-1.5 rounded-sm border border-line bg-surface px-2 py-1">
                                <span className={cn('rounded-sm border px-1.5 py-0.5 font-mono text-[10px]', s.code === 0 ? 'border-signal-text/50 text-signal-text dark:text-signal' : 'border-fault-text/60 text-fault-text')} dir="ltr">{s.code}</span>
                                <span className="text-[11px] font-semibold">{CHAIN_STEP_AR[s.name] ?? s.name}</span>
                                <span className="ms-auto font-mono text-[10px] text-dim" dir="ltr">{s.durationMs}ms</span>
                              </li>
                            ))}
                          </ul>
                          {tests.steps.some((s) => s.code !== 0 && s.tail) && (
                            <pre className="max-h-32 overflow-y-auto whitespace-pre-wrap break-all rounded-sm border border-line bg-surface px-2 py-1.5 font-mono text-[10px] text-fault-text" dir="ltr">
                              {tests.steps.find((s) => s.code !== 0)?.tail ?? ''}
                            </pre>
                          )}
                        </div>
                      ) : (
                        <div className="mt-1.5 flex flex-col gap-1 text-[11px]">
                          <span className={cn('font-mono', tests.code === 0 ? 'text-signal-text dark:text-signal' : 'text-fault-text')} dir="ltr">
                            exit {tests.code} · {tests.durationMs}ms
                          </span>
                          {(tests.stderr || tests.stdout) && (
                            <pre className="max-h-32 overflow-y-auto whitespace-pre-wrap break-all rounded-sm border border-line bg-surface px-2 py-1.5 font-mono text-[10px] text-dim" dir="ltr">
                              {(tests.stderr || tests.stdout || '').slice(0, 1200)}
                            </pre>
                          )}
                        </div>
                      )
                    ) : (
                      <p className="mt-1.5 text-[11px] text-dim">—</p>
                    )}
                  </div>
                  <div className="rounded-md border border-line bg-canvas p-3">
                    <p className="flex items-center gap-1.5 text-xs font-semibold"><ShieldCheck size={13} /> {t.forgeSecurity}</p>
                    {change.security_review ? (
                      <div className="mt-1.5 flex flex-col gap-1 text-[11px]">
                        <span className={cn('rounded-sm border px-1.5 py-0.5 font-mono w-fit', review.verdict === 'clean' ? 'border-signal-text/50 text-signal-text dark:text-signal' : 'border-rust/60 text-rust-text')}>
                          {review.verdict}
                        </span>
                        {review.highRiskTouched?.map((h) => (
                          <span key={h.file} className="text-rust-text" dir="auto">⚠ {h.ar}: <span className="font-mono text-[10px]" dir="ltr">{h.file}</span></span>
                        ))}
                        {review.findings?.slice(0, 6).map((f, i) => (
                          <span key={i} className="text-dim" dir="auto">· {f.note} (<span className="font-mono text-[10px]" dir="ltr">{f.rule}</span>)</span>
                        ))}
                        {(review.findings?.length ?? 0) === 0 && (review.highRiskTouched?.length ?? 0) === 0 && <span className="text-dim">—</span>}
                      </div>
                    ) : (
                      <p className="mt-1.5 text-[11px] text-dim">—</p>
                    )}
                  </div>
                </div>

                {/* diff */}
                {change.diff && (
                  <details className="mt-3" open>
                    <summary className="flex cursor-pointer items-center gap-1.5 text-xs font-semibold">
                      <FileDiff size={13} /> {t.forgeDiff}
                    </summary>
                    <pre className="mt-2 max-h-72 overflow-auto whitespace-pre rounded-md border border-line bg-surface px-3 py-2 font-mono text-[10px] leading-relaxed" dir="ltr">{change.diff}</pre>
                  </details>
                )}

                {/* audit trail */}
                <details className="mt-3">
                  <summary className="flex cursor-pointer items-center gap-1.5 text-xs font-semibold">
                    <History size={13} /> {t.forgeEvents} ({detail?.events.length ?? 0})
                  </summary>
                  <ul className="mt-2 flex max-h-56 flex-col gap-1 overflow-y-auto">
                    {detail?.events.map((e) => (
                      <li key={e.id} className="flex items-start gap-2 rounded-sm border border-line bg-canvas px-2.5 py-1.5">
                        <span className="shrink-0 rounded-sm border border-input px-1.5 py-0.5 font-mono text-[10px] text-dim">{ACTOR_AR[e.actor] ?? e.actor}</span>
                        <span className="min-w-0 flex-1">
                          <span className="block font-mono text-[10px]" dir="ltr">{e.kind} · {e.ts.slice(11, 19)}</span>
                          <span className="block truncate font-mono text-[10px] text-dim" dir="ltr" title={e.data}>{e.data.slice(0, 160)}</span>
                        </span>
                      </li>
                    ))}
                  </ul>
                </details>
              </section>
            )}

            {/* changes list */}
            <section className="rounded-lg border border-line bg-surface p-4">
              <h3 className="font-display text-base font-bold">{t.forgeChanges}</h3>
              {changes.length === 0 ? (
                <p className="mt-2 text-xs text-dim">{t.forgeNoChanges}</p>
              ) : (
                <ul className="mt-2 flex flex-col divide-y divide-line">
                  {changes.slice(0, 20).map((c) => (
                    <li key={c.id}>
                      <button
                        type="button"
                        onClick={() => setActiveId(c.id)}
                        className={cn('flex w-full items-center gap-2 px-1 py-2 text-start transition-colors hover:bg-canvas', activeId === c.id && 'bg-canvas')}
                      >
                        <span className="shrink-0">
                          {c.status === 'applied' ? <CheckCircle2 size={14} className="text-signal-text dark:text-signal" /> : c.status === 'failed' ? <XCircle size={14} className="text-fault-text" /> : c.status === 'awaiting_approval' ? <AlertTriangle size={14} className="text-rust-text" /> : ACTIVE_STATUS.has(c.status) ? <Loader2 size={14} className="animate-spin text-dim" /> : <CircleDashed size={14} className="text-dim" />}
                        </span>
                        <span className={cn('shrink-0 rounded-sm border px-1.5 py-0.5 font-mono text-[10px]', STATUS_STYLE[c.status] ?? 'border-input text-dim')} dir="ltr">
                          #{c.id} · {c.status}
                        </span>
                        <span className="min-w-0 flex-1 truncate text-sm">{c.request}</span>
                        <span className="shrink-0 font-mono text-[10px] text-dim" dir="ltr">L{c.level}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            {/* self-understanding map */}
            {map && (
              <section className="rounded-lg border border-line bg-surface p-4">
                <h3 className="flex items-center gap-2 font-display text-base font-bold">
                  <MapIcon size={15} /> {t.forgeMap}
                </h3>
                <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 font-mono text-[11px] text-dim" dir="ltr">
                  <span>{map.files} {t.forgeMapFiles}</span>
                  <span>{map.edges} {t.forgeMapEdges}</span>
                  <span>{map.entryPoints.length} {t.forgeMapEntries}</span>
                  <span>{new Date(map.scannedAt).toLocaleTimeString('en-GB')}</span>
                </div>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {Object.entries(map.layers).map(([layer, n]) => (
                    <span key={layer} className="rounded-sm border border-input bg-canvas px-2 py-0.5 font-mono text-[10px]" dir="ltr">{layer}: {n}</span>
                  ))}
                </div>
                <p className="mt-2 font-mono text-[10px] leading-relaxed text-dim break-all" dir="ltr">{map.entryPoints.join(' · ')}</p>
                {map.debt.length > 0 && (
                  <details className="mt-2">
                    <summary className="cursor-pointer text-[11px] text-dim">{t.forgeMapDebt} ({map.debt.length}) · {t.forgeMapDup} ({map.duplication.length})</summary>
                    <ul className="mt-1.5 flex flex-col gap-0.5">
                      {map.debt.slice(0, 12).map((d, i) => (
                        <li key={i} className="flex items-center gap-2 font-mono text-[10px] text-dim" dir="ltr">
                          <span className="rounded-sm border border-input px-1">{DEBT_AR[d.kind] ?? d.kind}</span>
                          <span className="truncate">{d.file}</span>
                          <span className="shrink-0">{d.detail}</span>
                        </li>
                      ))}
                      {map.duplication.slice(0, 5).map((d, i) => (
                        <li key={`d${i}`} className="flex items-center gap-2 font-mono text-[10px] text-dim" dir="ltr">
                          <span className="rounded-sm border border-input px-1">{t.forgeMapDup}</span>
                          <span className="truncate">{d.a} ⇄ {d.b} ({d.windows})</span>
                        </li>
                      ))}
                    </ul>
                  </details>
                )}
                <p className="mt-2 text-[10px] leading-relaxed text-dim" dir="auto">{map.conventions.join(' · ')}</p>
              </section>
            )}

            {/* evolution proposals */}
            <section className="rounded-lg border border-line bg-surface p-4">
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="flex items-center gap-2 font-display text-base font-bold">
                  <Lightbulb size={15} className="text-signal-text dark:text-signal" />
                  {t.forgeProposals}
                </h3>
                <span className="text-[11px] text-dim">{t.forgeProposalsSub}</span>
                <Button size="sm" variant="outline" disabled={genBusy} onClick={() => void generate()} className="ms-auto h-8 rounded-sm border-input bg-canvas px-3 text-[11px]">
                  {genBusy ? <Loader2 size={12} className="animate-spin" /> : <Code2 size={12} />}
                  {t.forgeGenerate}
                </Button>
              </div>
              {proposals.length === 0 ? (
                <p className="mt-2 text-xs text-dim">{t.forgeNoProposals}</p>
              ) : (
                <ul className="mt-3 flex flex-col gap-2">
                  {proposals.map((p) => (
                    <li key={p.id} className="rounded-md border border-line bg-canvas p-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="rounded-sm border border-input px-1.5 py-0.5 text-[10px] text-dim">{KIND_AR[p.kind] ?? p.kind}</span>
                        <p className="min-w-0 flex-1 text-sm font-semibold leading-snug" dir="auto">{p.title}</p>
                      </div>
                      <div className="mt-1.5 grid gap-x-4 gap-y-0.5 text-[11px] leading-relaxed sm:grid-cols-2">
                        <p><span className="text-dim">{t.forgeBenefit}: </span>{p.benefit}</p>
                        <p><span className="text-dim">{t.forgeRisk}: </span>{p.risk}</p>
                        <p><span className="text-dim">{t.forgeCost}: </span>{p.cost}</p>
                        <p><span className="text-dim">{t.forgeValidation}: </span>{p.validation}</p>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-2">
                        <Button size="sm" variant="outline" onClick={() => void proposalStatus(p.id, 'accepted')} className="h-7 rounded-sm border-input bg-surface px-2 text-[11px]">
                          <CheckCircle2 size={11} /> {t.forgeAccept}
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => void proposalStatus(p.id, 'dismissed')} className="h-7 rounded-sm px-2 text-[11px] text-dim hover:text-body">
                          {t.forgeDismiss}
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setPrefill(p.title)} className="h-7 rounded-sm border-input bg-surface px-2 text-[11px]">
                          <Play size={11} /> {t.forgeUseAsRequest}
                        </Button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </>
        )}
      </div>
    </div>
  )
}
