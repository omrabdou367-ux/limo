'use client'

import { useCallback, useEffect, useState } from 'react'
import { Activity, Loader2, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useI18n } from '@/lib/i18n'
import { api, type BreakerInfo, type CatalogSummary, type UsageBoard } from '@/lib/api'
import { cn, timeAgo } from '@/lib/utils'

/**
 * The honest usage board (PLAN.md §8.1.3): flat numbers, 1px rules, mono
 * digits — observed local behaviour only. Per-provider rows carry the
 * "last verified" clock and a thin ok/fail bar; the catalog strip shows the
 * real aggregation timestamp with a manual refresh. No charts library, no
 * invented quota claims.
 */
export function UsagePanel({ onBreakerReset }: { onBreakerReset?: () => void }) {
  const { t, lang } = useI18n()
  const [days, setDays] = useState(7)
  const [board, setBoard] = useState<UsageBoard | null>(null)
  const [catalog, setCatalog] = useState<CatalogSummary | null>(null)
  const [breakers, setBreakers] = useState<BreakerInfo[]>([])
  const [refreshing, setRefreshing] = useState(false)
  const [resetting, setResetting] = useState<string | null>(null)

  const load = useCallback(async () => {
    try {
      const [u, c, r] = await Promise.all([api.usage(days), api.catalog(), api.routerState()])
      setBoard(u)
      setCatalog(c)
      setBreakers(r.breakers)
    } catch {
      /* keep whatever we had */
    }
  }, [days])

  useEffect(() => {
    void load()
  }, [load])

  const refreshCatalog = async () => {
    setRefreshing(true)
    try {
      await api.catalogRefresh()
      await load()
    } catch {
      /* surfaced by the errors list on next load */
    } finally {
      setRefreshing(false)
    }
  }

  const resetBreaker = async (provider: string) => {
    setResetting(provider)
    try {
      await api.resetBreaker(provider)
      await load()
      onBreakerReset?.()
    } finally {
      setResetting(null)
    }
  }

  const totals = board?.totals
  const okRate = totals && totals.calls > 0 ? Math.round((totals.ok / totals.calls) * 100) : null
  const breakerFor = (provider: string) => breakers.find((b) => b.provider === provider)

  return (
    <section className="h-full overflow-y-auto" aria-label={t.usageTitle}>
      <div className="mx-auto flex max-w-5xl flex-col gap-6 px-5 py-6">
        {/* title + window */}
        <header className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="flex items-center gap-2 font-display text-xl font-bold">
              <Activity size={18} className="text-signal-text" />
              {t.usageTitle}
            </h2>
            <p className="mt-1 text-xs text-dim">{t.usageSub}</p>
          </div>
          <div className="flex overflow-hidden rounded-md border border-input" role="group" aria-label={t.usageDays}>
            {[1, 7, 30].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => setDays(d)}
                className={cn(
                  'h-8 w-12 font-mono text-xs transition-colors',
                  d === days ? 'bg-surface text-body' : 'text-dim hover:bg-surface/60',
                )}
              >
                {d}d
              </button>
            ))}
          </div>
        </header>

        {/* flat stats strip */}
        <div className="grid grid-cols-2 divide-line rounded-lg border border-line bg-surface sm:grid-cols-4 sm:divide-x sm:rtl:divide-x-reverse">
          <Stat label={t.usageCalls} value={totals ? String(totals.calls) : '—'} sub={okRate === null ? undefined : `${okRate}% ${t.usageOk}`} />
          <Stat label={t.usageFailed} value={totals ? String(totals.failed) : '—'} tone={totals && totals.failed > 0 ? 'fault' : undefined} />
          <Stat
            label={t.usageTokens}
            value={totals ? String(totals.promptTokens + totals.completionTokens) : '—'}
            sub={totals && totals.completionTokens > 0 ? `↑${totals.promptTokens} ↓${totals.completionTokens}` : undefined}
          />
          <Stat label={t.usageAvgMs} value={totals?.avgMs !== null && totals?.avgMs !== undefined ? `${totals.avgMs}ms` : '—'} />
        </div>

        {/* catalog strip */}
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 rounded-lg border border-line bg-surface px-4 py-3">
          <span className="font-mono text-xs text-dim" dir="ltr">
            {t.usageCatalogTitle}
          </span>
          <span className="font-mono text-xs" dir="ltr">
            {catalog?.refreshedAt
              ? `${catalog.models} ${t.usageCatalogModels} · ${catalog.freeModels} ${t.usageCatalogFree} · ${timeAgo(catalog.refreshedAt, lang)}`
              : t.usageCatalogNever}
          </span>
          {catalog?.stale && catalog.refreshedAt && (
            <span className="rounded-sm border border-rust/40 px-1.5 py-0.5 font-mono text-[10px] text-rust-text">stale</span>
          )}
          <Button
            size="sm"
            onClick={() => void refreshCatalog()}
            disabled={refreshing}
            className="ms-auto h-8 rounded-sm bg-signal px-3 text-xs font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0"
          >
            {refreshing ? <Loader2 size={12} className="animate-spin" /> : <RefreshCw size={12} />}
            {refreshing ? t.usageRefreshing : t.usageRefreshNow}
          </Button>
          {catalog && catalog.errors.length > 0 && (
            <p className="w-full font-mono text-[11px] text-rust-text" dir="ltr">
              {t.usageCatalogErrors} {catalog.errors.map((e) => `${e.source}: ${e.error}`).join(' · ')}
            </p>
          )}
        </div>

        {/* providers table */}
        <div>
          <h3 className="mb-2 font-mono text-xs text-dim" dir="ltr">
            {t.usageProvider}
          </h3>
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="border-b border-line text-start font-mono text-[11px] text-dim">
                <th className="py-2 text-start font-normal">{t.usageProvider}</th>
                <th className="py-2 text-start font-normal">{t.usageCalls}</th>
                <th className="py-2 text-start font-normal">{t.usageTokens}</th>
                <th className="py-2 text-start font-normal">{t.usageAvgMs}</th>
                <th className="py-2 text-start font-normal">{t.usageLastVerified}</th>
                <th className="hidden py-2 text-start font-normal md:table-cell">{t.usageLastError}</th>
              </tr>
            </thead>
            <tbody>
              {(board?.providers ?? []).map((p) => {
                const breaker = breakerFor(p.provider)
                const okShare = p.calls > 0 ? (p.ok / p.calls) * 100 : 0
                return (
                  <tr key={p.provider} className="border-b border-line/60 transition-colors hover:bg-surface/60">
                    <td className="py-2.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs" dir="ltr">
                          {p.provider}
                        </span>
                        {breaker && breaker.state !== 'closed' && (
                          <span
                            className={cn(
                              'rounded-sm border px-1.5 py-0.5 font-mono text-[10px]',
                              breaker.state === 'open'
                                ? 'border-rust/50 bg-rust-fill text-stone'
                                : 'border-signal/50 text-signal-text',
                            )}
                          >
                            {breaker.state === 'open' ? t.breakerOpen : t.breakerHalfOpen}
                          </span>
                        )}
                      </div>
                      <div className="mt-1 h-1 w-24 overflow-hidden rounded-sm bg-line" aria-hidden="true">
                        <div className="h-full bg-signal" style={{ width: `${okShare}%` }} />
                      </div>
                    </td>
                    <td className="py-2.5 font-mono text-xs" dir="ltr">
                      {p.calls}
                      <span className="text-dim">
                        {' '}
                        ({p.ok}/{p.failed})
                      </span>
                    </td>
                    <td className="py-2.5 font-mono text-xs text-dim" dir="ltr">
                      {p.promptTokens + p.completionTokens}
                    </td>
                    <td className="py-2.5 font-mono text-xs text-dim" dir="ltr">
                      {p.avgMs === null ? '—' : `${p.avgMs}ms`}
                    </td>
                    <td className="py-2.5 font-mono text-[11px] text-dim">
                      {p.lastOkAt ? timeAgo(p.lastOkAt, lang) : t.usageNever}
                    </td>
                    <td className="hidden max-w-56 truncate py-2.5 font-mono text-[11px] text-fault-text md:table-cell" dir="ltr" title={p.lastError ?? ''}>
                      {p.lastError ?? '—'}
                    </td>
                  </tr>
                )
              })}
              {board && board.providers.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-6 text-center text-xs text-dim">
                    {t.usageNoData}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* top models */}
        {board && board.models.length > 0 && (
          <div>
            <h3 className="mb-2 font-mono text-xs text-dim" dir="ltr">
              {t.usageTopModels}
            </h3>
            <table className="w-full border-collapse text-sm">
              <tbody>
                {board.models.map((m) => (
                  <tr key={`${m.provider}/${m.model}`} className="border-b border-line/60 transition-colors hover:bg-surface/60">
                    <td className="py-2 font-mono text-xs" dir="ltr">
                      {m.provider}/{m.model}
                    </td>
                    <td className="py-2 font-mono text-xs text-dim" dir="ltr">
                      ×{m.calls}
                      {m.failed > 0 && <span className="text-fault-text"> ·{m.failed}✗</span>}
                    </td>
                    <td className="py-2 font-mono text-xs text-dim" dir="ltr">
                      {m.tokens} tok
                    </td>
                    <td className="py-2 text-end font-mono text-[11px] text-dim">
                      {m.lastUsedAt ? timeAgo(m.lastUsedAt, lang) : ''}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* recent errors */}
        {board && board.recentErrors.length > 0 && (
          <div>
            <h3 className="mb-2 font-mono text-xs text-dim" dir="ltr">
              {t.usageRecentErrors}
            </h3>
            <div className="flex flex-col gap-1">
              {board.recentErrors.map((e, i) => (
                <div key={i} className="flex items-center gap-3 rounded-sm border border-line/60 px-3 py-1.5 font-mono text-[11px]" dir="ltr">
                  <span className="text-fault-text">{e.error_kind ?? 'error'}</span>
                  <span className="text-dim">{e.provider}/{e.model}</span>
                  <span className="ms-auto text-dim">{timeAgo(e.ts, lang)}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* breaker resets */}
        {breakers.length > 0 && (
          <div>
            <h3 className="mb-2 font-mono text-xs text-dim" dir="ltr">
              {t.routerBreakers}
            </h3>
            <div className="flex flex-col gap-1.5">
              {breakers.map((b) => (
                <div key={b.provider} className="flex flex-wrap items-center gap-3 rounded-sm border border-line px-3 py-2 font-mono text-[11px]" dir="ltr">
                  <span className={cn(b.state === 'open' ? 'text-rust-text' : b.state === 'half-open' ? 'text-signal-text' : 'text-body')}>
                    {b.provider}: {b.state === 'open' ? t.breakerOpen : b.state === 'half-open' ? t.breakerHalfOpen : t.breakerClosed}
                  </span>
                  <span className="text-dim">
                    {b.failures} {t.breakerFailures}
                  </span>
                  {b.lastError && (
                    <span className="max-w-64 truncate text-fault-text" title={b.lastError}>
                      {b.lastError}
                    </span>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={resetting === b.provider}
                    onClick={() => void resetBreaker(b.provider)}
                    className="ms-auto h-7 rounded-sm border-input bg-canvas px-2 text-[11px]"
                  >
                    {resetting === b.provider ? <Loader2 size={11} className="animate-spin" /> : null}
                    {t.breakerReset}
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  )
}

function Stat({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone?: 'fault' }) {
  return (
    <div className="flex flex-col gap-1 px-4 py-3">
      <span className="font-mono text-[11px] text-dim">{label}</span>
      <span className={cn('font-mono text-xl', tone === 'fault' ? 'text-fault-text' : 'text-body')} dir="ltr">
        {value}
      </span>
      {sub && (
        <span className="font-mono text-[10px] text-dim" dir="ltr">
          {sub}
        </span>
      )}
    </div>
  )
}
