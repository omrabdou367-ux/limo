'use client'

/**
 * The LIMO AGENT mark: a geometric monogram "L" — solid structure — with a
 * hollow node continuing the line: the autonomous agent operating beyond the
 * scaffold. Strictly monochrome: one ink (currentColor), the accent is a
 * SHAPE (hollow vs solid), never a hue — so the mark inverts perfectly with
 * the theme.
 */
export function Mark({ className = 'h-6 w-auto' }: { className?: string }) {
  return (
    <svg viewBox="0 0 38 38" className={className} aria-hidden="true">
      {/* solid L — the scaffold */}
      <path d="M9 5h6v20h7v6H9z" fill="currentColor" />
      {/* hollow node — the agent, one step ahead of the structure */}
      <rect x="25" y="25" width="8" height="8" fill="none" stroke="currentColor" strokeWidth="2.5" />
    </svg>
  )
}

/** Static favicon-safe lockup (no CSS vars): ink tile, white glyph. */
export function MarkStatic({ className = 'h-8 w-8' }: { className?: string }) {
  return (
    <svg viewBox="0 0 38 38" className={className} aria-hidden="true">
      <rect width="38" height="38" rx="7" fill="#0A0A0A" />
      <path d="M9 5h6v20h7v6H9z" fill="#FAFAFA" />
      <rect x="25" y="25" width="8" height="8" fill="none" stroke="#FAFAFA" strokeWidth="2.5" />
    </svg>
  )
}

/** Full brand lockup: mark + LIMO AGENT wordmark (mono, wide tracking). */
export function Wordmark({ className = '' }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`} aria-label="LIMO AGENT">
      <Mark className="h-6 w-6" />
      <span className="limo-wordmark text-sm" dir="ltr">
        LIMO AGENT
      </span>
    </span>
  )
}
