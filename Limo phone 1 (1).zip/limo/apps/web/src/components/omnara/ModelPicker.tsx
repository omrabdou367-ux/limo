'use client'

import { useEffect, useMemo, useState } from 'react'
import { Check, ChevronDown, Loader2, RefreshCw, Search, Sparkles } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useI18n } from '@/lib/i18n'
import { api, type ModelInfo } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * Model picker — live list from /v1/models, grouped per provider, refreshed
 * every time it opens. Mono ids; free models carry a subtle tag.
 * allowAuto adds the AUTOMATIC entry (اختيار النماذج أوتوماتيكياً) on top.
 * LIMO #21: a searchable list (Krea-parity) — the filter is client-side over
 * the REAL /v1/models answer; nothing is invented to fill the search.
 */
export function ModelPicker({
  value,
  onChange,
  onNeedVault,
  triggerClassName,
  allowAuto = false,
}: {
  value: string | null
  onChange: (id: string) => void
  onNeedVault: () => void
  /** extra classes for the trigger pill (soft/round variants) */
  triggerClassName?: string
  /** show the AUTO entry (per-purpose automatic model routing) */
  allowAuto?: boolean
}) {
  const { t } = useI18n()
  const [models, setModels] = useState<ModelInfo[] | null>(null)
  const [loading, setLoading] = useState(false)
  const [query, setQuery] = useState('')

  const refresh = async () => {
    setLoading(true)
    try {
      const res = await api.models()
      setModels(res.data)
    } catch {
      setModels([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    void refresh()
  }, [])

  const groups = useMemo(() => {
    const map = new Map<string, ModelInfo[]>()
    const q = query.trim().toLowerCase()
    for (const m of models ?? []) {
      if (q && !m.id.toLowerCase().includes(q)) continue
      const provider = m.id.split('/')[0] ?? m.id
      const list = map.get(provider) ?? []
      list.push(m)
      map.set(provider, list)
    }
    return [...map.entries()]
  }, [models, query])
  const anyMatch = groups.some(([, list]) => list.length > 0)

  return (
    <DropdownMenu onOpenChange={(open) => open && void refresh()}>
      <DropdownMenuTrigger
        className={cn(
          'flex h-9 max-w-64 items-center gap-2 rounded-full border border-input bg-surface px-3 text-s transition-colors hover:bg-surface/70 data-[state=open]:border-signal-text dark:data-[state=open]:border-signal',
          triggerClassName,
        )}
        aria-label={t.pickModel}
      >
        <span className="truncate font-mono text-xs" dir="ltr">
          {value === 'auto' ? t.autoModel : (value ?? t.pickModel)}
        </span>
        {loading ? <Loader2 size={13} className="shrink-0 animate-spin text-dim" /> : <ChevronDown size={14} className="shrink-0 text-dim" />}
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-80 rounded-2xl border-line bg-surface p-1.5">
        {/* LIMO #21 — searchable list over the real /v1/models answer */}
        {(models?.length ?? 0) > 0 && (
          <div className="relative px-1 pb-1.5">
            <Search size={13} className="pointer-events-none absolute top-1/2 ms-2 -translate-y-1/2 text-dim" aria-hidden="true" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t.modelsSearch}
              dir="ltr"
              className="h-8 w-full rounded-lg border border-input bg-canvas ps-7 pe-2 font-mono text-xs outline-none placeholder:text-dim focus:border-border-strong"
            />
          </div>
        )}
        {allowAuto && !query && (
          <>
            <DropdownMenuItem
              onClick={() => onChange('auto')}
              className="gap-2 rounded-xl px-2.5 py-2 font-mono text-xs"
            >
              <Sparkles size={13} className={cn('shrink-0', value === 'auto' ? 'opacity-100 text-signal-text' : 'opacity-60')} aria-hidden="true" />
              <span className="truncate" title="auto">{t.autoModel}</span>
              <span className="ms-auto shrink-0 rounded-sm border border-line px-1.5 py-0.5 text-[10px] text-dim">AUTO</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-line" />
          </>
        )}
        {(models?.length ?? 0) === 0 && !loading && (
          <div className="p-3 text-xs text-dim">
            <p>{t.noModels}</p>
            <p className="mt-1">{t.noModelsSub}</p>
          </div>
        )}
        {query && !anyMatch && (models?.length ?? 0) > 0 && (
          <p className="p-3 text-xs text-dim">{t.modelsNoMatch}</p>
        )}
        {groups.map(([provider, list]) => (
          <DropdownMenuGroup key={provider}>
            <DropdownMenuLabel className="font-mono text-xs text-dim" dir="ltr">
              {provider} · {list.length}
            </DropdownMenuLabel>
            {list.map((m) => (
              <DropdownMenuItem
                key={m.id}
                onClick={() => onChange(m.id)}
                className="gap-2 rounded-xl px-2.5 py-2 font-mono text-xs"
              >
                <Check size={13} className={cn('shrink-0', value === m.id ? 'opacity-100' : 'opacity-0')} aria-hidden="true" />
                <span className="truncate" dir="ltr" title={m.id}>
                  {m.id.split('/').slice(1).join('/')}
                </span>
                {m.free && (
                  <span className="ms-auto shrink-0 rounded-sm border border-line px-1.5 py-0.5 text-[10px] text-signal-text">
                    free
                  </span>
                )}
              </DropdownMenuItem>
            ))}
            <DropdownMenuSeparator className="bg-line" />
          </DropdownMenuGroup>
        ))}
        <div className="flex items-center justify-between p-2">
          <span className="font-mono text-[10px] text-dim">{t.modelsLive}</span>
          <button
            type="button"
            onClick={() => (models && models.length === 0 ? onNeedVault() : void refresh())}
            className="flex items-center gap-1 rounded-sm px-2 py-1 text-xs text-dim transition-colors hover:text-signal-text"
          >
            <RefreshCw size={12} />
            {models && models.length === 0 ? t.openVault : t.refresh}
          </button>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
