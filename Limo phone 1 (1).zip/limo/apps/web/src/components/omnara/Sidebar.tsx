'use client'

import { Globe, KeyRound, MessageSquareText, Moon, Plus, Sun, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Mark } from './Mark'
import { StatusBar } from './StatusBar'
import { useI18n } from '@/lib/i18n'
import { useTheme } from '@/lib/theme'
import { AREAS, AREA_GROUPS, type Area } from '@/lib/nav'
import type { ConversationInfo, HealthResponse } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * The LIMO rail (start side): brand, the 14 navigation areas grouped for
 * progressive disclosure, conversations (the chat history), and the
 * control-room footer. On mobile it renders as a fixed overlay controlled by
 * the parent. Open mode: no logout — the owner never logs out of their own
 * machine.
 */
export function Sidebar({
  conversations,
  activeId,
  health,
  vaultState,
  area,
  brandName,
  onArea,
  onNewChat,
  onSelect,
  onDelete,
  onOpenVault,
  onNavigate,
}: {
  conversations: ConversationInfo[]
  activeId: number | null
  health: HealthResponse | null
  vaultState: 'uninitialized' | 'locked' | 'unlocked' | null
  area: Area
  /** the owner-renamable identity (Black Box «غيّر اسم التطبيق…») */
  brandName?: string | null
  onArea: (a: Area) => void
  onNewChat: () => void
  onSelect: (id: number) => void
  onDelete: (id: number) => void
  onOpenVault: () => void
  onNavigate?: () => void
}) {
  const { t, lang, setLang } = useI18n()
  const { theme, toggle } = useTheme()

  const go = (a: Area) => {
    onArea(a)
    onNavigate?.()
  }

  return (
    <aside className="flex h-dvh w-72 shrink-0 flex-col border-e border-line bg-surface">
      <div className="flex h-14 items-center gap-2.5 border-b border-line px-4">
        <Mark className="h-5 w-auto text-dim" />
        <span className="font-display text-base font-bold tracking-[0.18em]" dir="ltr">{brandName ?? 'LIMO AGENT'}</span>
      </div>

      {/* the 14 areas — grouped, progressive disclosure */}
      <nav className="border-b border-line px-3 py-3" aria-label={t.viewsNav}>
        {AREA_GROUPS.map((group) => (
          <div key={group.id} className="mb-2 last:mb-0">
            <p className="px-2 pb-1 font-mono text-[10px] tracking-[0.2em] text-dim">{t[group.key as keyof typeof t] as string}</p>
            <ul className="flex flex-col gap-0.5">
              {AREAS.filter((a) => a.group === group.id).map((a) => {
                const Icon = a.icon
                const active = area === a.id || (a.id === 'home' && area === 'chat')
                return (
                  <li key={a.id}>
                    <button
                      type="button"
                      onClick={() => go(a.id)}
                      aria-current={active ? 'page' : undefined}
                      className={cn(
                        'flex h-9 w-full items-center gap-2.5 rounded-full px-3 text-xs transition-colors',
                        active ? 'bg-canvas font-semibold text-signal-text shadow-xs dark:text-signal' : 'text-dim hover:bg-canvas hover:text-body',
                      )}
                    >
                      <Icon size={14} className="shrink-0" />
                      <span className="truncate">{t[a.key as keyof typeof t] as string}</span>
                    </button>
                  </li>
                )
              })}
            </ul>
          </div>
        ))}
      </nav>

      <div className="px-3 pt-2">
        <Button
          onClick={() => {
            onNewChat()
            onNavigate?.()
          }}
          className="h-10 w-full justify-start gap-2 rounded-full bg-signal text-sm font-semibold text-primary-foreground hover:bg-signal/90"
        >
          <Plus size={15} />
          {t.homeNewChat}
        </Button>
      </div>

      <ScrollArea className="flex-1 px-3">
        <p className="px-2 pt-3 pb-1 font-mono text-[10px] tracking-[0.2em] text-dim">{t.viewChat}</p>
        <nav aria-label={t.chats} className="flex flex-col gap-0.5 pb-3">
          {conversations.map((c) => (
            <div
              key={c.id}
              className={cn(
                'group flex cursor-pointer items-center gap-2 rounded-2xl px-3 py-2 transition-colors hover:bg-canvas',
                c.id === activeId ? 'bg-canvas shadow-xs' : '',
              )}
              onClick={() => {
                onSelect(c.id)
                onNavigate?.()
              }}
            >
              <MessageSquareText size={13} className="shrink-0 text-dim" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs">{c.title}</p>
                <p className="mt-0.5 font-mono text-[10px] text-dim" dir="ltr">
                  {new Date(c.updatedAt).toLocaleDateString('en-GB')} {new Date(c.updatedAt).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation()
                  onDelete(c.id)
                }}
                aria-label={t.deleteChat}
                className="opacity-0 transition-opacity text-dim hover:text-fault-text group-hover:opacity-100"
              >
                <Trash2 size={13} />
              </button>
            </div>
          ))}
        </nav>
      </ScrollArea>

      <div className="border-t border-line p-3">
        <StatusBar health={health} vaultState={vaultState} />
        <div className="mt-3 flex items-center gap-1">
          <Button variant="ghost" size="icon" onClick={onOpenVault} aria-label={t.vault} title={t.vault} className="rounded-full text-dim hover:text-body">
            <KeyRound size={15} />
          </Button>
          <Button variant="ghost" size="icon" onClick={toggle} aria-label={t.theme} title={t.theme} className="rounded-full text-dim hover:text-body">
            {theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
            aria-label={t.language}
            title={t.language}
            className="rounded-full px-2 font-mono text-xs text-dim hover:text-body"
          >
            {lang === 'ar' ? t.english : t.arabic}
            <Globe size={13} />
          </Button>
        </div>
      </div>
    </aside>
  )
}
