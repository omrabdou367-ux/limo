'use client'

import { useEffect, useRef, useState } from 'react'
import { Columns3, Loader2, Play, Square } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useI18n } from '@/lib/i18n'
import { api, type ModelInfo } from '@/lib/api'
import { streamChat } from '@/lib/stream'
import { cn } from '@/lib/utils'

/**
 * Compare mode (PLAN.md §8.1.4): one prompt, 2–5 models, PARALLEL live
 * streams — each column is an independent SSE call through the same /v1
 * gateway, so routing, usage recording and the vault all behave exactly as
 * in a normal chat. Metrics are measured client-side per column: time to
 * first delta, total, chars, tokens/sec from the gateway's usage event.
 */

interface Column {
  model: string
  content: string
  state: 'idle' | 'streaming' | 'done' | 'error'
  ttfbMs: number | null
  totalMs: number | null
  completionTokens: number | null
  tokensPerSec: number | null
  error: string | null
}

const MAX = 5

export function CompareMode() {
  const { t } = useI18n()
  const [models, setModels] = useState<ModelInfo[]>([])
  const [selected, setSelected] = useState<string[]>([])
  const [prompt, setPrompt] = useState('')
  const [columns, setColumns] = useState<Column[]>([])
  const [running, setRunning] = useState(false)
  const controllers = useRef<AbortController[]>([])

  useEffect(() => {
    void api
      .models()
      .then((r) => setModels(r.data))
      .catch(() => setModels([]))
    return () => stopAll()
  }, [])

  const toggle = (id: string) => {
    setSelected((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id)
      if (prev.length >= MAX) return prev
      return [...prev, id]
    })
  }

  function stopAll() {
    for (const c of controllers.current) c.abort()
    controllers.current = []
    setRunning(false)
    setColumns((cols) => cols.map((c) => (c.state === 'streaming' ? { ...c, state: 'done' } : c)))
  }

  const run = async () => {
    const text = prompt.trim()
    if (!text || selected.length < 2 || running) return
    setRunning(true)
    controllers.current = []
    setColumns(
      selected.map((model) => ({
        model,
        content: '',
        state: 'streaming' as const,
        ttfbMs: null,
        totalMs: null,
        completionTokens: null,
        tokensPerSec: null,
        error: null,
      })),
    )

    const patch = (model: string, fn: (c: Column) => Column) =>
      setColumns((cols) => cols.map((c) => (c.model === model ? fn(c) : c)))

    await Promise.all(
      selected.map(async (model) => {
        const controller = new AbortController()
        controllers.current.push(controller)
        const t0 = Date.now()
        try {
          const result = await streamChat({
            model,
            messages: [{ role: 'user', content: text }],
            signal: controller.signal,
            onDelta: (chunk) =>
              patch(model, (c) => ({
                ...c,
                content: c.content + chunk,
                ttfbMs: c.ttfbMs ?? Date.now() - t0,
              })),
          })
          const totalMs = Date.now() - t0
          const completionTokens = result.usage?.completionTokens ?? null
          patch(model, (c) => ({
            ...c,
            state: result.error ? 'error' : 'done',
            error: result.error?.message ?? null,
            totalMs,
            completionTokens,
            tokensPerSec:
              completionTokens !== null && completionTokens > 0
                ? Number(((completionTokens / Math.max(totalMs, 1)) * 1000).toFixed(1))
                : null,
          }))
        } catch (err) {
          patch(model, (c) => ({ ...c, state: 'error', error: err instanceof Error ? err.message : String(err) }))
        }
      }),
    )
    setRunning(false)
    controllers.current = []
  }

  const cols = columns.length > 0 ? columns.length : selected.length || 2
  const gridClass =
    cols >= 4
      ? 'grid-cols-1 md:grid-cols-2 xl:grid-cols-4'
      : cols === 3
        ? 'grid-cols-1 md:grid-cols-2 xl:grid-cols-3'
        : 'grid-cols-1 md:grid-cols-2'

  return (
    <div className="flex h-full min-h-0 flex-col">
      {/* toolbar: model chips + prompt */}
      <div className="shrink-0 border-b border-line bg-surface px-5 py-3">
        <div className="mx-auto max-w-6xl">
          <div className="flex items-center gap-2">
            <Columns3 size={15} className="text-signal-text" />
            <h2 className="font-display text-base font-bold">{t.compareTitle}</h2>
            <span className="hidden font-mono text-[11px] text-dim sm:inline" dir="ltr">
              {selected.length}/{MAX} · SSE ×N
            </span>
          </div>
          <p className="mt-1 text-xs text-dim">{t.compareHint}</p>

          <div className="mt-2.5 flex flex-wrap gap-1.5" dir="ltr">
            {models.map((m) => {
              const on = selected.includes(m.id)
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => toggle(m.id)}
                  disabled={!on && selected.length >= MAX}
                  className={cn(
                    'flex items-center gap-1.5 rounded-sm border px-2 py-1 font-mono text-[11px] transition-colors',
                    on
                      ? 'border-signal-text bg-canvas text-signal-text dark:border-signal'
                      : 'border-input bg-canvas text-dim hover:text-body disabled:opacity-30',
                  )}
                  title={m.id}
                >
                  <span className="max-w-56 truncate">{m.id}</span>
                  {m.free && <span className="text-[10px] text-signal-text">free</span>}
                </button>
              )
            })}
            {models.length === 0 && <span className="font-mono text-[11px] text-dim">{t.noModels}</span>}
          </div>

          <div className="mt-3 flex items-end gap-2">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  void run()
                }
              }}
              placeholder={t.comparePromptPlaceholder}
              dir="auto"
              rows={1}
              aria-label={t.comparePromptPlaceholder}
              className="max-h-32 min-h-9 flex-1 resize-none rounded-md border border-input bg-canvas px-3 py-2 text-sm leading-relaxed outline-none transition-colors placeholder:text-dim focus:border-signal-text dark:focus:border-signal"
            />
            {running ? (
              <Button
                onClick={stopAll}
                className="h-9 shrink-0 rounded-md border border-fault/40 px-3 text-xs text-fault-text transition-colors hover:bg-fault/10"
                variant="ghost"
              >
                <Square size={12} fill="currentColor" />
                {t.compareStop}
              </Button>
            ) : (
              <Button
                onClick={() => void run()}
                disabled={prompt.trim().length === 0 || selected.length < 2}
                className="h-9 shrink-0 rounded-md bg-signal px-3 text-xs font-semibold text-primary-foreground hover:bg-signal/90 border border-ink dark:border-0"
              >
                <Play size={12} className="-scale-x-100 rtl:rotate-0" />
                {t.compareRun}
              </Button>
            )}
          </div>
          {selected.length < 2 && (
            <p className="mt-1.5 font-mono text-[11px] text-dim">{t.compareNeedsTwo}</p>
          )}
        </div>
      </div>

      {/* columns */}
      <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
        {columns.length === 0 ? (
          <div className="flex h-full items-center justify-center">
            <p className="font-mono text-xs text-dim">{t.compareEmpty}</p>
          </div>
        ) : (
          <div className={cn('mx-auto grid max-w-6xl gap-3', gridClass)}>
            {columns.map((c) => (
              <article key={c.model} className="flex min-h-48 flex-col rounded-lg border border-line bg-surface">
                <header className="flex items-center gap-2 border-b border-line px-3 py-2">
                  <span
                    aria-hidden="true"
                    className={cn(
                      'size-1.5 shrink-0 rounded-full',
                      c.state === 'streaming' ? 'animate-pulse bg-signal' : c.state === 'error' ? 'bg-fault' : 'bg-line',
                    )}
                  />
                  <span className="min-w-0 flex-1 truncate font-mono text-[11px]" dir="ltr" title={c.model}>
                    {c.model}
                  </span>
                  {c.state === 'streaming' && <Loader2 size={11} className="shrink-0 animate-spin text-dim" />}
                </header>
                <div className="min-h-24 flex-1 overflow-y-auto whitespace-pre-wrap px-3 py-2.5 text-sm leading-relaxed">
                  {c.error ? <span className="text-xs text-fault-text">{c.error}</span> : c.content || '…'}
                  {c.state === 'streaming' && <span className="ms-0.5 inline-block h-4 w-1.5 animate-pulse bg-signal align-middle" />}
                </div>
                <footer className="flex flex-wrap items-center gap-x-3 gap-y-0.5 border-t border-line px-3 py-1.5 font-mono text-[10px] text-dim" dir="ltr">
                  <span>
                    {t.compareTtfb} {c.ttfbMs !== null ? `${c.ttfbMs}ms` : '—'}
                  </span>
                  <span>
                    {t.compareTotal} {c.totalMs !== null ? `${c.totalMs}ms` : '—'}
                  </span>
                  <span>
                    {t.compareChars} {c.content.length}
                  </span>
                  {c.tokensPerSec !== null && (
                    <span className="text-signal-text">
                      {t.compareTokPerSec} {c.tokensPerSec}
                    </span>
                  )}
                </footer>
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
