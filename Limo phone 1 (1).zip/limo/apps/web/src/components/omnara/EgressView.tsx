'use client'

import { useCallback, useEffect, useState } from 'react'
import { ArrowLeftRight, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useI18n } from '@/lib/i18n'
import { api, ApiError, type EgressBoard } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * «ما غادر الجهاز» (owner directive v2.2 #7): every outbound request as the
 * server recorded it — provider, model, payload size, sha256 fingerprint,
 * and whether it actually LEFT the machine. No content column exists in the
 * schema, so none can ever appear here.
 */
export function EgressView({ onAuthLost }: { onAuthLost: () => void }) {
  const { t } = useI18n()
  const [board, setBoard] = useState<EgressBoard | null>(null)
  const [leftOnly, setLeftOnly] = useState(false)
  const [loading, setLoading] = useState(false)

  const load = useCallback(
    async (only: boolean) => {
      setLoading(true)
      try {
        setBoard(await api.egress(only, 150))
      } catch (e) {
        if (e instanceof ApiError && e.status === 401) onAuthLost()
      } finally {
        setLoading(false)
      }
    },
    [onAuthLost],
  )

  useEffect(() => {
    void load(leftOnly)
  }, [load, leftOnly])

  const fmtBytes = (n: number): string => (n < 1024 ? `${n} B` : n < 1024 * 1024 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1024 / 1024).toFixed(1)} MB`)

  return (
    <div className="h-full overflow-y-auto bg-canvas px-4 py-5 sm:px-6">
      <div className="mx-auto flex max-w-4xl flex-col gap-5">
        <section className="rounded-lg border border-line bg-surface p-4">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="font-display text-lg font-bold">{t.egressTitle}</h2>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setLeftOnly((v) => !v)}
              aria-pressed={leftOnly}
              className="ms-auto h-8 rounded-sm border-input bg-canvas px-2 text-[11px]"
            >
              <ArrowLeftRight size={12} />
              {t.egressLeftOnly}
            </Button>
          </div>
          <p className="mt-1 text-xs leading-relaxed text-dim">{t.egressSub}</p>

          <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {board &&
              (
                [
                  { label: t.egressTotal, value: String(board.counts.total) },
                  { label: t.egressLeft, value: String(board.counts.leftMachine) },
                  { label: t.egressLocal, value: String(board.counts.local) },
                  { label: t.egressBytes, value: fmtBytes(board.counts.bytesLeft) },
                ] as const
              ).map((c) => (
                <div key={c.label} className="rounded-sm border border-line bg-canvas px-3 py-2">
                  <p className="font-mono text-lg font-bold" dir="ltr">
                    {c.value}
                  </p>
                  <p className="mt-0.5 text-[11px] text-dim">{c.label}</p>
                </div>
              ))}
          </div>
        </section>

        <section className="rounded-lg border border-line bg-surface p-4">
          {loading && !board ? (
            <p className="flex items-center gap-2 text-xs text-dim">
              <Loader2 size={13} className="animate-spin" />
            </p>
          ) : !board || board.rows.length === 0 ? (
            <p className="text-xs text-dim">{t.egressNone}</p>
          ) : (
            <ul className="flex flex-col gap-1.5">
              {board.rows.map((r) => (
                <li key={r.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-sm border border-line bg-canvas px-3 py-2 font-mono text-[11px]" dir="ltr">
                  <span className="text-dim">{r.ts.slice(11, 19)}</span>
                  <span className="rounded-sm border border-input px-1.5 py-0.5 text-[10px] text-dim">{r.source}</span>
                  <span className="font-semibold">{r.provider}</span>
                  {r.model && <span className="max-w-56 truncate text-dim">{r.model}</span>}
                  <span className={cn('rounded-sm border px-1.5 py-0.5 text-[10px]', r.left_machine === 1 ? 'border-rust/50 text-rust-text' : 'border-input text-dim')}>
                    {r.left_machine === 1 ? 'EGRESS' : t.egressLocalTag}
                  </span>
                  <span className="text-dim">{fmtBytes(r.payload_bytes)}</span>
                  <span className="text-dim" title={t.egressFingerprint}>
                    #{r.payload_sha256}
                  </span>
                  <span
                    className={cn(
                      'ms-auto rounded-sm border px-1.5 py-0.5 text-[10px]',
                      r.ok === 1 && 'border-signal-text/50 text-signal-text dark:text-signal',
                      r.ok === 0 && 'border-fault-text/50 text-fault-text',
                      r.ok === null && 'border-input text-dim',
                    )}
                  >
                    {r.ok === 1 ? t.egressOk : r.ok === 0 ? `${t.egressFailed}${r.error_kind ? ` (${r.error_kind})` : ''}` : t.egressPending}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  )
}
