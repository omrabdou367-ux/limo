'use client'

import { useCallback, useEffect, useState } from 'react'
import { Check, Copy, KeyRound, Loader2, Lock, LockOpen, Plus, Trash2 } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useI18n } from '@/lib/i18n'
import { api, ApiError, type ApiKeyInfo, type HealthResponse, type SecretInfo } from '@/lib/api'
import { cn } from '@/lib/utils'
import { CustomProvidersSection } from './CustomProvidersSection'

/**
 * Vault panel — the ONLY place secrets are written (never read back).
 * Three tabs: provider keys (BYOK), gateway API keys (Bearer omn_live_…),
 * and custom OpenAI-compatible providers. Open mode (LIMO #8): the vault
 * self-unwraps at boot with the machine key — there is no unlock form and
 * no lock button; the pill just reflects the live server state.
 */
export function VaultPanel({
  open,
  onOpenChange,
  health,
  onVaultChanged,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  health: HealthResponse | null
  onVaultChanged: () => void
}) {
  const { t } = useI18n()
  const [state, setState] = useState<'uninitialized' | 'locked' | 'unlocked'>('uninitialized')
  const [secrets, setSecrets] = useState<SecretInfo[]>([])
  const [apiKeys, setApiKeys] = useState<ApiKeyInfo[]>([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [createdKey, setCreatedKey] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [newKeyName, setNewKeyName] = useState('')
  const [drafts, setDrafts] = useState<Record<string, string>>({})
  const [testing, setTesting] = useState<string | null>(null)
  const [testResult, setTestResult] = useState<Record<string, string>>({})

  const reload = useCallback(async () => {
    try {
      const status = await api.vaultStatus()
      setState(status.state)
      if (status.state === 'unlocked') {
        const list = await api.vaultSecrets()
        setSecrets(list.secrets)
      }
      setApiKeys(await api.apiKeys())
    } catch {
      /* keep current */
    }
  }, [])

  useEffect(() => {
    if (open) void reload()
  }, [open, reload])

  const saveKey = async (alias: string, provider: string) => {
    const value = drafts[alias]
    if (!value || value.length < 8) return
    setBusy(true)
    setError(null)
    try {
      await api.vaultPutSecret(alias, provider, value)
      setDrafts((d) => ({ ...d, [alias]: '' }))
      await reload()
      onVaultChanged()
    } catch (err) {
      setError(err instanceof ApiError ? err.message : String(err))
    } finally {
      setBusy(false)
    }
  }

  const removeKey = async (alias: string) => {
    await api.vaultDeleteSecret(alias)
    await reload()
    onVaultChanged()
  }

  const testKey = async (alias: string) => {
    setTesting(alias)
    setTestResult((r) => ({ ...r, [alias]: '' }))
    try {
      const res = await api.vaultTestSecret(alias)
      setTestResult((r) => ({ ...r, [alias]: `✓ ${res.models} models` }))
    } catch (err) {
      setTestResult((r) => ({ ...r, [alias]: err instanceof ApiError ? `✗ ${err.message}` : '✗' }))
    } finally {
      setTesting(null)
    }
  }

  const createKey = async () => {
    setBusy(true)
    try {
      const res = await api.createApiKey(newKeyName.trim() || 'key')
      setCreatedKey(res.key)
      setNewKeyName('')
      await reload()
    } catch (err) {
      setError(err instanceof ApiError ? err.message : String(err))
    } finally {
      setBusy(false)
    }
  }

  const copyKey = async () => {
    if (!createdKey) return
    await navigator.clipboard.writeText(createdKey).catch(() => undefined)
    setCopied(true)
    setTimeout(() => setCopied(false), 1600)
  }

  const providerRows = (health?.providers ?? []).filter((p) => p.needsKey)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg rounded-lg border-line bg-canvas p-0" dir="auto">
        <DialogHeader className="border-b border-line px-5 py-4">
          <DialogTitle className="flex items-center gap-2 font-display text-lg">
            <KeyRound size={17} className="text-signal-text" />
            {t.vault}
            <span
              className={cn(
                'ms-auto inline-flex items-center gap-1.5 rounded-full border border-line px-2.5 py-0.5 font-mono text-[11px]',
                state === 'unlocked' ? 'text-signal-text' : 'text-rust-text',
              )}
            >
              {state === 'unlocked' ? <LockOpen size={12} /> : <Lock size={12} />}
              {state === 'unlocked' ? t.vaultUnlocked : state === 'locked' ? t.vaultLocked : t.vaultUninitialized}
            </span>
          </DialogTitle>
          <DialogDescription className="text-xs leading-relaxed text-dim">{t.providerKeysHint}</DialogDescription>
        </DialogHeader>

        {state === 'locked' && (
          <p className="border-b border-line bg-surface px-5 py-2.5 text-xs text-rust-text" role="status">
            {t.vaultLegacyHint}
          </p>
        )}

        {error && <p role="alert" className="border-b border-line bg-surface px-5 py-2 text-xs text-fault-text">{error}</p>}

        <Tabs defaultValue="keys" className="px-5 py-4">
          <TabsList className="rounded-md bg-surface">
            <TabsTrigger value="keys" className="rounded-sm text-sm data-[state=active]:bg-canvas">{t.keysTab}</TabsTrigger>
            <TabsTrigger value="api" className="rounded-sm text-sm data-[state=active]:bg-canvas">{t.apiKeysTab}</TabsTrigger>
            <TabsTrigger value="custom" className="rounded-sm text-sm data-[state=active]:bg-canvas">{t.customTab}</TabsTrigger>
          </TabsList>

          <TabsContent value="keys" className="mt-4 flex flex-col gap-3">
            {providerRows.map((p) => {
              const alias = `${p.id}:default`
              const secret = secrets.find((s) => s.alias === alias)
              return (
                <div key={p.id} className="rounded-md border border-line bg-surface p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-sm" dir="ltr">{p.label}</span>
                    <span className={cn('font-mono text-[11px]', secret ? 'text-signal-text' : 'text-dim')}>
                      {secret ? `${t.keyHint} ····${secret.hint ?? ''}` : t.noKey}
                    </span>
                  </div>
                  {state === 'unlocked' && (
                    <div className="mt-2.5 flex flex-wrap items-center gap-2">
                      <Input
                        type="password"
                        value={drafts[alias] ?? ''}
                        onChange={(e) => setDrafts((d) => ({ ...d, [alias]: e.target.value }))}
                        placeholder="sk-…"
                        dir="ltr"
                        className="h-8 min-w-40 flex-1 rounded-sm border-input bg-canvas font-mono text-xs"
                      />
                      <Button size="sm" disabled={busy || (drafts[alias] ?? '').length < 8} onClick={() => saveKey(alias, p.id)} className="h-8 rounded-sm bg-signal px-3 text-xs font-semibold text-primary-foreground hover:bg-signal/90">
                        {t.save}
                      </Button>
                      {secret && (
                        <>
                          <Button size="sm" variant="outline" disabled={testing === alias} onClick={() => testKey(alias)} className="h-8 rounded-sm border-input bg-canvas px-3 text-xs">
                            {testing === alias ? <Loader2 size={12} className="animate-spin" /> : null}
                            {testing === alias ? t.testing : t.test}
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => removeKey(alias)} aria-label={t.remove} className="h-8 rounded-sm px-2 text-xs text-dim hover:text-fault-text">
                            <Trash2 size={13} />
                          </Button>
                        </>
                      )}
                    </div>
                  )}
                  {testResult[alias] && (
                    <p className={cn('mt-2 font-mono text-[11px]', testResult[alias]?.startsWith('✓') ? 'text-signal-text' : 'text-fault-text')}>
                      {testResult[alias]}
                    </p>
                  )}
                </div>
              )
            })}
            {providerRows.length === 0 && <p className="text-xs text-dim">—</p>}
          </TabsContent>

          <TabsContent value="api" className="mt-4 flex flex-col gap-3">
            {createdKey && (
              <div className="rounded-md border border-signal/50 bg-surface p-3">
                <p className="text-xs text-signal-text">{t.apiKeyOnce}</p>
                <div className="mt-2 flex items-center gap-2">
                  <code dir="ltr" className="flex-1 overflow-x-auto rounded-sm bg-canvas px-2 py-1.5 font-mono text-xs">{createdKey}</code>
                  <Button size="sm" variant="outline" onClick={copyKey} className="h-8 rounded-sm border-input bg-canvas px-2 text-xs">
                    {copied ? <Check size={13} /> : <Copy size={13} />}
                  </Button>
                </div>
                <p className="mt-2 font-mono text-[10px] text-dim" dir="ltr">{t.apiKeyUse}</p>
              </div>
            )}
            <div className="flex gap-2">
              <Input
                value={newKeyName}
                onChange={(e) => setNewKeyName(e.target.value)}
                placeholder={t.apiKeyName}
                aria-label={t.apiKeyName}
                className="h-8 rounded-sm border-input bg-surface text-xs"
              />
              <Button size="sm" disabled={busy} onClick={createKey} className="h-8 rounded-sm bg-signal px-3 text-xs font-semibold text-primary-foreground hover:bg-signal/90">
                <Plus size={13} />
                {t.newApiKey}
              </Button>
            </div>
            <div className="flex flex-col gap-1.5">
              {apiKeys.map((k) => (
                <div key={k.id} className="flex items-center gap-2 rounded-md border border-line bg-surface px-3 py-2">
                  <span className="text-sm">{k.name}</span>
                  <code dir="ltr" className="ms-auto font-mono text-xs text-dim">{k.prefix}…</code>
                  <Button size="sm" variant="ghost" onClick={async () => { await api.deleteApiKey(k.id); await reload() }} aria-label={t.remove} className="h-7 rounded-sm px-2 text-dim hover:text-fault-text">
                    <Trash2 size={13} />
                  </Button>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="custom" className="mt-4">
            <CustomProvidersSection
              vaultUnlocked={state === 'unlocked'}
              secrets={state === 'unlocked' ? secrets : []}
              onChanged={() => {
                void reload()
                onVaultChanged()
              }}
            />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
