'use client'

import { useState } from 'react'
import { Check, Copy } from 'lucide-react'
import { useI18n } from '@/lib/i18n'

/** LTR code block — JetBrains Mono with Readex fallback (rule F1). */
export function CodeBlock({ lang, code }: { lang: string; code: string }) {
  const { t } = useI18n()
  const [copied, setCopied] = useState(false)

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code)
      setCopied(true)
      setTimeout(() => setCopied(false), 1600)
    } catch {
      /* clipboard unavailable */
    }
  }

  return (
    <div dir="ltr" className="my-3 overflow-hidden rounded-md border border-line bg-surface">
      <div className="flex items-center justify-between border-b border-line px-3 py-1.5">
        <span className="font-mono text-xs text-dim">{lang || 'text'}</span>
        <button
          type="button"
          onClick={copy}
          className="flex items-center gap-1 rounded-sm px-1.5 py-0.5 text-xs text-dim transition-colors hover:text-signal-text"
          aria-label={t.copy}
        >
          {copied ? <Check size={13} /> : <Copy size={13} />}
          <span>{copied ? t.copied : t.copy}</span>
        </button>
      </div>
      <pre className="overflow-x-auto p-3 font-mono text-[13.5px] leading-relaxed text-body">
        <code>{code}</code>
      </pre>
    </div>
  )
}
