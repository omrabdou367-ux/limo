'use client'

import { useCallback, useEffect, useState } from 'react'
import { Loader2, Play, Plus, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { api, ApiError, type AgentTaskInfo, type WorkflowInfo, type WorkflowRunInfo, type WorkflowStepInfo } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { AGENT_ROLE_IDS } from '@/lib/nav'
import { PageLoader, SectionHeader } from './shared'

/**
 * Workflow Lab — editable prompt chains; a run is a sequence of REAL agent
 * tasks through the engine. The UI polls the run row until it finishes — no
 * fabricated progress: status comes from the server's own state machine.
 */

function parseSteps(json: string): WorkflowStepInfo[] {
  try {
    const arr = JSON.parse(json) as WorkflowStepInfo[]
    return Array.isArray(arr) ? arr : []
  } catch {
    return []
  }
}

export function WorkflowsView({
  model,
  onOpenTask,
  onAuthLost,
}: {
  model: string | null
  onOpenTask: (id: number) => void
  onAuthLost: () => void
}) {
  const { t } = useI18n()
  const [flows, setFlows] = useState<WorkflowInfo[] | null>(null)
  const [openId, setOpenId] = useState<string | null>(null)
  const [runs, setRuns] = useState<WorkflowRunInfo[] | null>(null)
  const [runTasks, setRunTasks] = useState<Record<string, AgentTaskInfo[]>>({})
  const [name, setName] = useState('')
  const [steps, setSteps] = useState<WorkflowStepInfo[]>([{ title: '', prompt: '' }])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const load = useCallback(async () => {
    try {
      const r = await api.workflows()
      setFlows(r.workflows)
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) onAuthLost()
      setFlows([])
    }
  }, [onAuthLost])

  const loadRuns = useCallback(async (id: string) => {
    try {
      const r = await api.workflow(id)
      setRuns(r.runs)
      const detailed = await Promise.all(
        r.runs
          .filter((run) => run.status === 'running' || run.status === 'completed')
          .slice(0, 3)
          .map(async (run) => {
            const rr = await api.workflowRun(run.id)
            return [run.id, rr.tasks] as const
          }),
      )
      setRunTasks(Object.fromEntries(detailed))
    } catch {
      setRuns([])
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  useEffect(() => {
    if (!openId) return
    void loadRuns(openId)
    const timer = setInterval(() => {
      const active = runs?.some((r) => r.status === 'running')
      if (active) void loadRuns(openId)
    }, 2000)
    return () => clearInterval(timer)
  }, [openId, loadRuns, runs])

  const create = async () => {
    const valid = steps.filter((s) => s.title.trim() && s.prompt.trim().length >= 4)
    if (name.trim().length === 0 || valid.length === 0) return
    setBusy(true)
    setError(null)
    try {
      const r = await api.createWorkflow({ name: name.trim(), steps: valid })
      setName('')
      setSteps([{ title: '', prompt: '' }])
      await load()
      setOpenId(r.workflow.id)
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }

  const run = async (id: string) => {
    if (!model) {
      setError(t.homeNeedModel)
      return
    }
    setError(null)
    try {
      await api.runWorkflow(id, model)
      await loadRuns(id)
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
    }
  }

  const remove = async (id: string) => {
    try {
      await api.deleteWorkflow(id)
      if (openId === id) setOpenId(null)
      await load()
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
    }
  }

  const statusLabel = (s: string) =>
    s === 'completed' ? t.runCompleted : s === 'partial' ? t.runPartial : s === 'failed' ? t.runFailed : t.runRunning

  const roleLabel = (r?: string) => {
    if (!r) return ''
    const map: Record<string, string> = {
      orchestrator: t.roleOrchestrator, researcher: t.roleResearcher, engineer: t.roleEngineer,
      frontend: t.roleFrontend, backend: t.roleBackend, creative: t.roleCreative,
      security: t.roleSecurity, qa: t.roleQa, writer: t.roleWriter,
    }
    return map[r] ?? r
  }

  const openFlow = flows?.find((f) => f.id === openId)

  return (
    <div className="flex h-full min-h-0 flex-col">
      <SectionHeader title={t.workflowsTitle} sub={t.workflowsSub} />
      {error && <p role="alert" className="border-b border-line bg-surface px-6 py-1.5 text-xs text-fault-text">{error}</p>}

      {/* new workflow composer */}
      <div className="border-b border-line px-6 py-3">
        <div className="flex flex-wrap items-end gap-2">
          <label className="flex flex-col gap-1 text-xs">
            <span className="text-dim">{t.wfName}</span>
            <Input value={name} onChange={(e) => setName(e.target.value)} className="h-9 w-44 rounded-md text-sm" dir="auto" />
          </label>
          <Button onClick={() => void create()} disabled={busy} className="h-9 gap-1 rounded-md text-sm">
            {busy ? <Loader2 size={13} className="animate-spin" /> : <Plus size={13} />}
            {t.newWorkflow}
          </Button>
        </div>
        <div className="mt-3 flex flex-col gap-2">
          {steps.map((s, i) => (
            <div key={i} className="grid gap-2 rounded-md border border-line bg-surface p-2 lg:grid-cols-[160px_1fr_150px]">
              <Input
                value={s.title}
                onChange={(e) => setSteps((prev) => prev.map((x, j) => (j === i ? { ...x, title: e.target.value } : x)))}
                placeholder={t.wfStepTitle}
                className="h-8 rounded-md text-xs"
                dir="auto"
              />
              <Input
                value={s.prompt}
                onChange={(e) => setSteps((prev) => prev.map((x, j) => (j === i ? { ...x, prompt: e.target.value } : x)))}
                placeholder={t.wfStepPrompt}
                className="h-8 rounded-md text-xs"
                dir="auto"
              />
              <div className="flex items-center gap-1">
                <select
                  value={s.role ?? ''}
                  onChange={(e) => setSteps((prev) => prev.map((x, j) => (j === i ? { ...x, role: e.target.value || undefined } : x)))}
                  className="h-8 w-full rounded-md border border-input bg-canvas px-1.5 text-xs outline-none"
                >
                  <option value="">{t.wfStepRole}</option>
                  {AGENT_ROLE_IDS.filter((r) => r !== 'orchestrator').map((r) => (
                    <option key={r} value={r}>{roleLabel(r)}</option>
                  ))}
                </select>
                {steps.length > 1 && (
                  <Button variant="ghost" size="icon" aria-label={t.cancel} onClick={() => setSteps((prev) => prev.filter((_, j) => j !== i))} className="size-8 shrink-0 rounded-md text-dim hover:text-fault-text">
                    <Trash2 size={13} />
                  </Button>
                )}
              </div>
            </div>
          ))}
          <Button variant="outline" size="sm" onClick={() => setSteps((prev) => [...prev, { title: '', prompt: '' }])} className="h-8 w-fit gap-1 rounded-md text-xs">
            <Plus size={13} />
            {t.addStep}
          </Button>
        </div>
      </div>

      {/* list + open detail */}
      <div className="min-h-0 flex-1 overflow-y-auto p-6">
        {flows === null ? (
          <PageLoader />
        ) : flows.length === 0 ? (
          <p className="rounded-md border border-line bg-surface px-4 py-8 text-center text-xs text-dim">{t.noWorkflows}</p>
        ) : (
          <div className="flex flex-col gap-4">
            {flows.map((f) => (
              <article key={f.id} className="overflow-hidden rounded-lg border border-line bg-surface">
                <header className="flex items-center gap-2 border-b border-line px-4 py-2.5">
                  <button type="button" onClick={() => setOpenId(openId === f.id ? null : f.id)} className="min-w-0 flex-1 text-start">
                    <p className="truncate text-sm font-semibold">{f.name}</p>
                    <p className="mt-0.5 truncate text-xs text-dim" dir="auto">{parseSteps(f.steps).map((s) => s.title).join(' ← ')}</p>
                  </button>
                  <span className="shrink-0 font-mono text-[10px] text-dim" dir="ltr">{parseSteps(f.steps).length} {t.wfSteps}</span>
                  <Button variant="outline" size="sm" onClick={() => void run(f.id)} className="h-8 gap-1 rounded-md text-xs">
                    <Play size={12} />
                    {t.runWorkflow}
                  </Button>
                  <Button variant="ghost" size="icon" aria-label={t.deleteChat} onClick={() => void remove(f.id)} className="size-8 shrink-0 rounded-md text-dim hover:text-fault-text">
                    <Trash2 size={13} />
                  </Button>
                </header>
                {openId === f.id && (
                  <div className="border-b border-line px-4 py-3">
                    <ol className="flex flex-col gap-1.5">
                      {parseSteps(f.steps).map((s, i) => (
                        <li key={i} className="flex items-center gap-2 text-xs">
                          <span className="font-mono text-[10px] text-dim" dir="ltr">{String(i + 1).padStart(2, '0')}</span>
                          <span className="font-semibold">{s.title}</span>
                          {s.role && <span className="rounded-sm border border-line px-1.5 py-0.5 text-[10px] text-dim">{roleLabel(s.role)}</span>}
                          <span className="min-w-0 flex-1 truncate text-dim" dir="auto">{s.prompt}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                )}
                {openId === f.id && runs && runs.length > 0 && (
                  <div className="px-4 py-3">
                    <p className="mb-2 font-display text-xs font-semibold tracking-wide">{t.runsTitle}</p>
                    <ul className="flex flex-col gap-1.5">
                      {runs.slice(0, 5).map((r) => (
                        <li key={r.id} className="flex items-center gap-2 text-xs">
                          <span className={`size-1.5 shrink-0 rounded-full ${r.status === 'completed' ? 'bg-signal' : r.status === 'failed' ? 'bg-fault' : r.status === 'partial' ? 'bg-signal/60' : 'animate-pulse bg-signal'}`} />
                          <span className="font-mono text-[10px] text-dim" dir="ltr">{new Date(r.started_at).toLocaleTimeString('en-GB')}</span>
                          <span>{statusLabel(r.status)}</span>
                          <span className="ms-auto flex items-center gap-1">
                            {(runTasks[r.id] ?? []).map((task) => (
                              <button
                                key={task.id}
                                type="button"
                                onClick={() => onOpenTask(task.id)}
                                className="rounded-sm border border-line px-1.5 py-0.5 font-mono text-[10px] text-dim transition-colors hover:border-border-strong hover:text-body"
                                dir="ltr"
                              >
                                #{task.id} {task.status}
                              </button>
                            ))}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </article>
            ))}
          </div>
        )}
      </div>
      {openFlow && <span className="sr-only">{openFlow.name}</span>}
    </div>
  )
}
