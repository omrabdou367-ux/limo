'use client'

import { useCallback, useEffect, useState } from 'react'
import { ArrowUpRight, Check, Download, ExternalLink, GitBranch, History, Loader2, RefreshCw, ShieldAlert, ShieldCheck, Trash2, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { api, ApiError, type CompatibilityAssessment, type DiscoveredSkill, type DiscoveryResponse, type SecurityAssessment, type SkillEventRow, type SkillImportInfo, type SkillInfo, type SkillInspectionReport } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { cn } from '@/lib/utils'
import { PageLoader, SectionHeader } from './shared'

/**
 * Allimni — the Universal Skills Ecosystem (LIMO #11).
 *
 * Four real surfaces, zero fabrication:
 *  - Discover: live search over skills.sh (the same public endpoint the
 *    official CLI uses) + the local library; Arabic/English natural language
 *    is converted to keywords TRANSPARENTLY (the effective query is shown);
 *  - Import: the 10-step approval workflow — 12-check report rendered
 *    verbatim + risk level + compatibility + capability summary;
 *  - Library: enable/disable, update checks, removal — the real registry;
 *  - History: the immutable activity log.
 *
 * Unavailable things are labelled unavailable (trending/curated need Vercel
 * OIDC; external audits the same). No ratings, no fake counts.
 */

type Tab = 'discover' | 'import' | 'library' | 'history'

const STATUS_STYLE: Record<string, string> = {
  verified: 'border-signal-text/40 text-signal-text dark:text-signal',
  not_detected: 'border-line text-dim',
  not_tested: 'border-dashed border-border-strong text-rust-text',
  failed: 'border-fault/50 text-fault-text',
  unknown: 'border-dashed border-border-strong text-dim',
}

const RISK_STYLE: Record<string, string> = {
  NONE: 'border-line text-dim',
  LOW: 'border-signal-text/40 text-signal-text dark:text-signal',
  MEDIUM: 'border-border-strong text-rust-text',
  HIGH: 'border-fault/50 text-fault-text',
  CRITICAL: 'border-fault text-fault-text',
  UNKNOWN: 'border-dashed border-border-strong text-dim',
}

const COMPAT_STYLE: Record<string, string> = {
  COMPATIBLE: 'border-signal-text/40 text-signal-text dark:text-signal',
  PARTIALLY_COMPATIBLE: 'border-border-strong text-rust-text',
  INCOMPATIBLE: 'border-fault/50 text-fault-text',
  UNKNOWN: 'border-dashed border-border-strong text-dim',
}

const EVENT_KEY: Record<string, string> = {
  discovered: 'alEventDiscovered',
  inspected: 'alEventInspected',
  approved: 'alEventApproved',
  rejected: 'alEventRejected',
  installed: 'alEventInstalled',
  enabled: 'alEventEnabled',
  disabled: 'alEventDisabled',
  update_check: 'alEventUpdateCheck',
  update_available: 'alEventUpdateAvailable',
  removed: 'alEventRemoved',
  permission_denied: 'alEventPermissionDenied',
}

function fmtInstalls(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`
  return String(n)
}

const isGitHubSource = (s: string) => /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(s) && !s.includes(' ')

export function AllimniView({ onAuthLost, onInstalled }: { onAuthLost: () => void; onInstalled: () => void }) {
  const { t } = useI18n()
  const [tab, setTab] = useState<Tab>('discover')

  // ---- discover
  const [q, setQ] = useState('')
  const [searching, setSearching] = useState(false)
  const [discovery, setDiscovery] = useState<DiscoveryResponse | null>(null)
  const [searchError, setSearchError] = useState<string | null>(null)
  const [importing, setImporting] = useState<string | null>(null)

  // ---- import (approval workflow)
  const [url, setUrl] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [imports, setImports] = useState<Array<SkillImportInfo & { report?: string | null }> | null>(null)
  const [report, setReport] = useState<SkillInspectionReport | null>(null)
  const [security, setSecurity] = useState<SecurityAssessment | null>(null)
  const [compatibility, setCompatibility] = useState<CompatibilityAssessment | null>(null)
  const [reportFor, setReportFor] = useState<string | null>(null)
  const [deciding, setDeciding] = useState<string | null>(null)

  // ---- library
  const [skills, setSkills] = useState<SkillInfo[] | null>(null)
  const [checking, setChecking] = useState<string | null>(null)
  const [updateMsg, setUpdateMsg] = useState<string | null>(null)

  // ---- history
  const [events, setEvents] = useState<SkillEventRow[] | null>(null)

  // ---------------------------------------------------------------- loaders
  const loadImports = useCallback(async () => {
    try {
      const r = await api.skillImports()
      setImports(r.imports)
      const awaiting = r.imports.find((i) => i.status === 'awaiting_approval')
      if (awaiting) {
        const det = await api.skillImport(awaiting.id)
        setReportFor(awaiting.id)
        try {
          const p = JSON.parse(det.import.report ?? '{}') as { report?: SkillInspectionReport; security?: SecurityAssessment; compatibility?: CompatibilityAssessment }
          setReport(p.report ?? null)
          setSecurity(p.security ?? null)
          setCompatibility(p.compatibility ?? null)
        } catch {
          setReport(null)
        }
      }
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) onAuthLost()
      setImports([])
    }
  }, [onAuthLost])

  const loadSkills = useCallback(async () => {
    try {
      const r = await api.skills()
      setSkills(r.skills)
    } catch {
      setSkills([])
    }
  }, [])

  const loadEvents = useCallback(async () => {
    try {
      const r = await api.skillEvents()
      setEvents(r.events)
    } catch {
      setEvents([])
    }
  }, [])

  useEffect(() => {
    void loadImports()
    void loadSkills()
  }, [loadImports, loadSkills])

  useEffect(() => {
    if (tab === 'history') void loadEvents()
    if (tab === 'library') void loadSkills()
  }, [tab, loadEvents, loadSkills])

  // ---------------------------------------------------------------- discover
  const search = async () => {
    if (q.trim().length < 2) return
    setSearching(true)
    setSearchError(null)
    try {
      const r = await api.discoverSkills(q.trim(), { limit: 20 })
      setDiscovery(r)
      if (tab !== 'discover') setTab('discover')
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) onAuthLost()
      setSearchError(e instanceof ApiError ? e.message : String(e))
    } finally {
      setSearching(false)
    }
  }

  const inspectDiscovered = async (s: DiscoveredSkill) => {
    const key = `${s.provider}:${s.id}`
    setImporting(key)
    setSearchError(null)
    try {
      const payload = isGitHubSource(s.source)
        ? { source: s.source, skillId: s.id.split('/').slice(2).join('/') || s.name, ...(s.installs !== null ? { installs: s.installs } : {}) }
        : { url: s.sourceUrl ?? s.id }
      const r = await api.importSkill(payload)
      if (r.report) setReport(r.report)
      setSecurity(r.security ?? null)
      setCompatibility(r.compatibility ?? null)
      setReportFor(r.import.id)
      setTab('import')
      await loadImports()
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) onAuthLost()
      // honest failure path: a blocked inspection still SHOWS its verbatim
      // report — fetched from the server row, never re-assembled client-side
      setSearchError(e instanceof ApiError ? e.message : String(e))
      try {
        const expectedUrl = isGitHubSource(s.source) ? `https://github.com/${s.source}` : (s.sourceUrl ?? s.id)
        const list = await api.skillImports()
        const mine = list.imports.find((i) => i.url === expectedUrl)
        if (mine) {
          const det = await api.skillImport(mine.id)
          if (det.import.report) {
            const p = JSON.parse(det.import.report) as { report?: SkillInspectionReport; security?: SecurityAssessment; compatibility?: CompatibilityAssessment }
            setReport(p.report ?? null)
            setSecurity(p.security ?? null)
            setCompatibility(p.compatibility ?? null)
            setReportFor(mine.id)
            setTab('import')
          }
        }
      } catch {
        /* the message alone is shown */
      }
    } finally {
      setImporting(null)
    }
  }

  // ---------------------------------------------------------------- import
  const startImport = async () => {
    if (url.trim().length < 8) return
    setBusy(true)
    setError(null)
    setReport(null)
    setReportFor(null)
    try {
      const r = await api.importSkill({ url: url.trim() })
      if (r.report) setReport(r.report)
      setSecurity(r.security ?? null)
      setCompatibility(r.compatibility ?? null)
      setReportFor(r.import.id)
      await loadImports()
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
      try {
        const list = await api.skillImports()
        const mine = list.imports.find((i) => i.url === url.trim())
        if (mine) {
          const det = await api.skillImport(mine.id)
          if (det.import.report) {
            const p = JSON.parse(det.import.report) as { report?: SkillInspectionReport; security?: SecurityAssessment; compatibility?: CompatibilityAssessment }
            setReport(p.report ?? null)
            setSecurity(p.security ?? null)
            setCompatibility(p.compatibility ?? null)
            setReportFor(mine.id)
          }
        }
      } catch {
        /* the message alone is shown */
      }
    } finally {
      setBusy(false)
    }
  }

  const decide = async (id: string, decision: 'approve' | 'reject') => {
    setDeciding(id)
    setError(null)
    try {
      await api.decideSkillImport(id, decision)
      if (decision === 'approve') onInstalled()
      setReport(null)
      setReportFor(null)
      setSecurity(null)
      setCompatibility(null)
      await loadImports()
      await loadSkills()
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
    } finally {
      setDeciding(null)
    }
  }

  // ---------------------------------------------------------------- library
  const toggle = async (slug: string, status: 'active' | 'disabled') => {
    try {
      await api.setSkillStatus(slug, status)
      await loadSkills()
    } catch {
      /* the row stays as-is; next load shows the truth */
    }
  }

  const checkUpdate = async (slug: string) => {
    setChecking(slug)
    setUpdateMsg(null)
    try {
      const r = await api.checkSkillUpdate(slug)
      if (!r.update.checked) setUpdateMsg(`${slug}: ${r.update.reason ?? ''}`)
      else if (r.update.changed) setUpdateMsg(`${slug}: ${t.alUpdateFound} — ${r.update.headCommit?.slice(0, 12) ?? ''}`)
      else setUpdateMsg(`${slug}: ${r.update.headCommit ? `${t.alUpToDate} (${r.update.headCommit.slice(0, 12)})` : (r.update.reason ?? '')}`)
      await loadSkills()
    } catch (e) {
      setUpdateMsg(e instanceof ApiError ? e.message : String(e))
    } finally {
      setChecking(null)
    }
  }

  const remove = async (slug: string) => {
    try {
      await api.deleteSkill(slug)
      await loadSkills()
      onInstalled()
    } catch {
      /* next load shows the truth */
    }
  }

  // ---------------------------------------------------------------- labels
  const statusLabel = (s: string) =>
    s === 'verified' ? t.checkVerified : s === 'not_detected' ? t.checkNotDetected : s === 'not_tested' ? t.checkNotTested : s === 'failed' ? t.checkFailed : t.checkUnknown
  const verdictLabel = (v: string) => (v === 'pass' ? t.verdictPass : v === 'needs_review' ? t.verdictNeedsReview : t.verdictFail)
  const riskLabel = (r: string) => (t as unknown as Record<string, string>)[`alRisk_${r}`] ?? r
  const compatLabel = (c: string) => (t as unknown as Record<string, string>)[`alCompat_${c}`] ?? c
  const provLabel = (p: string) => (t as unknown as Record<string, string>)[`alProv_${p}`] ?? p
  const provStatus = (s: string) => (s === 'clean' ? t.alStatusClean : s === 'findings' ? t.alStatusFindings : s === 'not_run' ? t.alProvNotRun : t.alProvUnavail)

  const TABS: Array<{ id: Tab; label: string }> = [
    { id: 'discover', label: t.alTabDiscover },
    { id: 'import', label: t.alTabImport },
    { id: 'library', label: t.alTabLibrary },
    { id: 'history', label: t.alTabHistory },
  ]

  // ---------------------------------------------------------------- render
  return (
    <div className="flex h-full min-h-0 flex-col">
      <SectionHeader title={t.allimniTitle} sub={t.allimniSub} slogan={t.allimniSlogan} />

      {/* the discovery bar — always visible: ALLIMNI starts from intent */}
      <div className="border-b border-line px-6 py-3">
        <div className="flex max-w-2xl items-center gap-2">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && void search()}
            placeholder={t.alSearchPh}
            className="h-10 rounded-full px-4 text-sm"
          />
          <Button onClick={() => void search()} disabled={searching} className="h-10 shrink-0 gap-1.5 rounded-full px-5 text-sm">
            {searching ? <Loader2 size={14} className="animate-spin" /> : <Download size={14} />}
            {searching ? t.alSearching : t.alSearchBtn}
          </Button>
        </div>
        {searchError && <p role="alert" className="mt-2 max-w-2xl text-xs text-fault-text">{searchError}</p>}
      </div>

      {/* tabs */}
      <div className="flex items-center gap-1 border-b border-line px-6 py-2" role="tablist" aria-label={t.allimniTitle}>
        {TABS.map((tb) => (
          <button
            key={tb.id}
            role="tab"
            aria-selected={tab === tb.id}
            onClick={() => setTab(tb.id)}
            className={cn(
              'rounded-full px-3.5 py-1.5 text-xs font-semibold transition-colors',
              tab === tb.id ? 'bg-signal text-primary-foreground' : 'text-dim hover:bg-surface hover:text-signal-text',
            )}
          >
            {tb.label}
          </button>
        ))}
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto p-6">
        {/* ================================================= DISCOVER */}
        {tab === 'discover' && (
          <section className="mx-auto max-w-3xl" aria-label={t.alTabDiscover}>
            {discovery && (
              <div className="mb-4 flex flex-wrap items-center gap-2 text-[11px] text-dim">
                <span>
                  {t.alSearchedFor}: <span className="font-mono" dir="ltr">{discovery.effectiveQuery || '—'}</span>
                </span>
                {discovery.mappings.map((m, i) => (
                  <span key={i} className="rounded-full border border-line px-2 py-0.5" dir="ltr">{m.from} → {m.to}</span>
                ))}
              </div>
            )}

            {discovery?.providers.map((p) =>
              p.unavailable ? (
                <p key={p.provider} className="mb-3 rounded-2xl border border-dashed border-border-strong bg-surface px-4 py-3 text-xs text-rust-text">
                  {p.provider} — {t.alProviderUnavailable}: {p.reason}
                </p>
              ) : null,
            )}

            {discovery && discovery.effectiveQuery === '' && (
              <p className="rounded-2xl border border-dashed border-border-strong bg-surface px-4 py-6 text-center text-xs text-dim">{t.alNoTerms}</p>
            )}

            {discovery && discovery.effectiveQuery !== '' && discovery.skills.length === 0 && (
              <div className="rounded-2xl border border-line bg-surface px-4 py-6 text-center">
                <p className="text-xs font-semibold">{t.alNoResults}</p>
                <p className="mt-1 text-[11px] text-dim">{t.alNoResultsSub}</p>
              </div>
            )}

            {discovery && discovery.skills.length > 0 && (
              <ul className="flex flex-col gap-2">
                {discovery.skills.map((s) => {
                  const key = `${s.provider}:${s.id}`
                  const github = isGitHubSource(s.source)
                  return (
                    <li key={key} className="rounded-2xl border border-line bg-surface p-3.5 transition-colors hover:border-border-strong">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="min-w-0 truncate text-sm font-semibold" dir="ltr" title={s.id}>{s.name}</span>
                        <span className="shrink-0 rounded-full border border-line px-2 py-0.5 font-mono text-[10px] text-dim" dir="ltr">{s.provider}</span>
                        {s.provider === 'local' ? (
                          <span className="shrink-0 rounded-full border border-signal-text/40 px-2 py-0.5 text-[10px] text-signal-text dark:text-signal">{t.alLocalHit}</span>
                        ) : s.installs !== null ? (
                          <span className="shrink-0 text-[11px] text-dim" dir="ltr" title={t.alInstalls}>{fmtInstalls(s.installs)} {t.alInstalls}</span>
                        ) : null}
                        <div className="ms-auto flex shrink-0 items-center gap-2">
                          {s.sourceUrl && (
                            <a
                              href={s.sourceUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="flex items-center gap-1 rounded-full px-2 py-1 text-[11px] text-dim transition-colors hover:text-signal-text"
                              dir="ltr"
                            >
                              <ExternalLink size={11} />
                              {s.source}
                            </a>
                          )}
                          {s.provider === 'local' ? (
                            <span className="flex items-center gap-1 text-[11px] text-dim"><Check size={12} />{t.alLocalHit}</span>
                          ) : github ? (
                            <Button
                              size="sm"
                              onClick={() => void inspectDiscovered(s)}
                              disabled={importing === key}
                              className="h-8 gap-1.5 rounded-full px-3 text-xs"
                            >
                              {importing === key ? <Loader2 size={12} className="animate-spin" /> : <ShieldAlert size={12} />}
                              {importing === key ? t.inspecting : t.alInspectInstall}
                            </Button>
                          ) : (
                            <span className="max-w-56 text-[10px] text-dim">{t.alNotGithub}</span>
                          )}
                        </div>
                      </div>
                    </li>
                  )
                })}
              </ul>
            )}

            {!discovery && (
              <p className="rounded-2xl border border-line bg-surface px-4 py-6 text-center text-xs text-dim">{t.alSearchPh}</p>
            )}
          </section>
        )}

        {/* ================================================= IMPORT */}
        {tab === 'import' && (
          <section className="mx-auto max-w-3xl" aria-label={t.alTabImport}>
            <div className="mb-4 flex max-w-xl items-center gap-2">
              <Input
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && void startImport()}
                placeholder="https://github.com/owner/repo"
                dir="ltr"
                className="h-9 rounded-full font-mono text-xs"
              />
              <Button onClick={() => void startImport()} disabled={busy} className="h-9 shrink-0 gap-1.5 rounded-full px-4 text-sm">
                {busy ? <Loader2 size={13} className="animate-spin" /> : <ShieldAlert size={13} />}
                {busy ? t.inspecting : t.importBtn}
              </Button>
            </div>
            {error && <p role="alert" className="mb-3 max-w-xl text-xs text-fault-text">{error}</p>}

            {report && (
              <div aria-label={t.inspectionTitle}>
                <div className="mb-3 flex flex-wrap items-center gap-2">
                  <h2 className="font-display text-sm font-semibold tracking-wide">{t.inspectionTitle}</h2>
                  <span className="font-mono text-[11px] text-dim" dir="ltr">{report.repo.owner}/{report.repo.name}</span>
                  <span
                    className={cn(
                      'rounded-full border px-2 py-0.5 text-[11px] font-semibold',
                      report.verdict === 'pass' ? 'border-signal-text/40 text-signal-text dark:text-signal' : report.verdict === 'needs_review' ? 'border-border-strong text-rust-text' : 'border-fault/50 text-fault-text',
                    )}
                  >
                    {verdictLabel(report.verdict)}
                  </span>
                  {security && (
                    <span className={cn('rounded-full border px-2 py-0.5 text-[11px] font-semibold', RISK_STYLE[security.riskLevel])}>
                      {t.alRiskLevel}: {riskLabel(security.riskLevel)}
                    </span>
                  )}
                  {compatibility && (
                    <span className={cn('rounded-full border px-2 py-0.5 text-[11px] font-semibold', COMPAT_STYLE[compatibility.state])}>
                      {compatLabel(compatibility.state)}
                    </span>
                  )}
                  <span className="ms-auto font-mono text-[10px] text-dim" dir="ltr">
                    {t.coverage}: {report.coverage.scanned}/{report.coverage.total}
                  </span>
                </div>

                {/* provenance line — where the data came from */}
                <p className="mb-3 flex flex-wrap items-center gap-2 text-[10px] text-dim" dir="ltr">
                  <GitBranch size={10} />
                  {report.commit ? `${t.alCommit}: ${report.commit.slice(0, 12)}` : `${t.alCommit}: —`}
                  {report.target.dir && <span>· {t.alSkillDir}: {report.target.dir}</span>}
                  {report.dataSource === 'jsdelivr' && <span className="rounded-full border border-line px-2 py-0.5">{t.alViaMirror}</span>}
                </p>

                <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
                  {report.checks.map((c) => (
                    <li key={c.id} className="flex items-start gap-3 px-3 py-2">
                      <span className={cn('mt-0.5 shrink-0 rounded-full border px-1.5 py-0.5 text-[10px] font-semibold', STATUS_STYLE[c.status] ?? 'border-line text-dim')}>
                        {statusLabel(c.status)}
                      </span>
                      <div className="min-w-0">
                        <p className="text-xs font-semibold">{c.label}</p>
                        <p className="mt-0.5 break-words text-[11px] leading-relaxed text-dim">{c.detail}</p>
                        {c.evidence && c.evidence.length > 0 && (
                          <ul className="mt-1 flex flex-col gap-0.5" dir="ltr">
                            {c.evidence.map((e, i) => (
                              <li key={i} className="font-mono text-[10px] text-dim">• {e}</li>
                            ))}
                          </ul>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>

                {/* security dimensions — provenance-labelled */}
                {security && (
                  <div className="mt-4">
                    <h3 className="mb-2 font-display text-xs font-semibold tracking-wide">{t.alSecurityDims}</h3>
                    <ul className="grid gap-2 sm:grid-cols-2">
                      {security.dimensions.map((d) => (
                        <li key={d.id} className="rounded-2xl border border-line bg-surface px-3 py-2">
                          <div className="flex items-center gap-2">
                            {d.status === 'clean' ? <ShieldCheck size={13} className="shrink-0 text-signal-text dark:text-signal" /> : <ShieldAlert size={13} className="shrink-0 text-rust-text" />}
                            <span className="text-xs font-semibold">{d.label}</span>
                            <span className="ms-auto rounded-full border border-line px-2 py-0.5 text-[10px] text-dim">{provLabel(d.provenance)}</span>
                          </div>
                          <p className="mt-1 text-[11px] leading-relaxed text-dim">
                            <span className={cn('font-semibold', d.status === 'findings' ? 'text-fault-text' : d.status === 'clean' ? 'text-signal-text dark:text-signal' : 'text-rust-text')}>{provStatus(d.status)}</span>
                            {' — '}{d.detail}
                          </p>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* compatibility + capability summary */}
                {compatibility && (
                  <div className="mt-4 flex flex-col gap-3">
                    <div className="rounded-2xl border border-line bg-surface px-4 py-3">
                      <h3 className="font-display text-xs font-semibold tracking-wide">{t.alCapability}</h3>
                      <p className="mt-1 text-xs leading-relaxed">{compatibility.capabilitySummary}</p>
                    </div>
                    <div className="rounded-2xl border border-line bg-surface px-4 py-3">
                      <h3 className="font-display text-xs font-semibold tracking-wide">{t.alCompatReqs}</h3>
                      <ul className="mt-1.5 flex flex-col gap-1">
                        {compatibility.requirements.map((r) => (
                          <li key={r.id} className="flex items-start gap-2 text-[11px]">
                            <span className={cn('mt-0.5 shrink-0 font-semibold', r.met ? 'text-signal-text dark:text-signal' : 'text-rust-text')} dir="ltr">{r.met ? '✓' : '!'}</span>
                            <span><span className="font-semibold">{r.label}</span> — <span className="text-dim">{r.detail}</span></span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="rounded-2xl border border-line bg-surface px-4 py-3">
                      <h3 className="font-display text-xs font-semibold tracking-wide">{t.alLimits}</h3>
                      <ul className="mt-1.5 flex flex-col gap-1 text-[11px] text-dim">
                        {compatibility.limitations.map((l, i) => (
                          <li key={i}>• {l}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}

                {(report.blockers.length > 0 || report.warnings.length > 0 || (report.dependencies?.length ?? 0) > 0) && (
                  <div className="mt-3 flex flex-col gap-2 text-xs">
                    {report.blockers.length > 0 && (
                      <p className="rounded-2xl border border-fault/40 bg-surface px-3 py-2 text-fault-text">
                        {t.blockers}: {report.blockers.join(' · ')}
                      </p>
                    )}
                    {report.warnings.length > 0 && (
                      <p className="rounded-2xl border border-line bg-surface px-3 py-2 text-rust-text">
                        {t.warnings}: {report.warnings.join(' · ')}
                      </p>
                    )}
                    {(report.dependencies?.length ?? 0) > 0 && (
                      <p className="rounded-2xl border border-line bg-surface px-3 py-2 text-dim">
                        {t.depsDeclared}: {report.dependencies.map((d) => `${d.file} (${d.deps})`).join(' · ')}
                      </p>
                    )}
                    {report.files.length > 0 && (
                      <p className="rounded-2xl border border-line bg-surface px-3 py-2 text-dim">
                        {t.alFilesToInstall}: {report.files.length} · {(report.files.reduce((a, f) => a + f.bytes, 0) / 1024).toFixed(1)}KB
                      </p>
                    )}
                  </div>
                )}

                {reportFor && report.verdict !== 'fail' && !(security?.installBlocked) && (
                  <div className="mt-4 flex items-center gap-2">
                    <Button onClick={() => void decide(reportFor, 'approve')} disabled={deciding === reportFor} className="h-9 gap-1.5 rounded-full bg-signal px-4 text-sm font-semibold text-primary-foreground hover:bg-signal/90">
                      {deciding === reportFor ? <Loader2 size={13} className="animate-spin" /> : <Check size={14} />}
                      {t.approveInstall}
                    </Button>
                    <Button variant="outline" onClick={() => void decide(reportFor, 'reject')} disabled={deciding === reportFor} className="h-9 gap-1.5 rounded-full px-4 text-sm">
                      <X size={14} />
                      {t.rejectImport}
                    </Button>
                  </div>
                )}
                {reportFor && security?.installBlocked && (
                  <p className="mt-4 rounded-2xl border border-fault/40 bg-surface px-4 py-3 text-xs font-semibold text-fault-text">
                    {t.alRiskLevel}: {riskLabel(security.riskLevel)} — {t.alEventPermissionDenied}
                  </p>
                )}
              </div>
            )}

            <div className="mt-6" aria-label={t.alTabImport}>
              {imports === null ? (
                <PageLoader />
              ) : imports.length === 0 ? (
                <p className="rounded-2xl border border-line bg-surface px-4 py-6 text-center text-xs text-dim">{t.noImports}</p>
              ) : (
                <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
                  {imports.map((imp) => (
                    <li key={imp.id} className="flex items-center gap-3 px-3 py-2 text-xs">
                      <span className={cn('size-1.5 shrink-0 rounded-full', imp.status === 'installed' ? 'bg-signal' : imp.status === 'rejected' || imp.status === 'failed' ? 'bg-fault' : 'animate-pulse bg-signal')} />
                      <span className="min-w-0 flex-1 truncate font-mono text-[11px]" dir="ltr">{imp.url}</span>
                      <span className="shrink-0 text-dim">{imp.status}</span>
                      <span className="shrink-0 font-mono text-[10px] text-dim" dir="ltr">{new Date(imp.requested_at).toLocaleString('en-GB')}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </section>
        )}

        {/* ================================================= LIBRARY */}
        {tab === 'library' && (
          <section className="mx-auto max-w-3xl" aria-label={t.alTabLibrary}>
            {updateMsg && <p className="mb-3 rounded-2xl border border-line bg-surface px-4 py-2 text-xs text-dim" dir="auto">{updateMsg}</p>}
            {skills === null ? (
              <PageLoader />
            ) : skills.length === 0 ? (
              <p className="rounded-2xl border border-line bg-surface px-4 py-6 text-center text-xs text-dim">{t.noSkills}</p>
            ) : (
              <ul className="flex flex-col gap-2">
                {skills.map((s) => (
                  <li key={s.slug} className="rounded-2xl border border-line bg-surface p-3.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-semibold" dir="ltr">{s.name}</span>
                      <span className="rounded-full border border-line px-2 py-0.5 font-mono text-[10px] text-dim" dir="ltr">{s.provider}</span>
                      {s.risk_level && (
                        <span className={cn('rounded-full border px-2 py-0.5 text-[10px] font-semibold', RISK_STYLE[s.risk_level] ?? 'border-line text-dim')}>
                          {riskLabel(s.risk_level)}
                        </span>
                      )}
                      {s.compatibility && (
                        <span className={cn('rounded-full border px-2 py-0.5 text-[10px] font-semibold', COMPAT_STYLE[s.compatibility] ?? 'border-line text-dim')}>
                          {compatLabel(s.compatibility)}
                        </span>
                      )}
                      {s.update_available && (
                        <span className="flex items-center gap-1 rounded-full border border-border-strong px-2 py-0.5 text-[10px] text-rust-text">
                          <ArrowUpRight size={10} />
                          {t.alUpdateFound}
                        </span>
                      )}
                      <span className="ms-auto text-[10px] text-dim" dir="ltr">{s.installed_at.slice(0, 10)} · {s.file_count} files{s.installs !== null ? ` · ${fmtInstalls(s.installs)} ${t.alInstalls}` : ''}</span>
                    </div>
                    {s.description && <p className="mt-1.5 line-clamp-2 text-[11px] leading-relaxed text-dim" dir="auto">{s.description}</p>}
                    <div className="mt-2.5 flex flex-wrap items-center gap-2">
                      <Button
                        size="sm"
                        variant={s.status === 'active' ? 'outline' : 'default'}
                        onClick={() => void toggle(s.slug, s.status === 'active' ? 'disabled' : 'active')}
                        className="h-7 rounded-full px-3 text-[11px]"
                      >
                        {s.status === 'active' ? t.disableSkill : t.enableSkill}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => void checkUpdate(s.slug)}
                        disabled={checking === s.slug}
                        className="h-7 gap-1 rounded-full px-3 text-[11px]"
                      >
                        {checking === s.slug ? <Loader2 size={11} className="animate-spin" /> : <RefreshCw size={11} />}
                        {t.alCheckUpdate}
                      </Button>
                      {s.update_available && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setUrl(s.source_url ?? `https://github.com/${s.repo_owner}/${s.repo_name}`)
                            setTab('import')
                          }}
                          className="h-7 rounded-full px-3 text-[11px]"
                        >
                          {t.alReinspectUpdate}
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => void remove(s.slug)}
                        className="h-7 gap-1 rounded-full px-3 text-[11px] text-fault-text"
                      >
                        <Trash2 size={11} />
                        {t.removeSkill}
                      </Button>
                      {s.commit_hash && (
                        <span className="ms-auto font-mono text-[10px] text-dim" dir="ltr" title={t.alCommit}>
                          {s.commit_hash.slice(0, 12)}
                        </span>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
        )}

        {/* ================================================= HISTORY */}
        {tab === 'history' && (
          <section className="mx-auto max-w-3xl" aria-label={t.alTabHistory}>
            {events === null ? (
              <PageLoader />
            ) : events.length === 0 ? (
              <p className="rounded-2xl border border-line bg-surface px-4 py-6 text-center text-xs text-dim">{t.alNoEvents}</p>
            ) : (
              <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
                {events.map((ev) => (
                  <li key={ev.id} className="flex items-start gap-3 px-3 py-2 text-xs">
                    <History size={12} className="mt-0.5 shrink-0 text-dim" />
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold">
                        {(t as unknown as Record<string, string>)[EVENT_KEY[ev.action] ?? ''] ?? ev.action}
                        <span className="ms-2 font-mono text-[10px] font-normal text-dim" dir="ltr">{ev.skill_slug}</span>
                      </p>
                      {ev.detail && <p className="mt-0.5 break-words text-[11px] text-dim">{ev.detail}</p>}
                    </div>
                    <span className="shrink-0 font-mono text-[10px] text-dim" dir="ltr">{new Date(ev.created_at).toLocaleString('en-GB')}</span>
                  </li>
                ))}
              </ul>
            )}
          </section>
        )}
      </div>
    </div>
  )
}
