'use client'

import { useCallback, useEffect, useState } from 'react'
import { Check, File as FileIcon, Globe, KeyRound, Loader2, Plus, Radar, ShieldCheck, Sparkles, Trash2, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  api, ApiError,
  type IntegrationCardInfo, type SkillImportInfo, type SkillInfo, type ToolsInventoryResponse,
} from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { setPendingIntegrationsTab } from '@/lib/nav'
import { cn } from '@/lib/utils'
import { PageLoader, SectionHeader } from './shared'

/**
 * LIMO #21 — «المهارات والتكاملات» (the Krea-parity Skills & Integrations
 * center). Three tabs over REAL surfaces only:
 *  - المهارات: the installed library + the real import pipeline (same
 *    startSkillImport the Black Box tool drives — inspection, risk gate,
 *    owner approval in عَلِّمني).
 *  - التكاملات: what is ACTUALLY connected, measured from the vault / the
 *    deploy ledger by GET /api/integrations — every «connect» button lands on
 *    the real flow (vault keys / system map), never a fake catalog.
 *  - الأدوات والإضافات: the registered inventories from
 *    GET /api/system/tools — a tool listed is a tool the code dispatches.
 */

type HubTab = 'skills' | 'integrations' | 'tools'

export function SkillsView({ onAuthLost }: { onAuthLost: () => void }) {
  const { t } = useI18n()
  const [tab, setTab] = useState<HubTab>('skills')

  const tabs: Array<{ id: HubTab; label: string }> = [
    { id: 'skills', label: t.hubTabSkills },
    { id: 'integrations', label: t.hubTabIntegrations },
    { id: 'tools', label: t.hubTabTools },
  ]

  return (
    <div className="flex h-full min-h-0 flex-col">
      <SectionHeader title={t.skillsTitle} sub={t.skillsSub} />
      <nav className="flex gap-1 border-b border-line px-6 py-2" aria-label={t.viewsNav}>
        {tabs.map((x) => (
          <button
            key={x.id}
            type="button"
            aria-pressed={tab === x.id}
            onClick={() => setTab(x.id)}
            className={cn(
              'h-8 rounded-md px-3 text-xs transition-colors',
              tab === x.id ? 'bg-surface font-semibold text-signal-text dark:text-signal' : 'text-dim hover:text-body',
            )}
          >
            {x.label}
          </button>
        ))}
      </nav>
      <div className="min-h-0 flex-1 overflow-hidden">
        {tab === 'skills' && <SkillsLibrary onAuthLost={onAuthLost} />}
        {tab === 'integrations' && <IntegrationsCatalog onAuthLost={onAuthLost} />}
        {tab === 'tools' && <ToolsInventory onAuthLost={onAuthLost} />}
      </div>
    </div>
  )
}

// ------------------------------------------------------------- skills tab

function SkillsLibrary({ onAuthLost }: { onAuthLost: () => void }) {
  const { t } = useI18n()
  const [skills, setSkills] = useState<SkillInfo[] | null>(null)
  const [openSlug, setOpenSlug] = useState<string | null>(null)
  const [files, setFiles] = useState<string[] | null>(null)
  const [file, setFile] = useState<{ path: string; content: string } | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [source, setSource] = useState('')
  const [skillId, setSkillId] = useState('')
  const [imports, setImports] = useState<SkillImportInfo[] | null>(null)
  const [requesting, setRequesting] = useState(false)

  /** refetches the installed library (returns the rows; caller sets state) */
  const fetchSkills = useCallback(async () => (await api.skills()).skills, [])

  const fetchImports = useCallback(async () => {
    try {
      const r = await api.skillImports()
      setImports(r.imports.slice(0, 6))
    } catch {
      setImports([])
    }
  }, [])
  useEffect(() => {
    let cancelled = false
    fetchSkills()
      .then((rows) => { if (!cancelled) setSkills(rows) })
      .catch(() => { if (!cancelled) setSkills([]) })
    void fetchImports()
    return () => { cancelled = true }
  }, [fetchSkills, fetchImports])

  const open = async (slug: string) => {
    if (openSlug === slug) {
      setOpenSlug(null)
      setFiles(null)
      setFile(null)
      return
    }
    setOpenSlug(slug)
    setFiles(null)
    setFile(null)
    try {
      const r = await api.skill(slug)
      setFiles(r.files.map((f) => f.path))
    } catch {
      setFiles([])
    }
  }

  const openFile = async (slug: string, path: string) => {
    try {
      const r = await api.skillFileContent(slug, path)
      setFile({ path, content: r.file.content })
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
    }
  }

  const toggle = async (skill: SkillInfo) => {
    try {
      await api.setSkillStatus(skill.slug, skill.status === 'active' ? 'disabled' : 'active')
      setSkills(await fetchSkills())
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
    }
  }

  const remove = async (slug: string) => {
    try {
      await api.deleteSkill(slug)
      if (openSlug === slug) {
        setOpenSlug(null)
        setFiles(null)
        setFile(null)
      }
      setSkills(await fetchSkills())
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
    }
  }

  /** the REAL import request — same pipeline the box's request_skill_install drives */
  const requestInstall = async () => {
    const s = source.trim()
    if (s.length < 3) return
    setRequesting(true)
    setError(null)
    try {
      const id = skillId.trim()
      // the route's own union — skillId optional, multi-skill repos reply honestly
      const body: { source: string; skillId?: string } = id ? { source: s, skillId: id } : { source: s }
      await api.importSkill(body)
      setSource('')
      setSkillId('')
      await fetchImports()
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
      void fetchImports()
    } finally {
      setRequesting(false)
    }
  }

  const importStatus = (s: string): string =>
    s === 'awaiting_approval' ? t.importAwaiting : s === 'rejected' ? t.importRejected : s === 'failed' || s === 'inspection_failed' ? t.importFailed : s

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="mx-auto flex max-w-3xl flex-col gap-4">
        {/* real install request — inspection + owner gate, nothing auto-installs */}
        <section className="rounded-lg border border-line bg-surface p-4">
          <h3 className="flex items-center gap-2 font-display text-sm font-semibold">
            <Plus size={14} className="text-signal-text dark:text-signal" aria-hidden="true" />
            {t.skillsInstallTitle}
          </h3>
          <p className="mt-1 text-[11px] leading-relaxed text-dim">{t.skillsInstallHint}</p>
          <div className="mt-3 flex flex-col gap-2">
            <div className="flex flex-wrap items-center gap-2">
              <input
                value={source}
                onChange={(e) => setSource(e.target.value)}
                placeholder={t.skillsSourcePh}
                dir="ltr"
                className="h-9 min-w-48 flex-1 rounded-md border border-input bg-canvas px-3 font-mono text-xs outline-none placeholder:text-dim focus:border-border-strong"
              />
              <input
                value={skillId}
                onChange={(e) => setSkillId(e.target.value)}
                placeholder={t.skillsSkillIdPh}
                dir="ltr"
                className="h-9 min-w-44 flex-1 rounded-md border border-input bg-canvas px-3 font-mono text-xs outline-none placeholder:text-dim focus:border-border-strong"
              />
              <Button
                type="button"
                onClick={() => void requestInstall()}
                disabled={requesting || source.trim().length < 3}
                className="h-9 rounded-md bg-signal px-4 text-sm font-semibold text-primary-foreground hover:bg-signal/90 disabled:opacity-40"
              >
                {requesting ? <Loader2 size={14} className="animate-spin" /> : null}
                {t.skillsInstallBtn}
              </Button>
            </div>
          </div>
        </section>

        {error && <p role="alert" className="rounded-md border border-fault-text/40 bg-fault/5 px-3 py-2 text-xs text-fault-text">{error}</p>}

        {imports !== null && imports.length > 0 && (
          <section className="rounded-lg border border-line bg-surface p-4">
            <h3 className="font-display text-sm font-semibold">{t.importsTitle}</h3>
            <ul className="mt-2 flex flex-col gap-1.5">
              {imports.map((r) => (
                <li key={r.id} className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="min-w-0 flex-1 truncate font-mono text-[11px]" dir="ltr">{r.url}</span>
                  <span
                    className={cn(
                      'shrink-0 rounded-sm border px-1.5 py-0.5 text-[10px]',
                      r.status === 'awaiting_approval' ? 'border-signal-text/50 text-signal-text dark:text-signal' : 'border-line text-dim',
                    )}
                  >
                    {importStatus(r.status)}
                  </span>
                </li>
              ))}
            </ul>
          </section>
        )}

        {/* the installed library — unchanged honest rows (#13) */}
        <section>
          <h3 className="mb-2 font-display text-sm font-semibold">{t.skillsTitle}</h3>
          {skills === null ? (
            <PageLoader />
          ) : skills.length === 0 ? (
            <p className="rounded-md border border-line bg-surface px-4 py-8 text-center text-xs text-dim">{t.noSkills}</p>
          ) : (
            <ul className="flex flex-col gap-2">
              {skills.map((s) => (
                <li key={s.id} className="overflow-hidden rounded-lg border border-line bg-surface">
                  <div className="flex flex-wrap items-center gap-2 px-4 py-3">
                    <button type="button" onClick={() => void open(s.slug)} className="min-w-0 flex-1 text-start">
                      <p className="truncate text-sm font-semibold">{s.name}</p>
                      <p className="mt-0.5 truncate text-[11px] text-dim">{s.description || `${s.repo_owner ?? ''}/${s.repo_name ?? ''}`}</p>
                    </button>
                    <span className="font-mono text-[10px] text-dim" dir="ltr">{s.file_count} {t.skillFiles}</span>
                    {s.version && <span className="font-mono text-[10px] text-dim" dir="ltr">v{s.version}</span>}
                    {s.license && <span className="rounded-sm border border-line px-1.5 py-0.5 text-[10px] text-dim" dir="ltr">{s.license}</span>}
                    <span className={cn('rounded-sm border px-1.5 py-0.5 text-[10px]', s.status === 'active' ? 'border-signal-text/40 text-signal-text dark:text-signal' : 'border-line text-dim')}>
                      {s.status === 'active' ? t.enableSkill : t.disableSkill}
                    </span>
                    <Button variant="outline" size="sm" onClick={() => void toggle(s)} className="h-7 gap-1 rounded-md text-[11px]">
                      {s.status === 'active' ? <X size={11} /> : <Check size={11} />}
                      {s.status === 'active' ? t.disableSkill : t.enableSkill}
                    </Button>
                    <Button variant="ghost" size="icon" aria-label={t.removeSkill} onClick={() => void remove(s.slug)} className="size-7 shrink-0 rounded-md text-dim hover:text-fault-text">
                      <Trash2 size={12} />
                    </Button>
                  </div>
                  {openSlug === s.slug && (
                    <div className="border-t border-line px-4 py-3">
                      {files === null ? (
                        <PageLoader />
                      ) : (
                        <div className="flex flex-col gap-2">
                          <ul className="flex flex-wrap gap-1.5">
                            {files.map((f) => (
                              <li key={f}>
                                <button
                                  type="button"
                                  onClick={() => void openFile(s.slug, f)}
                                  className={cn(
                                    'flex items-center gap-1 rounded-sm border px-1.5 py-0.5 font-mono text-[10px] transition-colors',
                                    file?.path === f ? 'border-border-strong text-body' : 'border-line text-dim hover:text-body',
                                  )}
                                  dir="ltr"
                                >
                                  <FileIcon size={10} />
                                  {f}
                                </button>
                              </li>
                            ))}
                          </ul>
                          {file && (
                            <pre className="max-h-72 overflow-auto rounded-md border border-line bg-canvas p-3 font-mono text-[11px] leading-relaxed" dir="ltr">
                              {file.content.slice(0, 20_000)}
                            </pre>
                          )}
                          <p className="font-mono text-[10px] text-dim" dir="ltr">{t.installedAt}: {new Date(s.installed_at).toLocaleString('en-GB')}</p>
                        </div>
                      )}
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  )
}

// -------------------------------------------------------- integrations tab

function IntegrationsCatalog({ onAuthLost }: { onAuthLost: () => void }) {
  const { t } = useI18n()
  const [cards, setCards] = useState<IntegrationCardInfo[] | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    api
      .integrations()
      .then((r) => { if (!cancelled) setCards(r.integrations) })
      .catch((e) => {
        if (e instanceof ApiError && e.status === 401) onAuthLost()
        if (!cancelled) setError(e instanceof ApiError ? e.message : String(e))
      })
    return () => { cancelled = true }
  }, [onAuthLost])

  /** the connect button lands on the REAL flow — deep links measured in #15 */
  const go = (card: IntegrationCardInfo) => {
    if (card.connectArea === 'systemmap') {
      window.dispatchEvent(new CustomEvent('limo:navigate-area', { detail: 'systemmap' }))
    } else {
      setPendingIntegrationsTab('providers')
      window.dispatchEvent(new CustomEvent('limo:navigate-area', { detail: 'integrations' }))
    }
  }

  const kindIcon = (kind: IntegrationCardInfo['kind']) =>
    kind === 'deploy' ? Radar : kind === 'source' ? Globe : Sparkles
  const kindLabel = (kind: IntegrationCardInfo['kind']) =>
    kind === 'deploy' ? t.integKindDeploy : kind === 'source' ? t.integKindSource : t.integKindIntelligence

  if (error) {
    return (
      <div className="p-6">
        <p role="alert" className="mx-auto max-w-2xl rounded-md border border-fault-text/40 bg-fault/5 px-3 py-2 text-xs text-fault-text">{error}</p>
      </div>
    )
  }
  if (cards === null) return <PageLoader />

  return (
    <div className="h-full overflow-y-auto p-6">
      <ul className="mx-auto flex max-w-2xl flex-col gap-2">
        {cards.map((c) => {
          const Icon = kindIcon(c.kind)
          return (
            <li key={c.id} className="rounded-lg border border-line bg-surface p-4">
              <div className="flex flex-wrap items-center gap-2">
                <span className="flex size-9 shrink-0 items-center justify-center rounded-full border border-line bg-canvas text-dim">
                  <Icon size={15} aria-hidden="true" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="flex items-center gap-2 text-sm font-semibold">
                    {c.name}
                    <span className="rounded-sm border border-line px-1.5 py-0.5 text-[10px] font-normal text-dim">{kindLabel(c.kind)}</span>
                  </p>
                  <p className="mt-0.5 text-[11px] leading-relaxed text-dim">{c.detail}</p>
                </div>
                <span
                  className={cn(
                    'shrink-0 rounded-sm border px-1.5 py-0.5 text-[10px] font-semibold',
                    c.connected ? 'border-signal-text/50 bg-signal/5 text-signal-text dark:text-signal' : 'border-line text-dim',
                  )}
                  data-testid={`integration-${c.id}-state`}
                >
                  {c.connected ? t.integConnected : t.integNotConnected}
                </span>
                {!c.connected && (
                  <Button variant="outline" size="sm" onClick={() => go(c)} className="h-7 gap-1 rounded-md text-[11px]">
                    <KeyRound size={11} />
                    {t.integConnect}
                  </Button>
                )}
                {c.connected && (
                  <Button variant="ghost" size="sm" onClick={() => go(c)} className="h-7 rounded-md text-[11px] text-dim hover:text-body">
                    {t.integManage}
                  </Button>
                )}
              </div>
              <p className="mt-2 border-t border-line pt-2 text-[10px] leading-relaxed text-dim">
                <ShieldCheck size={10} className="me-1 inline" aria-hidden="true" />
                {t.integPermLabel}: {c.permissions}
              </p>
            </li>
          )
        })}
      </ul>
    </div>
  )
}

// -------------------------------------------------------------- tools tab

function ToolsInventory({ onAuthLost }: { onAuthLost: () => void }) {
  const { t } = useI18n()
  const [inv, setInv] = useState<ToolsInventoryResponse | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    api
      .systemTools()
      .then((r) => { if (!cancelled) setInv(r) })
      .catch((e) => {
        if (e instanceof ApiError && e.status === 401) onAuthLost()
        if (!cancelled) setError(e instanceof ApiError ? e.message : String(e))
      })
    return () => { cancelled = true }
  }, [onAuthLost])

  if (error) {
    return (
      <div className="p-6">
        <p role="alert" className="mx-auto max-w-2xl rounded-md border border-fault-text/40 bg-fault/5 px-3 py-2 text-xs text-fault-text">{error}</p>
      </div>
    )
  }
  if (inv === null) return <PageLoader />

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="mx-auto flex max-w-3xl flex-col gap-4">
        <p className="text-xs leading-relaxed text-dim">{t.toolsHubSub}</p>

        <section className="rounded-lg border border-line bg-surface">
          <header className="flex items-center gap-2 border-b border-line px-4 py-2.5">
            <ShieldCheck size={14} className="text-signal-text dark:text-signal" aria-hidden="true" />
            <h3 className="font-display text-sm font-semibold">{t.boxToolsLabel}</h3>
            <span className="ms-auto font-mono text-[10px] text-dim" dir="ltr">{inv.box.count}</span>
          </header>
          <ul className="divide-y divide-line">
            {inv.box.tools.map((tool) => (
              <li key={tool.name} className="flex items-start gap-2 px-4 py-2">
                <span className="shrink-0 rounded-sm border border-line px-1.5 py-0.5 font-mono text-[10px] text-dim" dir="ltr">
                  {tool.name}
                </span>
                <span className="min-w-0 flex-1 text-[11px] leading-relaxed text-body">{tool.description}</span>
                <span className={cn('shrink-0 rounded-sm border px-1.5 py-0.5 text-[10px]', tool.mutates ? 'border-rust/40 text-rust-text' : 'border-line text-dim')}>
                  {tool.mutates ? t.toolMutates : t.toolReadOnly}
                </span>
              </li>
            ))}
          </ul>
        </section>

        <section className="rounded-lg border border-line bg-surface">
          <header className="flex items-center gap-2 border-b border-line px-4 py-2.5">
            <Sparkles size={14} className="text-signal-text dark:text-signal" aria-hidden="true" />
            <h3 className="font-display text-sm font-semibold">{t.agentToolsLabel}</h3>
            <span className="ms-auto font-mono text-[10px] text-dim" dir="ltr">{inv.agent.count}</span>
          </header>
          <ul className="divide-y divide-line">
            {inv.agent.tools.map((tool) => (
              <li key={tool.name} className="flex items-start gap-2 px-4 py-2">
                <span className="shrink-0 rounded-sm border border-line px-1.5 py-0.5 font-mono text-[10px] text-dim" dir="ltr">
                  {tool.name}
                </span>
                <span className="min-w-0 flex-1 text-[11px] leading-relaxed text-body">{tool.description}</span>
                {tool.risk && (
                  <span className="shrink-0 rounded-sm border border-rust/40 px-1.5 py-0.5 text-[10px] text-rust-text" dir="ltr">
                    {tool.risk}
                  </span>
                )}
              </li>
            ))}
          </ul>
        </section>

        <p className="text-center font-mono text-[11px] text-dim" dir="ltr">
          total: {inv.total}
        </p>
      </div>
    </div>
  )
}
