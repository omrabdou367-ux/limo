'use client'

import { useCallback, useEffect, useState } from 'react'
import { ArrowRight, File as FileIcon, Folder, Loader2, Plus, Save, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { api, ApiError, type ProjectFileInfo, type ProjectInfo } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { cn } from '@/lib/utils'
import { PageLoader, SectionHeader } from './shared'

/**
 * Projects — real workspaces: create, browse files, read/write through the
 * jailed store, and preview HTML inside a sandboxed iframe (the server sends
 * `Content-Security-Policy: sandbox` — the preview cannot touch LIMO origin).
 */

export function ProjectsView({
  kindFilter,
  focusProjectId,
  onAuthLost,
}: {
  kindFilter?: 'web_app' | 'creative'
  focusProjectId?: string | null
  onAuthLost: () => void
}) {
  const { t } = useI18n()
  const [projects, setProjects] = useState<ProjectInfo[] | null>(null)
  const [openId, setOpenId] = useState<string | null>(null)
  const [files, setFiles] = useState<ProjectFileInfo[] | null>(null)
  const [selected, setSelected] = useState<{ path: string; content: string } | null>(null)
  const [draft, setDraft] = useState('')
  const [newPath, setNewPath] = useState('')
  const [creating, setCreating] = useState(false)
  const [name, setName] = useState('')
  const [desc, setDesc] = useState('')
  const [kind, setKind] = useState<'general' | 'web_app' | 'creative' | 'workflow'>(kindFilter ?? 'general')
  const [error, setError] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  const loadProjects = useCallback(async () => {
    try {
      const r = await api.projects()
      setProjects(kindFilter ? r.projects.filter((p) => p.kind === kindFilter) : r.projects)
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) onAuthLost()
      setProjects([])
    }
  }, [kindFilter, onAuthLost])

  useEffect(() => {
    void loadProjects()
  }, [loadProjects])

  // Library (and other areas) can focus a specific project workspace
  useEffect(() => {
    if (focusProjectId) void openProject(focusProjectId)
  }, [focusProjectId])

  const openProject = async (id: string) => {
    setOpenId(id)
    setSelected(null)
    setFiles(null)
    try {
      const r = await api.projectFiles(id)
      setFiles(r.files)
    } catch {
      setFiles([])
    }
  }

  const openFile = async (path: string) => {
    if (!openId) return
    setError(null)
    try {
      const r = await api.projectFileContent(openId, path)
      setSelected({ path, content: r.file.content })
      setDraft(r.file.content)
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
    }
  }

  const saveFile = async () => {
    if (!openId || !selected) return
    setSaving(true)
    setError(null)
    try {
      await api.writeProjectFile(openId, selected.path, draft)
      setSelected({ ...selected, content: draft })
      const r = await api.projectFiles(openId)
      setFiles(r.files)
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
    } finally {
      setSaving(false)
    }
  }

  const addFile = async () => {
    if (!openId || newPath.trim().length === 0) return
    setError(null)
    try {
      await api.writeProjectFile(openId, newPath.trim(), '')
      setNewPath('')
      const r = await api.projectFiles(openId)
      setFiles(r.files)
      await openFile(newPath.trim())
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
    }
  }

  const removeFile = async (path: string) => {
    if (!openId) return
    try {
      await api.deleteProjectFile(openId, path)
      if (selected?.path === path) setSelected(null)
      const r = await api.projectFiles(openId)
      setFiles(r.files)
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
    }
  }

  const createProject = async () => {
    if (name.trim().length === 0) return
    setCreating(true)
    setError(null)
    try {
      const r = await api.createProject({ name: name.trim(), description: desc.trim() || undefined, kind })
      setName('')
      setDesc('')
      await loadProjects()
      await openProject(r.project.id)
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
    } finally {
      setCreating(false)
    }
  }

  const kindLabels: Record<string, string> = {
    general: t.kindGeneral,
    web_app: t.kindWebApp,
    creative: t.kindCreative,
    workflow: t.kindWorkflow,
  }

  // ------------------------------------------------ project detail (jail view)
  if (openId && projects) {
    const project = projects.find((p) => p.id === openId)
    const htmlFiles = (files ?? []).filter((f) => !f.dir && /\.(html?|svg)$/i.test(f.path))
    return (
      <div className="flex h-full min-h-0 flex-col">
        <SectionHeader
          title={project?.name ?? '…'}
          sub={project?.description || (kindLabels[project?.kind ?? ''] ?? '')}
        />
        <div className="flex items-center gap-2 border-b border-line px-6 py-2">
          <Button variant="ghost" size="sm" onClick={() => { setOpenId(null); setSelected(null) }} className="h-8 gap-1 rounded-md text-xs">
            <ArrowRight size={13} className="rtl:-scale-x-100" />
            {t.backToProjects}
          </Button>
          <div className="ms-auto flex items-center gap-1.5">
            <Input
              value={newPath}
              onChange={(e) => setNewPath(e.target.value)}
              placeholder="src/app.js"
              dir="ltr"
              className="h-8 w-44 rounded-md font-mono text-xs"
            />
            <Button variant="outline" size="sm" onClick={() => void addFile()} disabled={newPath.trim().length === 0} className="h-8 gap-1 rounded-md text-xs">
              <Plus size={13} />
              {t.addFile}
            </Button>
          </div>
        </div>
        {error && <p role="alert" className="border-b border-line bg-surface px-6 py-1.5 text-xs text-fault-text">{error}</p>}
        <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[240px_1fr]">
          {/* file tree */}
          <div className="min-h-0 overflow-y-auto border-e border-line bg-surface">
            <p className="px-3 py-2 font-display text-xs font-semibold tracking-wide">{t.filesTitle}</p>
            {files === null ? (
              <div className="p-3"><PageLoader /></div>
            ) : files.length === 0 ? (
              <p className="px-3 py-4 text-xs text-dim">{t.noFiles}</p>
            ) : (
              <ul className="pb-3">
                {files.map((f) => (
                  <li key={f.path}>
                    <div
                      className={cn(
                        'group flex cursor-pointer items-center gap-1.5 px-3 py-1.5 transition-colors hover:bg-canvas',
                        selected?.path === f.path && 'bg-canvas',
                      )}
                      onClick={() => !f.dir && void openFile(f.path)}
                    >
                      {f.dir ? <Folder size={13} className="shrink-0 text-dim" /> : <FileIcon size={13} className="shrink-0 text-dim" />}
                      <span className={cn('min-w-0 flex-1 truncate font-mono text-[11px]', f.dir && 'text-dim')} dir="ltr">{f.path}</span>
                      {!f.dir && (
                        <button
                          type="button"
                          aria-label={`${t.deleteChat}: ${f.path}`}
                          onClick={(e) => { e.stopPropagation(); void removeFile(f.path) }}
                          className="opacity-0 transition-opacity text-dim hover:text-fault-text group-hover:opacity-100"
                        >
                          <Trash2 size={12} />
                        </button>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
          {/* editor + preview */}
          <div className="min-h-0 overflow-y-auto p-4">
            {selected === null ? (
              htmlFiles.length > 0 ? (
                <div className="flex h-full flex-col gap-2">
                  <p className="text-xs text-dim">{t.preview} — {htmlFiles[0]!.path}</p>
                  <iframe
                    title={t.preview}
                    src={`/api/projects/${openId}/preview/${htmlFiles[0]!.path}`}
                    className="min-h-96 w-full flex-1 rounded-md border border-line bg-white"
                    sandbox="allow-scripts allow-forms"
                  />
                </div>
              ) : (
                <p className="py-16 text-center text-xs text-dim">{t.previewUnavailable}</p>
              )
            ) : (
              <div className="flex h-full flex-col gap-2">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs" dir="ltr">{selected.path}</span>
                  <Button size="sm" onClick={() => void saveFile()} disabled={saving || draft === selected.content} className="ms-auto h-8 gap-1 rounded-md text-xs">
                    {saving ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />}
                    {t.saveFile}
                  </Button>
                </div>
                <textarea
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  dir="ltr"
                  className="min-h-[60vh] w-full flex-1 resize-none rounded-md border border-input bg-surface p-3 font-mono text-xs leading-relaxed outline-none focus:border-border-strong"
                />
              </div>
            )}
          </div>
        </div>
      </div>
    )
  }

  // ------------------------------------------------------------- project list
  return (
    <div className="flex h-full flex-col">
      <SectionHeader title={t.projectsTitle} sub={t.projectsSub} />
      <div className="border-b border-line px-6 py-3">
        <div className="flex flex-wrap items-end gap-2">
          <label className="flex flex-col gap-1 text-xs">
            <span className="text-dim">{t.projectName}</span>
            <Input value={name} onChange={(e) => setName(e.target.value)} className="h-9 w-44 rounded-md text-sm" dir="auto" />
          </label>
          <label className="flex flex-col gap-1 text-xs">
            <span className="text-dim">{t.projectDesc}</span>
            <Input value={desc} onChange={(e) => setDesc(e.target.value)} className="h-9 w-56 rounded-md text-sm" dir="auto" />
          </label>
          {!kindFilter && (
            <label className="flex flex-col gap-1 text-xs">
              <span className="text-dim">{t.projectKind}</span>
              <select
                value={kind}
                onChange={(e) => setKind(e.target.value as 'general' | 'web_app' | 'creative' | 'workflow')}
                className="h-9 rounded-md border border-input bg-surface px-2 text-sm outline-none"
              >
                {['general', 'web_app', 'creative', 'workflow'].map((k) => (
                  <option key={k} value={k}>{kindLabels[k]}</option>
                ))}
              </select>
            </label>
          )}
          <Button onClick={() => void createProject()} disabled={creating || name.trim().length === 0} className="h-9 gap-1 rounded-md text-sm">
            {creating ? <Loader2 size={13} className="animate-spin" /> : <Plus size={13} />}
            {t.createProject}
          </Button>
        </div>
        {error && <p role="alert" className="mt-2 text-xs text-fault-text">{error}</p>}
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto p-6">
        {projects === null ? (
          <PageLoader />
        ) : projects.length === 0 ? (
          <p className="rounded-md border border-line bg-surface px-4 py-8 text-center text-xs text-dim">{t.noFiles}</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {projects.map((p) => (
              <li key={p.id}>
                <button
                  type="button"
                  onClick={() => void openProject(p.id)}
                  className="flex w-full items-center gap-3 rounded-md border border-line bg-surface px-4 py-3 text-start transition-colors hover:border-border-strong"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{p.name}</p>
                    <p className="mt-0.5 truncate text-xs text-dim">{p.description || (kindLabels[p.kind] ?? p.kind)}</p>
                  </div>
                  <span className="shrink-0 font-mono text-[10px] text-dim" dir="ltr">{new Date(p.updated_at).toLocaleDateString('en-GB')}</span>
                  <span className="shrink-0 rounded-sm border border-line px-1.5 py-0.5 text-[10px] text-dim">{kindLabels[p.kind] ?? p.kind}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
