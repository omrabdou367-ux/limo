'use client'

import { useCallback, useEffect, useState } from 'react'
import { File as FileIcon, Folder } from 'lucide-react'
import { api, ApiError, type ProjectFileInfo, type ProjectInfo } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { PageLoader, SectionHeader } from './shared'

/**
 * Library — an honest index of what actually exists on disk: every project
 * workspace with its file tree. Reading a file goes through the same jailed
 * store the agent uses.
 */
export function LibraryView({ onOpenProject, onAuthLost }: { onOpenProject: (id: string) => void; onAuthLost: () => void }) {
  const { t } = useI18n()
  const [projects, setProjects] = useState<Array<{ project: ProjectInfo; files: ProjectFileInfo[] }> | null>(null)
  const [file, setFile] = useState<{ path: string; content: string; projectId: string } | null>(null)
  const [error, setError] = useState<string | null>(null)

  /** fetches the real index; setState happens in the caller's .then */
  const fetchLibrary = useCallback(async (): Promise<Array<{ project: ProjectInfo; files: ProjectFileInfo[] }>> => {
    const r = await api.projects()
    return Promise.all(
      r.projects.map(async (project) => {
        const f = await api.projectFiles(project.id).catch(() => ({ files: [] as ProjectFileInfo[] }))
        return { project, files: f.files }
      }),
    )
  }, [])

  useEffect(() => {
    let cancelled = false
    fetchLibrary()
      .then((rows) => { if (!cancelled) setProjects(rows) })
      .catch(() => { if (!cancelled) setProjects([]) })
    return () => { cancelled = true }
  }, [fetchLibrary])

  const openFile = async (projectId: string, path: string) => {
    setError(null)
    try {
      const r = await api.projectFileContent(projectId, path)
      setFile({ path, content: r.file.content, projectId })
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
    }
  }

  const totalFiles = (projects ?? []).reduce((s, p) => s + p.files.filter((f) => !f.dir).length, 0)

  return (
    <div className="flex h-full min-h-0 flex-col">
      <SectionHeader title={t.libraryTitle} sub={t.librarySub} />
      {error && <p role="alert" className="border-b border-line bg-surface px-6 py-1.5 text-xs text-fault-text">{error}</p>}
      <div className="min-h-0 flex-1 overflow-y-auto p-6">
        {projects === null ? (
          <PageLoader />
        ) : totalFiles === 0 ? (
          <p className="rounded-md border border-line bg-surface px-4 py-8 text-center text-xs text-dim">{t.noLibraryFiles}</p>
        ) : (
          <div className="mx-auto flex max-w-3xl flex-col gap-4">
            {projects.map(({ project, files }) => (
              <section key={project.id} className="overflow-hidden rounded-lg border border-line bg-surface">
                <header className="flex items-center gap-2 border-b border-line px-4 py-2.5">
                  <Folder size={14} className="text-dim" />
                  <p className="min-w-0 flex-1 truncate text-sm font-semibold">{project.name}</p>
                  <span className="font-mono text-[10px] text-dim" dir="ltr">{files.filter((f) => !f.dir).length}</span>
                  <button type="button" onClick={() => onOpenProject(project.id)} className="rounded-sm border border-line px-2 py-0.5 text-[11px] text-dim transition-colors hover:border-border-strong hover:text-body">
                    {t.openProject}
                  </button>
                </header>
                <ul className="flex flex-wrap gap-1.5 px-4 py-3">
                  {files.filter((f) => !f.dir).map((f) => (
                    <li key={f.path}>
                      <button
                        type="button"
                        onClick={() => void openFile(project.id, f.path)}
                        className="flex items-center gap-1 rounded-sm border border-line px-1.5 py-0.5 font-mono text-[10px] text-dim transition-colors hover:border-border-strong hover:text-body"
                        dir="ltr"
                      >
                        <FileIcon size={10} />
                        {f.path}
                      </button>
                    </li>
                  ))}
                </ul>
              </section>
            ))}
          </div>
        )}
      </div>
      {file && (
        <div className="border-t border-line bg-surface p-4">
          <p className="mb-1 font-mono text-[11px] text-dim" dir="ltr">{file.path}</p>
          <pre className="max-h-56 overflow-auto rounded-md border border-line bg-canvas p-3 font-mono text-[11px] leading-relaxed" dir="ltr">
            {file.content.slice(0, 20_000)}
          </pre>
        </div>
      )}
    </div>
  )
}
