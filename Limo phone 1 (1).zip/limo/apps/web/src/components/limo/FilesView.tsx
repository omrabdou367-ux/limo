'use client'

import { useCallback, useEffect, useState } from 'react'
import { ChevronLeft, File as FileIcon, Folder, Loader2, Lock, Search } from 'lucide-react'
import { api, ApiError, type DirListingInfo, type WorkspaceFileInfo } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { cn } from '@/lib/utils'
import { PageLoader, SectionHeader } from './shared'

/**
 * LIMO #21 — «الملفات» (the Krea-parity Files area): the REAL repository the
 * agent reads and Reality Forge modifies, browsed read-only through the jailed
 * /api/files endpoints. Secrets, build output and dependencies are denied by
 * the SAME server-side jail the box inspectors use — nothing is hidden in the
 * client, and nothing beyond text files opens.
 */

function fmtBytes(n: number): string {
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`
  return `${(n / (1024 * 1024)).toFixed(1)} MB`
}

export function FilesView({ onAuthLost }: { onAuthLost: () => void }) {
  const { t } = useI18n()
  const [dir, setDir] = useState('')
  const [listing, setListing] = useState<DirListingInfo | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [query, setQuery] = useState('')
  const [openFile, setOpenFile] = useState<WorkspaceFileInfo | null>(null)
  const [fileLoading, setFileLoading] = useState(false)

  const load = useCallback(async (d: string) => {
    setError(null)
    setOpenFile(null)
    setListing(null)
    try {
      setListing(await api.workspaceFiles(d))
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) onAuthLost()
      setError(e instanceof ApiError ? e.message : String(e))
    }
  }, [onAuthLost])

  useEffect(() => {
    void load('')
  }, [load])

  const open = async (path: string) => {
    setFileLoading(true)
    setError(null)
    try {
      const r = await api.workspaceFileContent(path)
      setOpenFile(r.file)
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e))
    } finally {
      setFileLoading(false)
    }
  }

  const parent = dir.includes('/') ? dir.slice(0, dir.lastIndexOf('/')) : ''
  const q = query.trim().toLowerCase()
  const dirs = (listing?.dirs ?? []).filter((d) => !q || d.toLowerCase().includes(q))
  const files = (listing?.files ?? []).filter((f) => !q || f.name.toLowerCase().includes(q))
  const crumbs = dir ? dir.split('/') : []

  return (
    <div className="flex h-full min-h-0 flex-col">
      <SectionHeader title={t.filesTitle} sub={t.repoFilesSub} />

      {/* path bar: up + breadcrumb + in-folder search */}
      <div className="flex flex-wrap items-center gap-2 border-b border-line px-6 py-2">
        {dir && (
          <button
            type="button"
            onClick={() => void load(parent)}
            className="flex h-8 shrink-0 items-center gap-1 rounded-md border border-line bg-surface px-2.5 text-xs text-dim transition-colors hover:text-body"
          >
            <ChevronLeft size={13} className="rtl:rotate-180" aria-hidden="true" />
            {t.filesUp}
          </button>
        )}
        <nav className="flex min-w-0 flex-1 items-center gap-1 font-mono text-[11px]" dir="ltr" aria-label="path">
          <button type="button" onClick={() => void load('')} className="text-dim transition-colors hover:text-body">
            repo
          </button>
          {crumbs.map((c, i) => (
            <span key={i} className="flex min-w-0 items-center gap-1">
              <span className="text-dim">/</span>
              <button
                type="button"
                onClick={() => void load(crumbs.slice(0, i + 1).join('/'))}
                className={cn('truncate transition-colors hover:text-body', i === crumbs.length - 1 ? 'text-body' : 'text-dim')}
              >
                {c}
              </button>
            </span>
          ))}
        </nav>
        <label className="relative flex h-8 min-w-44 items-center">
          <Search size={12} className="pointer-events-none absolute ms-2 text-dim" aria-hidden="true" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="…"
            className="h-8 w-full rounded-md border border-input bg-surface ps-7 pe-2 font-mono text-xs outline-none placeholder:text-dim focus:border-border-strong"
          />
        </label>
      </div>

      {error && <p role="alert" className="border-b border-line bg-surface px-6 py-1.5 text-xs text-fault-text">{error}</p>}

      <div className="min-h-0 flex-1 overflow-y-auto p-6">
        {!listing && !error ? (
          <PageLoader />
        ) : (
          <div className="mx-auto flex max-w-3xl flex-col gap-3">
            {dirs.length === 0 && files.length === 0 ? (
              <p className="rounded-md border border-line bg-surface px-4 py-8 text-center text-xs text-dim">{t.filesEmpty}</p>
            ) : (
              <ul className="overflow-hidden rounded-lg border border-line bg-surface">
                {dirs.map((d) => (
                  <li key={`d-${d}`} className="border-b border-line last:border-b-0">
                    <button
                      type="button"
                      onClick={() => void load(dir ? `${dir}/${d}` : d)}
                      className="flex w-full items-center gap-2.5 px-4 py-2.5 text-start text-sm transition-colors hover:bg-canvas"
                    >
                      <Folder size={14} className="shrink-0 text-dim" aria-hidden="true" />
                      <span className="min-w-0 flex-1 truncate font-mono text-xs" dir="ltr">{d}</span>
                    </button>
                  </li>
                ))}
                {files.map((f) => {
                  const path = dir ? `${dir}/${f.name}` : f.name
                  return (
                    <li key={`f-${path}`} className="border-b border-line last:border-b-0">
                      <button
                        type="button"
                        onClick={() => void open(path)}
                        className={cn(
                          'flex w-full items-center gap-2.5 px-4 py-2.5 text-start transition-colors hover:bg-canvas',
                          openFile?.path === path && 'bg-canvas',
                        )}
                      >
                        <FileIcon size={14} className="shrink-0 text-dim" aria-hidden="true" />
                        <span className="min-w-0 flex-1 truncate font-mono text-xs" dir="ltr">{f.name}</span>
                        <span className="shrink-0 font-mono text-[10px] text-dim" dir="ltr">{fmtBytes(f.bytes)}</span>
                      </button>
                    </li>
                  )
                })}
              </ul>
            )}

            {listing?.capped && <p className="text-center text-[11px] text-dim">{t.filesCapped}</p>}
            <p className="flex items-center justify-center gap-1.5 text-center text-[11px] text-dim">
              <Lock size={11} aria-hidden="true" />
              {t.filesDeniedHint}
            </p>

            {(openFile || fileLoading) && (
              <section className="overflow-hidden rounded-lg border border-line bg-surface" aria-busy={fileLoading}>
                <header className="flex items-center gap-2 border-b border-line px-4 py-2">
                  <span className="min-w-0 flex-1 truncate font-mono text-[11px]" dir="ltr">{openFile?.path ?? ''}</span>
                  {openFile && (
                    <span className="shrink-0 font-mono text-[10px] text-dim" dir="ltr">
                      {openFile.lines} ln · {fmtBytes(openFile.bytes)}
                    </span>
                  )}
                </header>
                {fileLoading ? (
                  <div className="flex items-center justify-center gap-2 py-10 text-dim">
                    <Loader2 size={14} className="animate-spin" />
                    <span className="font-mono text-xs">…</span>
                  </div>
                ) : (
                  openFile && (
                    <pre className="max-h-96 overflow-auto p-4 font-mono text-[11px] leading-relaxed" dir="ltr">
                      {openFile.content.slice(0, 30_000)}
                      {openFile.truncated ? '\n…' : ''}
                    </pre>
                  )
                )}
              </section>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
