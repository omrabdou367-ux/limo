import type { ReactNode } from 'react'

/**
 * LIMO #22 — tiny safe markdown renderer for chat bubbles.
 *
 * The box's live models answer with markdown (## headings, **bold**, `code`,
 * lists) and the raw glyphs used to show as-is — ugly and confusing inside an
 * RTL conversation. This renders the common subset with plain React nodes
 * (NO dangerouslySetInnerHTML — model output is untrusted input), keeps
 * everything else verbatim, and inherits the bubble's direction/RTL styling.
 */

function inline(text: string, keyPrefix: string): ReactNode[] {
  const nodes: ReactNode[] = []
  const re = /(`[^`\n]+`|\*\*[^*\n]+\*\*|__[^_\n]+__|\*[^*\n]+\*)/g
  let last = 0
  let m: RegExpExecArray | null
  let i = 0
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) nodes.push(text.slice(last, m.index))
    const tok = m[0]
    const key = `${keyPrefix}-${i++}`
    if (tok.startsWith('`')) {
      nodes.push(
        <code key={key} className="mx-0.5 rounded border border-line bg-surface px-1.5 py-0.5 font-mono text-[0.85em]" dir="auto">
          {tok.slice(1, -1)}
        </code>,
      )
    } else if (tok.startsWith('**') || tok.startsWith('__')) {
      nodes.push(
        <strong key={key} className="font-semibold text-body">
          {tok.slice(2, -2)}
        </strong>,
      )
    } else {
      nodes.push(
        <em key={key}>
          {tok.slice(1, -1)}
        </em>,
      )
    }
    last = m.index + tok.length
  }
  if (last < text.length) nodes.push(text.slice(last))
  return nodes
}

interface Block {
  kind: 'p' | 'h' | 'ul' | 'ol' | 'code' | 'quote'
  level?: number
  lines: string[]
  ordered?: boolean[]
}

function parseBlocks(text: string): Block[] {
  const lines = text.replace(/\r\n?/g, '\n').split('\n')
  const blocks: Block[] = []
  let i = 0
  while (i < lines.length) {
    const line = lines[i]!
    if (line.trim().startsWith('```')) {
      const body: string[] = []
      i++
      while (i < lines.length && !lines[i]!.trim().startsWith('```')) body.push(lines[i++]!)
      if (i < lines.length) i++ // closing fence
      blocks.push({ kind: 'code', lines: body })
      continue
    }
    const heading = /^(#{1,4})\s+(.*)$/.exec(line)
    if (heading) {
      blocks.push({ kind: 'h', level: heading[1]!.length, lines: [heading[2]!] })
      i++
      continue
    }
    if (/^\s*([-*•])\s+/.test(line)) {
      const items: string[] = []
      while (i < lines.length && /^\s*([-*•])\s+/.test(lines[i]!)) items.push(lines[i++]!.replace(/^\s*([-*•])\s+/, ''))
      blocks.push({ kind: 'ul', lines: items })
      continue
    }
    if (/^\s*\d+[.)]\s+/.test(line)) {
      const items: string[] = []
      while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i]!)) items.push(lines[i++]!.replace(/^\s*\d+[.)]\s+/, ''))
      blocks.push({ kind: 'ol', lines: items })
      continue
    }
    if (/^\s*>\s?/.test(line)) {
      const body: string[] = []
      while (i < lines.length && /^\s*>\s?/.test(lines[i]!)) body.push(lines[i++]!.replace(/^\s*>\s?/, ''))
      blocks.push({ kind: 'quote', lines: body })
      continue
    }
    if (line.trim() === '') {
      i++
      continue
    }
    const para: string[] = []
    while (
      i < lines.length &&
      lines[i]!.trim() !== '' &&
      !lines[i]!.trim().startsWith('```') &&
      !/^(#{1,4})\s+/.test(lines[i]!) &&
      !/^\s*([-*•])\s+/.test(lines[i]!) &&
      !/^\s*\d+[.)]\s+/.test(lines[i]!) &&
      !/^\s*>\s?/.test(lines[i]!)
    ) {
      para.push(lines[i++]!)
    }
    blocks.push({ kind: 'p', lines: para })
  }
  return blocks
}

export function MarkdownText({ text, className }: { text: string; className?: string }) {
  const blocks = parseBlocks(text)
  return (
    <div className={className}>
      {blocks.map((b, bi) => {
        const key = `b${bi}`
        if (b.kind === 'code') {
          return (
            <pre key={key} className="my-2 overflow-x-auto rounded-xl border border-line bg-surface p-3 font-mono text-xs leading-relaxed" dir="ltr">
              {b.lines.join('\n')}
            </pre>
          )
        }
        if (b.kind === 'h') {
          const size = b.level === 1 ? 'text-base' : b.level === 2 ? 'text-sm' : 'text-sm'
          return (
            <p key={key} className={`mt-3 mb-1.5 font-semibold first:mt-0 ${size}`} dir="auto">
              {inline(b.lines[0] ?? '', key)}
            </p>
          )
        }
        if (b.kind === 'ul' || b.kind === 'ol') {
          const ListTag = b.kind === 'ul' ? 'ul' : 'ol'
          return (
            <ListTag key={key} className="my-1.5 list-outside space-y-1 ps-5">
              {b.lines.map((li, li2) => (
                <li key={`${key}-${li2}`} className="leading-relaxed" dir="auto">
                  {inline(li, `${key}-${li2}`)}
                </li>
              ))}
            </ListTag>
          )
        }
        if (b.kind === 'quote') {
          return (
            <blockquote key={key} className="my-2 border-s-2 border-line ps-3 text-dim">
              {b.lines.map((l, li2) => (
                <p key={`${key}-${li2}`} dir="auto">
                  {inline(l, `${key}-${li2}`)}
                </p>
              ))}
            </blockquote>
          )
        }
        return (
          <p key={key} className="whitespace-pre-line leading-relaxed" dir="auto">
            {b.lines.map((l, li2) => (
              <span key={`${key}-${li2}`}>
                {li2 > 0 && <br />}
                {inline(l, `${key}-${li2}`)}
              </span>
            ))}
          </p>
        )
      })}
    </div>
  )
}
