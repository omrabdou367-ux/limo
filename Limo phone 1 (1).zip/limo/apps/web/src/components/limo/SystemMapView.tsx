'use client'

import { useCallback, useEffect, useState } from 'react'
import { Boxes, Cpu, Gauge, HardDrive, KeyRound, Loader2, MessageSquare, Radar, RefreshCw, Rocket, ShieldCheck, Sparkles, Bot, Database, FlaskConical } from 'lucide-react'
import { api, type SystemEnginesResponse, type SystemMapResponse, type DeployStateResponse } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { cn } from '@/lib/utils'
import { PageLoader, SectionHeader } from './shared'
import type { SubsystemEntryDto } from '@/lib/api'

/**
 * LIMO COMPUTER PRO — the live system map (decision #17).
 * Every number on this screen is measured at request time; every subsystem
 * status is an AUDIT result (dated), never a marketing claim. Missing
 * subsystems are shown as missing — that honesty IS the feature.
 */

const STATUS_CHIP: Record<string, string> = {
  verified: 'bg-signal text-primary-foreground',
  implemented: 'border border-signal text-signal',
  partial: 'border border-dashed border-signal text-signal',
  mocked: 'bg-fault text-fault-text font-bold',
  broken: 'bg-fault text-fault-text font-bold',
  missing: 'border border-line text-dim',
  unknown: 'border border-dashed border-line text-dim',
}

const GROUP_ORDER: Array<SubsystemEntryDto['group']> = ['intelligence', 'knowledge', 'creation', 'platform']

function VitalsCard({ icon, label, value, sub, warn }: { icon: React.ReactNode; label: string; value: string; sub?: string; warn?: boolean }) {
  return (
    <div className={cn('rounded-2xl border p-4', warn ? 'border-dashed border-signal bg-surface' : 'border-line bg-surface')}>
      <div className="flex items-center gap-2 text-dim">
        {icon}
        <span className="text-[11px] leading-tight">{label}</span>
      </div>
      <p className="mt-2 font-display text-2xl font-bold leading-none">{value}</p>
      {sub ? <p className="mt-1 truncate text-[11px] text-dim" dir="auto">{sub}</p> : null}
    </div>
  )
}

function fmtBytes(n: number): string {
  if (n >= 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`
  if (n >= 1024) return `${Math.round(n / 1024)} KB`
  return `${n} B`
}

function fmtUptime(sec: number): string {
  const h = Math.floor(sec / 3600)
  const m = Math.floor((sec % 3600) / 60)
  return h > 0 ? `${h}س ${m}د` : `${m}د ${sec % 60}ث`
}

/** LIMO DEPLOYMENT COMMAND CENTER (#20) — real Vercel state, honest states. */
function DeployCard({ onAuthLost }: { onAuthLost: () => void }) {
  const { t } = useI18n()
  const [state, setState] = useState<DeployStateResponse | null>(null)
  const [token, setToken] = useState('')
  const [busy, setBusy] = useState<string | null>(null)
  const [msg, setMsg] = useState<string | null>(null)
  const [fail, setFail] = useState<string | null>(null)

  const load = useCallback(() => {
    api.deployState().then(setState).catch((e) => {
      if (e instanceof Error && 'status' in e && (e as { status: number }).status === 401) onAuthLost()
    })
  }, [onAuthLost])
  useEffect(load, [load])

  const run = async (label: string, fn: () => Promise<string>) => {
    setBusy(label); setMsg(null); setFail(null)
    try {
      setMsg(await fn())
      load()
    } catch (e) {
      setFail(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(null)
    }
  }

  const stateLabel = (s: string) => t.depState[s] ?? s

  return (
    <div className="rounded-2xl border border-line bg-surface p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Rocket size={16} className="text-dim" />
          <div>
            <p className="font-display text-sm font-bold">{t.depTitle}</p>
            <p className="mt-0.5 max-w-xl text-[11px] leading-relaxed text-dim" dir="auto">{t.depSub}</p>
          </div>
        </div>
        {state?.configured ? (
          <div className="flex items-center gap-2">
            <span className="rounded-full bg-signal px-3 py-1 text-[11px] font-semibold text-primary-foreground">
              {t.depConfigured}: {state.username ?? '?'}
            </span>
            <button
              type="button"
              disabled={busy !== null}
              onClick={() => void run('forget', async () => { await api.deployClearToken(); return t.depForget })}
              className="h-8 rounded-full border border-line px-3 text-[11px] text-dim transition-colors hover:border-border-strong disabled:opacity-50"
            >
              {t.depForget}
            </button>
          </div>
        ) : null}
      </div>

      {state && !state.configured ? (
        <form
          className="mt-4 flex flex-col gap-2 sm:flex-row"
          onSubmit={(e) => {
            e.preventDefault()
            if (!token.trim()) return
            void run('token', async () => {
              const r = await api.deploySetToken(token.trim())
              setToken('')
              return `${t.depSaved} ${r.username}`
            })
          }}
        >
          <input
            type="password"
            value={token}
            onChange={(e) => setToken(e.target.value)}
            placeholder={t.depTokenPlaceholder}
            dir="ltr"
            className="h-10 flex-1 rounded-xl border border-line bg-canvas px-3 font-mono text-xs outline-none focus:border-border-strong"
          />
          <button type="submit" disabled={busy !== null || !token.trim()} className="h-10 rounded-xl bg-primary px-4 text-xs font-semibold text-primary-foreground transition-opacity disabled:opacity-40">
            {busy === 'token' ? <Loader2 size={13} className="animate-spin" /> : t.depSave}
          </button>
        </form>
      ) : null}

      {state?.configured ? (
        <>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className="rounded-full border border-line px-3 py-1 font-mono text-[11px]" dir="ltr">{t.depProject}: {state.project}</span>
            {state.webDist ? (
              <button
                type="button"
                disabled={busy !== null}
                onClick={() => void run('preview', async () => {
                  const r = await api.deployPreview()
                  return `↑ ${r.uploadedFiles} ${t.depDeploying} → ${r.deploymentId}`
                })}
                className="flex h-8 items-center gap-2 rounded-full bg-primary px-4 text-xs font-semibold text-primary-foreground transition-opacity disabled:opacity-40"
              >
                {busy === 'preview' ? <Loader2 size={13} className="animate-spin" /> : <Rocket size={13} />}
                {t.depPreview}
              </button>
            ) : (
              <span className="rounded-full border border-dashed border-fault px-3 py-1 text-[11px] text-fault-text">{t.depDistMissing}</span>
            )}
          </div>
          {msg ? <p className="mt-2 break-all font-mono text-[11px] text-signal" dir="ltr">{msg}</p> : null}
          {fail ? <p className="mt-2 break-all text-[11px] text-fault-text" dir="auto">{fail}</p> : null}
          {state.vercelError ? <p className="mt-2 text-[11px] text-fault-text" dir="auto">{state.vercelError}</p> : null}

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className={cn('rounded-full px-3 py-1 text-[11px]', state.previewProtection ? 'border border-dashed border-signal text-body' : 'bg-surface border border-line text-dim')}>
              {state.previewProtection ? t.depProtectionOn : t.depProtectionOff}
            </span>
            <button
              type="button"
              disabled={busy !== null}
              onClick={() => void run('protection', async () => {
                await api.deployProtection(state.previewProtection !== null)
                return state.previewProtection ? 'protection: OFF' : 'protection: ON'
              })}
              className="h-7 rounded-full border border-line px-3 text-[10px] text-body transition-colors hover:border-border-strong disabled:opacity-40"
            >
              {state.previewProtection ? t.depProtectEnable : t.depProtectDisable}
            </button>
          </div>

          <p className="mt-5 text-xs font-bold tracking-wide text-dim">{t.depLatest}</p>
          {(state.deployments ?? []).length === 0 ? (
            <p className="mt-1 text-[11px] text-dim">{t.depNone}</p>
          ) : (
            <ul className="mt-2 space-y-2">
              {(state.deployments ?? []).map((d) => (
                <li key={d.id} className="rounded-xl border border-line bg-canvas/60 p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <a href={d.url ? `https://${d.url}` : undefined} target="_blank" rel="noreferrer" className="break-all font-mono text-[11px] underline-offset-2 hover:underline" dir="ltr">
                      {d.url ?? d.id}
                    </a>
                    <span className={cn('rounded-full px-2.5 py-0.5 text-[10px] font-semibold', d.state === 'READY' ? 'bg-signal text-primary-foreground' : d.state === 'ERROR' || d.state === 'CANCELED' ? 'bg-fault text-fault-text' : 'border border-line text-dim')}>
                      {stateLabel(d.state)}{d.target === 'production' ? ' · PROD' : ''}
                    </span>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <button
                      type="button"
                      disabled={busy !== null || d.state !== 'READY'}
                      onClick={() => void run(`verify-${d.id}`, async () => {
                        const r = await api.deployVerify(d.id)
                        return r.served === 'limo-ui' ? `${t.depVerifyUi} (${r.httpStatus}, ${r.bytes}B)` : r.served === 'vercel-wall' ? t.depVerifyWall : `${t.depVerifyOther} (${r.httpStatus})`
                      })}
                      className="h-7 rounded-full border border-line px-3 text-[10px] text-body transition-colors hover:border-border-strong disabled:opacity-40"
                    >
                      {t.depVerify}
                    </button>
                    <button
                      type="button"
                      disabled={busy !== null || d.state !== 'READY'}
                      onClick={() => {
                        if (!window.confirm(t.depPromoteConfirm)) return
                        void run('promote', async () => { await api.deployPromote(d.id); return `${t.depPromote} ✓ ${d.id}` })
                      }}
                      className="h-7 rounded-full border border-line px-3 text-[10px] text-body transition-colors hover:border-border-strong disabled:opacity-40"
                    >
                      {t.depPromote}
                    </button>
                    <button
                      type="button"
                      disabled={busy !== null || d.state !== 'READY'}
                      onClick={() => {
                        if (!window.confirm(t.depRollbackConfirm)) return
                        void run('rollback', async () => { await api.deployRollback(d.id); return `${t.depRollback} ✓ ${d.id}` })
                      }}
                      className="h-7 rounded-full border border-line px-3 text-[10px] text-dim transition-colors hover:border-border-strong disabled:opacity-40"
                    >
                      {t.depRollback}
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </>
      ) : null}
    </div>
  )
}

export function SystemMapView({ onAuthLost }: { onAuthLost: () => void }) {
  const { t } = useI18n()
  const [map, setMap] = useState<SystemMapResponse | null>(null)
  const [engines, setEngines] = useState<SystemEnginesResponse | null>(null)
  const [rescanning, setRescanning] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const loadMap = useCallback(() => {
    api.systemMap()
      .then(setMap)
      .catch((e) => {
        if (e instanceof Error && 'status' in e && (e as { status: number }).status === 401) onAuthLost()
        else setErr(String(e instanceof Error ? e.message : e))
      })
  }, [onAuthLost])

  useEffect(() => {
    loadMap()
    api.systemEngines().then(setEngines).catch(() => setEngines(null))
  }, [loadMap])

  const rescan = async () => {
    setRescanning(true)
    try {
      setEngines(await api.systemEngines())
    } catch {
      /* keep previous honest result */
    } finally {
      setRescanning(false)
    }
  }

  if (err) {
    return (
      <div className="flex h-full items-center justify-center p-8">
        <p className="rounded-xl border border-fault bg-fault px-4 py-3 text-sm text-fault-text">{err}</p>
      </div>
    )
  }
  if (!map) return <PageLoader />

  const { live, platform } = map
  const groups = GROUP_ORDER.map((g) => ({ g, rows: map.subsystems.filter((s) => s.group === g) }))
  const st = (s: string) =>
    ({ verified: t.sysStVerified, implemented: t.sysStImplemented, partial: t.sysStPartial, mocked: t.sysStMocked, broken: t.sysStBroken, missing: t.sysStMissing, unknown: t.sysStUnknown } as Record<string, string>)[s] ?? s

  return (
    <div className="flex h-full flex-col overflow-y-auto">
      <SectionHeader title={t.sysmapTitle} slogan={t.sysmapSlogan} sub={t.sysmapSub} />

      <div className="mx-auto w-full max-w-5xl px-6 py-6">
        {/* identity strip */}
        <div className="rounded-2xl border border-line bg-surface p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-display text-lg font-bold tracking-wide" dir="ltr">LIMO COMPUTER PRO</p>
              <p className="mt-1 text-xs text-dim">
                {t.sysmapBase}: LIMO AGENT v{map.product.version} · {t.sysmapAudit}: {map.product.auditDate}
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-full border border-line px-3 py-1 font-mono text-[11px]" dir="ltr">{platform.node}</span>
              <span className="rounded-full border border-line px-3 py-1 font-mono text-[11px]" dir="ltr">{platform.platform}/{platform.arch}</span>
              {platform.termux ? (
                <span className="rounded-full bg-signal px-3 py-1 text-[11px] font-semibold text-primary-foreground">
                  Termux {platform.termuxVersion ?? ''}
                </span>
              ) : null}
              <span className="rounded-full border border-line px-3 py-1 text-[11px] text-dim">{t.sysUptime}: {fmtUptime(platform.uptimeSec)}</span>
            </div>
          </div>
        </div>

        {/* live vitals */}
        <h2 className="mt-8 font-display text-sm font-bold tracking-wide text-dim">{t.sysVitals}</h2>
        <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          <VitalsCard icon={<Sparkles size={14} />} label={t.sysModels} value={String(live.usableModels)} sub={live.usableModels === 0 ? t.sysNeedModel : undefined} warn={live.usableModels === 0} />
          <VitalsCard icon={<Database size={14} />} label={t.sysMemory} value={String(live.memoryCount)} sub={live.memoryMode === 'sqlite-vec' ? 'sqlite-vec' : 'js-cosine (fallback مُعلَن)'} />
          <VitalsCard icon={<Bot size={14} />} label={t.sysAgentTools} value={String(live.agentTools)} />
          <VitalsCard icon={<ShieldCheck size={14} />} label={t.sysBoxTools} value={String(live.boxTools)} />
          <VitalsCard icon={<Boxes size={14} />} label={t.sysProjects} value={String(live.projects)} />
          <VitalsCard icon={<Sparkles size={14} />} label={t.sysSkills} value={String(live.skillsActive)} />
          <VitalsCard icon={<MessageSquare size={14} />} label={t.sysConversations} value={String(live.conversations)} />
          <VitalsCard icon={<Cpu size={14} />} label={t.sysTasks} value={String(live.agentTasks)} sub={live.lastAgentTask ? `#${live.lastAgentTask.id} · ${live.lastAgentTask.status}` : undefined} />
          <VitalsCard icon={<HardDrive size={14} />} label={t.sysDb} value={String(live.dbTables)} sub={fmtBytes(live.dbBytes)} />
          <VitalsCard icon={<KeyRound size={14} />} label={t.sysVault} value={live.vaultState === 'unlocked' ? t.sysVaultOpen : live.vaultState === 'locked' ? t.sysVaultLocked : t.sysVaultInit} />
          <VitalsCard
            icon={<FlaskConical size={14} />}
            label={t.sysGauntlet}
            value={live.gauntlet ? `${live.gauntlet.passed}/${live.gauntlet.total}` : '—'}
            sub={live.gauntlet ? new Date(live.gauntlet.at).toLocaleString() : t.sysGauntletNone}
          />
          <VitalsCard icon={<Gauge size={14} />} label={t.sysUptime} value={fmtUptime(platform.uptimeSec)} />
        </div>

        {/* LIMO DEPLOYMENT COMMAND CENTER (#20) */}
        <div className="mt-8">
          <DeployCard onAuthLost={onAuthLost} />
        </div>

        {/* engine adapters */}
        <div className="mt-8 flex items-center justify-between gap-3">
          <h2 className="font-display text-sm font-bold tracking-wide text-dim">{t.sysEngines}</h2>
          <button
            type="button"
            onClick={() => void rescan()}
            disabled={rescanning}
            className="flex h-8 items-center gap-2 rounded-full border border-line bg-surface px-3 text-xs text-body transition-colors hover:border-border-strong disabled:opacity-50"
          >
            {rescanning ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
            {t.sysRescan}
          </button>
        </div>
        <p className="mt-1 text-xs leading-relaxed text-dim">{t.sysEnginesSub}</p>
        <div className="mt-3 grid gap-3 md:grid-cols-3">
          {(engines?.engines ?? []).map((e) => (
            <div key={e.id} className={cn('rounded-2xl border p-4', e.status === 'found' ? 'border-signal bg-surface' : 'border-dashed border-line bg-surface')}>
              <div className="flex items-center justify-between gap-2">
                <p className="font-display text-sm font-bold">{e.nameAr}</p>
                <span className={cn('rounded-full px-2.5 py-0.5 text-[10px] font-semibold', e.status === 'found' ? 'bg-signal text-primary-foreground' : 'border border-line text-dim')}>
                  {e.status === 'found' ? t.sysEngineFound : t.sysEngineMissing}
                </span>
              </div>
              <p className="mt-1 font-mono text-[11px] text-dim" dir="ltr">{e.nameEn}{e.version ? ` · ${e.version}` : ''}</p>
              {e.status === 'found' ? (
                <ul className="mt-2 space-y-1">
                  {e.validation.notes.map((n, i) => (
                    <li key={i} className="text-[11px] leading-relaxed text-body" dir="auto">— {n}</li>
                  ))}
                </ul>
              ) : (
                <p className="mt-2 text-[11px] leading-relaxed text-dim" dir="auto">{e.hintAr}</p>
              )}
            </div>
          ))}
          {!engines ? <p className="text-xs text-dim">{t.sysEnginesPending}</p> : null}
        </div>

        {/* audited subsystem registry */}
        <h2 className="mt-8 font-display text-sm font-bold tracking-wide text-dim">{t.sysRegistry}</h2>
        <p className="mt-1 text-xs leading-relaxed text-dim">{t.sysRegistrySub}</p>
        <div className="mt-3 space-y-6 pb-10">
          {groups.map(({ g, rows }) => (
            <section key={g}>
              <h3 className="mb-2 text-xs font-bold tracking-wide text-body">
                {{ intelligence: t.sysGroupIntelligence, knowledge: t.sysGroupKnowledge, creation: t.sysGroupCreation, platform: t.sysGroupPlatform }[g]}
              </h3>
              <div className="overflow-hidden rounded-2xl border border-line">
                {rows.map((s, i) => (
                  <div key={s.id} className={cn('bg-surface p-4', i > 0 && 'border-t border-line', (s.status === 'missing' || s.status === 'partial') && 'bg-canvas/40')}>
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="font-display text-sm font-bold">{s.nameAr}</p>
                      <span className={cn('rounded-full px-2.5 py-0.5 text-[10px] font-semibold', STATUS_CHIP[s.status] ?? STATUS_CHIP.unknown)}>{st(s.status)}</span>
                    </div>
                    <p className="mt-0.5 font-mono text-[10px] text-dim" dir="ltr">{s.nameEn}</p>
                    <p className="mt-2 text-xs leading-relaxed text-body" dir="auto">{s.noteAr}</p>
                    <p className="mt-1.5 font-mono text-[10px] text-dim" dir="ltr">{s.evidence}</p>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>

        <footer className="border-t border-line py-4 text-center">
          <p className="mx-auto max-w-2xl text-[11px] leading-relaxed text-dim" dir="auto">
            <Radar size={12} className="inline" /> {t.sysHonesty} ({map.product.auditDate})
          </p>
        </footer>
      </div>
    </div>
  )
}
