'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import {
  ArrowUp, Bot, MessageSquareText, Palette, PenLine, Plus, Rocket, Search, Sparkles,
} from 'lucide-react'
import { ModelPicker } from '@/components/omnara/ModelPicker'
import { Mark } from '@/components/omnara/Mark'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useVoiceInput } from '@/hooks/use-voice-input'
import { api, type AgentTaskInfo, type HealthResponse } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { cn } from '@/lib/utils'

/**
 * HeroChat — the chat-first heart of LIMO AGENT (v4 soft redesign).
 *
 * One big soft composer in the middle of the screen: a time-aware greeting,
 * "Create anything…" placeholder, a + menu (chat vs HYPERBRAIN dispatch — both
 * REAL), a live model pill, honest voice input (Web Speech API, hidden when
 * the browser lacks it) and a circular send button. Suggestion chips only
 * prefill the box; recent tasks are the engine's real rows.
 */
export function HeroChat({
  health,
  model,
  onModelChange,
  onNeedVault,
  onSendChat,
  onDispatchAgent,
  onOpenTask,
  showRecent = true,
}: {
  health: HealthResponse | null
  model: string | null
  onModelChange: (id: string) => void
  onNeedVault: () => void
  onSendChat: (text: string) => void
  onDispatchAgent: (text: string) => void
  onOpenTask: (id: number) => void
  showRecent?: boolean
}) {
  const { t, lang } = useI18n()
  const [text, setText] = useState('')
  const [mode, setMode] = useState<'chat' | 'agent'>('chat')
  const [tasks, setTasks] = useState<AgentTaskInfo[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const taRef = useRef<HTMLTextAreaElement>(null)
  const { supported: micSupported, listening, start, stop } = useVoiceInput({ lang })

  useEffect(() => {
    void api
      .agentTasks()
      .then((r) => setTasks(r.tasks.slice(0, 5)))
      .catch(() => setTasks([]))
  }, [])

  /** time-aware greeting — "What do you want to create tonight?" style */
  const greeting = useMemo(() => {
    const h = new Date().getHours()
    if (h >= 5 && h < 12) return t.heroGreetingMorning
    if (h >= 12 && h < 17) return t.heroGreetingAfternoon
    if (h >= 17 && h < 23) return t.heroGreetingEvening
    return t.heroGreetingNight
  }, [t])

  // auto-grow the hero textarea with content
  useEffect(() => {
    const el = taRef.current
    if (!el) return
    el.style.height = '0px'
    el.style.height = `${Math.min(el.scrollHeight, 260)}px`
  }, [text])

  const dispatch = (forceMode?: 'chat' | 'agent') => {
    const value = text.trim()
    if (value.length === 0) return
    if (!model) {
      setError(t.homeNeedModel)
      onNeedVault()
      return
    }
    setError(null)
    setText('')
    const kind = forceMode ?? mode
    if (kind === 'chat') onSendChat(value)
    else onDispatchAgent(value)
  }

  const chips = [
    { icon: PenLine, label: t.heroChip1 },
    { icon: Search, label: t.heroChip2 },
    { icon: Palette, label: t.heroChip3 },
    { icon: Rocket, label: t.heroChip4 },
  ]

  const statusChip = (s: string) =>
    s === 'completed' ? t.runCompleted : s === 'failed' ? t.runFailed : s === 'running' || s === 'planning' || s === 'queued' ? t.runRunning : s === 'cancelled' ? t.cancel : s === 'awaiting_approval' ? t.agentApprovals : s

  const roundBtn =
    'flex size-10 shrink-0 items-center justify-center rounded-full transition-colors'

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto flex w-full max-w-3xl flex-1 flex-col items-center justify-center gap-7 px-5 py-10 md:py-16">
        {/* brand + time-aware greeting */}
        <div className="limo-rise flex flex-col items-center gap-3 text-center">
          <div className="flex items-center gap-2.5 text-dim">
            <Mark className="h-6 w-auto" />
            <span className="limo-wordmark text-xs" dir="ltr">LIMO AGENT</span>
          </div>
          <h1 className="limo-rise-1 limo-display text-3xl font-bold md:text-4xl">{greeting}</h1>
          <p className="limo-rise-2 flex items-center gap-2 font-mono text-[11px] tracking-[0.3em] text-dim" dir="ltr">
            {t.tagline}
            <span className="text-line">·</span>
            <span className="font-body tracking-normal">{t.positioning}</span>
          </p>
        </div>

        {/* the big soft composer */}
        <div className="limo-rise-3 w-full">
          <div className="limo-soft p-3 shadow-lg shadow-ink/5 dark:shadow-black/40">
            <textarea
              ref={taRef}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={t.homePromptPlaceholder}
              dir="auto"
              rows={2}
              aria-label={t.homePromptPlaceholder}
              className="w-full resize-none bg-transparent px-3 pb-2 pt-2 text-base leading-relaxed outline-none placeholder:text-dim md:text-lg"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  dispatch()
                }
              }}
            />
            <div className="flex items-center gap-1.5 px-1 pb-0.5 pt-1">
              {/* + send options (REAL dispatch targets) */}
              <DropdownMenu>
                <DropdownMenuTrigger
                  aria-label={t.heroPlusLabel}
                  title={t.heroPlusLabel}
                  className={cn(roundBtn, 'border border-input bg-canvas text-dim hover:text-body data-[state=open]:text-body')}
                >
                  <Plus size={17} />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-72 rounded-2xl border-line bg-surface p-1.5">
                  <DropdownMenuItem
                    onClick={() => {
                      setMode('chat')
                      taRef.current?.focus()
                    }}
                    className="gap-3 rounded-xl px-3 py-2.5"
                    aria-pressed={mode === 'chat'}
                  >
                    <span className={cn('flex size-8 shrink-0 items-center justify-center rounded-full', mode === 'chat' ? 'bg-signal text-primary-foreground' : 'bg-canvas text-dim')}>
                      <MessageSquareText size={14} />
                    </span>
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold">{t.heroChatDispatch}</span>
                      <span className="block truncate text-xs text-dim">{t.heroChatDispatchSub}</span>
                    </span>
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => {
                      setMode('agent')
                      taRef.current?.focus()
                    }}
                    className="gap-3 rounded-xl px-3 py-2.5"
                    aria-pressed={mode === 'agent'}
                  >
                    <span className={cn('flex size-8 shrink-0 items-center justify-center rounded-full', mode === 'agent' ? 'bg-signal text-primary-foreground' : 'bg-canvas text-dim')}>
                      <Bot size={14} />
                    </span>
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold">{t.heroAgentDispatch}</span>
                      <span className="block truncate text-xs text-dim">{t.heroAgentDispatchSub}</span>
                    </span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* mode pills — what the circular send will do */}
              <div className="flex h-10 items-center gap-1 rounded-full border border-line bg-canvas p-1" role="group" aria-label={t.heroPlusLabel}>
                {(['chat', 'agent'] as const).map((m) => (
                  <button
                    key={m}
                    type="button"
                    aria-pressed={mode === m}
                    onClick={() => setMode(m)}
                    className={cn(
                      'flex h-8 items-center gap-1.5 rounded-full px-3 text-xs font-medium transition-colors',
                      mode === m ? 'bg-signal text-primary-foreground' : 'text-dim hover:text-body',
                    )}
                  >
                    {m === 'chat' ? <MessageSquareText size={12} /> : <Bot size={12} />}
                    {m === 'chat' ? t.heroModeChat : t.heroModeAgent}
                  </button>
                ))}
              </div>

              {/* live model pill */}
              <ModelPicker
                value={model}
                onChange={onModelChange}
                onNeedVault={onNeedVault}
                allowAuto
                triggerClassName="h-10 rounded-full border-transparent bg-canvas max-w-44"
              />

              <div className="ms-auto flex items-center gap-1.5">
                {/* honest mic — only when the browser exposes SpeechRecognition */}
                {micSupported && (
                  <button
                    type="button"
                    onClick={() => {
                      if (listening) stop()
                      else
                        start({
                          onFinal: (chunk) => {
                            setText((prev) => `${prev}${prev && !prev.endsWith(' ') ? ' ' : ''}${chunk.trim()} `)
                            taRef.current?.focus()
                          },
                        })
                    }}
                    aria-label={listening ? t.heroMicStop : t.heroMicLabel}
                    title={listening ? t.heroMicStop : t.heroMicLabel}
                    aria-pressed={listening}
                    className={cn(
                      roundBtn,
                      'border border-input bg-canvas text-dim hover:text-body',
                      listening && 'limo-mic-live border-signal-text text-signal-text dark:border-signal dark:text-signal',
                    )}
                  >
                    <svg viewBox="0 0 24 24" className="size-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
                      <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
                      <line x1="12" x2="12" y1="19" y2="22" />
                    </svg>
                  </button>
                )}

                {/* circular send */}
                <button
                  type="button"
                  onClick={() => dispatch()}
                  disabled={text.trim().length === 0}
                  aria-label={t.heroSend}
                  title={t.heroSend}
                  className={cn(
                    roundBtn, 'size-11 bg-signal text-primary-foreground transition-opacity',
                    'border border-ink dark:border-0',
                    text.trim().length === 0 && 'opacity-40',
                  )}
                >
                  <ArrowUp size={18} />
                </button>
              </div>
            </div>
          </div>
          {error && (
            <p role="alert" className="mt-3 text-center text-xs text-fault-text">{error}</p>
          )}
        </div>

        {/* suggestion chips — prefill only, no fake actions */}
        <div className="limo-rise-4 w-full">
          <p className="mb-2.5 text-center font-mono text-[10px] tracking-[0.25em] text-dim">{t.heroChipsLabel}</p>
          <div className="flex flex-wrap items-center justify-center gap-2">
            {chips.map(({ icon: Icon, label }) => (
              <button
                key={label}
                type="button"
                onClick={() => {
                  setText(label)
                  taRef.current?.focus()
                }}
                className="flex h-9 max-w-full items-center gap-2 rounded-full border border-line bg-surface px-4 text-xs text-dim transition-colors hover:border-border-strong hover:bg-canvas hover:text-body"
              >
                <Icon size={13} className="shrink-0" />
                <span className="truncate">{label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* recent tasks — real engine rows */}
        {showRecent && (
          <section className="w-full" aria-label={t.homeRecentTasks}>
            <h2 className="mb-2 flex items-center gap-2 font-display text-sm font-semibold tracking-wide">
              <Sparkles size={13} className="text-dim" />
              {t.homeRecentTasks}
            </h2>
            {tasks === null ? (
              <p className="text-xs text-dim">…</p>
            ) : tasks.length === 0 ? (
              <p className="rounded-2xl border border-line bg-surface px-4 py-5 text-center text-xs text-dim">{t.homeNoTasks}</p>
            ) : (
              <ul className="flex flex-col gap-1.5">
                {tasks.map((task) => (
                  <li key={task.id}>
                    <button
                      type="button"
                      onClick={() => onOpenTask(task.id)}
                      className="flex w-full items-center gap-3 rounded-2xl border border-line bg-surface px-4 py-3 text-start transition-colors hover:border-border-strong hover:bg-canvas"
                    >
                      <span className={cn('size-2 shrink-0 rounded-full', task.status === 'completed' ? 'bg-signal' : task.status === 'failed' ? 'bg-fault' : 'animate-pulse bg-signal')} />
                      <span className="min-w-0 flex-1 truncate text-xs">{task.goal}</span>
                      <span className="shrink-0 font-mono text-[10px] text-dim" dir="ltr">#{task.id} · {task.mode}</span>
                      <span className="shrink-0 rounded-full border border-line px-2.5 py-0.5 text-[10px] text-dim">{statusChip(task.status)}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
        )}

        <p className="font-mono text-[10px] tracking-[0.2em] text-dim" dir="ltr">
          {health ? `LIMO AGENT · v${health.version}` : 'LIMO AGENT'}
        </p>
      </div>
    </div>
  )
}
