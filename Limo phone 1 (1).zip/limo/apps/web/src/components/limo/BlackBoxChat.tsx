'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  ArrowUp, Boxes, CheckCircle2, CircleDashed, Clock, GitBranch, Hammer, History,
  KeyRound, Lightbulb, Loader2, Map as MapIcon, PanelBottomOpen, Pencil, Puzzle, RotateCcw, Search, Server,
  ShieldCheck, Sparkles, Trash2, Wrench, X, XCircle,
} from 'lucide-react'
import { useI18n } from '@/lib/i18n'
import { ACCENTS } from '@/lib/appearance'
import { setPendingIntegrationsTab } from '@/lib/nav'
import {
  api,
  ApiError,
  type BoxActionInfo,
  type BoxStateInfo,
  type ForgeChangeInfo,
  type ForgeEventInfo,
  type ForgeMapInfo,
  type ForgeProposalInfo,
  type ForgeStatusInfo,
} from '@/lib/api'
import { cn } from '@/lib/utils'
import { MarkdownText } from './Markdown'

/**
 * BlackBoxChat — the Black Box (الصندوق الأسود) as a REAL CHATBOT (owner
 * directive 2026-11-01: «شات بوت يتيح لك تعديل ليمو كما تشاء حتى تغيير
 * الاسم الخ… ويعطيك رابطا جديدا»).
 *
 * Two honest layers, no fakes:
 *  1. THE BRAIN — free-form text goes to a REAL model (chosen in خانة
 *     النماذج) that can call REAL modification tools on the server: rename
 *     the app, set the tagline/language/default model, set the autonomy
 *     level, scan the Forge, read live state, create a fresh access link.
 *     Every executed tool comes back as a visible action chip; every
 *     mutation lands in the server's append-only audit trail.
 *  2. DETERMINISTIC SAFETY RAIL — owner DECISIONS (apply/reject/rollback/
 *     resume/level/#details) never depend on an LLM: they parse locally and
 *     hit the same real APIs as before. If the model is unreachable, the
 *     read-only intents (status/map/scan/history/help) fall back to the
 *     deterministic cards — the box degrades honestly, never silently.
 */

// ---------------------------------------------------------------- intents

type Intent =
  | { type: 'help' }
  | { type: 'status' }
  | { type: 'map' }
  | { type: 'scan' }
  | { type: 'proposals' }
  | { type: 'history' }
  | { type: 'apply'; id: number | null }
  | { type: 'reject'; id: number | null }
  | { type: 'rollback'; id: number | null }
  | { type: 'resume'; id: number | null }
  | { type: 'cancel'; id: number | null }
  | { type: 'details'; id: number }
  | { type: 'level'; value: number }
  | { type: 'levelStatus' }
  | { type: 'unknown' }

function parseIntent(input: string): Intent {
  const s = input.toLowerCase()
  const idMatch = s.match(/#(\d+)/) ?? s.match(/(?:رقم|id)\s*[:#]?\s*(\d+)/)
  const id = idMatch ? Number(idMatch[1]!) : null

  if (/(مساعدة|ساعدني|help|ماذا تستطيع|what can you)/.test(s)) return { type: 'help' }

  // decisions FIRST — a decision sentence may also contain status words
  if (/(اطبق|طبّق|طبق|apply|موافقة|وافق|approve)/.test(s)) return { type: 'apply', id }
  if (/(ارفض|رفض|reject)/.test(s)) return { type: 'reject', id }
  if (/(استرجاع|استرجع|ارجع|رجوع|تراجع|rollback|roll back|revert)/.test(s)) return { type: 'rollback', id }
  if (/(استئناف|استأنف|أكمل|أكمِل|continue|resume)/.test(s)) return { type: 'resume', id }
  // LIMO #19: the owner's interruption is a DECISION — deterministic, never model-parsed
  if (/(ألغِ|ألغ|الغِ|الغي|إلغاء|cancel)/.test(s)) return { type: 'cancel', id }
  if (/(تفاصيل|details)/.test(s) && id !== null) return { type: 'details', id }

  // autonomy level
  if (/(استقلالي|autonom)/.test(s)) {
    const lv = s.match(/\b([0-4])\b/)
    return lv ? { type: 'level', value: Number(lv[1]!) } : { type: 'levelStatus' }
  }
  if (/(مستوى|level)/.test(s)) {
    const lv = s.match(/\b([0-4])\b/)
    if (lv && /(اجعل|اضبط|غيّر|غير|set|make|ارفع|اخفض|raise|lower)/.test(s)) return { type: 'level', value: Number(lv[1]!) }
    if (/(استقلالي|autonom)/.test(s)) return lv ? { type: 'level', value: Number(lv[1]!) } : { type: 'levelStatus' }
    return { type: 'status' }
  }

  if (/(خريطة|معماري|map|architecture)/.test(s)) return { type: 'map' }
  if (/(ولّد|ولد|ولِّد|افحص|فحص|scan|generate|تحسين|improve)/.test(s)) return { type: 'scan' }
  if (/(اقتراح|proposal)/.test(s)) return { type: 'proposals' }
  if (/(سجل|تغييرات|history|changes|log)/.test(s)) return { type: 'history' }
  if (/(حالة|كيف حال|وضع النظام|status|health|النظام)/.test(s)) return { type: 'status' }
  if (id !== null) return { type: 'details', id }

  return { type: 'unknown' }
}

/**
 * Owner decisions stay DETERMINISTIC (a destructive command must never
 * depend on model availability or model parsing) — but only when the message
 * IS a short imperative or carries an explicit #id. A question that merely
 * mentions «طبّق» goes to the brain, never to the executor.
 */
const DECISION_VERBS =
  /^(اطبق|طبّق|طبق|وافق|موافقة|ارفض|رفض|استرجع|استرجاع|ارجع|تراجع|رجوع|استأنف|استئناف|ألغِ|ألغ|الغِ|الغي|إلغاء|apply|approve|reject|rollback|revert|resume|cancel)\b/i

function isDirectDecision(v: string, intent: Intent): boolean {
  if (intent.type === 'apply' || intent.type === 'reject' || intent.type === 'rollback' || intent.type === 'resume' || intent.type === 'cancel') {
    if (intent.id !== null) return true // explicit #id — unambiguous
    return DECISION_VERBS.test(v.trim()) && v.trim().split(/\s+/).length <= 5
  }
  return intent.type === 'level' || intent.type === 'details' || intent.type === 'levelStatus'
}

// ---------------------------------------------------------------- messages

type BbCard =
  | { kind: 'status'; status: ForgeStatusInfo }
  | { kind: 'map'; map: ForgeMapInfo }
  | { kind: 'changes'; changes: ForgeChangeInfo[] }
  | { kind: 'change'; change: ForgeChangeInfo; events: ForgeEventInfo[] }
  | { kind: 'proposals'; proposals: ForgeProposalInfo[]; generated?: number }
  | { kind: 'help' }
  | { kind: 'error'; text: string }

interface BbMessage {
  id: string
  role: 'user' | 'box'
  text?: string
  card?: BbCard
  /** REAL tools the brain executed for this reply (server-verified) */
  actions?: BoxActionInfo[]
  /** durable box_messages row id — edit is offered only when known (LIMO #24) */
  serverId?: number
  /** produced by «أعد توليد الرد» — shown as an honest badge (LIMO #24) */
  regen?: boolean
}

const STATUS_STYLE: Record<string, string> = {
  awaiting_approval: 'border-rust/60 bg-rust/5 text-rust-text',
  applied: 'border-signal-text/50 bg-signal/5 text-signal-text dark:text-signal',
  rolled_back: 'border-signal-text/40 text-signal-text dark:text-signal',
  failed: 'border-fault-text/50 bg-fault/5 text-fault-text',
  rejected: 'border-line text-dim',
  cancelled: 'border-line bg-canvas text-dim',
}
const ACTIVE_STATUS = new Set(['analyzing', 'planned', 'implementing', 'testing', 'reviewing'])

const STATUS_KEY: Record<string, string> = {
  analyzing: 'bbStAnalyzing',
  planned: 'bbStPlanned',
  implementing: 'bbStImplementing',
  testing: 'bbStTesting',
  reviewing: 'bbStReviewing',
  awaiting_approval: 'bbStAwaiting',
  applied: 'bbStApplied',
  rejected: 'bbStRejected',
  rolled_back: 'bbStRolledBack',
  failed: 'bbStFailed',
  cancelled: 'bbStCancelled',
}

const BOX_MODEL_KEY = 'limo-box-model'

let seq = 0
const nextId = (p: string) => `${p}-${Date.now()}-${seq++}`

function safeParseActions(raw: string | null): BoxActionInfo[] | undefined {
  if (!raw) return undefined
  try {
    const parsed = JSON.parse(raw) as BoxActionInfo[]
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : undefined
  } catch {
    return undefined
  }
}

// ---------------------------------------------------------------- component

/**
 * LIMO #15 — «أين النماذج؟ أريد ربطه ب LLM حقيقي» — the model field's empty
 * state used to be a dead dropdown. Now it hands the owner the three REAL
 * connection paths, each wired to the actual flow (no fake model list):
 *  1. a cloud BYOK key (OpenRouter/Groq/OpenAI) → the vault dialog,
 *  2. any OpenAI-compatible endpoint (LM Studio/vLLM/llama.cpp) →
 *     Integrations ⇢ custom tab (the real add-endpoint form),
 *  3. local Ollama — auto-detected at 127.0.0.1:11434, with a live re-check.
 */
function ConnectModelPanel({ onRecheck, rechecking }: { onRecheck: () => void; rechecking: boolean }) {
  const { t } = useI18n()
  return (
    <section
      className="w-full rounded-3xl border border-line bg-surface p-5"
      aria-label={t.bbConnectTitle}
      data-testid="bb-connect-panel"
    >
      <div className="mb-4 flex items-center gap-2.5">
        <span className="flex size-9 shrink-0 items-center justify-center rounded-full border border-line bg-canvas text-signal-text dark:text-signal">
          <Boxes size={16} aria-hidden="true" />
        </span>
        <div className="min-w-0">
          <h2 className="text-sm font-bold leading-snug">{t.bbConnectTitle}</h2>
          <p className="text-xs leading-relaxed text-dim">{t.bbConnectSub}</p>
        </div>
      </div>
      <div className="grid gap-2.5 md:grid-cols-3">
        <div className="flex flex-col gap-2 rounded-2xl border border-line bg-canvas p-3.5">
          <KeyRound size={15} className="text-signal-text dark:text-signal" aria-hidden="true" />
          <h3 className="text-xs font-bold">{t.bbConnectCloud}</h3>
          <p className="min-h-0 flex-1 text-[11px] leading-relaxed text-dim">{t.bbConnectCloudSub}</p>
          <button
            type="button"
            onClick={() => window.dispatchEvent(new CustomEvent('limo:open-vault'))}
            className="h-8 rounded-full bg-signal px-3 text-[11px] font-semibold text-primary-foreground transition-opacity hover:opacity-90"
          >
            {t.bbConnectCloudAction}
          </button>
        </div>
        <div className="flex flex-col gap-2 rounded-2xl border border-line bg-canvas p-3.5">
          <Server size={15} className="text-signal-text dark:text-signal" aria-hidden="true" />
          <h3 className="text-xs font-bold">{t.bbConnectCustom}</h3>
          <p className="min-h-0 flex-1 text-[11px] leading-relaxed text-dim">{t.bbConnectCustomSub}</p>
          <button
            type="button"
            onClick={() => {
              // the tab hint travels via the nav mailbox — the Integrations
              // area MOUNTS on navigation, so a plain event would fire before
              // its listener exists (LIMO #15)
              setPendingIntegrationsTab('custom')
              window.dispatchEvent(new CustomEvent('limo:navigate-area', { detail: 'integrations' }))
            }}
            className="h-8 rounded-full bg-signal px-3 text-[11px] font-semibold text-primary-foreground transition-opacity hover:opacity-90"
          >
            {t.bbConnectCustomAction}
          </button>
        </div>
        <div className="flex flex-col gap-2 rounded-2xl border border-line bg-canvas p-3.5">
          <Boxes size={15} className="text-signal-text dark:text-signal" aria-hidden="true" />
          <h3 className="text-xs font-bold">{t.bbConnectOllama}</h3>
          <p className="min-h-0 flex-1 text-[11px] leading-relaxed text-dim">{t.bbConnectOllamaSub}</p>
          <button
            type="button"
            onClick={onRecheck}
            disabled={rechecking}
            className="flex h-8 items-center justify-center gap-1.5 rounded-full bg-signal px-3 text-[11px] font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
          >
            {rechecking && <Loader2 size={12} className="animate-spin" aria-hidden="true" />}
            {t.bbConnectOllamaAction}
          </button>
        </div>
      </div>
      <p className="mt-3.5 text-[11px] leading-relaxed text-dim">{t.bbConnectNote}</p>
    </section>
  )
}

export function BlackBoxChat({ onOpenDossier }: { onOpenDossier: () => void }) {
  const { t } = useI18n()
  const [messages, setMessages] = useState<BbMessage[]>([])
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const [status, setStatus] = useState<ForgeStatusInfo | null>(null)
  const [levelBusy, setLevelBusy] = useState(false)
  const [detail, setDetail] = useState<{ change: ForgeChangeInfo; events: ForgeEventInfo[] } | null>(null)
  const [boxState, setBoxState] = useState<BoxStateInfo | null>(null)
  const [boxModel, setBoxModel] = useState<string | null>(null)
  const [rechecking, setRechecking] = useState(false)
  // LIMO #23 — the live turn: streamed thinking + actions as they really happen
  const [live, setLive] = useState<{ thinking: string; actions: BoxActionInfo[] } | null>(null)
  // LIMO #24 — conversation search + edit + regenerate over the durable log
  const [editing, setEditing] = useState<{ key: string; value: string } | null>(null)
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchQ, setSearchQ] = useState('')
  const [searchResults, setSearchResults] = useState<Array<{ id: number; role: 'user' | 'box'; content: string; created_at: string }> | null>(null)
  const [searching, setSearching] = useState(false)
  const [highlightId, setHighlightId] = useState<string | null>(null)
  const abortRef = useRef<AbortController | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const taRef = useRef<HTMLTextAreaElement>(null)
  const searchInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    void api.forgeStatus().then(setStatus).catch(() => setStatus(null))
    // خانة النماذج: default = saved pick → profile default → first usable
    void api
      .boxState()
      .then((s) => {
        setBoxState(s)
        setBoxModel((prev) => {
          if (prev) return prev
          const saved = window.localStorage.getItem(BOX_MODEL_KEY)
          // LIMO #21: 'auto' is a real persisted choice — the server routes it
          if (saved && (saved === 'auto' || s.usableModels.some((m) => m.id === saved))) return saved
          if (s.profile.defaultModel && s.usableModels.some((m) => m.id === s.profile.defaultModel)) return s.profile.defaultModel
          return s.usableModels[0]?.id ?? null
        })
      })
      .catch(() => setBoxState(null))
    // the conversation is durable — the box remembers across reloads
    void api
      .boxMessages()
      .then((r) => {
        if (r.messages.length === 0) return
        setMessages(
          r.messages.map((m) => ({
            id: `h-${m.id}`,
            role: m.role,
            text: m.content,
            actions: safeParseActions(m.actions),
            serverId: m.id,
          })),
        )
      })
      .catch(() => undefined)
  }, [])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
  }, [messages, busy])

  // LIMO #24 — debounced honest search over the durable log
  useEffect(() => {
    if (!searchOpen) return
    searchInputRef.current?.focus()
    const q = searchQ.trim()
    if (q.length === 0) {
      setSearchResults(null)
      setSearching(false)
      return
    }
    setSearching(true)
    const timer = setTimeout(() => {
      api
        .boxSearchMessages(q)
        .then((r) => setSearchResults(r.results))
        .catch(() => setSearchResults([]))
        .finally(() => setSearching(false))
    }, 250)
    return () => clearTimeout(timer)
  }, [searchQ, searchOpen])

  const levelLabel = useMemo(() => status?.level ?? 0, [status])

  /** LIMO #15 — re-probe usable models (the Ollama path: start it locally,
   *  hit re-check, the field fills with its live models — no reload needed). */
  const refreshBoxState = useCallback(async () => {
    setRechecking(true)
    try {
      const s = await api.boxState()
      setBoxState(s)
      setBoxModel((prev) => {
        if (prev && (prev === 'auto' || s.usableModels.some((m) => m.id === prev))) return prev
        const saved = window.localStorage.getItem(BOX_MODEL_KEY)
        if (saved && (saved === 'auto' || s.usableModels.some((m) => m.id === saved))) return saved
        if (s.profile.defaultModel && s.usableModels.some((m) => m.id === s.profile.defaultModel)) return s.profile.defaultModel
        return s.usableModels[0]?.id ?? null
      })
    } catch {
      /* keep the previous state — honest, no invented availability */
    } finally {
      setRechecking(false)
    }
  }, [])

  const chooseModel = (id: string) => {
    setBoxModel(id)
    window.localStorage.setItem(BOX_MODEL_KEY, id)
  }

  const clearChat = async () => {
    try {
      await api.boxClearMessages()
      setMessages([])
    } catch {
      /* keep the log on failure — honest, no local-only wipe */
    }
  }

  const setLevel = async (value: number) => {
    if (levelBusy || value === status?.level) return
    setLevelBusy(true)
    try {
      const res = await api.forgeSetAutonomy(value)
      const st = await api.forgeStatus()
      setStatus(st)
      setMessages((prev) => [
        ...prev,
        {
          id: nextId('b'),
          role: 'box',
          text: `${t.bbLevelNow}: L${res.level} · ${levelName(t, res.level)}`,
          card: { kind: 'status', status: st },
        },
      ])
    } catch (err) {
      setMessages((prev) => [...prev, { id: nextId('b'), role: 'box', card: { kind: 'error', text: errMsg(err) } }])
    } finally {
      setLevelBusy(false)
    }
  }

  /** resolve an explicit id, or the newest change in the given status set */
  const resolveTarget = async (id: number | null, statuses: string[], fallbackText: string): Promise<ForgeChangeInfo | null> => {
    if (id !== null) {
      const c = (await api.forgeChanges()).changes.find((x) => x.id === id)
      if (!c) {
        setMessages((prev) => [...prev, { id: nextId('b'), role: 'box', text: t.bbNoIdMatch }])
        return null
      }
      return c
    }
    const all = (await api.forgeChanges()).changes
    const target = all.find((x) => statuses.includes(x.status))
    if (!target) {
      setMessages((prev) => [...prev, { id: nextId('b'), role: 'box', text: fallbackText }])
      return null
    }
    return target
  }

  const run = useCallback(
    async (intent: Intent) => {
      const push = (m: Omit<BbMessage, 'id' | 'role'>) =>
        setMessages((prev) => [...prev, { id: nextId('b'), role: 'box', ...m }])
      try {
        switch (intent.type) {
          case 'help':
            push({ card: { kind: 'help' } })
            break
          case 'status': {
            const st = await api.forgeStatus()
            setStatus(st)
            push({ text: t.bbStatusTitle, card: { kind: 'status', status: st } })
            break
          }
          case 'map': {
            const { map } = await api.forgeMap()
            push({ text: t.bbMapTitle, card: { kind: 'map', map } })
            break
          }
          case 'scan': {
            const res = await api.forgeGenerateProposals()
            push({
              text: `${t.bbScanDone} ${res.generated} ${t.bbGeneratedN}`,
              card: { kind: 'proposals', proposals: res.proposals, generated: res.generated },
            })
            break
          }
          case 'proposals': {
            const res = await api.forgeProposals()
            push({ card: { kind: 'proposals', proposals: res.proposals } })
            break
          }
          case 'history': {
            const res = await api.forgeChanges()
            push({
              text: res.changes.length === 0 ? t.bbNoChanges : t.bbChangesTitle,
              card: { kind: 'changes', changes: res.changes },
            })
            break
          }
          case 'apply':
          case 'reject': {
            const target = await resolveTarget(intent.id, ['awaiting_approval'], t.bbNothingAwaiting)
            if (!target) break
            const decision = intent.type === 'apply' ? 'apply' : 'reject'
            const { change } = await api.decideForgeChange(target.id, decision)
            const fresh = await api.forgeChanges()
            push({
              text: `${intent.type === 'apply' ? t.bbDoneApply : t.bbDoneReject} #${change.id} — ${change.status}`,
              card: { kind: 'changes', changes: fresh.changes },
            })
            break
          }
          case 'rollback': {
            const target = await resolveTarget(intent.id, ['applied'], t.bbNothingApplied)
            if (!target) break
            await api.rollbackForgeChange(target.id)
            const fresh = await api.forgeChanges()
            push({ text: t.bbDoneRollback, card: { kind: 'changes', changes: fresh.changes } })
            break
          }
          case 'resume': {
            const target = await resolveTarget(intent.id, ['planned', 'implementing', 'testing', 'reviewing'], t.bbNothingAwaiting)
            if (!target) break
            const { change } = await api.resumeForgeChange(target.id)
            push({ text: t.bbDoneResume, card: { kind: 'change', change, events: [] } })
            break
          }
          case 'cancel': {
            // LIMO #19 — the durable interruption: non-terminal only, and a
            // cancelled row can never be resumed (the server enforces it)
            const target = await resolveTarget(intent.id, ['analyzing', 'planned', 'implementing', 'testing', 'reviewing', 'awaiting_approval'], t.bbNothingActive)
            if (!target) break
            await api.cancelForgeChange(target.id)
            const fresh = await api.forgeChanges()
            push({ text: `${t.bbDoneCancel} #${target.id}`, card: { kind: 'changes', changes: fresh.changes } })
            break
          }
          case 'details': {
            try {
              const { change, events } = await api.forgeChange(intent.id)
              setDetail({ change, events })
            } catch {
              push({ text: t.bbNoIdMatch })
            }
            break
          }
          case 'level':
            await setLevel(intent.value)
            break
          case 'levelStatus': {
            const st = await api.forgeStatus()
            setStatus(st)
            push({ text: t.bbLevelNow, card: { kind: 'status', status: st } })
            break
          }
          case 'unknown':
            push({ text: t.bbUnknown, card: { kind: 'help' } })
            break
        }
      } catch (err) {
        if (err instanceof ApiError && err.status === 401) return
        push({ card: { kind: 'error', text: errMsg(err) } })
      }
    },
    [t],
  )

  /** THE BRAIN: free-form conversation with the real model + real tools. */
  const chatWithBrain = async (v: string, intent: Intent, opts?: { regen?: boolean }) => {
    const push = (m: Omit<BbMessage, 'id' | 'role'>) =>
      setMessages((prev) => [...prev, { id: nextId('b'), role: 'box', ...m }])
    try {
      const res = await api.boxChat(v, boxModel)
      push({ text: res.reply, actions: res.actions.length > 0 ? res.actions : undefined, regen: opts?.regen })
      if (res.actions.some((a) => a.ok)) {
        // the box changed the system (name/tagline/model/level/link) — the
        // shell re-reads the profile so the new identity shows everywhere
        window.dispatchEvent(new CustomEvent('limo:profile-changed'))
        void api.forgeStatus().then(setStatus).catch(() => undefined)
      }
      // LIMO #24 — attach durable ids so edit becomes available on new bubbles
      void syncServerIds()
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) return
      // honest degradation: known read-only intents still work without a model
      if (intent.type !== 'unknown' && intent.type !== 'apply' && intent.type !== 'reject' && intent.type !== 'rollback' && intent.type !== 'resume') {
        await run(intent)
        return
      }
      push({ card: { kind: 'error', text: `${errMsg(err)}${boxModel ? '' : ` — ${t.bbPickModelFirst}`}` } })
    }
  }

  /**
   * LIMO #23 — the LIVE turn: same loop on the server, streamed honestly.
   * Raw model tokens arrive as `delta` (real thinking, retries included),
   * each real tool lands as `action`, the final reply persists server-side
   * and shows as the same markdown bubble. STOP aborts the fetch — the server
   * notices the closed socket and ends the turn WITHOUT persisting a reply.
   * Falls back to the classic path ONLY when nothing streamed yet (pre-flight
   * failure) — a mid-stream failure reports honestly instead of re-sending
   * (a re-send would duplicate the persisted user turn).
   */
  const chatWithBrainLive = async (v: string, intent: Intent, opts?: { regen?: boolean }) => {
    const push = (m: Omit<BbMessage, 'id' | 'role'>) =>
      setMessages((prev) => [...prev, { id: nextId('b'), role: 'box', ...m }])
    const controller = new AbortController()
    abortRef.current = controller
    setLive({ thinking: '', actions: [] })
    let streamed = false
    try {
      const res = await fetch('/api/box/chat/stream', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ message: v, model: boxModel ?? null }),
        signal: controller.signal,
      })
      const ctype = res.headers.get('content-type') ?? ''
      if (!res.ok || !ctype.includes('text/event-stream')) {
        // pre-flight failure: nothing persisted server-side — classic path is safe
        setLive(null)
        await chatWithBrain(v, intent, opts)
        return
      }
      const reader = res.body?.getReader()
      if (!reader) throw new Error('no stream body')
      const decoder = new TextDecoder()
      let buffer = ''
      let done = false
      while (!done) {
        const { value, done: rdDone } = await reader.read()
        if (rdDone) break
        buffer += decoder.decode(value, { stream: true })
        let sep: number
        while ((sep = buffer.indexOf('\n\n')) >= 0) {
          const frame = buffer.slice(0, sep)
          buffer = buffer.slice(sep + 2)
          const evLine = frame.split('\n').find((l) => l.startsWith('event: '))
          const dataLine = frame.split('\n').find((l) => l.startsWith('data: '))
          if (!evLine || !dataLine) continue
          const event = evLine.slice(7).trim()
          let data: Record<string, unknown> = {}
          try {
            data = JSON.parse(dataLine.slice(6)) as Record<string, unknown>
          } catch {
            continue
          }
          if (event === 'delta') {
            streamed = true
            const chunk = typeof data.text === 'string' ? data.text : ''
            setLive((prev) => (prev ? { ...prev, thinking: prev.thinking + chunk } : prev))
          } else if (event === 'action') {
            streamed = true
            const action = data as unknown as BoxActionInfo
            setLive((prev) => (prev ? { ...prev, actions: [...prev.actions, action] } : prev))
          } else if (event === 'final') {
            const actions = (Array.isArray(data.actions) ? data.actions : []) as BoxActionInfo[]
            setLive(null)
            push({ text: String(data.reply ?? ''), actions: actions.length > 0 ? actions : undefined, regen: opts?.regen })
            if (actions.some((a) => a.ok)) {
              window.dispatchEvent(new CustomEvent('limo:profile-changed'))
              void api.forgeStatus().then(setStatus).catch(() => undefined)
            }
          } else if (event === 'stopped') {
            setLive(null)
            push({ text: t.bbStoppedNote })
          } else if (event === 'error') {
            setLive(null)
            push({ card: { kind: 'error', text: String(data.message ?? '') } })
          } else if (event === 'done') {
            done = true
          }
        }
      }
      setLive(null)
      // LIMO #24 — attach durable ids so edit becomes available on new bubbles
      void syncServerIds()
    } catch (err) {
      setLive(null)
      if (err instanceof DOMException && err.name === 'AbortError') {
        // owner pressed STOP — the server saw the closed socket and kept nothing
        push({ text: t.bbStoppedNote })
        void syncServerIds()
        return
      }
      if (err instanceof ApiError && err.status === 401) return
      if (!streamed) {
        await chatWithBrain(v, intent)
        return
      }
      push({ card: { kind: 'error', text: errMsg(err) } })
    } finally {
      abortRef.current = null
    }
  }

  const stopStreaming = () => {
    abortRef.current?.abort()
  }

  const send = (value?: string, opts?: { regen?: boolean }) => {
    const v = (value ?? text).trim()
    if (v.length === 0 || busy) return
    setMessages((prev) => [...prev, { id: nextId('u'), role: 'user', text: v }])
    setText('')
    setBusy(true)
    const intent = parseIntent(v)
    if (isDirectDecision(v, intent)) {
      void run(intent).finally(() => setBusy(false))
    } else {
      void chatWithBrainLive(v, intent, opts).finally(() => setBusy(false))
    }
  }

  /** button-initiated commands (apply/reject/rollback/resume) — same real run() */
  const command = (intent: Intent) => {
    if (busy) return
    setBusy(true)
    void run(intent).finally(() => setBusy(false))
  }

  // ------------------------------------------- LIMO #24: search/rewind UI
  /** Quietly attach durable-log ids to in-session bubbles — edit appears only
   *  when the visible list maps 1:1 onto the log (honest, no guessing). */
  const syncServerIds = useCallback(async () => {
    try {
      const r = await api.boxMessages()
      setMessages((prev) => {
        if (r.messages.length !== prev.length) return prev
        if (!r.messages.every((row, i) => row.role === prev[i].role)) return prev
        if (prev.every((m, i) => m.serverId === r.messages[i].id)) return prev
        return prev.map((m, i) => ({ ...m, serverId: r.messages[i].id }))
      })
    } catch {
      /* keep local ids — edit stays unavailable rather than guessing */
    }
  }, [])

  const rebuildFromLog = async () => {
    const r = await api.boxMessages()
    setMessages(
      r.messages.map((m) => ({
        id: `h-${m.id}`,
        role: m.role,
        text: m.content,
        actions: safeParseActions(m.actions),
        serverId: m.id,
      })),
    )
  }

  const beginEdit = (m: BbMessage) => setEditing({ key: m.id, value: m.text ?? '' })
  const cancelEdit = () => setEditing(null)

  /** edit = rewind from this user row (inclusive) + re-send the edited text
   *  through the SAME live pipeline — one engine, no duplicate sends. */
  const saveEdit = async () => {
    const target = messages.find((x) => x.id === editing?.key)
    const newText = (editing?.value ?? '').trim()
    if (!editing || !target?.serverId || newText.length === 0 || busy) return
    setEditing(null)
    try {
      await api.boxRewind({ target: 'message', id: target.serverId })
      await rebuildFromLog()
      send(newText)
    } catch (err) {
      setMessages((prev) => [...prev, { id: nextId('b'), role: 'box', card: { kind: 'error', text: errMsg(err) } }])
    }
  }

  /** regenerate = rewind the last user row + re-send the SAME text, marked. */
  const regenerate = async () => {
    if (busy) return
    try {
      const r = await api.boxRewind({ target: 'last-user' })
      await rebuildFromLog()
      send(r.text, { regen: true })
    } catch (err) {
      setMessages((prev) => [...prev, { id: nextId('b'), role: 'box', card: { kind: 'error', text: errMsg(err) } }])
    }
  }

  const jumpTo = (rowId: number) => {
    const el = document.querySelector(`[data-sid="${rowId}"]`)
    if (!el) return
    el.scrollIntoView({ behavior: 'smooth', block: 'center' })
    setHighlightId(`h-${rowId}`)
    window.setTimeout(() => setHighlightId((cur) => (cur === `h-${rowId}` ? null : cur)), 2200)
  }

  const openDetail = async (id: number) => {
    try {
      const { change, events } = await api.forgeChange(id)
      setDetail({ change, events })
    } catch {
      setMessages((prev) => [...prev, { id: nextId('b'), role: 'box', text: t.bbNoIdMatch }])
    }
  }

  const decideProposal = async (id: number, decision: 'accepted' | 'dismissed') => {
    try {
      await api.forgeProposalStatus(id, decision)
      const res = await api.forgeProposals()
      setMessages((prev) => [
        ...prev,
        {
          id: nextId('b'),
          role: 'box',
          text: decision === 'accepted' ? t.bbAccept : t.bbDismiss,
          card: { kind: 'proposals', proposals: res.proposals },
        },
      ])
    } catch (err) {
      setMessages((prev) => [...prev, { id: nextId('b'), role: 'box', card: { kind: 'error', text: errMsg(err) } }])
    }
  }

  const hasChat = messages.length > 0 || busy

  const chips = [
    { label: t.bbChipStatus, run: () => send(t.bbChipStatus) },
    { label: t.bbChipXray, run: () => send(t.bbChipXray) },
    { label: t.bbChipAgent, run: () => send(t.bbChipAgent) },
    { label: t.bbChipScan, run: () => send(t.bbChipScan) },
    { label: t.bbChipHistory, run: () => send(t.bbChipHistory) },
    { label: t.bbChipRename, run: () => send(t.bbChipRename) },
    { label: t.bbChipColor, run: () => send(t.bbChipColor) },
    { label: t.bbChipSkills, run: () => send(t.bbChipSkills) },
    { label: t.bbChipHelp, run: () => send(t.bbChipHelp) },
  ]

  const modelOptions = boxState?.usableModels ?? []
  // LIMO #24 — the regenerate control lives under the last box bubble, offered
  // only when the conversation holds a real user row to rewind from
  const lastBoxId = useMemo(() => [...messages].reverse().find((m) => m.role === 'box')?.id ?? null, [messages])
  const hasUserRow = useMemo(() => messages.some((m) => m.role === 'user'), [messages])

  return (
    <div className="flex h-full flex-col">
      {/* control strip: autonomy pills + خانة النماذج + dossier — all REAL writes */}
      <div className="flex flex-wrap items-center gap-2 border-b border-line bg-surface/60 px-4 py-2.5">
        <span className="flex items-center gap-1.5 font-mono text-[10px] tracking-[0.2em] text-dim">
          <ShieldCheck size={13} className="text-signal-text" aria-hidden="true" />
          {t.bbAutonomy}
        </span>
        <div className="flex h-8 items-center gap-1 rounded-full border border-line bg-canvas p-1" role="group" aria-label={t.bbAutonomy} title={t.bbAutonomyHint}>
          {[0, 1, 2, 3, 4].map((lv) => (
            <button
              key={lv}
              type="button"
              aria-pressed={levelLabel === lv}
              title={`L${lv} · ${levelName(t, lv)}`}
              onClick={() => void setLevel(lv)}
              disabled={levelBusy}
              className={cn(
                'flex h-6 items-center rounded-full px-2.5 font-mono text-[11px] transition-colors',
                levelLabel === lv ? 'bg-signal text-primary-foreground' : 'text-dim hover:text-body',
              )}
            >
              L{lv}
            </button>
          ))}
        </div>
        {levelBusy && <Loader2 size={13} className="animate-spin text-dim" aria-hidden="true" />}

        {/* خانة النماذج — the brain's model (persisted per device) */}
        <label
          className="flex h-8 items-center gap-1.5 rounded-full border border-line bg-canvas px-2.5"
          title={t.bbModelHint}
        >
          <Boxes size={13} className="shrink-0 text-dim" aria-hidden="true" />
          <span className="hidden text-[10px] text-dim sm:inline">{t.bbModelField}</span>
          <select
            value={boxModel ?? ''}
            onChange={(e) => chooseModel(e.target.value)}
            className="max-w-40 bg-transparent font-mono text-[11px] text-body outline-none"
            dir="ltr"
            aria-label={t.bbModelField}
          >
            {modelOptions.length === 0 && <option value="">{t.bbModelEmpty}</option>}
            {/* LIMO #21 — real automatic routing (same pickAutoModel as the agent engine) */}
            <option value="auto">{t.autoModel}</option>
            {modelOptions.map((m) => (
              <option key={m.id} value={m.id}>
                {m.id}
                {m.free ? ' · free' : ''}
              </option>
            ))}
          </select>
        </label>

        <div className="ms-auto flex items-center gap-1.5">
          {hasChat && (
            <button
              type="button"
              onClick={() => setSearchOpen((o) => !o)}
              title={t.bbSearch}
              aria-label={t.bbSearch}
              aria-pressed={searchOpen}
              className={cn(
                'flex size-8 items-center justify-center rounded-full border bg-canvas transition-colors',
                searchOpen ? 'border-signal/60 text-signal-text dark:text-signal' : 'border-line text-dim hover:border-border-strong hover:text-body',
              )}
            >
              <Search size={13} aria-hidden="true" />
            </button>
          )}
          {hasChat && (
            <button
              type="button"
              onClick={() => void clearChat()}
              title={t.bbClear}
              aria-label={t.bbClear}
              className="flex size-8 items-center justify-center rounded-full border border-line bg-canvas text-dim transition-colors hover:border-border-strong hover:text-body"
            >
              <Trash2 size={13} aria-hidden="true" />
            </button>
          )}
          <button
            type="button"
            onClick={onOpenDossier}
            className="flex h-8 items-center gap-1.5 rounded-full border border-line bg-canvas px-3.5 text-xs text-dim transition-colors hover:border-border-strong hover:text-body"
          >
            <PanelBottomOpen size={13} className="rtl:-scale-x-100" aria-hidden="true" />
            {t.bbDossier}
          </button>
        </div>
      </div>

      {/* LIMO #24 — conversation search over the durable log */}
      {searchOpen && (
        <div className="border-b border-line bg-surface/80 px-4 py-2.5">
          <div className="mx-auto w-full max-w-3xl">
            <div className="flex h-9 items-center gap-2 rounded-full border border-line bg-canvas px-3.5">
              <Search size={13} className="shrink-0 text-dim" aria-hidden="true" />
              <input
                ref={searchInputRef}
                value={searchQ}
                onChange={(e) => setSearchQ(e.target.value)}
                placeholder={t.bbSearchPlaceholder}
                aria-label={t.bbSearch}
                className="w-full bg-transparent text-xs text-body outline-none placeholder:text-dim"
              />
              {searchQ.length > 0 && (
                <button
                  type="button"
                  onClick={() => setSearchQ('')}
                  title={t.bbCancelEdit}
                  aria-label={t.bbCancelEdit}
                  className="text-dim transition-colors hover:text-body"
                >
                  <X size={12} aria-hidden="true" />
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  setSearchOpen(false)
                  setSearchQ('')
                  setSearchResults(null)
                  setHighlightId(null)
                }}
                title={t.bbCloseDetails}
                aria-label={t.bbCloseDetails}
                className="text-dim transition-colors hover:text-body"
              >
                <X size={14} aria-hidden="true" />
              </button>
            </div>
            {searchResults && (
              <div className="mt-2 max-h-64 overflow-y-auto rounded-2xl border border-line bg-canvas">
                {searchResults.length === 0 ? (
                  <p className="px-3.5 py-3 text-xs text-dim">{searching ? t.bbSearching : t.bbSearchEmpty}</p>
                ) : (
                  searchResults.map((r) => (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => jumpTo(r.id)}
                      className="flex w-full items-start gap-2.5 border-b border-line/60 px-3.5 py-2.5 text-start transition-colors last:border-b-0 hover:bg-surface"
                    >
                      <span
                        className={cn(
                          'mt-0.5 shrink-0 rounded-full border px-2 py-0.5 text-[10px]',
                          r.role === 'user' ? 'border-line text-dim' : 'border-signal-text/40 text-signal-text dark:text-signal',
                        )}
                      >
                        {r.role === 'user' ? t.bbYou : t.bbBoxRole}
                      </span>
                      <span className="min-w-0 flex-1 truncate text-xs text-body">{r.content}</span>
                    </button>
                  ))
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* the conversation */}
      <div className="min-h-0 flex-1 overflow-y-auto">
        {!hasChat ? (
          <div className="mx-auto flex w-full max-w-3xl flex-1 flex-col items-center justify-center gap-7 px-5 py-12 md:py-20">
            <div className="limo-rise flex flex-col items-center gap-3 text-center">
              <span className="flex size-14 items-center justify-center rounded-full border border-line bg-surface text-signal-text dark:text-signal">
                <ShieldCheck size={24} aria-hidden="true" />
              </span>
              <h1 className="limo-display text-3xl font-bold md:text-4xl">{t.bbGreeting}</h1>
              <p className="max-w-md text-s leading-relaxed text-dim">{t.bbSub}</p>
            </div>
            {modelOptions.length === 0 && (
              <div className="limo-rise-2 w-full">
                <ConnectModelPanel onRecheck={() => void refreshBoxState()} rechecking={rechecking} />
              </div>
            )}
            <div className={cn('w-full', modelOptions.length === 0 ? 'limo-rise-3' : 'limo-rise')}>
              <Composer value={text} onChange={setText} onSend={() => send()} busy={busy} taRef={taRef} />
            </div>
            <div className="limo-rise-4 w-full">
              <p className="mb-2.5 text-center font-mono text-[10px] tracking-[0.25em] text-dim">{t.bbChipsLabel}</p>
              <div className="flex flex-wrap items-center justify-center gap-2">
                {chips.map((c) => (
                  <button
                    key={c.label}
                    type="button"
                    onClick={c.run}
                    className="flex h-9 max-w-full items-center gap-2 rounded-full border border-line bg-surface px-4 text-xs text-dim transition-colors hover:border-border-strong hover:bg-canvas hover:text-body"
                  >
                    <span className="truncate">{c.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="mx-auto flex w-full max-w-3xl flex-col gap-5 px-4 py-6">
            {modelOptions.length === 0 && (
              <ConnectModelPanel onRecheck={() => void refreshBoxState()} rechecking={rechecking} />
            )}
            {messages.map((m) =>
              m.role === 'user' ? (
                <div
                  key={m.id}
                  data-sid={m.serverId}
                  className={cn(
                    'group flex justify-end rounded-3xl transition-shadow',
                    highlightId === m.id && 'ring-2 ring-signal/60',
                  )}
                >
                  {editing?.key === m.id ? (
                    <div className="w-full max-w-[85%] rounded-3xl rounded-ee-lg border border-signal/50 bg-surface p-3">
                      <textarea
                        value={editing.value}
                        onChange={(e) => setEditing({ key: editing.key, value: e.target.value })}
                        rows={Math.min(6, Math.max(2, editing.value.split('\n').length + 1))}
                        autoFocus
                        aria-label={t.bbEdit}
                        className="w-full resize-none bg-transparent text-sm leading-relaxed text-body outline-none"
                      />
                      <div className="mt-2 flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={cancelEdit}
                          className="h-7 rounded-full border border-line px-3 text-[11px] text-dim transition-colors hover:text-body"
                        >
                          {t.bbCancelEdit}
                        </button>
                        <button
                          type="button"
                          onClick={() => void saveEdit()}
                          disabled={busy || editing.value.trim().length === 0}
                          className="h-7 rounded-full bg-signal px-3 text-[11px] font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50"
                        >
                          {t.bbSaveResend}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex max-w-[85%] items-end gap-1.5">
                      {m.serverId && !busy && (
                        <button
                          type="button"
                          onClick={() => beginEdit(m)}
                          title={t.bbEdit}
                          aria-label={t.bbEdit}
                          className="mb-1 flex size-7 shrink-0 items-center justify-center rounded-full border border-line bg-canvas text-dim opacity-0 transition-opacity hover:text-body focus-visible:opacity-100 group-hover:opacity-100"
                        >
                          <Pencil size={12} aria-hidden="true" />
                        </button>
                      )}
                      <div className="rounded-3xl rounded-ee-lg border border-line bg-surface px-4 py-2.5 text-sm leading-relaxed">
                        {m.text}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div
                  key={m.id}
                  data-sid={m.serverId}
                  className={cn(
                    'flex items-start gap-3 rounded-3xl transition-shadow',
                    highlightId === m.id && 'ring-2 ring-signal/60',
                  )}
                >
                  <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-full border border-line bg-surface text-signal-text dark:text-signal">
                    <ShieldCheck size={15} aria-hidden="true" />
                  </span>
                  <div className="min-w-0 flex-1">
                    {m.regen && (
                      <span className="mb-1.5 inline-flex items-center gap-1 rounded-full border border-line bg-canvas px-2 py-0.5 text-[10px] text-dim">
                        <RotateCcw size={10} className="rtl:-scale-x-100" aria-hidden="true" />
                        {t.bbRegenBadge}
                      </span>
                    )}
                    {m.text && <MarkdownText text={m.text} className="text-sm" />}
                    {m.actions && <ActionList actions={m.actions} />}
                    {m.card && (
                      <div className={cn(m.text && 'mt-3')}>
                        <Card card={m.card} onOpenDetail={(id) => void openDetail(id)} onDecide={(id, d) => void decideProposal(id, d)} onCommand={command} />
                      </div>
                    )}
                  </div>
                </div>
              ),
            )}
            {!busy && lastBoxId && hasUserRow && (
              <div className="flex justify-start">
                <button
                  type="button"
                  onClick={() => void regenerate()}
                  className="flex h-8 items-center gap-1.5 rounded-full border border-line bg-surface px-3.5 text-[11px] text-dim transition-colors hover:border-border-strong hover:text-body"
                >
                  <RotateCcw size={12} className="rtl:-scale-x-100" aria-hidden="true" />
                  {t.bbRegenerate}
                </button>
              </div>
            )}
            {busy && !live && (
              <div className="flex items-center gap-3">
                <span className="flex size-8 shrink-0 items-center justify-center rounded-full border border-line bg-surface text-signal-text dark:text-signal">
                  <Loader2 size={14} className="animate-spin" aria-hidden="true" />
                </span>
                <p className="flex items-center gap-1.5 text-xs text-dim">
                  {t.bbThinking}
                  <span className="flex gap-1" aria-hidden="true">
                    <span className="size-1 animate-pulse rounded-full bg-dim" />
                    <span className="size-1 animate-pulse rounded-full bg-dim [animation-delay:150ms]" />
                    <span className="size-1 animate-pulse rounded-full bg-dim [animation-delay:300ms]" />
                  </span>
                </p>
              </div>
            )}
            {busy && live && (
              <div className="flex items-start gap-3">
                <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-full border border-line bg-surface text-signal-text dark:text-signal">
                  <Loader2 size={14} className="animate-spin" aria-hidden="true" />
                </span>
                <div className="min-w-0 flex-1 overflow-hidden rounded-2xl border border-line bg-surface/60">
                  <p className="border-b border-line px-3 py-1.5 text-[10px] font-mono tracking-[0.2em] text-dim">{t.bbLiveThinking}</p>
                  {live.actions.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 border-b border-line px-3 py-2">
                      {live.actions.map((a, i) => (
                        <span key={`la${i}`} className={cn('flex items-center gap-1 rounded-full border px-2.5 py-1 font-mono text-[10px]', a.ok ? 'border-line text-dim' : 'border-rust/50 text-rust-text')}>
                          {a.ok ? <CheckCircle2 size={10} aria-hidden="true" /> : <XCircle size={10} aria-hidden="true" />}
                          {a.tool}
                        </span>
                      ))}
                    </div>
                  )}
                  {live.thinking && (
                    <p dir="auto" className="max-h-40 overflow-y-auto whitespace-pre-wrap px-3 py-2 font-mono text-[11px] leading-relaxed text-dim">
                      {live.thinking}
                    </p>
                  )}
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>
        )}
      </div>

      {hasChat && (
        <div className="border-t border-line bg-canvas/80 px-4 py-3">
          <div className="mx-auto w-full max-w-3xl">
            <Composer value={text} onChange={setText} onSend={() => send()} busy={busy} onStop={stopStreaming} />
          </div>
        </div>
      )}

      {/* change detail drawer (events + full request) — server data only */}
      {detail && (
        <div className="fixed inset-0 z-50" role="dialog" aria-modal="true">
          <button
            type="button"
            aria-label={t.bbCloseDetails}
            onClick={() => setDetail(null)}
            className="absolute inset-0 bg-ink/60 backdrop-blur-sm"
          />
          <div className="absolute inset-x-0 bottom-0 mx-auto max-h-[80dvh] w-full max-w-3xl overflow-y-auto rounded-t-3xl border border-line bg-canvas p-6 shadow-2xl">
            <div className="mb-4 flex items-center gap-3">
              <span className="font-mono text-xs text-dim" dir="ltr">#{detail.change.id}</span>
              <StatusPill status={detail.change.status} />
              <button
                type="button"
                onClick={() => setDetail(null)}
                className="ms-auto flex size-9 items-center justify-center rounded-full text-dim transition-colors hover:bg-surface hover:text-body"
                aria-label={t.bbCloseDetails}
              >
                <XCircle size={17} />
              </button>
            </div>
            <p className="text-sm leading-relaxed">{detail.change.request}</p>
            <div className="mt-4 grid gap-2 font-mono text-[11px] text-dim sm:grid-cols-2" dir="ltr">
              <span>model: {detail.change.model ?? t.bbNoModel}</span>
              <span>level: L{detail.change.level}</span>
              {detail.change.commit_id && <span className="truncate">commit: {detail.change.commit_id}</span>}
              {detail.change.rollback_of && <span>rollback of: #{detail.change.rollback_of}</span>}
            </div>
            {detail.change.error && (
              <p className="mt-3 rounded-2xl border border-fault-text/40 bg-fault/5 px-4 py-3 text-xs leading-relaxed text-fault-text" dir="auto">
                {detail.change.error}
              </p>
            )}
            <h4 className="mb-2 mt-5 flex items-center gap-2 font-display text-sm font-semibold">
              <History size={13} className="text-dim" aria-hidden="true" />
              {t.bbEvents}
            </h4>
            <ol className="flex flex-col gap-1.5">
              {detail.events.map((e) => (
                <li key={e.id} className="flex items-center gap-2.5 rounded-2xl border border-line bg-surface px-3 py-2">
                  <CircleDashed size={12} className="shrink-0 text-dim" aria-hidden="true" />
                  <span className="font-mono text-[10px] text-dim" dir="ltr">{e.kind}</span>
                  <span className="ms-auto font-mono text-[10px] text-dim" dir="ltr">{e.ts.slice(11, 19)}</span>
                </li>
              ))}
              {detail.events.length === 0 && <p className="text-xs text-dim">—</p>}
            </ol>
          </div>
        </div>
      )}
    </div>
  )
}

// ---------------------------------------------------------------- actions

/** What the brain ACTUALLY executed — server-verified, never client-invented. */
function ActionList({ actions }: { actions: BoxActionInfo[] }) {
  const { t } = useI18n()
  return (
    <div className="mt-2 flex flex-col gap-1.5">
      {actions.map((a, i) => {
        const r = (a.ok ? a.result : null) as Record<string, unknown> | null
        const isLink = a.tool === 'create_access_link' && a.ok && r && typeof r.key === 'string'
        const isSkill = a.tool === 'request_skill_install' && a.ok && r && typeof r.importId === 'string'
        const isAccent = a.tool === 'set_accent' && a.ok && r && typeof r.accent === 'string'
        return (
          <div
            key={i}
            className={cn(
              'rounded-2xl border px-3 py-2 text-[11px] leading-relaxed',
              a.ok ? 'border-signal-text/40 bg-signal/5' : 'border-fault-text/40 bg-fault/5',
            )}
            role="status"
          >
            <p className="flex items-center gap-1.5">
              <Wrench size={11} className={a.ok ? 'text-signal-text dark:text-signal' : 'text-fault-text'} aria-hidden="true" />
              <span className="font-mono" dir="ltr">{a.tool}</span>
              {a.ok ? (
                <CheckCircle2 size={11} className="text-signal-text dark:text-signal" aria-hidden="true" />
              ) : (
                <XCircle size={11} className="text-fault-text" aria-hidden="true" />
              )}
              {!isLink && !isSkill && !isAccent && <span className="truncate text-dim">{actionArgSummary(a)}</span>}
            </p>
            {!a.ok && typeof a.result === 'string' && <p className="mt-1 text-fault-text">{a.result}</p>}
            {isLink && r && (
              <div className="mt-1.5 flex flex-col gap-1" dir="ltr">
                <span className="flex items-center gap-1.5 text-dim">
                  <KeyRound size={11} aria-hidden="true" />
                  {t.bbNewLinkNote}
                </span>
                <code className="break-all rounded-xl bg-canvas px-2 py-1 font-mono text-[10px]">{String(r.link)}</code>
                <code className="break-all rounded-xl bg-canvas px-2 py-1 font-mono text-[10px]">{String(r.key)}</code>
              </div>
            )}
            {isSkill && r && (
              <div className="mt-1.5 flex flex-col gap-1">
                <span className="flex items-center gap-1.5 font-semibold">
                  <Puzzle size={11} aria-hidden="true" />
                  {String(r.skill ?? '')} · {String(r.risk ?? '')} · {String(r.compatibility ?? '')}
                </span>
                <span className="text-dim">{t.bbSkillAwaiting}</span>
              </div>
            )}
            {isAccent && r && (() => {
              const def = ACCENTS.find((x) => x.id === String(r.accent))
              return (
                <span className="mt-1.5 flex items-center gap-1.5">
                  <span
                    className="size-3.5 shrink-0 rounded-full border border-line"
                    style={{ background: def ? `linear-gradient(135deg, ${def.light.signal} 50%, ${def.dark.signal} 50%)` : undefined }}
                  />
                  {def ? (t.bbAccentNames as Record<string, string>)[def.id] ?? def.en : String(r.accent)} — {t.bbAppearanceLive}
                </span>
              )
            })()}
          </div>
        )
      })}
    </div>
  )
}

function actionArgSummary(a: BoxActionInfo): string {
  const args = a.args ?? {}
  if (typeof args.name === 'string') return `«${args.name}»`
  if (typeof args.tagline === 'string') return `«${args.tagline}»`
  if (typeof args.model === 'string') return args.model
  if (args.level !== undefined) return `L${String(args.level)}`
  if (typeof args.lang === 'string' || typeof args.language === 'string') return String(args.lang ?? args.language)
  if (typeof args.mode === 'string') return String(args.mode)
  if (typeof args.accent === 'string') return String(args.accent)
  if (typeof args.query === 'string') return `«${args.query}»`
  if (typeof args.source === 'string') return String(args.source)
  return ''
}

// ---------------------------------------------------------------- composer

function Composer({
  value,
  onChange,
  onSend,
  busy,
  onStop,
  taRef,
}: {
  value: string
  onChange: (v: string) => void
  onSend: () => void
  busy: boolean
  onStop?: () => void
  taRef?: React.RefObject<HTMLTextAreaElement | null>
}) {
  const { t } = useI18n()
  const localRef = useRef<HTMLTextAreaElement>(null)
  const ref = taRef ?? localRef

  useEffect(() => {
    const el = ref.current
    if (!el) return
    el.style.height = '0px'
    el.style.height = `${Math.min(el.scrollHeight, 200)}px`
  }, [value, ref])

  return (
    <div className="limo-soft p-2.5 shadow-lg shadow-ink/5 dark:shadow-black/40">
      <div className="flex items-end gap-2">
        <textarea
          ref={ref}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={t.bbPlaceholder}
          dir="auto"
          rows={1}
          aria-label={t.bbPlaceholder}
          className="max-h-[200px] min-h-11 flex-1 resize-none bg-transparent px-3 py-2.5 text-base leading-relaxed outline-none placeholder:text-dim"
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault()
              onSend()
            }
          }}
        />
        {busy && onStop ? (
          <button
            type="button"
            onClick={onStop}
            aria-label={t.bbStop}
            title={t.bbStop}
            className="flex size-11 shrink-0 items-center justify-center rounded-full bg-surface text-body transition-colors hover:bg-canvas border border-line"
          >
            <span className="size-3.5 rounded-[3px] bg-current" aria-hidden="true" />
          </button>
        ) : (
          <button
            type="button"
            onClick={onSend}
            disabled={value.trim().length === 0 || busy}
            aria-label={t.send}
            title={t.send}
            className={cn(
              'flex size-11 shrink-0 items-center justify-center rounded-full bg-signal text-primary-foreground transition-opacity',
              'border border-ink dark:border-0',
              (value.trim().length === 0 || busy) && 'opacity-40',
            )}
          >
            <ArrowUp size={18} />
          </button>
        )}
      </div>
    </div>
  )
}

// ---------------------------------------------------------------- cards

function Card({
  card,
  onOpenDetail,
  onDecide,
  onCommand,
}: {
  card: BbCard
  onOpenDetail: (id: number) => void
  onDecide: (id: number, decision: 'accepted' | 'dismissed') => void
  onCommand: (intent: Intent) => void
}) {
  const { t } = useI18n()

  switch (card.kind) {
    case 'status':
      return (
        <div className="limo-soft p-4">
          <p className="mb-3 flex items-center gap-2 font-display text-sm font-semibold">
            <ShieldCheck size={14} className="text-signal-text dark:text-signal" aria-hidden="true" />
            {t.bbStatusTitle}
          </p>
          <dl className="grid gap-2 text-xs sm:grid-cols-2">
            <div className="flex items-center gap-2 rounded-2xl border border-line bg-surface px-3 py-2">
              <dt className="text-dim">{t.bbEnabled}</dt>
              <dd className="ms-auto flex items-center gap-1.5 font-medium">
                {card.status.enabled ? (
                  <>
                    <CheckCircle2 size={13} className="text-signal-text dark:text-signal" aria-hidden="true" />
                    {t.bbEnabled}
                  </>
                ) : (
                  <>
                    <XCircle size={13} className="text-fault-text" aria-hidden="true" />
                    {t.bbDisabled}
                  </>
                )}
              </dd>
            </div>
            <div className="flex items-center gap-2 rounded-2xl border border-line bg-surface px-3 py-2">
              <dt className="text-dim">{t.bbRepo}</dt>
              <dd className="ms-auto truncate font-mono text-[11px]" dir="ltr">{card.status.repo ?? '—'}</dd>
            </div>
            <div className="flex items-center gap-2 rounded-2xl border border-line bg-surface px-3 py-2 sm:col-span-2">
              <dt className="text-dim">{t.bbAutonomy}</dt>
              <dd className="ms-auto font-mono text-[11px]">L{card.status.level} · {levelName(t, card.status.level)}</dd>
            </div>
          </dl>
        </div>
      )

    case 'map':
      return (
        <div className="limo-soft p-4">
          <p className="mb-3 flex items-center gap-2 font-display text-sm font-semibold">
            <MapIcon size={14} className="text-signal-text dark:text-signal" aria-hidden="true" />
            {t.bbMapTitle}
          </p>
          <div className="grid grid-cols-3 gap-2 text-center">
            <Stat value={card.map.files} label={t.bbFiles} />
            <Stat value={card.map.edges} label={t.bbEdges} />
            <Stat value={card.map.entryPoints.length} label={t.bbEntries} />
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {Object.entries(card.map.layers).map(([layer, n]) => (
              <span key={layer} className="rounded-full border border-line bg-surface px-2.5 py-0.5 font-mono text-[10px] text-dim" dir="ltr">
                {layer} · {n}
              </span>
            ))}
          </div>
        </div>
      )

    case 'changes': {
      if (card.changes.length === 0) {
        return <div className="limo-soft px-4 py-5 text-center text-xs text-dim">{t.bbNoChanges}</div>
      }
      return (
        <div className="limo-soft flex flex-col gap-2 p-3">
          {card.changes.map((c) => (
            <ChangeRow key={c.id} change={c} onOpenDetail={onOpenDetail} onCommand={onCommand} />
          ))}
        </div>
      )
    }

    case 'change':
      return (
        <div className="limo-soft p-3">
          <ChangeRow change={card.change} onOpenDetail={onOpenDetail} onCommand={onCommand} />
        </div>
      )

    case 'proposals': {
      const list = card.proposals
      if (list.length === 0) {
        return <div className="limo-soft px-4 py-5 text-center text-xs text-dim">{t.bbNoProposals}</div>
      }
      return (
        <div className="limo-soft flex flex-col gap-2 p-3">
          <p className="flex items-center gap-2 px-1 pb-1 font-display text-sm font-semibold">
            <Lightbulb size={14} className="text-signal-text dark:text-signal" aria-hidden="true" />
            {t.bbProposalsTitle}
            {card.generated !== undefined && card.generated > 0 && (
              <span className="font-mono text-[10px] font-normal text-dim" dir="ltr">+{card.generated}</span>
            )}
          </p>
          {list.map((p) => (
            <div key={p.id} className="rounded-2xl border border-line bg-surface p-3.5">
              <div className="flex items-start gap-2">
                <span className="rounded-full border border-line px-2 py-0.5 font-mono text-[10px] text-dim" dir="ltr">{p.kind}</span>
                <p className="min-w-0 flex-1 text-sm font-medium leading-snug">{p.title}</p>
              </div>
              <p className="mt-2 text-xs leading-relaxed text-dim">{p.benefit}</p>
              <div className="mt-2 flex flex-wrap items-center gap-1.5 font-mono text-[10px] text-dim" dir="ltr">
                <span className="rounded-full bg-canvas px-2 py-0.5">risk: {p.risk}</span>
                <span className="rounded-full bg-canvas px-2 py-0.5">cost: {p.cost}</span>
              </div>
              {p.status === 'proposed' && (
                <div className="mt-3 flex gap-2">
                  <button
                    type="button"
                    onClick={() => onDecide(p.id, 'accepted')}
                    className="flex h-8 items-center gap-1.5 rounded-full bg-signal px-3.5 text-xs font-semibold text-primary-foreground transition-opacity hover:opacity-90 border border-ink dark:border-0"
                  >
                    <CheckCircle2 size={13} aria-hidden="true" />
                    {t.bbAccept}
                  </button>
                  <button
                    type="button"
                    onClick={() => onDecide(p.id, 'dismissed')}
                    className="flex h-8 items-center gap-1.5 rounded-full border border-line px-3.5 text-xs text-dim transition-colors hover:text-body"
                  >
                    <XCircle size={13} aria-hidden="true" />
                    {t.bbDismiss}
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )
    }

    case 'help':
      return (
        <div className="limo-soft p-4">
          <p className="mb-2 flex items-center gap-2 font-display text-sm font-semibold">
            <Sparkles size={14} className="text-signal-text dark:text-signal" aria-hidden="true" />
            {t.bbHelpTitle}
          </p>
          <p className="mb-3 text-xs leading-relaxed text-dim">{t.bbHelpIntro}</p>
          <ul className="flex flex-col gap-1.5">
            {[t.bbHelpStatus, t.bbHelpScan, t.bbHelpHistory, t.bbHelpDecide, t.bbHelpLevel, t.bbHelpModify, t.bbHelpDossier].map((line) => (
              <li key={line} className="flex items-start gap-2 rounded-2xl border border-line bg-surface px-3 py-2 text-xs leading-relaxed">
                <Hammer size={12} className="mt-0.5 shrink-0 text-dim" aria-hidden="true" />
                {line}
              </li>
            ))}
          </ul>
        </div>
      )

    case 'error':
      return (
        <div className="rounded-2xl border border-fault-text/40 bg-fault/5 px-4 py-3 text-xs leading-relaxed text-fault-text" role="alert">
          {card.text}
        </div>
      )
  }
}

function ChangeRow({ change, onOpenDetail, onCommand }: { change: ForgeChangeInfo; onOpenDetail: (id: number) => void; onCommand: (intent: Intent) => void }) {
  const { t } = useI18n()
  const awaiting = change.status === 'awaiting_approval'
  const applied = change.status === 'applied'
  const active = ACTIVE_STATUS.has(change.status)

  return (
    <div className="rounded-2xl border border-line bg-surface p-3.5">
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-mono text-[11px] text-dim" dir="ltr">#{change.id}</span>
        <StatusPill status={change.status} />
        <span className="ms-auto flex items-center gap-1 font-mono text-[10px] text-dim" dir="ltr">
          <Clock size={10} aria-hidden="true" />
          {new Date(change.updated_at).toLocaleString('en-GB', { hour12: false })}
        </span>
      </div>
      <p className="mt-2 line-clamp-2 text-xs leading-relaxed">{change.request}</p>
      <div className="mt-2 flex flex-wrap items-center gap-1.5">
        <span className="rounded-full bg-canvas px-2 py-0.5 font-mono text-[10px] text-dim" dir="ltr">
          L{change.level} · {change.model ?? 'deterministic'}
        </span>
        {change.commit_id && (
          <span className="flex items-center gap-1 rounded-full bg-canvas px-2 py-0.5 font-mono text-[10px] text-dim" dir="ltr">
            <GitBranch size={10} aria-hidden="true" />
            {change.commit_id.slice(0, 7)}
          </span>
        )}
        <div className="ms-auto flex flex-wrap gap-1.5">
          {awaiting && (
            <>
              <DecisionButton tone="solid" label={t.bbApply} onClick={() => onCommand({ type: 'apply', id: change.id })} />
              <DecisionButton tone="ghost" label={t.bbReject} onClick={() => onCommand({ type: 'reject', id: change.id })} />
            </>
          )}
          {applied && (
            <button
              type="button"
              onClick={() => onCommand({ type: 'rollback', id: change.id })}
              className="flex h-7 items-center gap-1 rounded-full border border-line px-2.5 text-[10px] text-dim transition-colors hover:text-body"
            >
              <RotateCcw size={11} aria-hidden="true" />
              {t.bbRollback}
            </button>
          )}
          {active && (
            <button
              type="button"
              onClick={() => onCommand({ type: 'resume', id: change.id })}
              className="flex h-7 items-center gap-1 rounded-full border border-line px-2.5 text-[10px] text-dim transition-colors hover:text-body"
            >
              <Loader2 size={11} aria-hidden="true" />
              {t.bbResume}
            </button>
          )}
          <button
            type="button"
            onClick={() => onOpenDetail(change.id)}
            className="flex h-7 items-center rounded-full border border-line px-2.5 text-[10px] text-dim transition-colors hover:text-body"
          >
            {t.bbDetails}
          </button>
        </div>
      </div>
    </div>
  )
}

function DecisionButton({ tone, label, onClick }: { tone: 'solid' | 'ghost'; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex h-7 items-center rounded-full px-3 text-[10px] font-semibold transition-opacity hover:opacity-90',
        tone === 'solid'
          ? 'bg-signal text-primary-foreground border border-ink dark:border-0'
          : 'border border-line text-dim hover:text-body',
      )}
    >
      {label}
    </button>
  )
}

function StatusPill({ status }: { status: string }) {
  const { t } = useI18n()
  const key = STATUS_KEY[status] ?? 'bbStAnalyzing'
  const label = (t as unknown as Record<string, string>)[key] ?? status
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[10px] font-medium',
        STATUS_STYLE[status] ?? 'border-line text-dim',
      )}
    >
      {ACTIVE_STATUS.has(status) && <Loader2 size={10} className="animate-spin" aria-hidden="true" />}
      {status === 'awaiting_approval' && <Clock size={10} aria-hidden="true" />}
      {status === 'applied' && <CheckCircle2 size={10} aria-hidden="true" />}
      {status === 'failed' && <XCircle size={10} aria-hidden="true" />}
      {label}
    </span>
  )
}

function Stat({ value, label }: { value: number; label: string }) {
  return (
    <div className="rounded-2xl border border-line bg-surface px-2 py-3">
      <p className="font-display text-xl font-bold" dir="ltr">{value.toLocaleString('en-US')}</p>
      <p className="mt-0.5 text-[10px] text-dim">{label}</p>
    </div>
  )
}

// ---------------------------------------------------------------- helpers

function levelName(t: ReturnType<typeof useI18n>['t'], level: number): string {
  const map: Record<number, string> = {
    0: t.bbL0,
    1: t.bbL1,
    2: t.bbL2,
    3: t.bbL3,
    4: t.bbL4,
  }
  return map[level] ?? t.bbL0
}

function errMsg(err: unknown): string {
  return err instanceof ApiError ? err.message : err instanceof Error ? err.message : String(err)
}
