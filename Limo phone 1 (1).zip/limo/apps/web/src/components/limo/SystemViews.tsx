'use client'

import { useCallback, useEffect, useState } from 'react'
import { MonitorCog, Moon, Sun } from 'lucide-react'
import { api, type BoxProfileInfo, type SecretInfo } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { takePendingIntegrationsTab } from '@/lib/nav'
import { ACCENTS, type AccentId, type ThemeMode } from '@/lib/appearance'
import { cn } from '@/lib/utils'
import { CustomProvidersSection } from '@/components/omnara/CustomProvidersSection'
import { EgressView } from '@/components/omnara/EgressView'
import { RouterPanel } from '@/components/omnara/RouterPanel'
import { UsagePanel } from '@/components/omnara/UsagePanel'
import { SectionHeader } from './shared'

/**
 * Integrations — what is ACTUALLY connected: the vault (provider keys),
 * custom OpenAI-compatible endpoints, and API keys for programmatic access.
 * Settings — the system control room: usage / routing / egress / general.
 */

export function IntegrationsView({
  onVaultOpen,
  vaultUnlocked,
  onVaultChanged,
}: {
  onVaultOpen: () => void
  vaultUnlocked: boolean
  onVaultChanged: () => void
}) {
  const { t } = useI18n()
  // LIMO #15 — the connect-model deep-link lands on the custom-endpoint form:
  // the tab hint travels via the nav mailbox (set BEFORE navigation, taken
  // here on mount — a plain event would fire before this view exists).
  const [tab, setTab] = useState<'providers' | 'custom' | 'apikeys'>(() => takePendingIntegrationsTab() ?? 'providers')
  const [secrets, setSecrets] = useState<SecretInfo[]>([])

  useEffect(() => {
    if (!vaultUnlocked) return
    let cancelled = false
    api.vaultSecrets()
      .then((r) => { if (!cancelled) setSecrets(r.secrets) })
      .catch(() => { if (!cancelled) setSecrets([]) })
    return () => { cancelled = true }
  }, [vaultUnlocked])

  const tabs = [
    { id: 'providers' as const, label: t.keysTab },
    { id: 'custom' as const, label: t.customTab },
    { id: 'apikeys' as const, label: t.apiKeysTab },
  ]
  return (
    <div className="flex h-full min-h-0 flex-col">
      <SectionHeader title={t.integrationsTitle} sub={t.integrationsSub} />
      <nav className="flex gap-1 border-b border-line px-6 py-2" aria-label={t.viewsNav}>
        {tabs.map((x) => (
          <button
            key={x.id}
            type="button"
            aria-pressed={tab === x.id}
            onClick={() => setTab(x.id)}
            className={cn(
              'h-8 rounded-md px-3 text-xs transition-colors',
              tab === x.id ? 'bg-surface font-semibold text-signal-text dark:text-signal' : 'text-dim hover:text-body',
            )}
          >
            {x.label}
          </button>
        ))}
      </nav>
      <div className="min-h-0 flex-1 overflow-y-auto p-6">
        {tab === 'providers' && (
          <div className="mx-auto max-w-2xl">
            <p className="mb-3 text-xs leading-relaxed text-dim">{t.providerKeysHint}</p>
            {!vaultUnlocked ? (
              <button type="button" onClick={onVaultOpen} className="rounded-md border border-border-strong bg-surface px-4 py-3 text-sm font-semibold transition-colors hover:bg-canvas">
                {t.vault}
              </button>
            ) : secrets.length === 0 ? (
              <p className="rounded-md border border-line bg-surface px-3 py-4 text-center text-xs text-dim">{t.usageNoData}</p>
            ) : (
              <ul className="divide-y divide-line overflow-hidden rounded-md border border-line bg-surface">
                {secrets.map((s) => (
                  <li key={s.alias} className="flex items-center gap-2 px-3 py-2 text-xs">
                    <span className="min-w-0 flex-1 truncate">{s.alias}</span>
                    <span className="font-mono text-[10px] text-dim" dir="ltr">{s.provider}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
        {tab === 'custom' && (
          <div className="mx-auto max-w-2xl">
            <CustomProvidersSection
              vaultUnlocked={vaultUnlocked}
              secrets={vaultUnlocked ? secrets : []}
              onChanged={() => {
                void api
                  .vaultSecrets()
                  .then((r) => setSecrets(r.secrets))
                  .catch(() => setSecrets([]))
                onVaultChanged()
              }}
            />
          </div>
        )}
        {tab === 'apikeys' && <ApiKeysPanel />}
      </div>
    </div>
  )
}

function ApiKeysPanel() {
  const { t } = useI18n()
  const [keys, setKeys] = useState<Array<{ id: number; name: string; prefix: string }> | null>(null)
  const [name, setName] = useState('')
  const [fresh, setFresh] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    api.apiKeys()
      .then((rows) => { if (!cancelled) setKeys(rows) })
      .catch(() => { if (!cancelled) setKeys([]) })
    return () => { cancelled = true }
  }, [])

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-3">
      <div className="flex items-end gap-2">
        <label className="flex flex-1 flex-col gap-1 text-xs">
          <span className="text-dim">{t.projectName}</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            dir="auto"
            className="h-9 rounded-md border border-input bg-surface px-3 text-sm outline-none focus:border-border-strong"
          />
        </label>
        <button
          type="button"
          onClick={async () => {
            if (name.trim().length === 0) return
            const r = await api.createApiKey(name.trim())
            setFresh(r.key)
            setName('')
            setKeys(await api.apiKeys().catch(() => []))
          }}
          className="h-9 shrink-0 rounded-md bg-signal px-4 text-sm font-semibold text-primary-foreground"
        >
          {t.save}
        </button>
      </div>
      {fresh && (
        <p className="break-all rounded-md border border-border-strong bg-surface px-3 py-2 font-mono text-[11px]" dir="ltr">
          {fresh}
        </p>
      )}
      {keys !== null && keys.length > 0 && (
        <ul className="divide-y divide-line overflow-hidden rounded-md border border-line bg-surface">
          {keys.map((k) => (
            <li key={k.id} className="flex items-center gap-2 px-3 py-2 text-xs">
              <span className="min-w-0 flex-1 truncate">{k.name}</span>
              <span className="font-mono text-[10px] text-dim" dir="ltr">{k.prefix}…</span>
              <button
                type="button"
                aria-label={t.deleteChat}
                onClick={async () => {
                  await api.deleteApiKey(k.id)
                  setKeys(await api.apiKeys().catch(() => []))
                }}
                className="text-dim transition-colors hover:text-fault-text"
              >
                ✕
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

export function SettingsView({ onBreakerReset, onVaultOpen }: { onBreakerReset: () => void; onVaultOpen: () => void }) {
  const { t } = useI18n()
  const [tab, setTab] = useState<'usage' | 'models' | 'router' | 'egress' | 'general'>('usage')
  const tabs = [
    { id: 'usage' as const, label: t.usageTab },
    { id: 'models' as const, label: t.modelsTab },
    { id: 'router' as const, label: t.routerTab },
    { id: 'egress' as const, label: t.egressTab },
    { id: 'general' as const, label: t.generalTab },
  ]
  return (
    <div className="flex h-full min-h-0 flex-col">
      <SectionHeader title={t.settingsTitle} sub={t.settingsSub} />
      <nav className="flex gap-1 border-b border-line px-6 py-2" aria-label={t.viewsNav}>
        {tabs.map((x) => (
          <button
            key={x.id}
            type="button"
            aria-pressed={tab === x.id}
            onClick={() => setTab(x.id)}
            className={cn(
              'h-8 rounded-md px-3 text-xs transition-colors',
              tab === x.id ? 'bg-surface font-semibold text-signal-text dark:text-signal' : 'text-dim hover:text-body',
            )}
          >
            {x.label}
          </button>
        ))}
      </nav>
      <div className="min-h-0 flex-1 overflow-y-auto">
        {tab === 'usage' && <UsagePanel onBreakerReset={onBreakerReset} />}
        {tab === 'models' && <ModelsPanel onProfileSaved={() => window.dispatchEvent(new CustomEvent('limo:profile-changed'))} />}
        {tab === 'router' && <RouterPanel />}
        {tab === 'egress' && <EgressView onAuthLost={() => undefined} />}
        {tab === 'general' && (
          <div className="mx-auto max-w-2xl p-6">
            <button type="button" onClick={onVaultOpen} className="rounded-md border border-border-strong bg-surface px-4 py-3 text-sm font-semibold transition-colors hover:bg-canvas">
              {t.vault}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

/**
 * خانة النماذج — the models control room: the app's default model, the
 * owner's ordered preferences for automatic per-purpose routing, and the
 * CURRENT auto picks with their honest reasons. Every write is a real
 * settings row the server validates; nothing here is decorative.
 */
function ModelsPanel({ onProfileSaved }: { onProfileSaved: () => void }) {
  const { t, lang } = useI18n()
  const [profile, setProfile] = useState<BoxProfileInfo | null>(null)
  const [usable, setUsable] = useState<Array<{ id: string; free: boolean; contextLength: number | null }>>([])
  const [prefs, setPrefs] = useState<{ planner: string[]; critic: string[] }>({ planner: [], critic: [] })
  const [picks, setPicks] = useState<{ planner: { model: string; reason: string }; critic: { model: string; reason: string } } | null>(null)
  const [name, setName] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [saved, setSaved] = useState(false)

  const load = useCallback(async () => {
    try {
      const s = await api.boxState()
      setProfile(s.profile)
      setUsable(s.usableModels)
      setName(s.profile.name)
      const p = await api.modelPrefs()
      setPrefs(p.prefs)
      setPicks(p.usable)
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }, [])

  // initial load follows the codebase's guarded .then pattern (setState inside
  // callbacks, never synchronously in the effect body — react-hooks rule)
  useEffect(() => {
    let cancelled = false
    api.boxState()
      .then((s) => {
        if (cancelled) return
        setProfile(s.profile)
        setUsable(s.usableModels)
        setName(s.profile.name)
        return api.modelPrefs()
      })
      .then((p) => {
        if (!p || cancelled) return
        setPrefs(p.prefs)
        setPicks(p.usable)
      })
      .catch((e) => {
        if (!cancelled) setError(e instanceof Error ? e.message : String(e))
      })
    return () => {
      cancelled = true
    }
  }, [])

  const saveDefaultModel = async (model: string) => {
    setError(null)
    setSaved(false)
    try {
      const r = await api.boxPutProfile({ defaultModel: model || null })
      setProfile(r.profile)
      setSaved(true)
      onProfileSaved()
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }

  const saveName = async () => {
    setError(null)
    setSaved(false)
    try {
      const r = await api.boxPutProfile({ name: name.trim() })
      setProfile(r.profile)
      setSaved(true)
      onProfileSaved()
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }

  /** appearance = the SAME profile rows the Black Box chat tools write */
  const saveAppearance = async (patch: { themeMode?: ThemeMode; accent?: AccentId }) => {
    setError(null)
    setSaved(false)
    try {
      const r = await api.boxPutProfile(patch)
      setProfile(r.profile)
      setSaved(true)
      onProfileSaved()
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }

  const savePrefs = async (next: { planner?: string[]; critic?: string[] }) => {
    setError(null)
    setSaved(false)
    try {
      await api.saveModelPrefs(next)
      const p = await api.modelPrefs()
      setPrefs(p.prefs)
      setPicks(p.usable)
      setSaved(true)
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }

  const prefSelect = (purpose: 'planner' | 'critic') => (
    <select
      value={prefs[purpose][0] ?? ''}
      onChange={(e) => void savePrefs({ [purpose]: e.target.value ? [e.target.value] : [] } as { planner?: string[]; critic?: string[] })}
      className="h-9 min-w-0 flex-1 rounded-md border border-input bg-surface px-2 font-mono text-xs outline-none"
      dir="ltr"
      aria-label={purpose === 'planner' ? t.modelsPlannerPref : t.modelsCriticPref}
    >
      <option value="">{t.modelsNoPref}</option>
      {usable.map((m) => (
        <option key={m.id} value={m.id}>{m.id}</option>
      ))}
    </select>
  )

  return (
    <div className="mx-auto max-w-2xl p-6">
      <h3 className="font-display text-base font-bold">{t.modelsTab}</h3>
      <p className="mt-1 text-xs leading-relaxed text-dim">{t.modelsIntro}</p>

      {error && (
        <p role="alert" className="mt-3 rounded-md border border-fault-text/40 bg-fault/5 px-3 py-2 text-xs text-fault-text">{error}</p>
      )}
      {saved && (
        <p className="mt-3 rounded-md border border-signal-text/40 bg-signal/5 px-3 py-2 text-xs text-signal-text dark:text-signal">{t.savedOk}</p>
      )}

      {/* identity — the same rows the Black Box modifies through chat */}
      <section className="mt-4 rounded-lg border border-line bg-surface p-4">
        <h4 className="font-display text-sm font-semibold">{t.modelsIdentity}</h4>
        <div className="mt-3 flex items-end gap-2">
          <label className="flex flex-1 flex-col gap-1 text-xs">
            <span className="text-dim">{t.modelsAppName}</span>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              dir="auto"
              maxLength={40}
              className="h-9 rounded-md border border-input bg-canvas px-3 text-sm outline-none focus:border-border-strong"
            />
          </label>
          <button
            type="button"
            onClick={() => void saveName()}
            disabled={name.trim().length < 2 || name.trim() === profile?.name}
            className="h-9 shrink-0 rounded-md bg-signal px-4 text-sm font-semibold text-primary-foreground disabled:opacity-40 border border-ink dark:border-0"
          >
            {t.save}
          </button>
        </div>
        <p className="mt-2 text-[11px] leading-relaxed text-dim">{t.modelsIdentityHint}</p>
      </section>

      {/* appearance — the SAME profile rows the Black Box sets by chat */}
      <section className="mt-4 rounded-lg border border-line bg-surface p-4">
        <h4 className="font-display text-sm font-semibold">{t.appearanceTitle}</h4>
        <p className="mt-1 text-[11px] leading-relaxed text-dim">{t.appearanceIntro}</p>

        <div className="mt-3 flex flex-col gap-1 text-xs">
          <span className="text-dim">{t.appearanceTheme}</span>
          <div className="flex h-9 w-fit items-center gap-1 rounded-full border border-input bg-canvas p-1" role="group" aria-label={t.appearanceTheme}>
            {(['system', 'light', 'dark'] as const).map((m) => (
              <button
                key={m}
                type="button"
                aria-pressed={profile?.themeMode === m}
                onClick={() => void saveAppearance({ themeMode: m as ThemeMode })}
                className={cn(
                  'flex h-7 items-center gap-1.5 rounded-full px-3 text-xs transition-colors',
                  profile?.themeMode === m ? 'bg-signal font-semibold text-primary-foreground' : 'text-dim hover:text-body',
                )}
              >
                {m === 'system' ? <MonitorCog size={12} aria-hidden="true" /> : m === 'light' ? <Sun size={12} aria-hidden="true" /> : <Moon size={12} aria-hidden="true" />}
                {m === 'system' ? t.themeSystem : m === 'light' ? t.themeLight : t.themeDark}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-3 flex flex-col gap-1 text-xs">
          <span className="text-dim">{t.appearanceAccent}</span>
          <div className="flex flex-wrap items-center gap-2">
            {ACCENTS.map((a) => (
              <button
                key={a.id}
                type="button"
                aria-pressed={profile?.accent === a.id}
                title={lang === 'ar' ? a.ar : a.en}
                onClick={() => void saveAppearance({ accent: a.id as AccentId })}
                className={cn(
                  'flex items-center gap-2 rounded-full border py-1 pe-3 ps-1 text-xs transition-colors',
                  profile?.accent === a.id ? 'border-border-strong font-semibold text-body' : 'border-line text-dim hover:text-body',
                )}
              >
                <span
                  className="size-6 shrink-0 rounded-full border border-line"
                  style={
                    a.id === 'mono'
                      ? { background: 'linear-gradient(135deg, #0A0A0A 50%, #FAFAFA 50%)' }
                      : { background: `linear-gradient(135deg, ${a.light.signal} 50%, ${a.dark.signal} 50%)` }
                  }
                />
                {lang === 'ar' ? a.ar : a.en}
              </button>
            ))}
          </div>
        </div>
        <p className="mt-2 text-[11px] leading-relaxed text-dim">{t.appearanceHint}</p>
      </section>

      {/* default model */}
      <section className="mt-4 rounded-lg border border-line bg-surface p-4">
        <h4 className="font-display text-sm font-semibold">{t.modelsDefault}</h4>
        <p className="mt-1 text-[11px] leading-relaxed text-dim">{t.modelsDefaultHint}</p>
        <select
          value={profile?.defaultModel ?? ''}
          onChange={(e) => void saveDefaultModel(e.target.value)}
          className="mt-3 h-9 w-full rounded-md border border-input bg-canvas px-2 font-mono text-xs outline-none"
          dir="ltr"
          aria-label={t.modelsDefault}
        >
          <option value="">{t.modelsNoDefault}</option>
          {usable.map((m) => (
            <option key={m.id} value={m.id}>{m.id}{m.free ? ' · free' : ''}</option>
          ))}
        </select>
        {usable.length === 0 && <p className="mt-2 text-[11px] text-dim">{t.noModelsSub}</p>}
      </section>

      {/* automatic routing preferences */}
      <section className="mt-4 rounded-lg border border-line bg-surface p-4">
        <h4 className="font-display text-sm font-semibold">{t.modelsAutoTitle}</h4>
        <p className="mt-1 text-[11px] leading-relaxed text-dim">{t.modelsAutoExplain}</p>
        <div className="mt-3 flex flex-col gap-3">
          <label className="flex flex-col gap-1 text-xs">
            <span className="text-dim">{t.modelsPlannerPref}</span>
            {prefSelect('planner')}
          </label>
          <label className="flex flex-col gap-1 text-xs">
            <span className="text-dim">{t.modelsCriticPref}</span>
            {prefSelect('critic')}
          </label>
        </div>
        {picks && (
          <div className="mt-3 rounded-md border border-line bg-canvas p-3 font-mono text-[11px] leading-relaxed" dir="ltr">
            <p>planner → {picks.planner.model} <span className="text-dim">({picks.planner.reason})</span></p>
            <p>critic → {picks.critic.model} <span className="text-dim">({picks.critic.reason})</span></p>
          </div>
        )}
        {!picks && <p className="mt-2 text-[11px] text-dim">{t.modelsNoUsable}</p>}
      </section>
    </div>
  )
}
