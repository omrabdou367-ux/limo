'use client'

import { useEffect, useState } from 'react'
import { Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { api, ApiError, type ProjectInfo } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { cn } from '@/lib/utils'
import type { TaskModeId } from '@/lib/nav'

/**
 * Shared LIMO building blocks — every control talks to REAL endpoints only.
 */

export function SectionHeader({ title, sub, slogan }: { title: string; sub?: string; slogan?: string }) {
  const { dir } = useI18n()
  return (
    <header className="border-b border-line px-6 py-4">
      <h1 className="font-display text-xl font-bold tracking-wide">{title}</h1>
      {slogan ? (
        <p
          dir={dir === 'ltr' ? 'ltr' : 'rtl'}
          className={cn(
            'mt-1 text-xs font-semibold text-body',
            dir === 'ltr' ? 'font-mono tracking-[0.35em]' : 'font-display',
          )}
        >
          {slogan}
        </p>
      ) : null}
      {sub ? <p className="mt-1 max-w-2xl text-xs leading-relaxed text-dim">{sub}</p> : null}
    </header>
  )
}

export function PageLoader() {
  return (
    <div className="flex h-full items-center justify-center gap-2 text-dim">
      <Loader2 size={15} className="animate-spin" />
      <span className="font-mono text-xs">…</span>
    </div>
  )
}

/** Project selector — loads the real list once. */
export function ProjectPicker({
  value,
  onChange,
  filter,
  allowNone = true,
}: {
  value: string | null
  onChange: (id: string | null) => void
  filter?: (p: ProjectInfo) => boolean
  allowNone?: boolean
}) {
  const { t } = useI18n()
  const [projects, setProjects] = useState<ProjectInfo[] | null>(null)

  useEffect(() => {
    void api
      .projects()
      .then((r) => setProjects(filter ? r.projects.filter(filter) : r.projects))
      .catch(() => setProjects([]))
  }, [])

  if (projects === null) return <PageLoader />
  return (
    <label className="flex h-9 items-center gap-2 rounded-md border border-input bg-surface px-2 text-xs">
      <span className="shrink-0 text-dim">{t.bindProject}</span>
      <select
        value={value ?? ''}
        onChange={(e) => onChange(e.target.value || null)}
        className="min-w-0 flex-1 bg-transparent text-body outline-none"
      >
        {allowNone && <option value="">{t.noProject}</option>}
        {projects.map((p) => (
          <option key={p.id} value={p.id}>
            {p.name}
          </option>
        ))}
      </select>
    </label>
  )
}

/** The HYPERBRAIN task launcher — goal + model + mode + project, real POST. */
export function TaskLauncher({
  model,
  mode,
  defaultMode,
  onModeChange,
  requireProject = false,
  projectFilter,
  placeholder,
  submitLabel,
  accent,
  onLaunched,
  onError,
}: {
  model: string | null
  mode: TaskModeId | null
  defaultMode: TaskModeId
  onModeChange?: (m: TaskModeId) => void
  requireProject?: boolean
  projectFilter?: (p: ProjectInfo) => boolean
  placeholder: string
  submitLabel: string
  accent?: boolean
  onLaunched: (taskId: number) => void
  onError: (msg: string) => void
}) {
  const { t } = useI18n()
  const [goal, setGoal] = useState('')
  const [projectId, setProjectId] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const modes: Array<{ id: TaskModeId; label: string }> = [
    { id: 'auto', label: t.modeAuto },
    { id: 'research', label: t.modeResearch },
    { id: 'build', label: t.modeBuild },
    { id: 'creative', label: t.modeCreative },
  ]
  const activeMode = mode ?? defaultMode

  const launch = async () => {
    if (!model) {
      onError(t.homeNeedModel)
      return
    }
    if (requireProject && !projectId) {
      onError(t.workshopNeedsProject)
      return
    }
    if (goal.trim().length < 4) return
    setBusy(true)
    try {
      const res = await api.createAgentTask(goal.trim(), model, {
        mode: activeMode,
        ...(projectId ? { projectId } : {}),
      })
      setGoal('')
      onLaunched(res.task.id)
    } catch (e) {
      onError(e instanceof ApiError ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        {onModeChange ? (
          <div className="flex h-9 items-center overflow-hidden rounded-md border border-input bg-surface" role="group" aria-label={t.modeLabel}>
            {modes.map((m) => (
              <button
                key={m.id}
                type="button"
                aria-pressed={activeMode === m.id}
                onClick={() => onModeChange(m.id)}
                className={cn(
                  'h-full px-3 text-xs transition-colors',
                  activeMode === m.id ? 'bg-canvas font-semibold text-signal-text dark:text-signal' : 'text-dim hover:text-body',
                )}
              >
                {m.label}
              </button>
            ))}
          </div>
        ) : (
          <span className="flex h-9 items-center rounded-md border border-line bg-surface px-3 text-xs text-dim">
            {t.modeLabel}: {modes.find((m) => m.id === activeMode)?.label}
          </span>
        )}
        <div className="min-w-48 flex-1">
          <ProjectPicker value={projectId} onChange={setProjectId} filter={projectFilter} allowNone={!requireProject} />
        </div>
      </div>
      <textarea
        value={goal}
        onChange={(e) => setGoal(e.target.value)}
        placeholder={placeholder}
        dir="auto"
        rows={3}
        className="w-full resize-none rounded-md border border-input bg-surface px-3 py-2 text-sm outline-none transition-colors placeholder:text-dim focus:border-border-strong"
      />
      <div className="flex items-center justify-end gap-2">
        <Button
          type="button"
          onClick={() => void launch()}
          disabled={busy || goal.trim().length < 4}
          className={cn('h-9 rounded-md px-4 text-sm font-semibold', accent && 'bg-signal text-primary-foreground hover:bg-signal/90')}
        >
          {busy ? <Loader2 size={14} className="animate-spin" /> : null}
          {submitLabel}
        </Button>
      </div>
    </div>
  )
}
