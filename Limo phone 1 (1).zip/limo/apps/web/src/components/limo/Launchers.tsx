'use client'

import { useState } from 'react'
import { api } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import type { TaskModeId } from '@/lib/nav'
import { SectionHeader, TaskLauncher } from './shared'

/**
 * The three launch surfaces share one real engine:
 *  - Creative Studio → mode "creative" (concepts/copy/specs as real files)
 *  - Workshop → mode "build" (engineer writes files in the sandbox)
 *  - App Builder → mode "build" bound to a web_app workspace
 * Each states exactly what it does — no invented capabilities.
 */
export function StudioView({ model, onOpenTask }: { model: string | null; onOpenTask: (id: number) => void }) {
  const { t } = useI18n()
  const [error, setError] = useState<string | null>(null)
  return (
    <div className="flex h-full min-h-0 flex-col">
      <SectionHeader title={t.studioTitle} sub={t.studioSub} />
      <div className="min-h-0 flex-1 overflow-y-auto p-6">
        <div className="mx-auto flex max-w-2xl flex-col gap-4">
          <p className="rounded-md border border-line bg-surface px-3 py-2 text-[11px] leading-relaxed text-dim">{t.studioHonesty}</p>
          <TaskLauncher
            model={model}
            mode={null}
            defaultMode="creative"
            requireProject
            projectFilter={(p) => p.kind === 'creative' || p.kind === 'general'}
            placeholder={t.creativeBrief}
            submitLabel={t.launchCreative}
            accent
            onLaunched={onOpenTask}
            onError={setError}
          />
          {error && <p role="alert" className="text-xs text-fault-text">{error}</p>}
        </div>
      </div>
    </div>
  )
}

export function WorkshopView({ model, onOpenTask }: { model: string | null; onOpenTask: (id: number) => void }) {
  const { t } = useI18n()
  const [error, setError] = useState<string | null>(null)
  return (
    <div className="flex h-full min-h-0 flex-col">
      <SectionHeader title={t.workshopTitle} sub={t.workshopSub} />
      <div className="min-h-0 flex-1 overflow-y-auto p-6">
        <div className="mx-auto flex max-w-2xl flex-col gap-4">
          <TaskLauncher
            model={model}
            mode={null}
            defaultMode="build"
            requireProject
            placeholder={t.buildBrief}
            submitLabel={t.launchBuild}
            accent
            onLaunched={onOpenTask}
            onError={setError}
          />
          {error && <p role="alert" className="text-xs text-fault-text">{error}</p>}
        </div>
      </div>
    </div>
  )
}

export function BuilderView({ model, onOpenTask }: { model: string | null; onOpenTask: (id: number) => void }) {
  const { t } = useI18n()
  const [error, setError] = useState<string | null>(null)
  return (
    <div className="flex h-full min-h-0 flex-col">
      <SectionHeader title={t.builderTitle} sub={t.builderSub} />
      <div className="min-h-0 flex-1 overflow-y-auto p-6">
        <div className="mx-auto flex max-w-2xl flex-col gap-4">
          <p className="rounded-md border border-line bg-surface px-3 py-2 text-[11px] leading-relaxed text-dim">{t.builderNeedsProject}</p>
          <TaskLauncher
            model={model}
            mode={null}
            defaultMode="build"
            requireProject
            projectFilter={(p) => p.kind === 'web_app'}
            placeholder={t.appBrief}
            submitLabel={t.launchBuild}
            accent
            onLaunched={onOpenTask}
            onError={setError}
          />
          {error && <p role="alert" className="text-xs text-fault-text">{error}</p>}
        </div>
      </div>
    </div>
  )
}

export function ResearchLauncher({ model, onOpenTask }: { model: string | null; onOpenTask: (id: number) => void }) {
  const { t } = useI18n()
  const [error, setError] = useState<string | null>(null)
  const [mode, setMode] = useState<TaskModeId>('auto')
  return (
    <TaskLauncher
      model={model}
      mode={mode}
      defaultMode="auto"
      onModeChange={setMode}
      placeholder={t.homePromptPlaceholder}
      submitLabel={t.homeDispatchAgent}
      onLaunched={onOpenTask}
      onError={setError}
    />
  )
}

void api
