'use client'

import { useEffect, useState } from 'react'
import { ArrowUp, Bot, Hammer, MessageSquareText, Palette } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ModelPicker } from '@/components/omnara/ModelPicker'
import { api, type AgentTaskInfo, type HealthResponse } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { Mark } from '@/components/omnara/Mark'
import { cn } from '@/lib/utils'

/**
 * Home — the central prompt experience (LIMO PHASE 1). One composer, four
 * honest dispatches: chat (straight to the gateway) or an agent task in a
 * strategy mode. Recent tasks are the real rows from the engine.
 */
export function HomeView({
  health,
  model,
  onModelChange,
  onNeedVault,
  onOpenChat,
  onOpenTask,
  onDispatchAgent,
}: {
  health: HealthResponse | null
  model: string | null
  onModelChange: (id: string) => void
  onNeedVault: () => void
  onOpenChat: (text: string) => void
  onOpenTask: (id: number) => void
  onDispatchAgent: (text: string) => void
}) {
  const { t } = useI18n()
  const [text, setText] = useState('')
  const [tasks, setTasks] = useState<AgentTaskInfo[] | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    void api
      .agentTasks()
      .then((r) => setTasks(r.tasks.slice(0, 6)))
      .catch(() => setTasks([]))
  }, [])

  const dispatch = (kind: 'chat' | 'agent') => {
    const value = text.trim()
    if (!model) {
      setError(t.homeNeedModel)
      onNeedVault()
      return
    }
    if (value.length === 0) return
    setError(null)
    setText('')
    if (kind === 'chat') onOpenChat(value)
    else onDispatchAgent(value)
  }

  const statusChip = (s: string) =>
    s === 'completed' ? t.runCompleted : s === 'failed' ? t.runFailed : s === 'running' || s === 'planning' || s === 'queued' ? t.runRunning : s === 'cancelled' ? t.cancel : s === 'awaiting_approval' ? t.agentApprovals : s

  return (
    <div className="flex h-full flex-col overflow-y-auto">
      <div className="mx-auto flex w-full max-w-3xl flex-1 flex-col items-center justify-center gap-8 px-6 py-16">
        <div className="limo-rise flex flex-col items-center gap-3 text-center">
          <Mark className="h-12 w-12 text-dim" />
          <h1 className="limo-rise-1 font-display text-hero font-bold tracking-[0.12em]" dir="ltr">
            LIMO AGENT
          </h1>
          <p className="limo-rise-2 font-mono text-[11px] tracking-[0.35em] text-dim" dir="ltr">
            THINK. CREATE. EXECUTE.
          </p>
          <p className="limo-rise-3 text-sm text-dim">{t.positioning}</p>
        </div>

        <div className="limo-rise-4 w-full">
          <div className="mb-3 flex items-center justify-between gap-2">
            <ModelPicker value={model} onChange={onModelChange} onNeedVault={onNeedVault} />
          </div>
          <div className="rounded-lg border border-border-strong bg-surface p-2 shadow-none transition-shadow focus-within:shadow-sm">
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={t.homePromptPlaceholder}
              dir="auto"
              rows={3}
              className="w-full resize-none bg-transparent px-2 py-1 text-sm outline-none placeholder:text-dim"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) dispatch('chat')
              }}
            />
            <div className="flex items-center justify-between gap-2 px-1 pb-1">
              <div className="flex items-center gap-1.5">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => dispatch('chat')}
                  disabled={text.trim().length === 0}
                  className="h-8 gap-1.5 rounded-md text-xs"
                >
                  <MessageSquareText size={13} />
                  {t.homeDispatchChat}
                </Button>
                <Button
                  type="button"
                  size="sm"
                  onClick={() => dispatch('agent')}
                  disabled={text.trim().length === 0}
                  className="h-8 gap-1.5 rounded-md bg-signal text-xs font-semibold text-primary-foreground hover:bg-signal/90"
                >
                  <Bot size={13} />
                  {t.homeDispatchAgent}
                </Button>
              </div>
              <span className="font-mono text-[10px] text-dim" dir="ltr">⌘⏎</span>
            </div>
          </div>
          {error && (
            <p role="alert" className="mt-2 text-center text-xs text-fault-text">
              {error}
            </p>
          )}
          <div className="mt-3 flex items-center justify-center gap-2 text-dim">
            <span className="flex items-center gap-1 text-[11px]"><Palette size={12} /> {t.homeDispatchCreative}</span>
            <span className="text-line">·</span>
            <span className="flex items-center gap-1 text-[11px]"><Hammer size={12} /> {t.homeDispatchBuild}</span>
            <span className="text-line">·</span>
            <span className="font-mono text-[11px]" dir="ltr">{health ? `v${health.version}` : ''}</span>
          </div>
        </div>

        <section className="w-full" aria-label={t.homeRecentTasks}>
          <h2 className="mb-2 font-display text-sm font-semibold tracking-wide">{t.homeRecentTasks}</h2>
          {tasks === null ? (
            <p className="text-xs text-dim">…</p>
          ) : tasks.length === 0 ? (
            <p className="rounded-md border border-line bg-surface px-3 py-4 text-center text-xs text-dim">{t.homeNoTasks}</p>
          ) : (
            <ul className="divide-y divide-line overflow-hidden rounded-md border border-line bg-surface">
              {tasks.map((task) => (
                <li key={task.id}>
                  <button
                    type="button"
                    onClick={() => onOpenTask(task.id)}
                    className="flex w-full items-center gap-3 px-3 py-2.5 text-start transition-colors hover:bg-canvas"
                  >
                    <span className={cn('size-1.5 shrink-0 rounded-full', task.status === 'completed' ? 'bg-signal' : task.status === 'failed' ? 'bg-fault' : 'animate-pulse bg-signal')} />
                    <span className="min-w-0 flex-1 truncate text-xs">{task.goal}</span>
                    <span className="shrink-0 font-mono text-[10px] text-dim" dir="ltr">#{task.id} · {task.mode}</span>
                    <span className="shrink-0 text-[10px] text-dim">{statusChip(task.status)}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  )
}
