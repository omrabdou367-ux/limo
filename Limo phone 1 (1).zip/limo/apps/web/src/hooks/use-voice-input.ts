'use client'

import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react'

/**
 * useVoiceInput — REAL voice dictation via the browser Web Speech API
 * (SpeechRecognition / webkitSpeechRecognition). No server ASR is involved;
 * if the browser does not expose the API the hook reports `supported: false`
 * and callers MUST hide the mic button (never show a dead control).
 */

type SpeechRecognitionLike = {
  lang: string
  continuous: boolean
  interimResults: boolean
  start: () => void
  stop: () => void
  abort: () => void
  onresult: ((e: SpeechRecognitionResultLikeEvent) => void) | null
  onerror: ((e: { error?: string }) => void) | null
  onend: (() => void) | null
}

type SpeechRecognitionResultLikeEvent = {
  resultIndex: number
  results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }>
}

type RecognitionCtor = new () => SpeechRecognitionLike

function getRecognitionCtor(): RecognitionCtor | null {
  if (typeof window === 'undefined') return null
  const w = window as unknown as {
    SpeechRecognition?: RecognitionCtor
    webkitSpeechRecognition?: RecognitionCtor
  }
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null
}

const noopSubscribe = () => () => undefined

export function useVoiceInput({ lang }: { lang: 'ar' | 'en' }) {
  // hydration-safe feature detection: server snapshot is always false,
  // the client snapshot resolves once on first client render
  const supported = useSyncExternalStore(
    noopSubscribe,
    () => getRecognitionCtor() !== null,
    () => false,
  )
  const [listening, setListening] = useState(false)
  const recRef = useRef<SpeechRecognitionLike | null>(null)
  const onFinalRef = useRef<((text: string) => void) | null>(null)
  const onPartialRef = useRef<((text: string) => void) | null>(null)

  const stop = useCallback(() => {
    recRef.current?.stop()
    recRef.current = null
    setListening(false)
  }, [])

  /**
   * Start dictation. `onFinal` receives each finalized utterance, `onPartial`
   * the live interim transcript — both are appended by the caller.
   */
  const start = useCallback(
    (handlers: { onFinal?: (text: string) => void; onPartial?: (text: string) => void }) => {
      const Ctor = getRecognitionCtor()
      if (!Ctor) return
      recRef.current?.abort()
      const rec = new Ctor()
      rec.lang = lang === 'ar' ? 'ar-SA' : 'en-US'
      rec.continuous = true
      rec.interimResults = true
      onFinalRef.current = handlers.onFinal ?? null
      onPartialRef.current = handlers.onPartial ?? null
      rec.onresult = (e) => {
        let interim = ''
        for (let i = e.resultIndex; i < e.results.length; i += 1) {
          const result = e.results[i]
          const transcript = result[0]?.transcript ?? ''
          if (result.isFinal) onFinalRef.current?.(transcript)
          else interim += transcript
        }
        if (interim) onPartialRef.current?.(interim)
      }
      rec.onerror = () => {
        setListening(false)
        recRef.current = null
      }
      rec.onend = () => {
        setListening(false)
        recRef.current = null
      }
      recRef.current = rec
      try {
        rec.start()
        setListening(true)
      } catch {
        setListening(false)
        recRef.current = null
      }
    },
    [lang],
  )

  useEffect(() => () => recRef.current?.abort(), [])

  return { supported, listening, start, stop }
}
