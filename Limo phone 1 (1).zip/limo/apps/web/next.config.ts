import type { NextConfig } from "next";
import path from "node:path";

/**
 * Omnara web — dual-mode Next config (PLAN.md §4.3):
 *
 *  1. DEV (default): rewrites proxy /api/* and /v1/* to the Fastify server
 *     (OMNARA_SERVER_URL, default http://127.0.0.1:8787). Same-origin from
 *     the browser's point of view — works behind the sandbox preview gateway
 *     and on your machine.
 *  2. BUILD_TARGET=export: `output: "export"` produces a fully static `out/`
 *     — the SAME artifact Fastify serves (@fastify/static) and Tauri embeds
 *     (tauri://localhost, full IPC). No route handlers, no dynamic routes.
 */
const isExport = process.env.BUILD_TARGET === "export";
const server = process.env.OMNARA_SERVER_URL ?? "http://127.0.0.1:8787";

const nextConfig: NextConfig = {
  // monorepo (bun workspaces + apps/* + packages/*): pin the Turbopack root to
  // the REPO root so files under packages/tokens compile correctly from apps/web
  turbopack: {
    root: path.resolve(process.cwd(), "../.."),
  },
  ...(isExport
    ? {
        output: "export" as const,
        trailingSlash: true,
        images: { unoptimized: true },
      }
    : {
        async rewrites() {
          return [
            { source: "/api/:path*", destination: `${server}/api/:path*` },
            { source: "/v1/:path*", destination: `${server}/v1/:path*` },
          ];
        },
      }),
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
